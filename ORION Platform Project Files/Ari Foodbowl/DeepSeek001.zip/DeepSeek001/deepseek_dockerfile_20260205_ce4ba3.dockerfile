# Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY dashboard.py .
RUN pip install streamlit
EXPOSE 8501
CMD ["streamlit", "run", "dashboard.py", "--server.port=8501", "--server.address=0.0.0.0"]