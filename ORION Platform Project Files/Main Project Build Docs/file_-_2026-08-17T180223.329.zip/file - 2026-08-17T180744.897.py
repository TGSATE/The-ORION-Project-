# PENROSE PROPRE : hash sommets + adjacence + fenêtre + inflation φ²
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Set, Tuple

PHI = (1 + math.sqrt(5)) / 2
PHI2 = PHI * PHI  # = PHI + 1

Vec2 = Tuple[float, float]
Key = Tuple[int, int]


def vadd(a: Vec2, b: Vec2) -> Vec2:
    return (a[0] + b[0], a[1] + b[1])


def vsub(a: Vec2, b: Vec2) -> Vec2:
    return (a[0] - b[0], a[1] - b[1])


def smul(s: float, a: Vec2) -> Vec2:
    return (s * a[0], s * a[1])


def dot(a: Vec2, b: Vec2) -> float:
    return a[0] * b[0] + a[1] * b[1]


def norm(a: Vec2) -> float:
    return math.hypot(a[0], a[1])


def qkey(p: Vec2, scale: float = 1e5) -> Key:
    """Hash de sommet (quantification)."""
    return (int(round(p[0] * scale)), int(round(p[1] * scale)))


def centroid(vs: Sequence[Vec2]) -> Vec2:
    n = max(1, len(vs))
    return (sum(p[0] for p in vs) / n, sum(p[1] for p in vs) / n)


@dataclass
class Rhomb:
    vertices: List[Vec2]
    kind: str  # "thin" | "fat"
    indices: Optional[List[List[int]]] = None

    def edges(self) -> List[Tuple[Vec2, Vec2]]:
        v = self.vertices
        return [(v[i], v[(i + 1) % 4]) for i in range(4)]


class PenroseClean:
    """
    Pentagrid + fenêtre pentagonale (filtre) + fusion de sommets + graphe.
    Inflation : subdivision fat/thin standard (échelle φ² sur les sommets).
    """

    def __init__(self, n_lines: int = 6, window_r: float = 3.2, gamma: Sequence[float] | None = None):
        self.n_lines = n_lines
        self.window_r = window_r
        if gamma is None:
            g = [0.11, 0.27, -0.19, 0.31, -0.50]
            s = sum(g)
            gamma = [x - s / 5.0 for x in g]
        self.gamma = list(gamma)
        self.dirs = [
            (math.cos(2 * math.pi * k / 5), math.sin(2 * math.pi * k / 5))
            for k in range(5)
        ]
        self.tiles: List[Rhomb] = []
        self.vertices: Dict[Key, Vec2] = {}
        self.adj: Dict[Key, Set[Key]] = defaultdict(set)

    def _index(self, x: float, y: float, k: int) -> int:
        ekx, eky = self.dirs[k]
        return math.ceil(x * ekx + y * eky + self.gamma[k])

    def _vertex_from_indices(self, indices: Sequence[int]) -> Vec2:
        zx = zy = 0.0
        for k, n in enumerate(indices):
            zx += n * self.dirs[k][0]
            zy += n * self.dirs[k][1]
        return (zx, zy)

    def _in_window(self, p: Vec2) -> bool:
        """Fenêtre : disque (proxy) ∩ pentagone régulier (coupe pentagrille)."""
        if norm(p) > self.window_r:
            return False
        # pentagone : 5 demi-plans
        for k in range(5):
            # normale = dirs[k], décalage ~ rayon interne
            if dot(p, self.dirs[k]) > self.window_r * math.cos(math.pi / 5):
                return False
        return True

    def build(self) -> dict:
        raw: List[Rhomb] = []
        rng = range(-self.n_lines, self.n_lines + 1)
        for k in range(5):
            for m in range(k + 1, 5):
                ek, em = self.dirs[k], self.dirs[m]
                det = ek[0] * em[1] - ek[1] * em[0]
                if abs(det) < 1e-12:
                    continue
                dkm = min((m - k) % 5, (k - m) % 5)
                kind = "thin" if dkm == 2 else "fat"
                for nk in rng:
                    for nm in rng:
                        bk, bm = nk - self.gamma[k], nm - self.gamma[m]
                        x = (bk * em[1] - bm * ek[1]) / det
                        y = (ek[0] * bm - em[0] * bk) / det
                        n = [self._index(x, y, i) for i in range(5)]
                        n[k], n[m] = nk, nm
                        corners = [list(n) for _ in range(4)]
                        corners[1][k] = nk - 1
                        corners[2][m] = nm - 1
                        corners[3][k] = nk - 1
                        corners[3][m] = nm - 1
                        verts = [self._vertex_from_indices(c) for c in corners]
                        raw.append(Rhomb(vertices=verts, kind=kind, indices=corners))

        # filtre fenêtre sur le centroïde + 4 sommets majoritairement dedans
        filtered: List[Rhomb] = []
        seen_tile: Set[Tuple[Key, ...]] = set()
        for t in raw:
            c = centroid(t.vertices)
            inside = sum(1 for v in t.vertices if self._in_window(v))
            if not self._in_window(c) or inside < 3:
                continue
            keys = tuple(sorted(qkey(v) for v in t.vertices))
            if keys in seen_tile:
                continue
            seen_tile.add(keys)
            filtered.append(t)

        self.tiles = filtered
        self.vertices.clear()
        self.adj.clear()
        for t in self.tiles:
            ks = []
            for v in t.vertices:
                key = qkey(v)
                if key not in self.vertices:
                    self.vertices[key] = v
                ks.append(key)
            for i in range(4):
                a, b = ks[i], ks[(i + 1) % 4]
                if a != b:
                    self.adj[a].add(b)
                    self.adj[b].add(a)

        fat = sum(1 for t in self.tiles if t.kind == "fat")
        thin = sum(1 for t in self.tiles if t.kind == "thin")
        return {
            "raw_intersections": len(raw),
            "tiles": len(self.tiles),
            "fat": fat,
            "thin": thin,
            "vertices": len(self.vertices),
            "edges": sum(len(n) for n in self.adj.values()) // 2,
            "ratio_fat_thin": (fat / thin) if thin else float("inf"),
            "phi": PHI,
        }

    def inflate(self) -> "PenroseClean":
        """
        Inflation φ² : chaque tuile → tuiles plus petites (règles P2).
        fat  → 2 fat + 1 thin  (schéma losange)
        thin → 1 fat + 1 thin
        Sommets mis à l’échelle 1/φ² dans le repère local, puis recomposition.
        Ici : subdivision géométrique par points d’or sur les arêtes.
        """
        child = PenroseClean(n_lines=self.n_lines, window_r=self.window_r * PHI2, gamma=self.gamma)
        new_tiles: List[Rhomb] = []

        def gold_point(a: Vec2, b: Vec2, t: float) -> Vec2:
            return (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))

        inv = 1.0 / PHI  # division d'or sur l'arête

        for t in self.tiles:
            v = t.vertices
            # points d'or sur chaque arête (orientation cohérente)
            g = [gold_point(v[i], v[(i + 1) % 4], inv) for i in range(4)]
            c = centroid(v)
            if t.kind == "fat":
                # 2 fat + 1 thin (approx. P2 : 3 losanges autour du centre)
                new_tiles.append(Rhomb([v[0], g[0], c, g[3]], "fat"))
                new_tiles.append(Rhomb([v[2], g[2], c, g[1]], "fat"))
                new_tiles.append(Rhomb([g[0], v[1], g[1], c], "thin"))
            else:
                new_tiles.append(Rhomb([v[0], g[0], c, g[3]], "thin"))
                new_tiles.append(Rhomb([g[0], v[1], v[2], c], "fat"))

        # scale-up global φ² pour que l’arête courte redevienne longueur 1
        scaled: List[Rhomb] = []
        for t in new_tiles:
            scaled.append(Rhomb([smul(PHI2, p) for p in t.vertices], t.kind))
        child.tiles = scaled

        # reconstruire hash + graphe (pas de re-filtre fenêtre : déjà enfants)
        child.vertices.clear()
        child.adj.clear()
        seen: Set[Tuple[Key, ...]] = set()
        kept: List[Rhomb] = []
        for t in child.tiles:
            keys = tuple(sorted(qkey(v) for v in t.vertices))
            if keys in seen:
                continue
            seen.add(keys)
            kept.append(t)
            ks = []
            for v in t.vertices:
                key = qkey(v)
                if key not in child.vertices:
                    child.vertices[key] = v
                ks.append(key)
            for i in range(4):
                a, b = ks[i], ks[(i + 1) % 4]
                if a != b:
                    child.adj[a].add(b)
                    child.adj[b].add(a)
        child.tiles = kept
        return child

    def stats(self) -> dict:
        fat = sum(1 for t in self.tiles if t.kind == "fat")
        thin = sum(1 for t in self.tiles if t.kind == "thin")
        deg = [len(n) for n in self.adj.values()]
        return {
            "tiles": len(self.tiles),
            "fat": fat,
            "thin": thin,
            "vertices": len(self.vertices),
            "edges": sum(len(n) for n in self.adj.values()) // 2,
            "deg_min": min(deg) if deg else 0,
            "deg_max": max(deg) if deg else 0,
            "ratio_fat_thin": (fat / thin) if thin else None,
            "phi": PHI,
        }


if __name__ == "__main__":
    p = PenroseClean(n_lines=5, window_r=2.8)
    info0 = p.build()
    print("=== génération 0 (fenêtre) ===")
    for k, v in info0.items():
        print(f"  {k}: {v}")

    p1 = p.inflate()
    print("=== génération 1 (inflation φ²) ===")
    for k, v in p1.stats().items():
        print(f"  {k}: {v}")

    p2 = p1.inflate()
    print("=== génération 2 ===")
    for k, v in p2.stats().items():
        print(f"  {k}: {v}")

    # petit extrait graphe
    some = list(p.adj.items())[:3]
    print("extrait adjacence (3 sommets):", [(k, len(n)) for k, n in some])
