# H4 EXACT — Q(√5) · CLOSE NODE
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, List, Sequence, Tuple

H4_ORDER = 14400


@dataclass(frozen=True)
class Q5:
    """a + b√5, a,b rationnels exacts."""
    a: Fraction
    b: Fraction

    def __add__(self, o: "Q5") -> "Q5":
        return Q5(self.a + o.a, self.b + o.b)

    def __sub__(self, o: "Q5") -> "Q5":
        return Q5(self.a - o.a, self.b - o.b)

    def __neg__(self) -> "Q5":
        return Q5(-self.a, -self.b)

    def __mul__(self, o: "Q5") -> "Q5":
        # (a+b√5)(c+d√5) = (ac+5bd) + (ad+bc)√5
        return Q5(self.a * o.a + 5 * self.b * o.b, self.a * o.b + self.b * o.a)

    def inv(self) -> "Q5":
        # (a+b√5)(a-b√5) = a² - 5b²
        nrm = self.a * self.a - 5 * self.b * self.b
        if nrm == 0:
            raise ZeroDivisionError("Q5 zero")
        return Q5(self.a / nrm, -self.b / nrm)

    def __truediv__(self, o: "Q5") -> "Q5":
        return self * o.inv()

    def key(self) -> Tuple[int, int, int, int]:
        return (
            self.a.numerator, self.a.denominator,
            self.b.numerator, self.b.denominator,
        )

    def __repr__(self) -> str:
        return f"({self.a}+{self.b}√5)"


Z = Q5(Fraction(0), Fraction(0))
ONE = Q5(Fraction(1), Fraction(0))
HALF = Q5(Fraction(1, 2), Fraction(0))
# φ = (1+√5)/2 ;  φ-1 = (√5-1)/2 = 1/φ
PHI = Q5(Fraction(1, 2), Fraction(1, 2))
IPHI = Q5(Fraction(-1, 2), Fraction(1, 2))  # (√5-1)/2


def q(n, d=1, b=0, bd=1) -> Q5:
    return Q5(Fraction(n, d), Fraction(b, bd))


Vec4 = Tuple[Q5, Q5, Q5, Q5]


def vadd(u: Vec4, v: Vec4) -> Vec4:
    return (u[0] + v[0], u[1] + v[1], u[2] + v[2], u[3] + v[3])


def vsub(u: Vec4, v: Vec4) -> Vec4:
    return (u[0] - v[0], u[1] - v[1], u[2] - v[2], u[3] - v[3])


def smul(s: Q5, u: Vec4) -> Vec4:
    return (s * u[0], s * u[1], s * u[2], s * u[3])


def dot(u: Vec4, v: Vec4) -> Q5:
    return u[0] * v[0] + u[1] * v[1] + u[2] * v[2] + u[3] * v[3]


def reflect(v: Vec4, n: Vec4) -> Vec4:
    """v - 2 (v·n / n·n) n   dans Q(√5)."""
    nn = dot(n, n)
    two = q(2)
    coef = (two * dot(v, n)) / nn
    return vsub(v, smul(coef, n))


def vkey(v: Vec4) -> Tuple:
    return tuple(c.key() for c in v)


# Racines simples H4 (Cartan : 2, -φ, -1, -1 sur la chaîne •—5—•—•—•)
# α1 = e1 - e2
# α2 = e2 - e3
# α3 = e3 - e4
# α4 choisie pour <α3,α4^∨> = -1 et <α4,α3^∨> = -1, angle 180°/5 avec α1 via la chaîne
# Forme standard (Bourbaki / Humphreys, coord. icosiennes) :
SIMPLE: List[Vec4] = [
    (ONE, -ONE, Z, Z),
    (Z, ONE, -ONE, Z),
    (Z, Z, ONE, -ONE),
    # (-1+√5)/4 , 1/2 , 1/2 , (-1+√5)/4   ≡  ((φ-1)/2, 1/2, 1/2, (φ-1)/2) wait:
    # standard: ½(-φ, 1, 1, φ-1) renormalisé dans le réseau
    (q(0, 1, -1, 4), HALF, HALF, q(0, 1, 1, 4)),  # (-√5/4, 1/2, 1/2, √5/4)
]


class H4Exact:
    def orbit(self, seed: Vec4, max_pts: int = 20000) -> dict:
        seen: Dict[Tuple, Vec4] = {vkey(seed): seed}
        stack: List[Vec4] = [seed]
        closed = True
        while stack:
            if len(seen) >= max_pts:
                closed = False
                break
            v = stack.pop()
            for n in SIMPLE:
                w = reflect(v, n)
                k = vkey(w)
                if k not in seen:
                    seen[k] = w
                    stack.append(w)
        n = len(seen)
        return {
            "count": n,
            "closed": closed and n < max_pts,
            "eq_120": n == 120,
            "eq_14400": n == H4_ORDER,
            "n_over_120": n / 120.0,
            "n_over_14400": n / float(H4_ORDER),
        }


def unit_e1() -> Vec4:
    return (ONE, Z, Z, Z)


def sample_root() -> Vec4:
    # (1,1,1,1)/2
    return (HALF, HALF, HALF, HALF)


if __name__ == "__main__":
    W = H4Exact()
    for name, s in (("e1", unit_e1()), ("half1111", sample_root()), ("alpha1", SIMPLE[0])):
        info = W.orbit(s)
        print(name, info)
    print("SIMPLE dots (Cartan-ish):")
    for i, ai in enumerate(SIMPLE):
        row = []
        for j, aj in enumerate(SIMPLE):
            # 2 <ai,aj> / <aj,aj>
            cij = (q(2) * dot(ai, aj)) / dot(aj, aj)
            row.append(str(cij))
        print(i, row)
