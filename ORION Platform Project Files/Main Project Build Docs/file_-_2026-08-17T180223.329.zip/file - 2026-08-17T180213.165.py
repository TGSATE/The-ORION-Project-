# H4 / PENROSE GEOMETRIC ENGINE
# Icosians + reflections + cut-and-project ( pentagrid )

from __future__ import annotations
import math
import cmath
from dataclasses import dataclass
from typing import Iterable, List, Sequence, Tuple

PHI = (1 + math.sqrt(5)) / 2
PSI = (1 - math.sqrt(5)) / 2  # 1 - PHI
H4_ORDER = 14400

Vec4 = Tuple[float, float, float, float]
Vec2 = Tuple[float, float]


def vadd(a: Sequence[float], b: Sequence[float]) -> Tuple[float, ...]:
    return tuple(x + y for x, y in zip(a, b))


def vsub(a: Sequence[float], b: Sequence[float]) -> Tuple[float, ...]:
    return tuple(x - y for x, y in zip(a, b))


def smul(s: float, a: Sequence[float]) -> Tuple[float, ...]:
    return tuple(s * x for x in a)


def dot(a: Sequence[float], b: Sequence[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def norm(a: Sequence[float]) -> float:
    return math.sqrt(dot(a, a))


def normalize(a: Sequence[float], eps: float = 1e-12) -> Tuple[float, ...]:
    n = norm(a)
    return a if n < eps else smul(1.0 / n, a)


def reflect(v: Sequence[float], n: Sequence[float]) -> Tuple[float, ...]:
    """Réflexion de Householder : v |-> v - 2 (v·n / n·n) n"""
    nn = dot(n, n)
    if nn < 1e-18:
        return tuple(v)
    return vsub(v, smul(2.0 * dot(v, n) / nn, n))


# ---------- Icosiens (sous-corps des quaternions, racines de H4) ----------
# Un icosien = (a + bφ + (c + dφ)i + (e + fφ)j + (g + hφ)k) / 2
# avec a..h entiers de même parité. Ici : icosiens unitaires « even » classiques.

def even_icosians_unit() -> List[Vec4]:
    """Ensemble fini générateur : 120 sommets du 600-cell (H4 root system Φ)."""
    pts: List[Vec4] = []
    # 16 points (±1,±1,±1,±1)/2
    for s in range(16):
        pts.append(tuple((1 if (s >> k) & 1 else -1) / 2.0 for k in range(4)))  # type: ignore
    # 8 points (±1,0,0,0) et permutations
    for i in range(4):
        for sgn in (1.0, -1.0):
            v = [0.0, 0.0, 0.0, 0.0]
            v[i] = sgn
            pts.append(tuple(v))  # type: ignore
    # 96 points even permutations of (±φ, ±1, ±1/φ, 0)/2  — ici even perms de (φ,1,1/φ,0)
    golden = [
        (PHI, 1.0, 1.0 / PHI, 0.0),
        (PHI, 1.0, -1.0 / PHI, 0.0),
        (PHI, -1.0, 1.0 / PHI, 0.0),
        (PHI, -1.0, -1.0 / PHI, 0.0),
        (-PHI, 1.0, 1.0 / PHI, 0.0),
        (-PHI, 1.0, -1.0 / PHI, 0.0),
        (-PHI, -1.0, 1.0 / PHI, 0.0),
        (-PHI, -1.0, -1.0 / PHI, 0.0),
    ]
    def even_perms(x, y, z, w):
        # 12 even permutations
        return [
            (x, y, z, w), (x, z, w, y), (x, w, y, z),
            (y, x, w, z), (y, z, x, w), (y, w, z, x),
            (z, x, y, w), (z, y, w, x), (z, w, x, y),
            (w, x, z, y), (w, y, x, z), (w, z, y, x),
        ]
    for g in golden:
        for p in even_perms(*g):
            pts.append(tuple(c / 2.0 for c in p))  # type: ignore
    # dédoublonnage
    uniq = {}
    for p in pts:
        key = tuple(round(c, 8) for c in p)
        uniq[key] = p
    return list(uniq.values())


class H4Weyl:
    """
    Groupe engendré par réflexions dans les racines de H4.
    On n'énumère pas 14400 matrices : on applique le groupe par réflexions
    (algorithme de Todd–Coxeter / orbit-stabilizer en miniature).
    """

    def __init__(self, max_orbit: int = 400):
        self.roots = even_icosians_unit()
        # simple system approximatif : 4 racines simple H4 (Coxeter)
        # diagramme •--5--•---•---•
        self.simple: List[Vec4] = [
            (1.0, -1.0, 0.0, 0.0),
            (0.0, 1.0, -1.0, 0.0),
            (0.0, 0.0, 1.0, -1.0),
            (-PHI / 2, 0.5, 0.5, (PHI - 1) / 2),
        ]
        self.max_orbit = max_orbit

    def reflect_simple(self, v: Sequence[float], i: int) -> Tuple[float, ...]:
        return reflect(v, self.simple[i % 4])

    def word(self, v: Sequence[float], gens: Iterable[int]) -> Tuple[float, ...]:
        w = tuple(v)
        for i in gens:
            w = self.reflect_simple(w, i)
        return w

    def orbit(self, seed: Sequence[float]) -> List[Tuple[float, ...]]:
        """Orbite sous le sous-groupe engendré par les 4 réflexions simples (tronquée)."""
        seen = {tuple(round(x, 7) for x in seed): tuple(seed)}
        stack = [tuple(seed)]
        while stack and len(seen) < self.max_orbit:
            v = stack.pop()
            for i in range(4):
                w = self.reflect_simple(v, i)
                key = tuple(round(x, 7) for x in w)
                if key not in seen:
                    seen[key] = w
                    stack.append(w)
        return list(seen.values())

    def project_r2(self, v: Sequence[float]) -> Vec2:
        """Projection 4D → 2D (plan de Coxeter / plan doré)."""
        # deux vecteurs orthogonaux « pentagonaux »
        e1 = normalize((1.0, PHI, 0.0, 0.0))
        e2 = normalize((0.0, 0.0, 1.0, PHI))
        return (dot(v, e1), dot(v, e2))


# ---------- Penrose : cut-and-project (pentagrid de de Bruijn) ----------

@dataclass
class Rhomb:
    vertices: List[Vec2]
    kind: str  # "thin" | "fat"


class PenrosePentagrid:
    """
    Méthode des pentagrilles (N.G. de Bruijn).
    5 familles de droites ; intersections → losanges d'or.
    """

    def __init__(self, n_lines: int = 7, gamma: Sequence[float] | None = None):
        self.n_lines = n_lines
        # shifts génériques (somme nulle) pour éviter les intersections triples
        if gamma is None:
            g = [0.11, 0.27, -0.19, 0.31, -0.50]
            s = sum(g)
            gamma = [x - s / 5 for x in g]
        self.gamma = list(gamma)
        self.dirs = [
            (math.cos(2 * math.pi * k / 5), math.sin(2 * math.pi * k / 5))
            for k in range(5)
        ]

    def _index(self, x: float, y: float, k: int) -> int:
        ekx, eky = self.dirs[k]
        return math.ceil(x * ekx + y * eky + self.gamma[k])

    def _vertex_from_indices(self, indices: Sequence[int]) -> Vec2:
        """Sommet dual : somme_k n_k e_k  (plongement complexe)."""
        zx = zy = 0.0
        for k, n in enumerate(indices):
            zx += n * self.dirs[k][0]
            zy += n * self.dirs[k][1]
        return (zx, zy)

    def tiles(self) -> List[Rhomb]:
        rhombs: List[Rhomb] = []
        rng = range(-self.n_lines, self.n_lines + 1)
        # intersections grille k ∩ grille m
        for k in range(5):
            for m in range(k + 1, 5):
                ek = self.dirs[k]
                em = self.dirs[m]
                det = ek[0] * em[1] - ek[1] * em[0]
                if abs(det) < 1e-12:
                    continue
                for nk in rng:
                    for nm in rng:
                        # résoudre  x·ek + γk = nk,  x·em + γm = nm
                        bk = nk - self.gamma[k]
                        bm = nm - self.gamma[m]
                        x = (bk * em[1] - bm * ek[1]) / det
                        y = (ek[0] * bm - em[0] * bk) / det
                        n = [self._index(x, y, i) for i in range(5)]
                        # aux droites k et m on force les deux côtés
                        n[k] = nk
                        n[m] = nm
                        # 4 sommets du losange
                        corners_idx = [
                            list(n),
                            list(n),
                            list(n),
                            list(n),
                        ]
                        corners_idx[1][k] = nk - 1
                        corners_idx[2][m] = nm - 1
                        corners_idx[3][k] = nk - 1
                        corners_idx[3][m] = nm - 1
                        verts = [self._vertex_from_indices(c) for c in corners_idx]
                        # type : angle 36° (thin) vs 72° (fat)
                        dkm = abs(k - m) % 5
                        dkm = min(dkm, 5 - dkm)
                        kind = "thin" if dkm == 2 else "fat"
                        rhombs.append(Rhomb(vertices=verts, kind=kind))
        return rhombs


# ---------- Pont « Dragon » : courbure discrète sur le pavage ----------

class H4PenroseSimulator:
    def __init__(self, n_lines: int = 5, max_orbit: int = 240):
        self.h4 = H4Weyl(max_orbit=max_orbit)
        self.penrose = PenrosePentagrid(n_lines=n_lines)
        self.weight = 1.0
        self.polarity = 0.0
        self.tiles: List[Rhomb] = []
        self.orbit_2d: List[Vec2] = []

    def build(self, seed: Vec4 = (1.0, 0.0, 0.0, 0.0)):
        orb = self.h4.orbit(seed)
        self.orbit_2d = [self.h4.project_r2(p) for p in orb]
        self.tiles = self.penrose.tiles()
        # masse ~ nombre de tuiles ; polarité ~ (fat - thin) / total
        fat = sum(1 for t in self.tiles if t.kind == "fat")
        thin = sum(1 for t in self.tiles if t.kind == "thin")
        tot = max(1, fat + thin)
        self.weight = 1.0 + math.log1p(tot) / 8.0
        self.polarity = (fat - thin) / tot
        return {
            "h4_roots": len(self.h4.roots),
            "orbit": len(orb),
            "tiles": tot,
            "fat": fat,
            "thin": thin,
            "weight": self.weight,
            "polarity": self.polarity,
            "h4_order_nominal": H4_ORDER,
        }

    def curvature_walk(self) -> float:
        """κ discret : variation d'angle le long des arêtes (approx. intégrale)."""
        if not self.tiles:
            return 0.0
        acc = 0.0
        for t in self.tiles:
            vs = t.vertices
            for i in range(4):
                a, b, c = vs[i - 1], vs[i], vs[(i + 1) % 4]
                u = vsub(b, a)
                v = vsub(c, b)
                nu, nv = norm(u), norm(v)
                if nu < 1e-12 or nv < 1e-12:
                    continue
                cosang = max(-1.0, min(1.0, dot(u, v) / (nu * nv)))
                turn = math.pi - math.acos(cosang)
                acc += turn * (1.2 if t.kind == "fat" else 0.8)
        kappa = acc / max(1, len(self.tiles))
        self.weight *= 1.0 + 0.01 * abs(kappa)
        return kappa


if __name__ == "__main__":
    sim = H4PenroseSimulator(n_lines=4, max_orbit=200)
    info = sim.build()
    kap = sim.curvature_walk()
    print("H4 roots (600-cell verts):", info["h4_roots"])
    print("Orbite réflexion (tronquée):", info["orbit"])
    print("Tuiles Penrose fat/thin:", info["fat"], info["thin"])
    print("W, polarity:", round(info["weight"], 4), round(info["polarity"], 4))
    print("κ discret (walk):", round(kap, 4))
    print("Ordre H4 (théorique):", H4_ORDER)
    print("Exemple projection 2D (5 pts):", sim.orbit_2d[:5])
