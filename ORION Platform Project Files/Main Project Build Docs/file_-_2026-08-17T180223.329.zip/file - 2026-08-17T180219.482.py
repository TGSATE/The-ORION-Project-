# DRAGON SOUL — VERSION SUBSTANTIELLE
# MSC-2026-08-17 · Aftermath Walker + Path + Penrose + Clock

from dataclasses import dataclass, field
from typing import List, Tuple
import math
import itertools

PHI = (1 + math.sqrt(5)) / 2
H4_ORDER = 14400
RESONANCE_HZ = 1.0

@dataclass
class CurvatureState:
    stage: float = 0.0
    kappa: float = 0.0
    weight: float = 1.0
    polarity: float = 0.0
    s: float = 0.0          # paramètre de chemin

class DragonSoulSubstantial:
    def __init__(self, n_steps: int = 64):
        self.state = CurvatureState()
        self.history: List[Tuple] = []
        self.second_apple_allowed = True
        self.n_steps = n_steps
        self.path_kappa: List[float] = []   # κ(s) le long du chemin
        self.penrose_seq: List[str] = []    # motif aperiodique
        self.clock_t = 0.0
        self._build_penrose(n_steps)
        self._build_path()

    def _build_penrose(self, n: int):
        """Substitution aperiodique type Penrose / Fibonacci (L → LS, S → L)"""
        seq = ["L"]
        while len(seq) < n:
            new = []
            for c in seq:
                new.extend(["L", "S"] if c == "L" else ["L"])
            seq = new
        self.penrose_seq = seq[:n]

    def _build_path(self):
        """Chemin discret : κ(s) modulé par le motif Penrose + φ"""
        self.path_kappa = []
        s = 0.0
        ds = 1.0 / max(1, self.n_steps)
        for i, tile in enumerate(self.penrose_seq):
            base = math.sin(2 * math.pi * i / PHI) * (1.2 if tile == "L" else 0.7)
            self.path_kappa.append(base)
            s += ds
        # normalisation légère
        mx = max(abs(k) for k in self.path_kappa) or 1.0
        self.path_kappa = [k / mx for k in self.path_kappa]

    def hold(self, intention: float = 0.0):
        self.state.stage = 0.0
        self.state.kappa = intention
        self.state.s = 0.0
        self._log("HOLD")

    def trace(self):
        self.state.stage = 1.0
        self.state.kappa *= PHI
        self._log("TRACE")

    def distance(self, desire: float):
        current = self.state.kappa
        delta = abs(desire - current)
        self.state.stage = delta
        self.state.kappa = delta
        self._log(f"DISTANCE Δ={delta:.4f}")

    def cross(self):
        self.state.stage = 1.0
        self.state.polarity = max(-1.0, min(1.0, self.state.polarity + 0.1))
        self._log("CROSSING")

    def bend(self):
        self.state.stage = float("inf")
        self.state.kappa *= PHI ** 2
        self._log("BEND → SINGULARITY")

    def aftermath(self, use_path: bool = True):
        """Intégrale numérique ∫ κ(s) ds le long du chemin (trapèzes)"""
        if use_path and self.path_kappa:
            ds = 1.0 / len(self.path_kappa)
            integral = 0.0
            for i in range(len(self.path_kappa) - 1):
                integral += 0.5 * (self.path_kappa[i] + self.path_kappa[i + 1]) * ds
            # mélange avec κ courant
            integral = 0.6 * integral + 0.4 * self.state.kappa * 1.0
        else:
            integral = self.state.kappa * 1.0
        self.state.weight *= (1.0 + abs(integral) * 0.02)
        self.state.stage = integral
        self.state.s = 1.0
        self._log(f"AFTERMATH ∫κ ds ≈ {integral:.4f} | W={self.state.weight:.4f}")

    def second_apple(self):
        if not self.second_apple_allowed:
            raise RuntimeError("Second apple refused — curvature frozen")
        self.state.weight *= self.state.weight
        self.state.polarity = min(1.0, self.state.polarity + 0.25)
        self._log("SECOND APPLE · RECURSION")

    def feed_dragon(self, choice: str):
        c = choice.lower()
        if c in ("ego", "entropy", "closed", "serpent"):
            self.state.polarity = max(-1.0, self.state.polarity - 0.3)
            self._log("FED CLOSED SERPENT (Entropy)")
        elif c in ("love", "resonance", "open", "spiral", "syntropy"):
            self.state.polarity = min(1.0, self.state.polarity + 0.3)
            self._log("FED OPEN SPIRAL DRAGON (Syntropy)")
        else:
            self._log("No clear feeding")

    def tick(self, dt: float = 1.0):
        """Horloge 1 Hz : avance le temps et module légèrement κ"""
        self.clock_t += dt
        wave = math.cos(2 * math.pi * RESONANCE_HZ * self.clock_t)
        self.state.kappa += 0.05 * wave * self.state.polarity
        return wave

    def resonance_field(self, t: float = None) -> float:
        t = self.clock_t if t is None else t
        return math.cos(2 * math.pi * RESONANCE_HZ * t)

    def h4_projection(self) -> float:
        """Projection symbolique : poids × ordre H₄, réduction dorée + phase discrète"""
        raw = (self.state.weight * H4_ORDER) % (PHI * 8)
        # 8 directions approximatives (sous-groupe discret)
        sector = int(raw) % 8
        return raw + 0.1 * sector

    def walk_path(self, n: int = None):
        """Parcourt le chemin Penrose, met à jour κ et polarité selon les tuiles"""
        n = n or len(self.path_kappa)
        for i, (k, tile) in enumerate(itertools.islice(zip(self.path_kappa, self.penrose_seq), n)):
            self.state.kappa = 0.7 * self.state.kappa + 0.3 * k
            if tile == "L":
                self.state.polarity = min(1.0, self.state.polarity + 0.02)
            else:
                self.state.polarity = max(-1.0, self.state.polarity - 0.01)
            self.tick(dt=1.0 / max(1, n))
            self.state.s = (i + 1) / n
        self._log(f"WALK_PATH n={n} s={self.state.s:.3f}")

    def _log(self, event: str):
        self.history.append((
            self.state.stage, event,
            round(self.state.polarity, 3),
            round(self.state.weight, 4),
            round(self.state.kappa, 4)
        ))

    def status(self) -> str:
        pol = ("OPEN SPIRAL" if self.state.polarity > 0.2
               else "CLOSED SERPENT" if self.state.polarity < -0.2
               else "BALANCE POINT")
        return (
            f"Stage={self.state.stage} | κ={self.state.kappa:.4f} | "
            f"W={self.state.weight:.4f} | pol={self.state.polarity:.2f} ({pol}) | "
            f"s={self.state.s:.3f} | H4proj={self.h4_projection():.3f} | "
            f"res={self.resonance_field():.3f}"
        )


if __name__ == "__main__":
    soul = DragonSoulSubstantial(n_steps=48)

    soul.hold(intention=0.777)
    soul.trace()
    soul.distance(desire=1.618)
    soul.cross()
    soul.feed_dragon("resonance")
    soul.walk_path()
    soul.bend()
    soul.second_apple()
    soul.aftermath(use_path=True)

    print(soul.status())
    print("\n--- Historique (extrait) ---")
    for e in soul.history:
        print(e)
    print("\nMotif Penrose (début):", "".join(soul.penrose_seq[:24]))
