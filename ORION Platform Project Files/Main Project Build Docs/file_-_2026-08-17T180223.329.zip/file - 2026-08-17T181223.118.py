# H4 ORBIT CLOSURE + PENROSE CLEAN + SVG
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Set, Tuple

PHI = (1 + math.sqrt(5)) / 2
H4_ORDER = 14400

Vec2 = Tuple[float, float]
Vec4 = Tuple[float, float, float, float]
Key2 = Tuple[int, int]
Key4 = Tuple[int, int, int, int]


def vsub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def smul(s, a):
    return tuple(s * x for x in a)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def norm(a):
    return math.sqrt(dot(a, a))


def normalize(a, eps=1e-12):
    n = norm(a)
    return a if n < eps else smul(1.0 / n, a)


def reflect(v, n):
    nn = dot(n, n)
    if nn < 1e-18:
        return tuple(v)
    return vsub(v, smul(2.0 * dot(v, n) / nn, n))


def qkey4(v: Sequence[float], scale: float = 1e6) -> Key4:
    return tuple(int(round(x * scale)) for x in v)  # type: ignore


def qkey2(p: Vec2, scale: float = 1e5) -> Key2:
    return (int(round(p[0] * scale)), int(round(p[1] * scale)))


def centroid(vs: Sequence[Vec2]) -> Vec2:
    n = max(1, len(vs))
    return (sum(p[0] for p in vs) / n, sum(p[1] for p in vs) / n)


# ---------- 120 sommets 600-cell / racines unitaires ----------
def even_icosians_unit() -> List[Vec4]:
    pts: List[Vec4] = []
    for s in range(16):
        pts.append(tuple((1 if (s >> k) & 1 else -1) / 2.0 for k in range(4)))  # type: ignore
    for i in range(4):
        for sgn in (1.0, -1.0):
            v = [0.0] * 4
            v[i] = sgn
            pts.append(tuple(v))  # type: ignore
    golden = []
    for s0 in (1.0, -1.0):
        for s1 in (1.0, -1.0):
            for s2 in (1.0, -1.0):
                golden.append((s0 * PHI, s1 * 1.0, s2 / PHI, 0.0))

    def even_perms(x, y, z, w):
        return [
            (x, y, z, w), (x, z, w, y), (x, w, y, z),
            (y, x, w, z), (y, z, x, w), (y, w, z, x),
            (z, x, y, w), (z, y, w, x), (z, w, x, y),
            (w, x, z, y), (w, y, x, z), (w, z, y, x),
        ]

    for g in golden:
        for p in even_perms(*g):
            pts.append(tuple(c / 2.0 for c in p))  # type: ignore
    uniq = {}
    for p in pts:
        uniq[tuple(round(c, 8) for c in p)] = p
    return list(uniq.values())


class H4Weyl:
    def __init__(self):
        self.roots = even_icosians_unit()
        # générateurs type Coxeter H4 (4e racine approchée mais dans le réseau d'icosiens)
        self.simple: List[Vec4] = [
            (1.0, -1.0, 0.0, 0.0),
            (0.0, 1.0, -1.0, 0.0),
            (0.0, 0.0, 1.0, -1.0),
            (-PHI / 2, 0.5, 0.5, (PHI - 1) / 2),
        ]

    def reflect_simple(self, v, i: int):
        return reflect(v, self.simple[i % 4])

    def orbit_until_close(self, seed: Sequence[float], max_pts: int = 20000) -> dict:
        """BFS réflexions ; clôture par hash. Compte vs 120 et 14400."""
        seed_t = tuple(float(x) for x in seed)
        seen: Dict[Key4, Vec4] = {qkey4(seed_t): seed_t}  # type: ignore
        stack = [seed_t]
        closed = True
        while stack:
            if len(seen) >= max_pts:
                closed = False
                break
            v = stack.pop()
            for i in range(4):
                w = self.reflect_simple(v, i)
                k = qkey4(w)
                if k not in seen:
                    seen[k] = w  # type: ignore
                    stack.append(w)  # type: ignore
        pts = list(seen.values())
        n = len(pts)
        return {
            "count": n,
            "closed": closed and n < max_pts,
            "is_root_orbit": n == 120,
            "is_full_weyl": n == H4_ORDER,
            "vs_120": n / 120.0,
            "vs_14400": n / float(H4_ORDER),
            "points": pts,
        }

    def project_r2(self, v: Sequence[float]) -> Vec2:
        e1 = normalize((1.0, PHI, 0.0, 0.0))
        e2 = normalize((0.0, 0.0, 1.0, PHI))
        return (dot(v, e1), dot(v, e2))


# ---------- Penrose fenêtre + hash + adjacence ----------
@dataclass
class Rhomb:
    vertices: List[Vec2]
    kind: str


class PenroseClean:
    def __init__(self, n_lines=5, window_r=2.8, gamma=None):
        self.n_lines = n_lines
        self.window_r = window_r
        if gamma is None:
            g = [0.11, 0.27, -0.19, 0.31, -0.50]
            s = sum(g)
            gamma = [x - s / 5.0 for x in g]
        self.gamma = list(gamma)
        self.dirs = [
            (math.cos(2 * math.pi * k / 5), math.sin(2 * math.pi * k / 5))
            for k in range(5)
        ]
        self.tiles: List[Rhomb] = []
        self.vertices: Dict[Key2, Vec2] = {}
        self.adj: Dict[Key2, Set[Key2]] = defaultdict(set)

    def _index(self, x, y, k):
        ekx, eky = self.dirs[k]
        return math.ceil(x * ekx + y * eky + self.gamma[k])

    def _from_idx(self, indices):
        zx = zy = 0.0
        for k, n in enumerate(indices):
            zx += n * self.dirs[k][0]
            zy += n * self.dirs[k][1]
        return (zx, zy)

    def _in_window(self, p: Vec2) -> bool:
        if math.hypot(*p) > self.window_r:
            return False
        lim = self.window_r * math.cos(math.pi / 5)
        return all(dot(p, self.dirs[k]) <= lim for k in range(5))

    def build(self) -> dict:
        raw = []
        rng = range(-self.n_lines, self.n_lines + 1)
        for k in range(5):
            for m in range(k + 1, 5):
                ek, em = self.dirs[k], self.dirs[m]
                det = ek[0] * em[1] - ek[1] * em[0]
                if abs(det) < 1e-12:
                    continue
                dkm = min((m - k) % 5, (k - m) % 5)
                kind = "thin" if dkm == 2 else "fat"
                for nk in rng:
                    for nm in rng:
                        bk, bm = nk - self.gamma[k], nm - self.gamma[m]
                        x = (bk * em[1] - bm * ek[1]) / det
                        y = (ek[0] * bm - em[0] * bk) / det
                        n = [self._index(x, y, i) for i in range(5)]
                        n[k], n[m] = nk, nm
                        corners = [list(n) for _ in range(4)]
                        corners[1][k] = nk - 1
                        corners[2][m] = nm - 1
                        corners[3][k] = nk - 1
                        corners[3][m] = nm - 1
                        verts = [self._from_idx(c) for c in corners]
                        raw.append(Rhomb(verts, kind))

        seen_tile = set()
        self.tiles = []
        for t in raw:
            c = centroid(t.vertices)
            inside = sum(1 for v in t.vertices if self._in_window(v))
            if not self._in_window(c) or inside < 3:
                continue
            keys = tuple(sorted(qkey2(v) for v in t.vertices))
            if keys in seen_tile:
                continue
            seen_tile.add(keys)
            self.tiles.append(t)

        self.vertices.clear()
        self.adj.clear()
        for t in self.tiles:
            ks = []
            for v in t.vertices:
                key = qkey2(v)
                self.vertices.setdefault(key, v)
                ks.append(key)
            for i in range(4):
                a, b = ks[i], ks[(i + 1) % 4]
                if a != b:
                    self.adj[a].add(b)
                    self.adj[b].add(a)
        fat = sum(1 for t in self.tiles if t.kind == "fat")
        thin = len(self.tiles) - fat
        return {
            "raw": len(raw),
            "tiles": len(self.tiles),
            "fat": fat,
            "thin": thin,
            "vertices": len(self.vertices),
            "edges": sum(len(n) for n in self.adj.values()) // 2,
        }


def svg_scene(
    tiles: List[Rhomb],
    orbit2d: List[Vec2],
    path: str = "h4_penrose.svg",
    size: int = 720,
    margin: float = 24.0,
) -> str:
    pts: List[Vec2] = [v for t in tiles for v in t.vertices] + list(orbit2d)
    if not pts:
        pts = [(0.0, 0.0)]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    dx, dy = max(xmax - xmin, 1e-9), max(ymax - ymin, 1e-9)
    s = (size - 2 * margin) / max(dx, dy)

    def xy(p: Vec2) -> Tuple[float, float]:
        return (margin + (p[0] - xmin) * s, size - (margin + (p[1] - ymin) * s))

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">',
        '<rect width="100%" height="100%" fill="#0b0d12"/>',
        '<g stroke="#1a2030" stroke-width="0.7">',
    ]
    for t in tiles:
        d = " ".join(f"{xy(v)[0]:.2f},{xy(v)[1]:.2f}" for v in t.vertices)
        fill = "#c9a22788" if t.kind == "fat" else "#4aa3a288"
        parts.append(f'<polygon points="{d}" fill="{fill}"/>')
    parts.append("</g>")
    parts.append('<g fill="#e8e4d9">')
    for p in orbit2d:
        x, y = xy(p)
        parts.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="2.2"/>')
    parts.append("</g></svg>")
    svg = "\n".join(parts)
    with open(path, "w", encoding="utf-8") as f:
        f.write(svg)
    return path


if __name__ == "__main__":
    h4 = H4Weyl()
    print("icosiens unitaires:", len(h4.roots))

    # 4 — clôture d'orbite
    o_root = h4.orbit_until_close(h4.roots[0])
    o_seed = h4.orbit_until_close((1.0, 0.0, 0.0, 0.0))
    o_gen = h4.orbit_until_close((0.3, 0.2, 0.1, 0.05), max_pts=20000)
    for name, o in (("racine", o_root), ("e1", o_seed), ("générique", o_gen)):
        print(
            f"orbite {name}: n={o['count']} closed={o['closed']} "
            f"==120:{o['is_root_orbit']} ==14400:{o['is_full_weyl']} "
            f"n/120={o['vs_120']:.3f} n/14400={o['vs_14400']:.4f}"
        )

    # 1 — Penrose propre
    pen = PenroseClean(n_lines=5, window_r=2.8)
    info = pen.build()
    print("penrose:", info)

    # 3 — SVG
    orb2 = [h4.project_r2(p) for p in o_seed["points"]]
    out = svg_scene(pen.tiles, orb2, path="h4_penrose.svg")
    print("svg:", out)
