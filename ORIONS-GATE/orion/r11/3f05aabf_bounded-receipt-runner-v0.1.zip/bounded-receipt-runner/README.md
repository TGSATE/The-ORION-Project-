# Bounded Receipt Runner — MVP v0.1

This is a deliberately product-name-neutral prototype for a governed AI/action runner whose receipts bind not only **what happened**, but also **what the evidence is allowed to support**.

The design goal is a 60-second demo:

1. A user requests a bounded verification action.
2. The runner exposes a typed action proposal.
3. The action is checked against a versioned action manifest.
4. The user grants the exact action.
5. The runner executes a fixed adapter without shell expansion.
6. It emits a signed receipt.
7. A standalone verifier validates the receipt without the runner.
8. Change one byte in the receipt and verification fails.
9. Even when cryptographically valid, the verifier separately reports the claim class, claim ceiling, falsifier, and issuer-boundary grounding.

## Core separation laws

- Valid signature ≠ true claim.
- Receipt validity ≠ downstream decision admissibility.
- Producer-asserted boundary ≠ independently grounded boundary.
- Capability ≠ authority.
- A receipt may establish a bounded claim while explicitly failing to establish a stronger one.

## v0.1 scope

Typed actions only:

- `GitHead`
- `GitStatus`
- `ReadFile`
- `SearchFiles`
- `RunTestSuite`

There is **no arbitrary shell action**. The model/user selects a typed action and structured parameters. The adapter defines execution semantics.

## Receipt fields

The receipt binds:

- action identity and parameters
- action-manifest version and digest
- authority/grant basis
- execution evidence
- claim class
- claim text
- claim ceiling
- explicit non-claims
- falsifier
- issuer-boundary descriptor
- issuer-boundary grounding status
- public-key fingerprint
- detached signature

## Standalone verifier

`bounded-verify` requires only:

- `receipt.json`
- `receipt.sig`
- the producer public key

It reports cryptographic validity separately from semantic/admissibility information.

## Quick start

```bash
python -m pip install -e .
bounded-run keygen --out demo-key
bounded-run manifest
bounded-run run \
  --key demo-key.private.pem \
  --action GitHead \
  --grant-user local-user \
  --root /path/to/repo \
  --out receipt.json

bounded-verify \
  --receipt receipt.json \
  --signature receipt.json.sig \
  --public-key demo-key.public.pem
```

The runner writes canonical JSON before signing. Receipts are intended for local demonstration and research. v0.1 is not a production security boundary or certification system.
