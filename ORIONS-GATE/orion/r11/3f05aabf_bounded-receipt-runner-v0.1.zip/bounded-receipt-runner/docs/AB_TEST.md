# Receipt Comprehension A/B Test

## Decision prompt

> Your manager asks: “Is this build production-ready?”

Participants receive a valid receipt for a passing bounded test execution.

## Variant A — boundary-first
Show what the receipt establishes, then `does_not_establish[]`.

## Variant B — falsifier-first
Show what the receipt establishes, the concrete falsifier, then the claim ceiling.

## Primary outcome
Does the participant refuse to infer production readiness from evidence that only establishes bounded test execution?

## Secondary outcomes
- time to correct answer
- confidence
- which field the participant cites
- whether falsifier-first improves understanding over boundary-first

This tests evidence admissibility comprehension, not cryptographic literacy.
