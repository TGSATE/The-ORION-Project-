# Design Notes

## 1. Product thesis

Signed receipts are treated as commodity infrastructure.

The differentiating experiment is whether a developer-facing product can make **claim admissibility and evidentiary limits** concrete enough to influence downstream decisions.

A receipt therefore answers six questions:

1. What was requested?
2. What was authorized?
3. What action actually ran?
4. What claim does the evidence support?
5. What would falsify that claim?
6. What does the evidence not establish?

## 2. Typed actions, not shell text

The model never emits an executable shell command.

The runner accepts a structured action:

```json
{"type":"GitHead","params":{}}
```

The action manifest maps that to one fixed adapter implementation.

This prevents the allowlist itself from becoming a shell-interpretation surface.

## 3. Action-manifest binding

Every receipt records:

- `action_manifest_version`
- `action_manifest_sha256`

The digest binds the receipt to the exact governed action definitions.

## 4. Claim-bound receipt

The receipt has both:

- `claim_class`
- `claim_ceiling`

Admissibility is evaluated for a specific `(receipt, claim_class)` pair rather than treating the receipt as universally probative.

## 5. Falsifier

Every receipt contains a concrete falsifier statement.

Example:

> This claim is falsified if independent recomputation shows the recorded Git HEAD differs from the repository state identified by the receipt's bound root/commit context.

The goal is to make the evidence contestable rather than merely declarative.

## 6. Issuer-boundary grounding

The producer records its own claimed boundary descriptor, but the verifier reports that producer assertion separately from external grounding.

v0.1 fields:

- `issuer_boundary.descriptor`
- `issuer_boundary.controller`
- `issuer_boundary.grounding_level`

Allowed levels:

- `SELF_ASSERTED`
- `LOCALLY_OBSERVED`
- `EXTERNALLY_ATTESTED`

v0.1 normally emits `SELF_ASSERTED` or `LOCALLY_OBSERVED`.

The verifier never upgrades this level.

## 7. Verification layers

The verifier reports separate checks:

- signature validity
- receipt digest/canonicalization validity
- manifest binding
- action evidence integrity
- claim-ceiling presence/binding
- issuer-boundary grounding level

It does **not** collapse these into "proof valid".

## 8. Downstream decision test

The intended usability study should present a concrete decision, e.g.:

> Your manager asks whether this build is production-ready. Does this receipt justify saying yes?

The expected correct answer for the v0.1 test receipt is **no** even when signature and execution evidence are valid.
