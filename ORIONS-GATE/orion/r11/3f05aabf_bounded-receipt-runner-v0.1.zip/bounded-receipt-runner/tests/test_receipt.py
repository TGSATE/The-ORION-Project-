from pathlib import Path
import json, subprocess
from bounded_runner.crypto import generate_keypair
from bounded_runner.receipt import issue_receipt
from bounded_runner.verifier import verify_receipt

def _repo(tmp_path):
    subprocess.run(["git","init","-q"], cwd=tmp_path, check=True)
    subprocess.run(["git","config","user.email","demo@example.invalid"], cwd=tmp_path, check=True)
    subprocess.run(["git","config","user.name","Demo"], cwd=tmp_path, check=True)
    (tmp_path/"x.txt").write_text("x")
    subprocess.run(["git","add","x.txt"], cwd=tmp_path, check=True)
    subprocess.run(["git","commit","-qm","init"], cwd=tmp_path, check=True)

def test_issue_and_verify(tmp_path):
    _repo(tmp_path)
    priv, pub = generate_keypair(tmp_path/"issuer")
    rp, sp = issue_receipt(
        private_key_path=priv,
        action="GitHead",
        params={},
        root=tmp_path,
        grant_user="tester",
        out_path=tmp_path/"receipt.json",
    )
    result = verify_receipt(rp, sp, pub)
    assert result["overall"] == "VALID"
    assert result["signature_valid"] is True
    assert result["claim_ceiling_bound"] is True
    assert "production readiness" in result["does_not_establish"]

def test_tamper_fails_signature(tmp_path):
    _repo(tmp_path)
    priv, pub = generate_keypair(tmp_path/"issuer")
    rp, sp = issue_receipt(
        private_key_path=priv,
        action="GitHead",
        params={},
        root=tmp_path,
        grant_user="tester",
        out_path=tmp_path/"receipt.json",
    )
    obj = json.loads(rp.read_text())
    obj["claim"]["claim_text"] += " tampered"
    rp.write_text(json.dumps(obj))
    result = verify_receipt(rp, sp, pub)
    assert result["overall"] == "INVALID"
    assert result["signature_valid"] is False

def test_ceiling_tamper_detected(tmp_path):
    _repo(tmp_path)
    priv, pub = generate_keypair(tmp_path/"issuer")
    rp, sp = issue_receipt(
        private_key_path=priv,
        action="GitHead",
        params={},
        root=tmp_path,
        grant_user="tester",
        out_path=tmp_path/"receipt.json",
    )
    obj = json.loads(rp.read_text())
    obj["claim"]["claim_ceiling"] = "Anything goes."
    # re-sign to prove structural ceiling binding is independently checked
    from bounded_runner.canonical import canonical_bytes
    from bounded_runner.crypto import load_private
    rp.write_bytes(canonical_bytes(obj) + b"\n")
    sp.write_bytes(load_private(priv).sign(canonical_bytes(obj)))
    result = verify_receipt(rp, sp, pub)
    assert result["overall"] == "INVALID"
    assert result["signature_valid"] is True
    assert result["claim_ceiling_bound"] is False
