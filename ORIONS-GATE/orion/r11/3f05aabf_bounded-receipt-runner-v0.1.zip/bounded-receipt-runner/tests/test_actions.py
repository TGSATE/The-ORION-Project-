from pathlib import Path
import subprocess
import pytest
from bounded_runner.actions import execute, ActionError

def test_readfile_blocks_traversal(tmp_path):
    (tmp_path / "ok.txt").write_text("hello", encoding="utf-8")
    with pytest.raises(ActionError):
        execute("ReadFile", {"path": "../escape.txt"}, tmp_path)

def test_git_head_has_fixed_argv(tmp_path):
    subprocess.run(["git","init","-q"], cwd=tmp_path, check=True)
    subprocess.run(["git","config","user.email","demo@example.invalid"], cwd=tmp_path, check=True)
    subprocess.run(["git","config","user.name","Demo"], cwd=tmp_path, check=True)
    (tmp_path/"x.txt").write_text("x")
    subprocess.run(["git","add","x.txt"], cwd=tmp_path, check=True)
    subprocess.run(["git","commit","-qm","init"], cwd=tmp_path, check=True)
    r = execute("GitHead", {}, tmp_path)
    assert r["argv"] == ["git","rev-parse","HEAD"]
    assert r["exit_code"] == 0
