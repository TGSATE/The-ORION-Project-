from bounded_runner.manifest import manifest_object, manifest_sha256

def test_manifest_is_stable_shape():
    m = manifest_object()
    assert m["version"] == "action-manifest/v1"
    assert "RunTestSuite" in m["actions"]
    assert len(manifest_sha256()) == 64
