from pathlib import Path
import subprocess
from bounded_runner.crypto import generate_keypair
from bounded_runner.receipt import issue_receipt
from bounded_runner.verifier import verify_receipt

def test_self_asserted_boundary_not_upgraded(tmp_path):
    subprocess.run(["git","init","-q"], cwd=tmp_path, check=True)
    subprocess.run(["git","config","user.email","demo@example.invalid"], cwd=tmp_path, check=True)
    subprocess.run(["git","config","user.name","Demo"], cwd=tmp_path, check=True)
    (tmp_path/"x").write_text("x")
    subprocess.run(["git","add","x"], cwd=tmp_path, check=True)
    subprocess.run(["git","commit","-qm","init"], cwd=tmp_path, check=True)
    priv, pub = generate_keypair(tmp_path/"issuer")
    rp, sp = issue_receipt(
        private_key_path=priv,
        action="GitHead",
        params={},
        root=tmp_path,
        grant_user="tester",
        out_path=tmp_path/"receipt.json",
        grounding_level="SELF_ASSERTED",
    )
    result = verify_receipt(rp, sp, pub)
    assert result["overall"] == "VALID"
    assert result["issuer_boundary_grounding_level"] == "SELF_ASSERTED"
