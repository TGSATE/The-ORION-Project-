from pathlib import Path
import argparse, json
from .crypto import generate_keypair
from .manifest import manifest_object, manifest_sha256
from .receipt import issue_receipt

def _params(args) -> dict:
    if args.action == "ReadFile":
        return {"path": args.path}
    if args.action == "SearchFiles":
        return {"query": args.query}
    return {}

def main():
    p = argparse.ArgumentParser(prog="bounded-run")
    sub = p.add_subparsers(dest="cmd", required=True)

    kg = sub.add_parser("keygen")
    kg.add_argument("--out", required=True)

    mf = sub.add_parser("manifest")

    run = sub.add_parser("run")
    run.add_argument("--key", required=True)
    run.add_argument("--action", required=True, choices=["GitHead","GitStatus","ReadFile","SearchFiles","RunTestSuite"])
    run.add_argument("--grant-user", required=True)
    run.add_argument("--root", required=True)
    run.add_argument("--out", required=True)
    run.add_argument("--path")
    run.add_argument("--query")
    run.add_argument("--issuer-controller", default="local-user")
    run.add_argument("--grounding-level", default="SELF_ASSERTED",
                     choices=["SELF_ASSERTED","LOCALLY_OBSERVED","EXTERNALLY_ATTESTED"])

    args = p.parse_args()

    if args.cmd == "keygen":
        priv, pub = generate_keypair(Path(args.out))
        print(json.dumps({"private_key": str(priv), "public_key": str(pub)}, indent=2))
        return

    if args.cmd == "manifest":
        print(json.dumps({
            "manifest": manifest_object(),
            "sha256": manifest_sha256()
        }, indent=2))
        return

    params = _params(args)
    if args.action == "ReadFile" and not args.path:
        p.error("--path is required for ReadFile")
    if args.action == "SearchFiles" and args.query is None:
        p.error("--query is required for SearchFiles")

    receipt, sig = issue_receipt(
        private_key_path=Path(args.key),
        action=args.action,
        params=params,
        root=Path(args.root),
        grant_user=args.grant_user,
        out_path=Path(args.out),
        issuer_controller=args.issuer_controller,
        grounding_level=args.grounding_level,
    )
    print(json.dumps({"receipt": str(receipt), "signature": str(sig)}, indent=2))

if __name__ == '__main__':
    main()
