from pathlib import Path
import argparse, json
from .verifier import verify_receipt

def main():
    p = argparse.ArgumentParser(prog="bounded-verify")
    p.add_argument("--receipt", required=True)
    p.add_argument("--signature", required=True)
    p.add_argument("--public-key", required=True)
    args = p.parse_args()
    result = verify_receipt(Path(args.receipt), Path(args.signature), Path(args.public_key))
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result.get("overall") == "VALID" else 2)

if __name__ == '__main__':
    main()
