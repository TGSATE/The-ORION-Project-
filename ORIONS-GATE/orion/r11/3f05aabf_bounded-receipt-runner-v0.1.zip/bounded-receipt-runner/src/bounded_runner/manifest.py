from dataclasses import dataclass, asdict
from typing import Any
import hashlib
from .canonical import canonical_bytes

MANIFEST_VERSION = "action-manifest/v1"

ACTIONS = {
    "GitHead": {
        "description": "Read the current Git HEAD commit identity.",
        "params": {},
        "side_effect": "NONE",
        "adapter": "git_head_v1",
    },
    "GitStatus": {
        "description": "Read porcelain Git working-tree status.",
        "params": {},
        "side_effect": "NONE",
        "adapter": "git_status_v1",
    },
    "ReadFile": {
        "description": "Read one UTF-8 text file beneath the granted root.",
        "params": {"path": "relative_path"},
        "side_effect": "NONE",
        "adapter": "read_file_v1",
    },
    "SearchFiles": {
        "description": "Search UTF-8 text files beneath the granted root for a literal query.",
        "params": {"query": "string"},
        "side_effect": "NONE",
        "adapter": "search_files_v1",
    },
    "RunTestSuite": {
        "description": "Execute the repository's fixed project-default test profile.",
        "params": {},
        "side_effect": "PROCESS_EXECUTION",
        "adapter": "pytest_default_v1",
    },
}

def manifest_object() -> dict[str, Any]:
    return {"version": MANIFEST_VERSION, "actions": ACTIONS}

def manifest_sha256() -> str:
    return hashlib.sha256(canonical_bytes(manifest_object())).hexdigest()
