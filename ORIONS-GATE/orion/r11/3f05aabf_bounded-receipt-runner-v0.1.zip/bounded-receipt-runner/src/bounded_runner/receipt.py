from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from typing import Any
import hashlib, json, os, platform

from .canonical import canonical_bytes
from .manifest import manifest_sha256, MANIFEST_VERSION, ACTIONS
from .actions import execute
from .crypto import load_private, public_key_pem_from_private, fingerprint_public_pem

RECEIPT_SCHEMA = "bounded-receipt/v1"

CLAIMS = {
    "GitHead": {
        "claim_class": "OBSERVED_REPOSITORY_IDENTITY",
        "claim_text": "The governed GitHead action returned the recorded Git commit identifier for the bound repository root at execution time.",
        "claim_ceiling": "This receipt does not establish repository correctness, source authenticity beyond the observed local repository state, absence of vulnerabilities, test coverage, production readiness, or safety.",
        "does_not_establish": [
            "repository correctness",
            "absence of vulnerabilities",
            "production readiness",
            "complete test coverage",
            "universal source authenticity",
        ],
        "falsifier": "Re-execution under the same bound repository state or independent examination of the bound repository metadata yields a different HEAD identity than the recorded result.",
    },
    "GitStatus": {
        "claim_class": "OBSERVED_WORKTREE_STATUS",
        "claim_text": "The governed GitStatus action returned the recorded porcelain worktree status for the bound repository root at execution time.",
        "claim_ceiling": "This receipt does not establish repository correctness, absence of hidden state, absence of vulnerabilities, or production readiness.",
        "does_not_establish": ["repository correctness", "absence of vulnerabilities", "production readiness"],
        "falsifier": "Independent observation of the same bound worktree state yields a materially different porcelain status.",
    },
    "ReadFile": {
        "claim_class": "OBSERVED_FILE_CONTENT",
        "claim_text": "The governed ReadFile action returned the recorded UTF-8 content and digest for the granted relative path.",
        "claim_ceiling": "This receipt does not establish that the file is truthful, safe, authoritative, complete, or representative of any wider system.",
        "does_not_establish": ["truth of file contents", "file authority", "system correctness", "production readiness"],
        "falsifier": "The bound file bytes independently recompute to a different SHA-256 digest than the receipt records.",
    },
    "SearchFiles": {
        "claim_class": "BOUNDED_LITERAL_SEARCH_RESULT",
        "claim_text": "The governed SearchFiles action produced the recorded bounded literal-match results under the granted root.",
        "claim_ceiling": "This receipt does not establish semantic completeness, absence of matches in unreadable/binary/excluded files, repository correctness, or production readiness.",
        "does_not_establish": ["semantic completeness", "binary-file coverage", "repository correctness", "production readiness"],
        "falsifier": "A conforming independent search over the same readable UTF-8 scope finds a qualifying literal match omitted from an untruncated result.",
    },
    "RunTestSuite": {
        "claim_class": "BOUNDED_TEST_EXECUTION_RESULT",
        "claim_text": "The governed fixed RunTestSuite action executed the project-default pytest profile and produced the recorded process result.",
        "claim_ceiling": "A passing test process does not establish production readiness, absence of vulnerabilities, complete correctness, adequate coverage, or suitability outside the tested configuration.",
        "does_not_establish": [
            "production readiness",
            "absence of vulnerabilities",
            "complete correctness",
            "adequate test coverage",
            "suitability outside the tested configuration",
        ],
        "falsifier": "Independent execution of the same frozen test profile against the same bound source/environment produces materially inconsistent execution evidence.",
    },
}

def _sha(obj: Any) -> str:
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()

def issue_receipt(
    *,
    private_key_path: Path,
    action: str,
    params: dict[str, Any],
    root: Path,
    grant_user: str,
    out_path: Path,
    issuer_controller: str = "local-user",
    grounding_level: str = "SELF_ASSERTED",
) -> tuple[Path, Path]:
    if action not in ACTIONS:
        raise ValueError("action not in governed action manifest")
    if grounding_level not in {"SELF_ASSERTED", "LOCALLY_OBSERVED", "EXTERNALLY_ATTESTED"}:
        raise ValueError("invalid grounding level")

    root = root.resolve()
    started = datetime.now(timezone.utc).isoformat()
    result = execute(action, params, root)
    finished = datetime.now(timezone.utc).isoformat()

    pub_pem = public_key_pem_from_private(private_key_path)
    claim = CLAIMS[action]
    ceiling_sha = hashlib.sha256(claim["claim_ceiling"].encode("utf-8")).hexdigest()

    evidence = {
        "action_result": result,
        "action_result_sha256": _sha(result),
    }

    receipt = {
        "schema": RECEIPT_SCHEMA,
        "issued_at": finished,
        "execution": {
            "started_at": started,
            "finished_at": finished,
            "root_descriptor": {
                "path": str(root),
                "note": "Local path is descriptive context, not an external identity anchor."
            },
            "action": {
                "type": action,
                "params": params,
                "manifest_version": MANIFEST_VERSION,
                "manifest_sha256": manifest_sha256(),
            },
            "authority_basis": {
                "grant_type": "EXPLICIT_LOCAL_USER_GRANT",
                "grant_user": grant_user,
                "authority_delta": 0,
            },
        },
        "evidence": evidence,
        "claim": {
            "claim_class": claim["claim_class"],
            "claim_text": claim["claim_text"],
            "claim_ceiling": claim["claim_ceiling"],
            "claim_ceiling_sha256": ceiling_sha,
            "does_not_establish": claim["does_not_establish"],
            "falsifier": claim["falsifier"],
        },
        "issuer_boundary": {
            "descriptor": "Single-user local runner process issuing an account of its own governed action execution.",
            "controller": issuer_controller,
            "grounding_level": grounding_level,
            "grounding_note": "The producer's boundary description is not upgraded by signature validity. External grounding must be supplied separately.",
        },
        "issuer": {
            "public_key_sha256": fingerprint_public_pem(pub_pem),
        },
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
        },
    }

    payload = canonical_bytes(receipt)
    out_path.write_bytes(payload + b"\n")
    signature = load_private(private_key_path).sign(payload)
    sig_path = out_path.with_suffix(out_path.suffix + ".sig")
    sig_path.write_bytes(signature)
    return out_path, sig_path
