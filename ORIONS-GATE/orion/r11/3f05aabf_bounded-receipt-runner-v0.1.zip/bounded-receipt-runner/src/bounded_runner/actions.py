from pathlib import Path
import subprocess
import hashlib
from typing import Any

class ActionError(RuntimeError):
    pass

def _safe_root(root: Path) -> Path:
    root = root.resolve()
    if not root.exists() or not root.is_dir():
        raise ActionError("granted root does not exist or is not a directory")
    return root

def _safe_relative(root: Path, rel: str) -> Path:
    if "\x00" in rel:
        raise ActionError("NUL in path")
    p = (root / rel).resolve()
    try:
        p.relative_to(root)
    except ValueError:
        raise ActionError("path escapes granted root")
    return p

def _run_fixed(argv: list[str], cwd: Path, timeout: int = 30) -> dict[str, Any]:
    cp = subprocess.run(
        argv,
        cwd=str(cwd),
        shell=False,
        capture_output=True,
        text=True,
        timeout=timeout,
        env={"PATH": "/usr/bin:/bin"},
    )
    return {
        "argv": argv,
        "exit_code": cp.returncode,
        "stdout": cp.stdout,
        "stderr": cp.stderr,
    }

def execute(action: str, params: dict[str, Any], root: Path) -> dict[str, Any]:
    root = _safe_root(root)

    if action == "GitHead":
        if params:
            raise ActionError("GitHead accepts no parameters")
        return _run_fixed(["git", "rev-parse", "HEAD"], root)

    if action == "GitStatus":
        if params:
            raise ActionError("GitStatus accepts no parameters")
        return _run_fixed(["git", "status", "--porcelain=v1", "--untracked-files=all"], root)

    if action == "ReadFile":
        if set(params) != {"path"} or not isinstance(params["path"], str):
            raise ActionError("ReadFile requires exactly string param 'path'")
        p = _safe_relative(root, params["path"])
        data = p.read_text(encoding="utf-8")
        return {
            "path": params["path"],
            "sha256": hashlib.sha256(data.encode("utf-8")).hexdigest(),
            "text": data,
        }

    if action == "SearchFiles":
        if set(params) != {"query"} or not isinstance(params["query"], str):
            raise ActionError("SearchFiles requires exactly string param 'query'")
        query = params["query"]
        results = []
        for p in sorted(root.rglob("*")):
            if not p.is_file():
                continue
            if ".git" in p.parts:
                continue
            try:
                text = p.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for line_no, line in enumerate(text.splitlines(), 1):
                if query in line:
                    results.append({"path": str(p.relative_to(root)), "line": line_no, "text": line})
                    if len(results) >= 200:
                        return {"query": query, "matches": results, "truncated": True}
        return {"query": query, "matches": results, "truncated": False}

    if action == "RunTestSuite":
        if params:
            raise ActionError("RunTestSuite accepts no parameters")
        # Fixed executable semantics: no model/user-controlled argv.
        return _run_fixed(
            ["/usr/bin/env", "python3", "-m", "pytest", "-q"],
            root,
            timeout=120,
        )

    raise ActionError(f"unsupported action: {action}")
