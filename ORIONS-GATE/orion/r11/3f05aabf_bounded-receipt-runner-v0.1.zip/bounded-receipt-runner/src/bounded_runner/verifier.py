from pathlib import Path
from typing import Any
import json, hashlib
from cryptography.exceptions import InvalidSignature
from .canonical import canonical_bytes
from .crypto import load_public, fingerprint_public_pem
from .manifest import manifest_sha256, MANIFEST_VERSION

def verify_receipt(receipt_path: Path, signature_path: Path, public_key_path: Path) -> dict[str, Any]:
    raw = receipt_path.read_bytes()
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as e:
        return {"overall": "INVALID", "reason": f"INVALID_JSON:{e.msg}"}

    canonical = canonical_bytes(obj)
    public_pem = public_key_path.read_bytes()
    pub = load_public(public_key_path)

    signature_valid = True
    try:
        pub.verify(signature_path.read_bytes(), canonical)
    except InvalidSignature:
        signature_valid = False

    claim = obj.get("claim", {})
    action = obj.get("execution", {}).get("action", {})
    evidence = obj.get("evidence", {})
    issuer = obj.get("issuer", {})
    boundary = obj.get("issuer_boundary", {})

    ceiling = claim.get("claim_ceiling")
    ceiling_digest = claim.get("claim_ceiling_sha256")
    ceiling_bound = (
        isinstance(ceiling, str)
        and isinstance(ceiling_digest, str)
        and hashlib.sha256(ceiling.encode("utf-8")).hexdigest() == ceiling_digest
    )

    evidence_payload = evidence.get("action_result")
    evidence_digest = evidence.get("action_result_sha256")
    evidence_integrity = (
        evidence_payload is not None
        and isinstance(evidence_digest, str)
        and hashlib.sha256(canonical_bytes(evidence_payload)).hexdigest() == evidence_digest
    )

    manifest_binding = (
        action.get("manifest_version") == MANIFEST_VERSION
        and action.get("manifest_sha256") == manifest_sha256()
    )

    key_binding = issuer.get("public_key_sha256") == fingerprint_public_pem(public_pem)

    required_semantic_fields = all([
        isinstance(claim.get("claim_class"), str),
        isinstance(claim.get("claim_text"), str),
        isinstance(claim.get("does_not_establish"), list),
        isinstance(claim.get("falsifier"), str),
        isinstance(boundary.get("descriptor"), str),
        boundary.get("grounding_level") in {"SELF_ASSERTED","LOCALLY_OBSERVED","EXTERNALLY_ATTESTED"},
    ])

    cryptographic_validity = signature_valid and key_binding
    structural_validity = ceiling_bound and evidence_integrity and manifest_binding and required_semantic_fields

    return {
        "overall": "VALID" if (cryptographic_validity and structural_validity) else "INVALID",
        "signature_valid": signature_valid,
        "public_key_binding": key_binding,
        "manifest_binding": manifest_binding,
        "evidence_integrity": evidence_integrity,
        "claim_ceiling_bound": ceiling_bound,
        "semantic_fields_present": required_semantic_fields,
        "claim_class": claim.get("claim_class"),
        "claim_text": claim.get("claim_text"),
        "does_not_establish": claim.get("does_not_establish"),
        "falsifier": claim.get("falsifier"),
        "issuer_boundary_grounding_level": boundary.get("grounding_level"),
        "important_note": "VALID means this receipt passed cryptographic and structural checks. It does not independently establish that the producer's factual account is true or that a stronger downstream claim is admissible.",
    }
