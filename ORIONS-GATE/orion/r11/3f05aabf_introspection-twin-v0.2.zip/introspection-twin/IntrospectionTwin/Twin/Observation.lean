-- RECONSTRUCTED placeholder. Replace with the original `weaver/introspection-twin` file.
-- Per the independent replay (2026-10-04), the original names the identity field `agentId` and
-- also carries `timestamp`, `binaryUri`, `exitCode`, `inputDigest`, `outputDigest`. Those extra
-- fields are omitted here rather than guessed: `step` does not read them, so their types are
-- not this file's to invent. Only the fields below are load-bearing for `State.lean`.
namespace IntrospectionTwin.Twin

structure ToolRecord where
  digestSHA256 : String
deriving Repr, DecidableEq

structure Observation where
  agentId     : String
  sequenceId  : Nat
  toolRecord  : ToolRecord
  command     : String
  outputBytes : Nat
deriving Repr, DecidableEq

end IntrospectionTwin.Twin
