-- RECONSTRUCTED placeholder. Replace with the original `weaver/introspection-twin` file.
-- Fields inferred from their use in `step`; the independent replay reported no mismatch here.
namespace IntrospectionTwin.Twin

structure TwinBounds where
  agentIdentity    : String
  allowedTools     : List String
  commandAllowlist : List String
  maxOutputBytes   : Nat
  maxGasBudget     : Nat
deriving Repr, DecidableEq

end IntrospectionTwin.Twin
