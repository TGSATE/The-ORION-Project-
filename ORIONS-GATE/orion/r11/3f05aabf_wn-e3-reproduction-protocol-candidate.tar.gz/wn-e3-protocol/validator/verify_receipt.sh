#!/usr/bin/env bash
set -euo pipefail

RECEIPT="${1:-receipt.json}"
DIR="$(cd "$(dirname "$RECEIPT")" && pwd -P)"
RECEIPT="$DIR/$(basename "$RECEIPT")"
SIG="$DIR/receipt.json.sig"
PUB="$DIR/operator_public_key.pem"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

command -v python3 >/dev/null || { echo 'INDETERMINATE: python3 missing' >&2; exit 40; }
command -v openssl >/dev/null || { echo 'INDETERMINATE: openssl missing' >&2; exit 40; }
[ -f "$RECEIPT" ] || { echo 'INVALID: receipt missing' >&2; exit 2; }
[ -f "$SIG" ] || { echo 'INVALID: detached signature missing' >&2; exit 2; }
[ -f "$PUB" ] || { echo 'INVALID: operator public key missing' >&2; exit 2; }

python3 "$HERE/validate_receipt.py" "$RECEIPT" >/dev/null
openssl pkeyutl -verify -rawin -pubin -inkey "$PUB" -in "$RECEIPT" -sigfile "$SIG" >/dev/null 2>&1 || {
  echo 'INVALID: detached Ed25519 signature verification failed' >&2
  exit 2
}

SHA=$(python3 - <<PY
import hashlib
p=r'''$RECEIPT'''
print(hashlib.sha256(open(p,'rb').read()).hexdigest())
PY
)
printf 'VALID receipt_sha256=%s signature=PASS\n' "$SHA"
