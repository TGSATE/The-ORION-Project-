#!/usr/bin/env python3
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

HEX64 = re.compile(r"^[0-9a-f]{64}$")
GATES = [
    "gate_H_integrity",
    "gate_T_toolchain",
    "gate_B_clean_build",
    "gate_A_axiom_audit",
    "gate_M_A_proof_mutation",
    "gate_M_B_toolchain_mutation",
]
ALLOWED_GATE = {"PASS", "FAIL", "NOT_RUN"}
ALLOWED_VERDICT = {"ATTESTED", "FALSIFIED", "INDETERMINATE"}
ALLOWED_FAILURE = {
    None,
    "TYPE_I_ENVIRONMENTAL",
    "TYPE_II_INTEGRITY_OOB",
    "TYPE_III_AXIOMATIC_FORMAL",
    "TYPE_IV_HARNESS_BUG",
    "OTHER",
}

class ValidationError(Exception):
    pass

def require(cond, msg):
    if not cond:
        raise ValidationError(msg)

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def validate(data, receipt_path: Path):
    require(data.get("schema_version") == "WN-E3-REC-01", "bad schema_version")
    require(data.get("target_artifact") == "WN-E3-001", "bad target_artifact")
    require(data.get("semantic_class") == "INDEPENDENTLY_REPRODUCED", "bad semantic_class")

    verdict = data.get("verdict")
    require(verdict in ALLOWED_VERDICT, "bad verdict")

    op = data.get("operator_context") or {}
    require(isinstance(op.get("operator_id"), str) and op["operator_id"], "missing operator_id")
    require(op.get("independence_attestation") is True, "independence_attestation must be true")
    platform = op.get("execution_platform") or {}
    for k in ("os", "arch", "lean_version_reported"):
        require(isinstance(platform.get(k), str) and platform[k], f"missing execution_platform.{k}")

    d = data.get("digest_verification") or {}
    for k in (
        "expected_archive_sha256", "computed_archive_sha256",
        "expected_manifest_sha256", "computed_manifest_sha256",
    ):
        require(isinstance(d.get(k), str) and HEX64.match(d[k]), f"invalid {k}")
    require(isinstance(d.get("oob_channel_type"), str) and d["oob_channel_type"], "missing oob_channel_type")
    require(isinstance(d.get("oob_channel_reference"), str) and d["oob_channel_reference"], "missing oob_channel_reference")

    archive_match = d["expected_archive_sha256"] == d["computed_archive_sha256"]
    manifest_match = d["expected_manifest_sha256"] == d["computed_manifest_sha256"]
    pre_match = d.get("pre_execution_integrity_match")
    require(pre_match is (archive_match and manifest_match), "pre_execution_integrity_match inconsistent with digests")

    gates = data.get("gate_results") or {}
    for g in GATES:
        require(gates.get(g) in ALLOWED_GATE, f"invalid or missing {g}")
    all_pass = all(gates[g] == "PASS" for g in GATES)

    term = data.get("terminal_contract") or {}
    require(term.get("all_gates_conjoined_pass") is all_pass, "all_gates_conjoined_pass inconsistent with gate_results")
    failure = term.get("failure_classification")
    require(failure in ALLOWED_FAILURE, "invalid failure_classification")
    reproduced = term.get("independently_reproduced")
    require(isinstance(reproduced, bool), "independently_reproduced must be boolean")

    sig = data.get("signature_metadata") or {}
    require(sig.get("detached_signature_required") is True, "detached_signature_required must be true")
    require(sig.get("signature_filename") == "receipt.json.sig", "signature_filename must be receipt.json.sig")
    require(sig.get("signature_algorithm") == "ED25519_OPENSSL_RAW", "signature_algorithm must be ED25519_OPENSSL_RAW")
    require(sig.get("public_key_file") == "operator_public_key.pem", "public_key_file must be operator_public_key.pem")

    if verdict == "ATTESTED":
        require(pre_match is True, "ATTESTED requires pre-execution digest match")
        require(all_pass, "ATTESTED requires all six gates PASS")
        require(failure is None, "ATTESTED requires null failure_classification")
        require(reproduced is True, "ATTESTED requires independently_reproduced=true")
    else:
        require(reproduced is False, f"{verdict} requires independently_reproduced=false")
        require(not all_pass or pre_match is False, f"{verdict} inconsistent: all gates and digests pass")
        require(failure is not None, f"{verdict} requires failure_classification")

    if verdict == "INDETERMINATE":
        require(failure in {"TYPE_I_ENVIRONMENTAL", "OTHER"}, "INDETERMINATE should classify environmental/other insufficient evidence")

    if verdict == "FALSIFIED":
        require(failure != "TYPE_I_ENVIRONMENTAL", "environmental failure alone cannot be FALSIFIED")

    sig_path = receipt_path.with_name(sig["signature_filename"])
    require(sig_path.exists(), f"detached signature missing: {sig_path.name}")

    return {
        "status": "VALID",
        "verdict": verdict,
        "semantic_class": data["semantic_class"],
        "independently_reproduced": reproduced,
        "receipt_sha256": sha256_file(receipt_path),
        "signature_present": True,
    }

def main():
    p = argparse.ArgumentParser()
    p.add_argument("receipt", type=Path)
    args = p.parse_args()
    try:
        data = json.loads(args.receipt.read_text(encoding="utf-8"))
        out = validate(data, args.receipt)
    except (OSError, json.JSONDecodeError, ValidationError) as e:
        print(json.dumps({"status": "INVALID", "error": str(e)}, sort_keys=True))
        return 2
    print(json.dumps(out, sort_keys=True))
    return 0

if __name__ == "__main__":
    sys.exit(main())
