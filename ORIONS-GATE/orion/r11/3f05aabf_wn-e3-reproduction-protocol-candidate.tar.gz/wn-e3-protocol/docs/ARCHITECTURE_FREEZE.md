# Temporary ACTIVE-Track Freeze

Effective immediately for Weaver Nexus Systems:

> No new architecture track may enter ACTIVE state until WN-E3-001 reaches `ATTESTED`, unless a human governance override is explicitly recorded.

## While frozen

Allowed:
- Gate Zero repository governance
- CI check-name disambiguation
- registry reconciliation
- PR triage and closure
- #65 / #66 promotion work
- WN-E3-001 packaging, release, reproduction, falsification repair
- preservation of failures and evidence

Not allowed as new ACTIVE work:
- new architecture subsystems
- new governance layers unrelated to the critical path
- promotion of quarantined WGRSI layers
- production NMS/Crosswalk integration claims
- widening Cadence or Round Three scope

## Lift condition

`ArchitectureFreeze = false` iff either:
1. `WN-E3-001.verdict == ATTESTED`, or
2. an explicit human override is recorded with rationale, timestamp, operator identity, and authority scope.

`FALSIFIED` and `INDETERMINATE` do not automatically lift the freeze.
