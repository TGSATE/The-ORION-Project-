# Integration note

This candidate is intentionally separate from `release/wn-e3-001/` so the established kit subtree identity can remain unchanged.

Recommended repository destination after review:

`governance/wn-e3-reproduction/`

Do not place these files under `release/wn-e3-001/` unless the project intentionally revokes the old subtree identity and records a new one.

The release kit produces the reproduction observation; this protocol governs how an outside observation is classified and accepted.
