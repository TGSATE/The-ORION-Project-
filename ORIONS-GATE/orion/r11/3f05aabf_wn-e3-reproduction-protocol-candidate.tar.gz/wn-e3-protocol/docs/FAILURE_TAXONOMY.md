# Reproduction Failure Taxonomy

A failed command is not automatically artifact falsification.

## TYPE_I_ENVIRONMENTAL
Examples: wrong/missing Lean runtime, unsupported host tooling, host filesystem/symlink behavior, interrupted execution, unavailable prerequisite.

Default terminal verdict: `INDETERMINATE` unless evidence shows the released compatibility contract itself was violated.

## TYPE_II_INTEGRITY_OOB
Expected OOB digest differs from the locally computed archive or manifest digest before execution.

Terminal verdict: usually `FALSIFIED` for the delivered release instance / chain-of-custody contract. Do not execute the mismatched payload.

## TYPE_III_AXIOMATIC_FORMAL
Examples: exact theorem oracle mismatch, unauthorized axiom leakage, a required negative control is not rejected, or a claimed clean build fails under the supported frozen toolchain.

Terminal verdict: `FALSIFIED` when reproduced under the declared supported environment.

## TYPE_IV_HARNESS_BUG
Verifier or isolation logic is defective, ambiguous, fail-open, or incapable of distinguishing a required negative control.

Terminal verdict: `FALSIFIED` for the released reproduction protocol, not necessarily for the underlying theorem artifact.

## Preservation rule

Never erase or rewrite the original observed result. Later root-cause analysis is append-only metadata and may classify the run as environmental, harness, integrity, or artifact failure.
