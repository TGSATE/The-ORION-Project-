# WN-E3-001 Reproduction State Machine

Canonical semantic progression:

`PREPARING_FOR_RELEASE → RELEASED → ATTEMPTED → {ATTESTED, FALSIFIED, INDETERMINATE}`

## Terminal semantics

### ATTESTED
All six gates passed, OOB digests matched before execution, operator independence is attested, and the detached receipt signature is valid.

Effect:
- `semantic_class = INDEPENDENTLY_REPRODUCED`
- `independently_reproduced = true`
- only the bounded WN-E3-001 claim may be promoted
- authority remains unchanged

### FALSIFIED
A valid independent attempt reached the artifact/harness contract and produced evidence that the released object failed that contract.

Effect:
- preserve receipt + logs
- classify failure
- do not reinterpret as a pass
- cut a new candidate version after remediation
- architecture freeze remains active

### INDETERMINATE
The attempt cannot support either reproduction or falsification, e.g. missing prerequisites, unsupported host, interruption, incomplete execution, unverifiable signature, or other insufficient evidence.

Effect:
- preserve attempt
- no evidence promotion
- architecture freeze remains active

## Invariant

Only `ATTESTED` may set `independently_reproduced=true`.
