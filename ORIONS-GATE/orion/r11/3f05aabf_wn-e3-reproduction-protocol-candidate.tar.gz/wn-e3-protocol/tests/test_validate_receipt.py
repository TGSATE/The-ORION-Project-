import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

MOD_PATH = Path(__file__).resolve().parents[1] / "validator" / "validate_receipt.py"
spec = importlib.util.spec_from_file_location("validate_receipt", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def base_receipt():
    h = "a" * 64
    return {
        "schema_version": "WN-E3-REC-01",
        "target_artifact": "WN-E3-001",
        "semantic_class": "INDEPENDENTLY_REPRODUCED",
        "verdict": "ATTESTED",
        "timestamp_utc": "2026-10-04T12:00:00Z",
        "operator_context": {
            "operator_id": "operator:test",
            "independence_attestation": True,
            "execution_platform": {"os": "Linux", "arch": "x86_64", "lean_version_reported": "leanprover/lean4:v4.22.0"},
        },
        "digest_verification": {
            "oob_channel_type": "SIGNED_DISPATCH",
            "oob_channel_reference": "test-ref",
            "expected_archive_sha256": h,
            "computed_archive_sha256": h,
            "expected_manifest_sha256": h,
            "computed_manifest_sha256": h,
            "pre_execution_integrity_match": True,
        },
        "gate_results": {
            "gate_H_integrity": "PASS", "gate_T_toolchain": "PASS", "gate_B_clean_build": "PASS",
            "gate_A_axiom_audit": "PASS", "gate_M_A_proof_mutation": "PASS", "gate_M_B_toolchain_mutation": "PASS",
        },
        "terminal_contract": {"all_gates_conjoined_pass": True, "failure_classification": None, "independently_reproduced": True},
        "signature_metadata": {"detached_signature_required": True, "signature_filename": "receipt.json.sig", "signature_algorithm": "ED25519_OPENSSL_RAW", "public_key_file": "operator_public_key.pem"},
    }

class ReceiptTests(unittest.TestCase):
    def run_validate(self, r):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "receipt.json"
            p.write_text(json.dumps(r), encoding="utf-8")
            p.with_name("receipt.json.sig").write_bytes(b"sig")
            return mod.validate(r, p)

    def test_attested_valid(self):
        out = self.run_validate(base_receipt())
        self.assertTrue(out["independently_reproduced"])

    def test_attested_requires_all_gates(self):
        r = base_receipt(); r["gate_results"]["gate_A_axiom_audit"] = "FAIL"; r["terminal_contract"]["all_gates_conjoined_pass"] = False
        with self.assertRaises(mod.ValidationError): self.run_validate(r)

    def test_indeterminate_environment(self):
        r = base_receipt(); r["verdict"] = "INDETERMINATE"; r["gate_results"]["gate_B_clean_build"] = "NOT_RUN"
        r["terminal_contract"] = {"all_gates_conjoined_pass": False, "failure_classification": "TYPE_I_ENVIRONMENTAL", "independently_reproduced": False}
        out = self.run_validate(r); self.assertFalse(out["independently_reproduced"])

    def test_environment_not_falsified(self):
        r = base_receipt(); r["verdict"] = "FALSIFIED"; r["gate_results"]["gate_B_clean_build"] = "FAIL"
        r["terminal_contract"] = {"all_gates_conjoined_pass": False, "failure_classification": "TYPE_I_ENVIRONMENTAL", "independently_reproduced": False}
        with self.assertRaises(mod.ValidationError): self.run_validate(r)

    def test_digest_flag_must_match_values(self):
        r = base_receipt(); r["digest_verification"]["computed_archive_sha256"] = "b" * 64
        with self.assertRaises(mod.ValidationError): self.run_validate(r)

    def test_falsified_formal(self):
        r = base_receipt(); r["verdict"] = "FALSIFIED"; r["gate_results"]["gate_A_axiom_audit"] = "FAIL"
        r["terminal_contract"] = {"all_gates_conjoined_pass": False, "failure_classification": "TYPE_III_AXIOMATIC_FORMAL", "independently_reproduced": False}
        out = self.run_validate(r); self.assertEqual(out["verdict"], "FALSIFIED")

    def test_missing_signature_rejected(self):
        r = base_receipt()
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "receipt.json"; p.write_text(json.dumps(r), encoding="utf-8")
            with self.assertRaises(mod.ValidationError): mod.validate(r, p)

if __name__ == "__main__":
    unittest.main()
