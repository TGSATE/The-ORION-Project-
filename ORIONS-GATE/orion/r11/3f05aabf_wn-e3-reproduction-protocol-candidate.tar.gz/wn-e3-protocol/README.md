# WN-E3 Reproduction Protocol Candidate

This package codifies the external-reproduction control plane for WN-E3-001 without modifying the byte-frozen `release/wn-e3-001/` kit subtree.

Status: CANDIDATE / NO EVIDENCE PROMOTION / AUTHORITY O0 WITHHELD

Contents:
- `schemas/WN-E3-REC-01.schema.json` — machine-readable receipt contract
- `validator/validate_receipt.py` — fail-closed stdlib validator
- `docs/STATE_MACHINE.md` — PREPARING → RELEASED → ATTEMPTED → {ATTESTED,FALSIFIED,INDETERMINATE}
- `docs/ARCHITECTURE_FREEZE.md` — temporary ACTIVE-track freeze policy
- `docs/FAILURE_TAXONOMY.md` — Type I–IV classification rules
- `tests/test_validate_receipt.py` — positive and negative regression tests

Key rules:
1. `INDEPENDENTLY_REPRODUCED` is a semantic class, never inferred from a numeric rung alone.
2. Only `verdict=ATTESTED` establishes `independently_reproduced=true`.
3. `FALSIFIED` requires a valid execution that contradicts the released contract.
4. Environment/prerequisite failures are `INDETERMINATE`, not artifact falsification.
5. The receipt JSON contains no embedded self-signature. Signature is detached as `receipt.json.sig`.
6. Expected archive + manifest digests must be received through a channel separate from the archive transport and checked before execution.
7. The architecture freeze remains active until ATTESTED or an explicit human override is recorded.

Detached signature acceptance uses Ed25519 with OpenSSL raw-input mode:

    openssl pkeyutl -sign -rawin -inkey operator_private_key.pem -in receipt.json -out receipt.json.sig
    bash validator/verify_receipt.sh receipt.json

The private key is never included in an evidence packet.
