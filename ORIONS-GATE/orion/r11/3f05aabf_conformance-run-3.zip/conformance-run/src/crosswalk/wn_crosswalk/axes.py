"""Canonical axes and the shared denotation vocabulary.

A ladder is never translated label-to-label. Every rung declares a *denotation*
drawn from a fixed vocabulary, and translation runs through the denotation.
Labels are compared separately, and only ever to lower a reading.

Four kinds of axis are defined. They measure different things and are not
interchangeable:

  evidence   E0-E6  epistemic_support        what has been shown
  authority  O0-O4  organizational_standing  who stands behind it
  standing   S0-S4  organizational_standing  proposed replacement for authority
  permission O0-O4  permission_to_act        proposed; what a system may do
  assurance  A0-A5  assurance_stage          proposed; how far assurance has run

`evidence` and `authority` are in force. `standing`, `permission` and
`assurance` are registered because amendment AM-001 proposes splitting the
overloaded O0-O4 label space three ways. The amendment is NOT applied here:
adopting it would relabel every existing O-claim in the corpus, which is a
constitutional change and not a code change. See `wn_crosswalk amendments`.
"""

from __future__ import annotations

EVIDENCE = "evidence"
AUTHORITY = "authority"
STANDING = "standing"
PERMISSION = "permission"
ASSURANCE = "assurance"

ALL_AXES = (EVIDENCE, AUTHORITY, STANDING, PERMISSION, ASSURANCE)
IN_FORCE = (EVIDENCE, AUTHORITY)

CANONICAL_KIND = {
    EVIDENCE: "epistemic_support",
    AUTHORITY: "organizational_standing",
    STANDING: "organizational_standing",
    PERMISSION: "permission_to_act",
    ASSURANCE: "assurance_stage",
}

PREFIX = {EVIDENCE: "E", AUTHORITY: "O", STANDING: "S", PERMISSION: "O", ASSURANCE: "A"}
CEILING = {EVIDENCE: 6, AUTHORITY: 4, STANDING: 4, PERMISSION: 4, ASSURANCE: 5}

# --- evidence ---------------------------------------------------------------
# No E7/E8: deleted by HANDOFF-2026-07-26-CORRECTED; recurrence is class B-001.
EVIDENCE_DENOTATIONS: dict[str, int] = {
    "assertion": 0,
    "unbound_claim": 0,
    "narrative": 0,
    "specified": 1,
    "documented_architecture": 1,
    "implemented": 1,
    "inspected_artifact": 1,
    "executed_local": 2,
    "project_reported": 2,
    "tests_pass_author_machine": 2,
    "replayed_fresh_same_org": 3,
    "replayed_fresh_same_author": 3,
    "reproduced_independent": 4,
    "independent_review": 4,
    "adversarial_assessment": 4,
    "operational_validation": 5,
    "monitored_realistic_use": 5,
    "qualified_external_assessment": 6,
    "production_authorized": 6,
}

# --- organizational standing (axis `authority` now, `standing` under AM-001) -
STANDING_DENOTATIONS: dict[str, int] = {
    "individual_research_artifact": 0,
    "no_authority": 0,
    "internal_organizational": 1,
    "external_collaborator_validated": 2,
    "independent_institutional": 3,
    "broad_operational_recognition": 4,
}

# --- permission to act (proposed) -------------------------------------------
PERMISSION_DENOTATIONS: dict[str, int] = {
    "may_not_act": 0,
    "may_act_in_development": 1,
    "may_act_in_staging": 2,
    "may_act_in_limited_operation": 3,
    "may_act_in_production": 4,
}

# --- assurance stage (proposed) ---------------------------------------------
ASSURANCE_DENOTATIONS: dict[str, int] = {
    "assurance_not_assessed": 0,
    "assurance_designed": 1,
    "assurance_implemented": 2,
    "assurance_evaluated": 3,
    "assurance_controlled": 4,
    "assurance_qualified": 5,
}

DENOTATIONS = {
    EVIDENCE: EVIDENCE_DENOTATIONS,
    AUTHORITY: STANDING_DENOTATIONS,
    STANDING: STANDING_DENOTATIONS,
    PERMISSION: PERMISSION_DENOTATIONS,
    ASSURANCE: ASSURANCE_DENOTATIONS,
}

# Tokens that read as levels but are speech acts. A performative is not a rung;
# accepting one is how the master invariant gets breached without a number
# changing. Recorded failure mode: SXR-2026-08-04 "ACCEPTED".
PERFORMATIVE_TOKENS = frozenset(
    {
        "accepted",
        "approved",
        "canonical",
        "certified",
        "final",
        "frozen",
        "ratified",
        "sealed",
        "signed",
        "validated",
        "verified",
    }
)


def label(axis: str, ordinal: int) -> str:
    return f"{PREFIX[axis]}{ordinal}"


def denotation_ordinal(axis: str, key: str) -> int | None:
    return DENOTATIONS[axis].get(key)


def clamp(axis: str, ordinal: int) -> int:
    return max(0, min(ordinal, CEILING[axis]))
