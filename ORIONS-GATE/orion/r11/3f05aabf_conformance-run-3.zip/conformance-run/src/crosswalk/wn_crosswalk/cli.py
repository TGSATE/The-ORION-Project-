"""Command line surface for the Crosswalk Kernel."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from . import __version__, axes
from .adjudicate import RULESET_VERSION, adjudicate, exit_code, load_corpus, wrap
from .canon import canonical_bytes, digest
from .attest import sign_receipt, verify_receipt
from .collisions import detect
from .registry import Registry
from .translate import translate

BAR = "-" * 78
TOOL_LINE = f"wn_crosswalk {__version__} / {RULESET_VERSION}"


def _registry(args) -> Registry:
    return Registry.load(args.registry)


def cmd_adjudicate(args) -> int:
    registry = _registry(args)
    corpus = load_corpus(args.corpus)
    core = adjudicate(registry, corpus)
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    receipt = wrap(core, now)

    if args.out:
        Path(args.out).write_bytes(canonical_bytes(receipt) + b"\n")

    if args.json:
        sys.stdout.write(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
        return exit_code(core)

    agg = core["aggregate"]
    print(BAR)
    print(f"CROSSWALK ADJUDICATION  {core['corpus']['corpus_id']}  ({core['corpus']['baseline']})")
    print(BAR)
    print(f"{'ARTIFACT':<30} {'STATED':<26} {'READS':<6} {'WITNESS':<22}")
    for item in core["artifacts"]:
        stated = item["stated"]["evidence"]
        if len(stated) > 25:
            stated = stated[:24] + "\u2026"
        reads = axes.label(axes.EVIDENCE, item["evidence_ordinal"])
        claimed = max(
            item["reading"]["label_reading"] or 0,
            item["reading"]["denotation_reading"] or 0,
        )
        moved = "\u2193" if item["evidence_ordinal"] < claimed else " "
        print(f"{item['artifact_id']:<30} {stated:<26} {reads:<5}{moved} {item['witness_class']:<22}")
    print(BAR)
    print(f"evidence ceiling            {agg['evidence_ceiling']}")
    print(f"independent reproductions   {agg['independent_reproduction_count']}")
    print(f"authority                   {agg['authority']}")
    print(f"production                  {agg['production']}")
    print(f"unsafe labels               {', '.join(core['unsafe_labels']) or 'none'}")
    counts = agg["finding_severity_counts"]
    print("findings                    " + ", ".join(f"{k} {counts[k]}" for k in sorted(counts)))
    print(f"registry                    {agg['registry_ratification']}")
    print(f"results are                 {agg['adoptability']}")
    print(f"core_sha256                 {receipt['envelope']['core_sha256']}")
    print(BAR)

    if args.findings:
        for item in core["artifacts"]:
            if not item["findings"]:
                continue
            print(f"\n{item['artifact_id']}  {item['name']}")
            for finding in item["findings"]:
                print(f"  [{finding['severity']}] {finding['code']}")
                print(f"        {finding['detail']}")

    return exit_code(core)


def cmd_ratification(args) -> int:
    registry = _registry(args)
    state = registry.ratification()
    audit = state["source_audit"]
    if args.json:
        sys.stdout.write(json.dumps(state, indent=2, sort_keys=True) + "\n")
        return 0 if state["status"] == "RATIFIED" else 1
    print(BAR)
    print(f"REGISTRY RATIFICATION: {state['status']}")
    print(BAR)
    counts = audit["counts"]
    print(f"rungs                 {audit['rung_total']}")
    print(f"  bound               {counts['bound']}   (document + version + locator + digest + decision)")
    print(f"  cited               {counts['cited']}   (citation present, document digest missing)")
    print(f"  unbound             {counts['unbound']}")
    print(f"ladder_set_digest     {state['ladder_set_digest']}")
    print()
    for reason in state["reasons"]:
        print(f"  BLOCKS RATIFICATION: {reason}")
    print(f"\n{state['consequence']}")
    if args.list_unbound:
        print(f"\nunbound rungs ({len(audit['unbound_rungs'])}):")
        for rung in audit["unbound_rungs"]:
            print(f"  {rung}")
    print(BAR)
    return 0 if state["status"] == "RATIFIED" else 1


def cmd_amendments(args) -> int:
    registry = _registry(args)
    report = registry.amendment_report()
    if args.json:
        sys.stdout.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
        return 0
    if not report:
        print("no registered amendments")
        return 0
    for amendment in report:
        print(BAR)
        print(f"{amendment['amendment_id']}  [{amendment['status'].upper()}]  {amendment['title']}")
        print(BAR)
        print(f"\nwhy\n  {amendment['rationale']}")
        print(f"\ncost\n  {amendment['cost']}")
        print("\nwhat it would change")
        for move in amendment["ladder_moves"]:
            print(f"  {move['ladder_id']}: {move['from_axis']} -> {move['to_axis']}")
            print(f"      currently refused: {move['currently_refused']}   {move['effect']}")
        print("\nrequires before it can be applied")
        for item in amendment["requires"]:
            print(f"  - {item}")
        print("\nNot applied. This tool does not amend the axis it is measured against.")
    return 0


def cmd_attest(args) -> int:
    receipt = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
    if args.sign_with:
        seed = bytes.fromhex(Path(args.sign_with).read_text(encoding="utf-8").strip())
        receipt = sign_receipt(receipt, seed)
        Path(args.receipt).write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n",
                                      encoding="utf-8")
        print(f"signed {args.receipt}")
    result = verify_receipt(receipt)
    if args.json:
        sys.stdout.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
        return 0 if result["verified"] and result["identity_fields_complete"] else 1
    print(BAR)
    print("WITNESS RECEIPT ATTESTATION")
    print(BAR)
    print(f"signature present     {result['signature_present']}")
    print(f"algorithm             {result['algorithm']}")
    print(f"signature verifies    {result['verified']}")
    print(f"key fingerprint       {result['key_fingerprint']}")
    print(f"preimage sha256       {result['preimage_digest']}")
    print(f"identity complete     {result['identity_fields_complete']}")
    for problem in result["problems"]:
        print(f"  PROBLEM: {problem}")
    if result["establishes"]:
        print("\nestablishes")
        for item in result["establishes"]:
            print(f"  + {item}")
    print("\ndoes NOT establish")
    for item in result["does_not_establish"]:
        print(f"  - {item}")
    print(BAR)
    return 0 if result["verified"] and result["identity_fields_complete"] else 1


def cmd_collisions(args) -> int:
    registry = _registry(args)
    found = detect(registry)
    if args.json:
        sys.stdout.write(json.dumps(found, indent=2, sort_keys=True) + "\n")
        return 2 if found else 0
    if not found:
        print("no label collisions")
        return 0
    print(BAR)
    print(f"LABEL COLLISIONS  {len(found)} labels carry more than one meaning")
    print(BAR)
    for item in found:
        print(f"\n[{item['severity']}] {item['axis']} label {item['label']}  "
              f"{item['distinct_meanings']} meanings, kinds: {', '.join(item['distinct_kinds'])}")
        for use in item["uses"]:
            marker = "*" if use["denotes"] == item["canonical_meaning"] else " "
            print(f"  {marker} {use['ladder_id']:<28} {use['denotes']:<32} -> {use['canonical_label']}")
    print(f"\n{BAR}\n* = agrees with the canonical meaning")
    return 2


def cmd_translate(args) -> int:
    registry = _registry(args)
    reading = translate(registry, args.axis, args.ladder, args.label)
    print(f"{args.ladder}:{args.label}  ->  {reading.normalized_label}")
    print(f"  denotes            {reading.denotes}")
    print(f"  label reading      {reading.label_reading}")
    print(f"  denotation reading {reading.denotation_reading}")
    for finding in reading.findings:
        print(f"  [{finding.severity}] {finding.code}: {finding.detail}")
    return 2 if any(f.severity == "P0" for f in reading.findings) else 0


def cmd_verify(args) -> int:
    expected_path = Path(args.expected).resolve()
    expected = json.loads(expected_path.read_text(encoding="utf-8"))
    base = expected_path.parent.parent
    registry = Registry.load(args.registry or base / expected["registry_path"])
    corpus = load_corpus(base / expected["corpus_path"])
    core = adjudicate(registry, corpus)
    actual = digest(core)
    match = actual == expected["core_sha256"]
    print(f"expected core_sha256  {expected['core_sha256']}")
    print(f"actual   core_sha256  {actual}")
    print(f"tool                  {TOOL_LINE}")
    print("RESULT: MATCH" if match else "RESULT: DIVERGENCE")
    if not match:
        print("\nA divergence here is a real finding, not a nuisance. Report the platform,")
        print("Python version and the actual digest rather than adjusting the expectation.")
    return 0 if match else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wn_crosswalk",
        description="Translate any evidence or authority claim into the canonical axis.",
    )
    parser.add_argument("--version", action="version", version=f"wn_crosswalk {__version__}")
    parser.add_argument("--registry", default=None, help="path to ladders.json")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("adjudicate", help="adjudicate a corpus of claims")
    p.add_argument("corpus")
    p.add_argument("-o", "--out", help="write the receipt here")
    p.add_argument("--json", action="store_true")
    p.add_argument("--findings", action="store_true", help="print every finding")
    p.set_defaults(func=cmd_adjudicate)

    p = sub.add_parser("collisions", help="labels that mean more than one thing")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_collisions)

    p = sub.add_parser("translate", help="translate a single rung")
    p.add_argument("axis", choices=[axes.EVIDENCE, axes.AUTHORITY])
    p.add_argument("ladder")
    p.add_argument("label")
    p.set_defaults(func=cmd_translate)

    p = sub.add_parser("ratification", help="is the registry ratified, and if not why not")
    p.add_argument("--json", action="store_true")
    p.add_argument("--list-unbound", action="store_true", help="print every unbound rung")
    p.set_defaults(func=cmd_ratification)

    p = sub.add_parser("amendments", help="registered amendment proposals and their effects")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_amendments)

    p = sub.add_parser("attest", help="verify (or sign) a witness receipt")
    p.add_argument("receipt")
    p.add_argument("--sign-with", metavar="SEEDFILE", help="hex ed25519 seed; signs then verifies")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_attest)

    p = sub.add_parser("verify", help="check a receipt against an expectation file")
    p.add_argument("--expected", required=True)
    p.set_defaults(func=cmd_verify)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)
