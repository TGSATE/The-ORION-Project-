"""Translate a rung stated in any ladder into the canonical axis.

The rule, in one line:

    normalized = min(what the label says, what the definition says)

Both readings are computed independently. The label reading is the position the
number occupies on the canonical axis. The denotation reading is where the
rung's own written definition lands. When they disagree, the disagreement is
itself the finding, and the lower reading wins.

This generalizes both recorded taxonomy failures:

  HANDOFF-2026-08-03  label E2, definition "an independent observer can
                      reproduce" -> canonical E4.  min = E2.
                      A low label smuggling a high claim.

  Sealkit local       label E4, definition "gates pass on the author machine"
                      -> canonical E2.  min = E2.
                      A high label resting on a local run.

No rule in this module can raise a reading. Combinator within a claim is FLOOR,
matching handoff_adjudicator v0.1.0.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import axes
from .registry import BOUND, CITED, STATUS_FINDING, Registry

SEVERITIES = ("P0", "P1", "P2", "info")


@dataclass
class Finding:
    code: str
    severity: str
    detail: str

    def to_dict(self) -> dict:
        return {"code": self.code, "severity": self.severity, "detail": self.detail}


@dataclass
class Reading:
    axis: str
    ladder_id: str
    stated_label: str
    normalized_ordinal: int
    label_reading: int | None = None
    denotation_reading: int | None = None
    denotes: str | None = None
    findings: list[Finding] = field(default_factory=list)

    @property
    def normalized_label(self) -> str:
        return axes.label(self.axis, self.normalized_ordinal)

    def to_dict(self) -> dict:
        return {
            "axis": self.axis,
            "ladder_id": self.ladder_id,
            "stated_label": self.stated_label,
            "denotes": self.denotes,
            "label_reading": self.label_reading,
            "denotation_reading": self.denotation_reading,
            "normalized_ordinal": self.normalized_ordinal,
            "normalized_label": self.normalized_label,
            "findings": [f.to_dict() for f in self.findings],
        }


def _floor(reading: Reading, ordinal: int) -> None:
    reading.normalized_ordinal = min(reading.normalized_ordinal, ordinal)


def is_performative(label: str) -> bool:
    token = "".join(ch for ch in label.strip().lower() if ch.isalpha())
    return token in axes.PERFORMATIVE_TOKENS


def translate(registry: Registry, axis: str, ladder_id: str, stated_label: str) -> Reading:
    reading = Reading(
        axis=axis,
        ladder_id=ladder_id,
        stated_label=stated_label,
        normalized_ordinal=axes.CEILING[axis],
    )

    if is_performative(stated_label):
        reading.findings.append(
            Finding(
                "PERFORMATIVE_NOT_LEVEL",
                "P0",
                f"{stated_label!r} is a speech act, not a rung. Declaring a thing accepted "
                "does not place it on an axis.",
            )
        )
        reading.normalized_ordinal = 0
        return reading

    ladder = registry.get(ladder_id)
    if ladder is None:
        reading.findings.append(
            Finding("UNKNOWN_LADDER", "P0", f"ladder {ladder_id!r} is not in the registry")
        )
        reading.normalized_ordinal = 0
        return reading

    if ladder.axis != axis:
        reading.findings.append(
            Finding(
                "AXIS_MISMATCH",
                "P0",
                f"ladder {ladder_id!r} is an {ladder.axis} ladder, read as {axis}",
            )
        )
        reading.normalized_ordinal = 0
        return reading

    code, severity = STATUS_FINDING[ladder.status]
    if code:
        reading.findings.append(
            Finding(code, severity, f"ladder {ladder_id!r} has status {ladder.status!r}: {ladder.source}")
        )

    rung = ladder.rungs.get(stated_label)
    if rung is None:
        reading.findings.append(
            Finding(
                "UNKNOWN_RUNG",
                "P0",
                f"{stated_label!r} is not a rung of {ladder_id!r}; missing evidence is not approval",
            )
        )
        reading.normalized_ordinal = 0
        return reading

    reading.denotes = rung.denotes

    # Different kinds of axis are not translatable by number. This is the
    # refusal that keeps three incompatible O0-O4 ladders from being averaged
    # into one meaning.
    if not ladder.is_canonical_kind:
        reading.findings.append(
            Finding(
                "AXIS_KIND_MISMATCH",
                "P0",
                f"{ladder_id!r} is kind {ladder.kind!r}; the canonical {axis} axis is kind "
                f"{axes.CANONICAL_KIND[axis]!r}. Same labels, different meanings; refused rather "
                "than mapped.",
            )
        )
        reading.normalized_ordinal = 0
        return reading

    denotation_reading = axes.denotation_ordinal(axis, rung.denotes)
    reading.denotation_reading = denotation_reading
    _floor(reading, denotation_reading)

    if ladder.label_comparable:
        if rung.ordinal > axes.CEILING[axis]:
            reading.findings.append(
                Finding(
                    "OUT_OF_RANGE_RUNG",
                    "P0",
                    f"{stated_label} sits above the canonical ceiling "
                    f"{axes.label(axis, axes.CEILING[axis])}; the rung does not exist on this axis",
                )
            )
        label_reading = axes.clamp(axis, rung.ordinal)
        reading.label_reading = label_reading
        _floor(reading, label_reading)

        if label_reading > denotation_reading:
            reading.findings.append(
                Finding(
                    "LABEL_INFLATION",
                    "P0",
                    f"{stated_label} sits at {axes.label(axis, label_reading)} by number but "
                    f"denotes {rung.denotes!r} = {axes.label(axis, denotation_reading)}. "
                    "The number is stronger than the thing it names.",
                )
            )
        elif denotation_reading > label_reading:
            reading.findings.append(
                Finding(
                    "DENOTATION_INFLATION",
                    "P0",
                    f"{stated_label} sits at {axes.label(axis, label_reading)} by number but "
                    f"denotes {rung.denotes!r} = {axes.label(axis, denotation_reading)}. "
                    "A modest-looking label carrying a large claim is the harder failure to "
                    "notice.",
                )
            )
    else:
        reading.findings.append(
            Finding(
                "LABEL_NOT_COMPARABLE",
                "info",
                f"{ladder_id!r} does not share the canonical label space; read by denotation only",
            )
        )

    if rung.binding != BOUND:
        reading.findings.append(
            Finding(
                "UNBOUND_RUNG" if rung.binding != CITED else "UNDIGESTED_RUNG",
                "P1",
                f"{ladder_id}:{stated_label} does not cite a governing document with a "
                "digest, so this mapping is recorded but not ratified; the result is "
                "advisory",
            )
        )

    if not rung.pinned:
        reading.findings.append(
            Finding(
                "DERIVED_MAPPING",
                "P2",
                f"the mapping for {stated_label} in {ladder_id!r} is derived, not ratified; "
                "it may only lower a reading, never support one",
            )
        )

    return reading
