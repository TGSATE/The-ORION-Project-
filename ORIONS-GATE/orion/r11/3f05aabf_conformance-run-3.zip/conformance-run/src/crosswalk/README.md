# WN-XWK-001 — Crosswalk Kernel v0.2.0

One candidate axis. Every other ladder translated into it at whichever reading
grants the least authority.

> **Status: the registry is UNRATIFIED.** Every result this tool produces is
> `ADVISORY_ONLY` and may not be recorded as a portfolio status decision. That
> is not a disclaimer in prose — it is computed, it appears in every receipt,
> and it will keep saying so until every canonical rung cites the governing
> document that fixed it and an accountable human adopts the ladder set by
> digest. Run `wn_crosswalk ratification` to see what is missing.

## Why this exists

Four times now, the same failure has been recorded in this portfolio, and each
time it arrived by relabelling rather than by code:

| | incident | what happened |
|---|---|---|
| 1 | B-001 H7-CORPUS | E7/E8 rungs in use after being deleted from the taxonomy |
| 2 | HANDOFF-2026-08-03 | a document-local ladder whose **E2 means "an independent observer can reproduce"** — canonically E4, the exact rung the portfolio has zero of |
| 3 | SXR-2026-08-04 | E0–E8 reproposed as canonical; O0–O4 redefined as permission-to-act against the organizational-standing axis; closure asserted with the word ACCEPTED |
| 4 | 2026-08-06 handoff | Sealkit's local ladder calls an author-machine run E4; the portfolio axis calls it E2 |

Step 1 of the portfolio's own critical path is *freeze one taxonomy*. A frozen
taxonomy that lives only in prose gets re-forked by the next document. This is
the taxonomy as an executable artifact: a registry of every ladder known to
exist in the corpus, and a translator that refuses to be generous.

It complements `handoff_adjudicator` v0.1.0 rather than replacing it. The
adjudicator judges a document's claims. This judges the *axes those claims are
stated on*, and is the thing the adjudicator should consult when a claim
arrives wearing an unfamiliar ladder.

## The rule

```
normalized = min(what the label says, what the definition says)
```

Both readings are computed independently. The label reading is where the
number sits on the canonical axis. The denotation reading is where the rung's
own written definition lands. When they disagree, the disagreement is the
finding, and the lower reading wins.

This one line covers both directions of the failure:

- **Label inflation** — Sealkit `E4` denoting "gates pass on the author machine"
  = canonical E2. The number is stronger than the thing it names.
- **Denotation inflation** — HANDOFF-2026-08-03 `E2` denoting "an independent
  observer can reproduce" = canonical E4. A modest-looking label carrying a
  large claim, which is the harder failure to notice, because nobody
  double-checks a low number.

Both land at E2. Neither is trusted upward.

## What it refuses to do

Some things are not translation problems and are not treated as one.

**Different kinds of axis are refused, not mapped.** Three ladders in this
corpus claim the O0–O4 label space: the canonical one means *organizational
standing*, SXR's means *permission to act*, CSAA runs O0–O5 as *assurance
stage*. A number cannot be carried between them. Any claim stated on a
non-canonical-kind authority ladder reads O0 with a P0 finding.

**Speech acts are not levels.** `ACCEPTED`, `SEALED`, `FINAL`, `VERIFIED`,
`CANONICAL` read as E0/O0. Declaring a thing accepted does not place it on an
axis. This is the recorded failure mode where the master invariant is breached
without any number changing.

**No rule can raise a reading.** Enforced by a test that walks every rung of
every registered ladder and asserts the result never exceeds that rung's own
strongest self-reading.

## Guard rails after translation

Constraints already ratified elsewhere in the portfolio, enforced by execution
rather than by remembering:

| | rule | effect |
|---|---|---|
| G-01 | receipt rule | E3+ requires a receipt digest **and** a witness identity binding, else E2, fail-closed |
| G-02 | witness independence | no witness or self as witness caps at E2; same organization caps at E3; independent requires a signature and an externally checkable identity |
| G-03 | substrate | simulation caps at E2 — simulation is not physical verification |
| G-04 | supersession | superseded artifacts contribute nothing to the ceiling |
| G-05 | mythos quarantine | mythos carries no runtime evidence |
| G-06 | composition floor | a composite cannot show more than its weakest declared part |
| G-07 | authority firewall | authority above O0 requires a ratification record naming an accountable human and a date; authority is granted, never derived |
| G-08 | track separation | research and mythos carry no runtime authority |
| G-09 | claim binding | a claim above E1 must record an `artifact_digest` — named is not located, located is not verified |
| G-10 | extraction provenance | a claim read out of prose cannot itself carry replay or independence; caps at E2 until the extraction is verified |

Combinators, inherited from `handoff_adjudicator`: **floor within an artifact**
(fail-closed), **max across the portfolio** (a ceiling is the best thing that
can be shown, not the worst sentence written).

## Result on the 2026-08-06 corpus

```
evidence ceiling            E2
independent reproductions   0
authority                   O0
production                  PROHIBITED
registry                    UNRATIFIED
results are                 ADVISORY_ONLY
findings                    P0 19, P1 34, P2 3, info 1
unsafe labels               11 of 11
claims naming their bytes   3 of 17
```

The headline matches the handoff's own summary — but it is now *derived from
the claims* rather than asserted alongside them. Three results worth reading
twice:

1. **Every rung label in the corpus is ambiguous.** All six E-labels and all
   five O-labels mean more than one thing across the registered ladders. There
   is currently no evidence label that can be written unqualified in portfolio
   prose without being wrong somewhere.
2. **The E2 ceiling rests on exactly one artifact.** Under G-09, a claim of
   local execution has to identify the bytes that were executed. Three of
   seventeen entries record an artifact digest; only Cathedral Guard v0.2.0
   both names its bytes and claims execution. Sealkit, Shock Kernel, the RSI
   Corridor and the Lucifer Latch all drop to E1 — not because the work is
   weaker, but because the corpus does not say *which bytes* the work was done
   on.
3. **AEGIS Agent Gate reads E1, not E2** — the composition floor pulls it down
   to its parts. The near-term product is capped by the runtime beneath it.
4. **The E4 line is empty, for two reasons rather than one.** Most claims are
   stopped before E2 by G-09. The ones that clear it are stopped at E2 by G-02:
   a candidate may not control its own acceptance.

## Use

```
python3 -m unittest discover -s tests
python3 -m wn_crosswalk adjudicate corpus/wn-2026-08-06.json --findings
python3 -m wn_crosswalk collisions
python3 -m wn_crosswalk translate evidence handoff.2026-08-03 E2
python3 -m wn_crosswalk verify --expected witness/EXPECTED.json
```

Exit codes: `0` nothing found, `1` findings below P0, `2` at least one P0.

Python 3.11+. No third-party dependencies, by design — see `REPRODUCE.md`.

## Witness attestation

`wn_crosswalk attest <receipt.json>` verifies an Ed25519 signature over the
canonical bytes of a witness receipt with its signature value removed. The
Ed25519 implementation is ~120 lines of stdlib integer arithmetic, so the
dependency closure stays empty; it is cross-checked against the `cryptography`
package in the test suite, and where that package is absent the test **skips
and says the implementation is unconfirmed on that machine** rather than
passing quietly.

What a verified signature establishes: the holder of a specific key signed
exactly these fields, and they have not changed since. What it does not
establish: that the key belongs to the named principal, that the signer is
independent, or that they ran anything. A witness block in a corpus can no
longer reach `INDEPENDENT` by asserting `signed: true` — it needs a
verification result and a quotable key fingerprint.

## Amendments

`wn_crosswalk amendments` reports registered proposals to change the axes
themselves. AM-001 proposes splitting the overloaded O-label space into
standing (S0–S4), permission (O0–O4) and assurance (A0–A5). It is **registered
and not applied.** Adopting it would relabel every existing O-claim in the
corpus, which is a constitutional change under R7. A tool that quietly amends
the axis it is measured against is the failure mode this kernel exists to
detect, so the amendment sits in the registry with its six preconditions
listed, waiting for a human.

## Adding a ladder

Ladders are data, in `registry/ladders.json`. A rung must declare a
`denotes` drawn from the shared vocabulary in `axes.py`; the registry refuses
to load otherwise, so a new ladder cannot introduce a new meaning by accident.
Mark a mapping `"pinned": true` only when a governing document actually fixes
it. Unpinned mappings are reported as derived and may only lower a reading.

Every rung also carries a `source` block. A rung is *bound* only when it cites
a document, version, locator, decision-maker, decision date **and** a document
digest. Until every canonical rung is bound, `ratification` reports UNRATIFIED
and every result is advisory. All 76 rungs currently ship unbound, with the
document name pre-filled where it is known — the audit is a fill-in-the-blanks
task, not a rewrite.

Registering a ladder is not endorsing it. `status` records what the portfolio
has decided about it — `canonical`, `local`, `superseded`,
`adjudicated_nonconformant`, `rejected`, `retired` — and shows up as a finding
whenever it is used.

## Non-claims

- This is evidence about labels and claims, not about the artifacts behind them.
- A conformant label is not a correct implementation.
- Running this tool is not an independent reproduction of anything it adjudicates.
- Reproducing this tool on another machine is E3/E4-class evidence **for this
  tool only** and raises nothing else.
- No authority is granted by anything in this package.
- The declared corpus normalizes to E2. That is not a finding that the
  underlying artifacts deserve E2: no package here was opened, executed, or
  checked.
- The registry is unratified, so no result here is adoptable as portfolio
  status.
