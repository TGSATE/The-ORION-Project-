"""Test suite for the Crosswalk Kernel. Standard library only."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from wn_crosswalk import axes, rules  # noqa: E402
from wn_crosswalk.adjudicate import adjudicate, exit_code, load_corpus, wrap  # noqa: E402
from wn_crosswalk.canon import CanonError, canonical_bytes, digest  # noqa: E402
from wn_crosswalk.collisions import detect  # noqa: E402
from wn_crosswalk.registry import Registry, RegistryError  # noqa: E402
from wn_crosswalk.translate import Finding, translate  # noqa: E402
from wn_crosswalk import attest, ed25519, schema  # noqa: E402
from wn_crosswalk.attest import sign_receipt, verify_receipt  # noqa: E402

CORPUS_PATH = ROOT / "corpus" / "wn-2026-08-06.json"
REGISTRY = Registry.load()
CORPUS = load_corpus(CORPUS_PATH)
REGISTRY_TEXT = (ROOT / "registry" / "ladders.json").read_text(encoding="utf-8")


def codes(reading) -> set[str]:
    return {f.code for f in reading.findings}


class TestCanon(unittest.TestCase):
    def test_keys_are_sorted(self):
        self.assertEqual(canonical_bytes({"b": 1, "a": 2}), b'{"a":2,"b":1}')

    def test_key_order_does_not_change_digest(self):
        self.assertEqual(digest({"a": 1, "b": [1, 2]}), digest({"b": [1, 2], "a": 1}))

    def test_floats_refused(self):
        with self.assertRaises(CanonError):
            canonical_bytes({"x": 1.5})

    def test_large_ints_refused(self):
        with self.assertRaises(CanonError):
            canonical_bytes({"x": 2**53})
        canonical_bytes({"x": 2**53 - 1})

    def test_non_string_keys_refused(self):
        with self.assertRaises(CanonError):
            canonical_bytes({1: "a"})

    def test_nfc_collision_refused(self):
        # U+00E9 and "e" + U+0301 normalize to the same key.
        with self.assertRaises(CanonError):
            canonical_bytes({"caf\u00e9": 1, "cafe\u0301": 2})

    def test_nfc_applied_to_values(self):
        self.assertEqual(digest({"k": "caf\u00e9"}), digest({"k": "cafe\u0301"}))

    def test_unsupported_type_refused(self):
        with self.assertRaises(CanonError):
            canonical_bytes({"x": {1, 2}})


class TestRegistry(unittest.TestCase):
    def test_loads_canonical_ladders(self):
        self.assertIsNotNone(REGISTRY.get("wn.core"))
        self.assertIsNotNone(REGISTRY.get("wn.core.authority"))

    def test_every_rung_uses_the_shared_vocabulary(self):
        for ladder in REGISTRY.ladders.values():
            for rung in ladder.rungs.values():
                self.assertIsNotNone(
                    axes.denotation_ordinal(ladder.axis, rung.denotes),
                    f"{ladder.ladder_id}:{rung.label} denotes {rung.denotes}",
                )

    def test_unknown_denotation_refused(self):
        bad = {
            "schema": "wn.crosswalk.registry/2",
            "registry_version": "test",
            "ladders": [
                {
                    "ladder_id": "x",
                    "axis": "evidence",
                    "kind": "epistemic_support",
                    "status": "local",
                    "label_comparable": True,
                    "rungs": [{"label": "E0", "ordinal": 0, "denotes": "vibes"}],
                }
            ],
        }
        path = Path(self.enterContext(__import__("tempfile").TemporaryDirectory())) / "r.json"
        path.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(RegistryError):
            Registry.load(path)

    def test_fingerprint_is_stable(self):
        self.assertEqual(digest(REGISTRY.fingerprint()), digest(Registry.load().fingerprint()))


class TestTranslate(unittest.TestCase):
    def test_canonical_rung_is_identity(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "wn.core", "E2")
        self.assertEqual(reading.normalized_ordinal, 2)
        self.assertNotIn("LABEL_INFLATION", codes(reading))
        self.assertNotIn("DENOTATION_INFLATION", codes(reading))

    def test_incident_2026_08_03_low_label_high_claim(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "handoff.2026-08-03", "E2")
        self.assertEqual(reading.denotation_reading, 4)
        self.assertEqual(reading.label_reading, 2)
        self.assertEqual(reading.normalized_ordinal, 2)
        self.assertIn("DENOTATION_INFLATION", codes(reading))

    def test_incident_sealkit_high_label_local_run(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "sealkit.local", "E4")
        self.assertEqual(reading.label_reading, 4)
        self.assertEqual(reading.denotation_reading, 2)
        self.assertEqual(reading.normalized_ordinal, 2)
        self.assertIn("LABEL_INFLATION", codes(reading))

    def test_sealkit_pinned_crosswalk_matches_the_handoff(self):
        # The 2026-08-06 handoff pins local E4->E2, E5->E3, E6->E4.
        for local, expected in (("E4", 2), ("E5", 3), ("E6", 4)):
            reading = translate(REGISTRY, axes.EVIDENCE, "sealkit.local", local)
            self.assertEqual(reading.denotation_reading, expected, local)

    def test_retired_rungs_clamp_and_report(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "h7-corpus", "E8")
        self.assertIn("OUT_OF_RANGE_RUNG", codes(reading))
        self.assertIn("RETIRED_LADDER", codes(reading))
        self.assertLessEqual(reading.normalized_ordinal, axes.CEILING[axes.EVIDENCE])

    def test_rejected_ladder_still_translates_but_reports(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "sxr.2026-08-04", "E5")
        self.assertIn("REJECTED_LADDER", codes(reading))
        self.assertEqual(reading.normalized_ordinal, 4)

    def test_authority_kind_mismatch_is_refused_not_mapped(self):
        for ladder_id in ("sxr.2026-08-04.authority", "csaa.authority"):
            reading = translate(REGISTRY, axes.AUTHORITY, ladder_id, "O3")
            self.assertEqual(reading.normalized_ordinal, 0, ladder_id)
            self.assertIn("AXIS_KIND_MISMATCH", codes(reading))

    def test_performative_is_not_a_level(self):
        for token in ("ACCEPTED", "sealed", "Final", "VERIFIED"):
            reading = translate(REGISTRY, axes.AUTHORITY, "wn.core.authority", token)
            self.assertEqual(reading.normalized_ordinal, 0, token)
            self.assertIn("PERFORMATIVE_NOT_LEVEL", codes(reading))

    def test_unknown_ladder_and_rung_floor_to_zero(self):
        self.assertEqual(
            translate(REGISTRY, axes.EVIDENCE, "nope", "E5").normalized_ordinal, 0
        )
        reading = translate(REGISTRY, axes.EVIDENCE, "wn.core", "E9")
        self.assertEqual(reading.normalized_ordinal, 0)
        self.assertIn("UNKNOWN_RUNG", codes(reading))

    def test_axis_confusion_refused(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "wn.core.authority", "O2")
        self.assertEqual(reading.normalized_ordinal, 0)
        self.assertIn("AXIS_MISMATCH", codes(reading))

    def test_non_comparable_labels_use_denotation_only(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "research.rlevel", "R2")
        self.assertIsNone(reading.label_reading)
        self.assertEqual(reading.normalized_ordinal, 2)
        self.assertIn("LABEL_NOT_COMPARABLE", codes(reading))

    def test_e4_subclasses_all_land_on_four_with_distinct_denotations(self):
        seen = set()
        for label in ("E4-A", "E4-B", "E4-C"):
            reading = translate(REGISTRY, axes.EVIDENCE, "weaver.e4class", label)
            self.assertEqual(reading.normalized_ordinal, 4, label)
            seen.add(reading.denotes)
        self.assertEqual(len(seen), 3)

    def test_derived_mappings_are_flagged(self):
        reading = translate(REGISTRY, axes.EVIDENCE, "sealkit.local", "E2")
        self.assertIn("DERIVED_MAPPING", codes(reading))


class TestMonotonicity(unittest.TestCase):
    """The design invariant: no path through translation can raise a reading."""

    def test_no_rung_reads_above_its_own_strongest_self_reading(self):
        for ladder in REGISTRY.ladders.values():
            for label, rung in ladder.rungs.items():
                reading = translate(REGISTRY, ladder.axis, ladder.ladder_id, label)
                strongest = axes.clamp(
                    ladder.axis,
                    max(rung.ordinal, axes.denotation_ordinal(ladder.axis, rung.denotes)),
                )
                self.assertLessEqual(
                    reading.normalized_ordinal, strongest, f"{ladder.ladder_id}:{label}"
                )
                self.assertLessEqual(reading.normalized_ordinal, axes.CEILING[ladder.axis])
                self.assertGreaterEqual(reading.normalized_ordinal, 0)

    def test_guard_rails_never_raise(self):
        artifact = {"witness": {"principal": "someone", "org": "other", "identity_binding": "x", "signed": True}}
        for start in range(0, 7):
            floored, _ = rules.evidence_floors(dict(artifact, receipt_digest="d"), start)
            self.assertLessEqual(floored, start)

    def test_composition_never_raises(self):
        floored, _ = rules.composition_floor(1, {"a": 5, "b": 6})
        self.assertEqual(floored, 1)


class TestRules(unittest.TestCase):
    def base(self, **kw):
        artifact = {
            "owner_org": "weaver-nexus",
            "owner_principal": "ryan",
            "bindings": {"artifact_digest": "aa" * 32, "receipt_digest": "bb" * 32},
            "extraction": {"extraction_status": "verified"},
            "witness": {
                "principal": "external-operator",
                "org": "other-org",
                "identity_binding": "https://example.org/keys/x",
                "signed": True,
                "signature": {
                    "algorithm": "ed25519",
                    "verified": True,
                    "key_fingerprint": "ed25519:deadbeef",
                },
            },
        }
        artifact.update(kw)
        return artifact

    def test_independent_witness_permits_e4(self):
        level, findings = rules.evidence_floors(self.base(), 4)
        self.assertEqual(level, 4)
        self.assertEqual(findings, [])

    def test_no_witness_caps_at_e2(self):
        artifact = self.base(witness={"principal": None})
        self.assertEqual(rules.evidence_floors(artifact, 5)[0], 2)

    def test_same_principal_caps_at_e2(self):
        artifact = self.base(witness={"principal": "ryan", "org": "weaver-nexus"})
        self.assertEqual(rules.classify_witness(artifact), rules.SAME_PRINCIPAL)
        self.assertEqual(rules.evidence_floors(artifact, 3)[0], 2)

    def test_same_org_caps_at_e3(self):
        artifact = self.base(
            witness={
                "principal": "colleague",
                "org": "weaver-nexus",
                "identity_binding": "x",
                "signed": True,
            }
        )
        self.assertEqual(rules.classify_witness(artifact), rules.SAME_ORG)
        self.assertEqual(rules.evidence_floors(artifact, 4)[0], 3)

    def test_unsigned_external_is_not_independent(self):
        artifact = self.base(
            witness={"principal": "external", "org": "other", "identity_binding": None, "signed": False}
        )
        self.assertEqual(rules.classify_witness(artifact), rules.UNVERIFIED_INDEPENDENT)
        self.assertEqual(rules.evidence_floors(artifact, 4)[0], 2)

    def test_declared_signature_is_not_a_verified_one(self):
        # The corpus cannot promote itself to independent by writing signed:true.
        artifact = self.base(
            witness={
                "principal": "external",
                "org": "other",
                "identity_binding": "https://example.org/k",
                "signed": True,
                "signature": {"algorithm": "ed25519", "verified": False, "key_fingerprint": None},
            }
        )
        self.assertEqual(rules.classify_witness(artifact), rules.UNVERIFIED_INDEPENDENT)

    def test_claim_binding_required_above_e1(self):
        artifact = self.base(bindings={"artifact_digest": None, "receipt_digest": "bb" * 32})
        level, findings = rules.evidence_floors(artifact, 4)
        self.assertEqual(level, 1)
        self.assertIn("G-09_CLAIM_BINDING", {f.code for f in findings})

    def test_hand_extracted_claims_cannot_exceed_e2(self):
        artifact = self.base(extraction={"extraction_status": "hand_extracted_from_prose"})
        level, findings = rules.evidence_floors(artifact, 4)
        self.assertEqual(level, 2)
        self.assertIn("G-10_EXTRACTION_UNVERIFIED", {f.code for f in findings})

    def test_receipt_rule_is_fail_closed(self):
        artifact = self.base(bindings={"artifact_digest": "aa" * 32, "receipt_digest": None})
        level, findings = rules.evidence_floors(artifact, 4)
        self.assertEqual(level, 2)
        self.assertIn("G-01_RECEIPT_RULE", {f.code for f in findings})

    def test_simulation_is_not_physical(self):
        artifact = self.base(substrate="simulation")
        level, findings = rules.evidence_floors(artifact, 4)
        self.assertEqual(level, 2)
        self.assertIn("G-03_SUBSTRATE", {f.code for f in findings})

    def test_mythos_carries_no_runtime_evidence(self):
        artifact = self.base(track="mythos")
        self.assertEqual(rules.evidence_floors(artifact, 4)[0], 0)

    def test_authority_firewall_requires_a_named_human(self):
        level, findings = rules.authority_floors({"track": "logos"}, 3)
        self.assertEqual(level, 0)
        self.assertIn("G-07_AUTHORITY_FIREWALL", {f.code for f in findings})

    def test_ratified_authority_survives(self):
        artifact = {"track": "logos", "ratification": {"principal": "a human", "date": "2026-08-06"}}
        self.assertEqual(rules.authority_floors(artifact, 2)[0], 2)

    def test_research_and_mythos_carry_no_authority(self):
        for track in ("research", "mythos"):
            artifact = {
                "track": track,
                "ratification": {"principal": "a human", "date": "2026-08-06"},
            }
            self.assertEqual(rules.authority_floors(artifact, 3)[0], 0, track)

    def test_supersession_and_mythos_do_not_raise_the_ceiling(self):
        self.assertFalse(rules.counts_toward_ceiling({"status": "superseded"})[0])
        self.assertFalse(rules.counts_toward_ceiling({"track": "mythos"})[0])
        self.assertTrue(rules.counts_toward_ceiling({"status": "active", "track": "logos"})[0])


class TestCollisions(unittest.TestCase):
    def test_the_authority_axis_carries_three_kinds(self):
        found = {(c["axis"], c["label"]): c for c in detect(REGISTRY)}
        entry = found[("authority", "O2")]
        self.assertEqual(
            entry["distinct_kinds"],
            ["assurance_stage", "organizational_standing", "permission_to_act"],
        )

    def test_e2_carries_the_reproduction_claim_in_one_ladder(self):
        found = {(c["axis"], c["label"]): c for c in detect(REGISTRY)}
        meanings = {u["denotes"] for u in found[("evidence", "E2")]["uses"]}
        self.assertIn("reproduced_independent", meanings)
        self.assertIn("executed_local", meanings)


class TestAdjudicate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = adjudicate(REGISTRY, CORPUS)
        cls.by_id = {a["artifact_id"]: a for a in cls.core["artifacts"]}

    def test_ceiling_is_e2(self):
        self.assertEqual(self.core["aggregate"]["evidence_ceiling"], "E2")

    def test_no_independent_reproduction(self):
        self.assertEqual(self.core["aggregate"]["independent_reproduction_count"], 0)

    def test_authority_is_withheld_and_production_prohibited(self):
        self.assertEqual(self.core["aggregate"]["authority"], "O0")
        self.assertEqual(self.core["aggregate"]["production"], "PROHIBITED")

    def test_sealkit_cannot_reach_e2_without_naming_its_bytes(self):
        self.assertEqual(self.by_id["WN-SEALKIT"]["evidence_ordinal"], 1)
        self.assertIn(
            "G-09_CLAIM_BINDING",
            {f["code"] for f in self.by_id["WN-SEALKIT"]["findings"]},
        )

    def test_the_ceiling_rests_on_artifacts_with_recorded_bytes(self):
        holders = [
            a["artifact_id"]
            for a in self.core["artifacts"]
            if a["evidence_ordinal"] == 2 and a["counts_toward_ceiling"]
        ]
        self.assertEqual(holders, ["WN-CATHEDRAL-GUARD-0.2.0"])

    def test_nothing_is_adoptable_while_the_registry_is_unratified(self):
        self.assertEqual(self.core["aggregate"]["adoptability"], "ADVISORY_ONLY")
        for artifact in self.core["artifacts"]:
            self.assertEqual(
                artifact["governance"]["governance_recommendation"], "ADVISORY_ONLY"
            )

    def test_the_2026_08_03_incident_still_normalizes_downward(self):
        for artifact_id in ("INC-2026-08-03-CATHEDRAL", "INC-2026-08-03-DREADNOUGHT"):
            self.assertLessEqual(self.by_id[artifact_id]["evidence_ordinal"], 2)

    def test_composite_is_capped_by_its_parts(self):
        self.assertEqual(self.by_id["WN-AEGIS-GATE"]["evidence_ordinal"], 1)

    def test_missing_component_floors_to_zero(self):
        corpus = json.loads(json.dumps(CORPUS))
        corpus["artifacts"].append(
            {
                "artifact_id": "WN-GHOST",
                "track": "logos",
                "status": "active",
                "owner_org": "weaver-nexus",
                "components": ["WN-DOES-NOT-EXIST"],
                "bindings": {"artifact_digest": "cc" * 32},
                "claim": {"ladder": "wn.core", "label": "E2"},
                "authority_claim": {"ladder": "wn.core.authority", "label": "O0"},
                "witness": {"principal": None},
            }
        )
        result = adjudicate(REGISTRY, corpus)
        ghost = {a["artifact_id"]: a for a in result["artifacts"]}["WN-GHOST"]
        self.assertEqual(ghost["evidence_ordinal"], 0)

    def test_superseded_and_mythos_excluded_from_ceiling(self):
        excluded = {e["artifact_id"] for e in self.core["aggregate"]["artifacts_excluded"]}
        self.assertIn("WN-MPB-001-v1.0.0", excluded)
        self.assertIn("WN-MYTHOS-ARCHIVE", excluded)

    def test_exit_code_reports_invariant_findings(self):
        self.assertEqual(exit_code(self.core), 2)

    def test_receipt_declares_its_non_claims(self):
        self.assertTrue(any("not an independent" in n for n in self.core["non_claims"]))


class TestDeterminism(unittest.TestCase):
    def test_core_digest_is_stable_across_runs(self):
        a = digest(adjudicate(Registry.load(), load_corpus(CORPUS_PATH)))
        b = digest(adjudicate(Registry.load(), load_corpus(CORPUS_PATH)))
        self.assertEqual(a, b)

    def test_judgment_is_independent_of_file_layout(self):
        shuffled = json.loads(json.dumps(CORPUS))
        shuffled["artifacts"] = list(reversed(shuffled["artifacts"]))
        for artifact in shuffled["artifacts"]:
            for key in list(artifact):
                artifact[key] = artifact.pop(key)
        a, b = adjudicate(REGISTRY, shuffled), adjudicate(REGISTRY, CORPUS)
        self.assertEqual(a["corpus"]["claims_digest"], b["corpus"]["claims_digest"])
        self.assertEqual(a["artifacts"], b["artifacts"])
        self.assertEqual(a["aggregate"], b["aggregate"])

    def test_input_digest_binds_the_exact_declaration(self):
        # Reordering the file is a different declaration even though it is the
        # same set of claims. Both facts are recorded rather than one hiding
        # the other.
        shuffled = json.loads(json.dumps(CORPUS))
        shuffled["artifacts"] = list(reversed(shuffled["artifacts"]))
        self.assertNotEqual(
            adjudicate(REGISTRY, shuffled)["corpus"]["input_digest"],
            adjudicate(REGISTRY, CORPUS)["corpus"]["input_digest"],
        )

    def test_envelope_names_its_own_unstable_fields(self):
        core = adjudicate(REGISTRY, CORPUS)
        one = wrap(core, "2026-08-06T00:00:00+00:00")
        two = wrap(core, "2030-01-01T00:00:00+00:00")
        self.assertEqual(one["envelope"]["core_sha256"], two["envelope"]["core_sha256"])
        self.assertNotEqual(digest(one), digest(two))
        self.assertIn("envelope.generated_at", one["envelope"]["nondeterministic_fields"])


class TestWitnessExpectation(unittest.TestCase):
    def test_expected_digest_file_matches_if_present(self):
        expected_path = ROOT / "witness" / "EXPECTED.json"
        if not expected_path.exists():
            self.skipTest("no expectation file yet")
        expected = json.loads(expected_path.read_text(encoding="utf-8"))
        actual = digest(adjudicate(Registry.load(), load_corpus(ROOT / expected["corpus_path"])))
        self.assertEqual(actual, expected["core_sha256"])


class TestEd25519(unittest.TestCase):
    SEED = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")

    def test_sign_verify_round_trip(self):
        for message in (b"", b"a", b"x" * 257):
            signature = ed25519.sign(self.SEED, message)
            self.assertEqual(len(signature), 64)
            self.assertTrue(ed25519.verify(ed25519.public_key(self.SEED), message, signature))

    def test_tampering_is_detected(self):
        public = ed25519.public_key(self.SEED)
        signature = ed25519.sign(self.SEED, b"message")
        self.assertFalse(ed25519.verify(public, b"message!", signature))
        flipped = bytearray(signature)
        flipped[63] ^= 1
        self.assertFalse(ed25519.verify(public, b"message", bytes(flipped)))

    def test_malformed_input_returns_false_rather_than_raising(self):
        self.assertFalse(ed25519.verify(b"short", b"m", b"\x00" * 64))
        self.assertFalse(ed25519.verify(b"\x00" * 32, b"m", b"\x00" * 63))
        self.assertFalse(ed25519.verify(b"\xff" * 32, b"m", b"\x00" * 64))

    def test_non_canonical_s_is_refused(self):
        public = ed25519.public_key(self.SEED)
        signature = ed25519.sign(self.SEED, b"m")
        malleable = signature[:32] + (
            int.from_bytes(signature[32:], "little") + ed25519.L
        ).to_bytes(33, "little")[:32]
        self.assertFalse(ed25519.verify(public, b"m", malleable))

    def test_conformance_against_reference_library(self):
        try:
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        except ImportError:
            self.skipTest(
                "`cryptography` not installed; the pure implementation is UNCONFIRMED "
                "against a reference on this machine"
            )
        import os

        for _ in range(8):
            seed, message = os.urandom(32), os.urandom(64)
            reference = Ed25519PrivateKey.from_private_bytes(seed)
            reference_public = reference.public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            )
            self.assertEqual(ed25519.public_key(seed), reference_public)
            self.assertEqual(ed25519.sign(seed, message), reference.sign(message))


class TestAttest(unittest.TestCase):
    SEED = bytes.fromhex("4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb")

    def receipt(self) -> dict:
        return {
            "schema": "wn.crosswalk.witness-receipt/1",
            "witness": {
                "principal": "A. Operator",
                "organization": "other-org",
                "identity_binding": "https://example.org/keys/a",
                "identity_binding_kind": "https_url",
                "conflict_of_interest_declared": "none",
            },
            "disposition": {"result": "PASS"},
        }

    def test_signature_verifies_and_reports_what_it_establishes(self):
        signed = sign_receipt(self.receipt(), self.SEED)
        result = verify_receipt(signed)
        self.assertTrue(result["verified"])
        self.assertTrue(result["identity_fields_complete"])
        self.assertTrue(result["key_fingerprint"].startswith("ed25519:"))
        self.assertIn(
            "that the signer executed anything", " | ".join(result["does_not_establish"])
        )

    def test_editing_a_signed_receipt_breaks_it(self):
        signed = sign_receipt(self.receipt(), self.SEED)
        signed["disposition"]["result"] = "FAIL"
        self.assertFalse(verify_receipt(signed)["verified"])

    def test_unsigned_receipt_is_a_claim_not_an_attestation(self):
        result = verify_receipt(self.receipt())
        self.assertFalse(result["verified"])
        self.assertIn("not an attestation", " ".join(result["problems"]))

    def test_incomplete_identity_blocks_completion_even_when_signed(self):
        receipt = self.receipt()
        receipt["witness"]["conflict_of_interest_declared"] = None
        result = verify_receipt(sign_receipt(receipt, self.SEED))
        self.assertTrue(result["verified"])
        self.assertFalse(result["identity_fields_complete"])
        self.assertIn("conflict_of_interest_declared", result["missing_identity_fields"])

    def test_witness_block_cannot_be_verified_by_assertion(self):
        block = attest.witness_block(verify_receipt(self.receipt()), self.receipt()["witness"])
        self.assertFalse(block["signature"]["verified"])


class TestRatificationGate(unittest.TestCase):
    def test_registry_is_unratified_and_says_why(self):
        state = REGISTRY.ratification()
        self.assertEqual(state["status"], "UNRATIFIED")
        self.assertTrue(state["reasons"])
        self.assertIn("ADVISORY_ONLY", state["consequence"])

    def test_every_rung_is_currently_unbound(self):
        audit = REGISTRY.source_audit()
        self.assertEqual(audit["counts"]["bound"], 0)
        self.assertEqual(audit["counts"]["unbound"], audit["rung_total"])

    def test_a_bound_rung_is_recognised(self):
        from wn_crosswalk.registry import BOUND, binding_class

        self.assertEqual(
            binding_class(
                {
                    "document": "WN-MPB-001",
                    "version": "1.1.0",
                    "document_digest": "ab" * 32,
                    "locator": "ch.5 table 3",
                    "decided_by": "a human",
                    "decided_on": "2026-08-06",
                }
            ),
            BOUND,
        )

    def test_amendment_is_registered_but_not_applied(self):
        report = REGISTRY.amendment_report()
        self.assertEqual(len(report), 1)
        self.assertEqual(report[0]["status"], "proposed")
        # The axis actually in force is unchanged.
        self.assertEqual(REGISTRY.get("wn.core.authority").axis, axes.AUTHORITY)
        moved = {m["ladder_id"]: m for m in report[0]["ladder_moves"]}
        self.assertTrue(moved["csaa.authority"]["currently_refused"])
        self.assertFalse(moved["csaa.authority"]["refused_after_amendment"])

    def test_proposed_axes_are_not_in_force(self):
        self.assertNotIn(axes.STANDING, axes.IN_FORCE)
        self.assertNotIn(axes.PERMISSION, axes.IN_FORCE)
        self.assertNotIn(axes.ASSURANCE, axes.IN_FORCE)


class TestSchema(unittest.TestCase):
    def test_shipped_documents_validate(self):
        self.assertEqual(schema.validate(json.loads(REGISTRY_TEXT), "registry"), [])
        self.assertEqual(schema.validate(CORPUS, "corpus"), [])

    def test_unknown_field_is_reported_not_ignored(self):
        corpus = json.loads(json.dumps(CORPUS))
        corpus["artifacts"][0]["evidnce_level"] = "E4"
        problems = schema.validate(corpus, "corpus")
        self.assertTrue(any("evidnce_level" in p for p in problems))

    def test_wrong_type_is_reported(self):
        corpus = json.loads(json.dumps(CORPUS))
        corpus["artifacts"][0]["components"] = "WN-CHRONICLE"
        self.assertTrue(any("components" in p for p in schema.validate(corpus, "corpus")))

    def test_all_problems_returned_at_once(self):
        corpus = json.loads(json.dumps(CORPUS))
        del corpus["artifacts"][0]["claim"]
        del corpus["artifacts"][1]["claim"]
        self.assertGreaterEqual(len(schema.validate(corpus, "corpus")), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
