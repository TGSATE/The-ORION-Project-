# Negative findings — WN-XWK-001 v0.2.0

## Status of the v0.1.0 findings

| | v0.1.0 finding | v0.2.0 |
|---|---|---|
| NF-001 | array order changed the receipt digest | closed, `input_digest` + `claims_digest` |
| NF-002 | derived mappings are not evidence | **open, now mechanical** — every rung carries a `source` block, all 76 are unbound, and the registry reports UNRATIFIED until they are cited |
| NF-003 | corpus is an extraction from prose | **open, now capped** — G-10 caps unverified extractions at E2 and the provenance block is required |
| NF-004 | witness independence declared, not verified | **partly closed** — `INDEPENDENT` now requires a signature this tool verified plus a quotable key fingerprint; see NF-008 for what remains |
| NF-005 | no cryptographic signing | closed for witness receipts, Ed25519 over a canonical preimage; still open for the adjudication receipt itself |
| NF-006 | denotation vocabulary is a design choice | open and unchanged; still the seat of judgment, still needs outside review |
| NF-007 | adjudicating labels is not auditing artifacts | open by construction, now stated in every receipt's `non_claims` |

The v0.1.0 findings below are retained verbatim as lineage. New findings for
this version follow them.

## v0.1.0 findings, retained

Defects found during construction and limitations known at release. Kept with
the artifact rather than fixed out of the record.

## NF-001 — array order silently changed the receipt digest

**Found by:** the determinism test, on its first run.

Canonical JSON sorts object keys, so key order was already neutralised. Array
order is not, and correctly so. But `input_digest` was computed over the corpus
as given, which meant reordering the artifacts in the file produced a different
receipt for an identical set of claims. A witness who reformatted the corpus
before running would have reported a divergence that meant nothing.

**Resolution:** two digests are now recorded. `input_digest` binds the exact
declaration including its layout. `claims_digest` binds the same claims
normalized to sorted order. Neither hides the other. Two tests now assert the
distinction: the judgment is layout-independent, the input digest is not.

**Class:** this is the same shape as the previously recorded canonicalization
defects in this portfolio — the boundary was under-specified, not the logic.

## NF-002 — the registry's derived mappings are not evidence

Only three rungs of `sealkit.local` are pinned by a governing document
(E4, E5, E6). The rest are interpolated by me, conservatively, and marked
`"pinned": false`. Every use of a derived mapping emits a `DERIVED_MAPPING`
finding. A derived mapping may only lower a reading, never support one, but it
is still an assumption sitting inside a registry that otherwise records
decisions. The same applies to `handoff.2026-08-03` and `sxr.2026-08-04`, whose
non-pinned rungs were reconstructed from the adjudication record rather than
from the source documents.

**Consequence:** the registry is at E1 — documented and inspected — not E2. It
has not been checked against the original source documents rung by rung. That
check is the single most valuable thing anyone could do to this artifact next.

## NF-003 — the corpus is an extraction from prose

Artifact claims in `corpus/wn-2026-08-06.json` were extracted by hand from a
narrative handoff. Every entry is a reading of a sentence, not a measurement.
This is the softest joint in the instrument and the same weakness logged
against `handoff_adjudicator` v0.1.0's claims bundle. A wrong extraction
produces a confident, deterministic, wrong receipt.

## NF-004 — witness independence is declared, not verified

`classify_witness` reads fields. It compares strings for organization and
principal and checks that `signed` and `identity_binding` are non-empty. It
does not verify a signature, resolve an identity, or detect an undeclared
conflict of interest. A determined author can produce an `INDEPENDENT`
classification by writing one into the corpus. The rule raises the cost of
self-acceptance; it does not make it impossible.

## NF-005 — no cryptographic signing

Digests bind content. Nothing here binds content to a person. Until receipts
are signed with a key bound to an externally checkable identity, every
attestation in this package is a claim about a claim. This is the same open gap
recorded portfolio-wide.

## NF-006 — the denotation vocabulary is a design choice

`axes.py` fixes a vocabulary of denotation keys and their canonical ordinals.
That table is the actual seat of judgment in this tool, and it was written by
me from the portfolio's own definitions. If a denotation is placed one rung too
low or too high, every claim routed through it inherits the error, silently and
deterministically. It is small enough to be reviewed line by line in a few
minutes, and it should be, by someone who was not involved in writing it.

## NF-007 — an adjudication of labels is not an audit of artifacts

The tool reports `evidence ceiling E2` for a corpus in which it has executed
nothing, opened no package, and verified no test result. Everything it says is
downstream of what the corpus declares. A corpus of confident fictions would
receive a clean, reproducible, entirely worthless receipt.

## Non-defects, recorded to prevent re-litigation

- **Exit code 2 on the standard corpus is correct.** The tool exits non-zero
  because it found P0 findings, which is the expected state of this corpus. A
  zero exit here would be the surprising result.
- **`min()` looks harsh on ladders that are internally consistent.** It is. A
  ladder that agrees with canon in both readings is unaffected, which
  `wn-final-package.v1.0` demonstrates: it passes through unchanged.
- **The tool refuses rather than maps across authority kinds.** This will look
  like a bug the first time someone stated a real O2 on the CSAA ladder and got
  O0 back. It is not. Restate the claim on the canonical axis.


## New in v0.2.0

## NF-008 — a verified signature is not a verified identity

`attest` proves that the holder of a key signed exactly these fields. It does
not resolve `identity_binding` to anything, does not fetch the URL, and does
not check the fingerprint against a published one. An author can generate a
keypair, write their own identity into the receipt, sign it, and receive
`verified: true`.

What the change actually buys: the signature commits to the *whole receipt*, so
the environment, commands, digests and disposition can no longer be edited
after the fact without detection; and the key fingerprint is a short externally
quotable string that a human can compare against what the named person
publishes. The arithmetic is machine-checked. The identity is not, and the
verification output says so in its own `does_not_establish` list.

**Remaining work:** a key register mapping fingerprints to identity bindings,
with the register itself source-bound the same way ladders are.

## NF-009 — the Ed25519 implementation is unconfirmed where the reference is absent

The pure-stdlib implementation is byte-identical to the `cryptography` package
across randomized keys, signatures and rejection cases — on a machine where
that package is installed. Where it is not, the conformance test skips. A skip
is reported, not hidden, but a skipped conformance test is an unconfirmed
implementation, and a witness verifying a receipt on a bare machine is relying
on arithmetic nobody cross-checked there.

**Mitigation available and not yet done:** ship the RFC 8032 test vectors so
conformance is checkable with no third-party package at all.

## NF-010 — G-09 may be measuring the corpus, not the artifacts

Claim binding drops most of the corpus to E1 because no `artifact_digest` was
recorded. In several cases the digest certainly exists — Sealkit has a release
tree and Merkle proofs — it simply was not carried into the corpus entry.

This is the correct behaviour: an evidence system cannot distinguish "not
recorded" from "does not exist", and it must not guess in the direction that
grants more. But the resulting E1 readings should be read as *the corpus does
not identify these bytes*, not as *this work was not done*. Filling in three
digests would move three artifacts back to E2 in about ten minutes, and that is
the correct fix rather than relaxing the rule.

## NF-011 — the ratification gate can be satisfied without doing the work

`binding_class` checks that six fields are non-empty. It does not fetch the
document, verify the digest, or check that the locator points anywhere. A
determined author can bind all 76 rungs with plausible-looking strings in an
afternoon and get RATIFIED.

The gate raises the cost of skipping the audit and makes the skip visible; it
does not perform the audit. As with witness independence, the mechanism is a
forcing function for a human act, not a replacement for one.

## NF-012 — the amendment mechanism is report-only

`amendments` describes what AM-001 would change and computes which ladders stop
being refused. It does not produce a counterfactual adjudication, so nobody can
see the full downstream effect of adopting it without doing the migration. A
dual-canon engine was deliberately not built: two simultaneously live axes is a
worse failure mode than an un-modelled proposal.
