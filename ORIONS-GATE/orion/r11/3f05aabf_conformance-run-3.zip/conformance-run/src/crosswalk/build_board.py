"""Render the adjudication receipt as a plumb board.

Every artifact hangs from the strongest reading it can give of itself down to
where the ruleset leaves it. The brass rule across the board is E4, independent
reproduction. Nothing in this corpus reaches it.
"""

from __future__ import annotations

import html
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from wn_crosswalk.canon import digest  # noqa: E402
from wn_crosswalk import axes  # noqa: E402
from wn_crosswalk.registry import Registry  # noqa: E402
from wn_crosswalk.translate import translate  # noqa: E402

TRACK = 340
COL = 58
LEVELS = list(range(6, -1, -1))

SHORT = {
    "WN-SEALKIT": "sealkit",
    "WN-CATHEDRAL-GUARD-0.2.0": "cathedral guard",
    "WN-CATHEDRAL-STARTER": "starter",
    "WN-WITNESS-KIT-2.1": "witness kit",
    "WN-LUMEN-PREFLIGHT": "lumen preflight",
    "WN-SHOCK-KERNEL": "shock kernel",
    "WN-RSI-CORRIDOR": "rsi corridor",
    "WN-LUCIFER-LATCH": "lucifer latch",
    "WN-FACE-RUNTIME": "face runtime",
    "WN-AUTHORITY-ENGINE": "authority engine",
    "WN-CHRONICLE": "chronicle",
    "WN-AEGIS-GATE": "aegis gate",
    "WN-MPB-001-v1.0.0": "mpb v1.0.0",
    "WN-MYTHOS-ARCHIVE": "mythos",
    "INC-2026-08-03-CATHEDRAL": "08-03 cathedral",
    "INC-2026-08-03-DREADNOUGHT": "08-03 dreadnought",
    "INC-2026-08-04-SXR": "08-04 sxr",
}

E_LADDERS = [
    ("wn.core", "canonical"),
    ("wn-final-package.v1.0", "superseded"),
    ("sealkit.local", "local"),
    ("handoff.2026-08-03", "nonconformant"),
    ("sxr.2026-08-04", "rejected"),
    ("h7-corpus", "retired"),
]
O_LADDERS = [
    ("wn.core.authority", "canonical"),
    ("sxr.2026-08-04.authority", "rejected"),
    ("csaa.authority", "local"),
]

CSS = """
*,*::before,*::after{box-sizing:border-box}
:root{
  --ground:#0E1C1B; --panel:#132524; --bone:#E7E3D7; --dim:#7B8C89;
  --brass:#C79A3E; --verdigris:#4E9083; --oxblood:#A8483E; --rule:#233937;
  --display:"Instrument Serif",Georgia,"Times New Roman",serif;
  --mono:"IBM Plex Mono",ui-monospace,"SF Mono",Menlo,Consolas,monospace;
}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--ground);color:var(--bone);font-family:var(--mono);
  font-size:14px;line-height:1.55;
  background-image:radial-gradient(ellipse 90% 60% at 50% -10%,#18302E 0%,transparent 70%)}
.wrap{max-width:1120px;margin:0 auto;padding:40px 20px 72px}
.eyebrow{font-size:10.5px;letter-spacing:.22em;text-transform:uppercase;color:var(--dim);
  display:flex;flex-wrap:wrap;gap:6px 18px;border-bottom:1px solid var(--rule);padding-bottom:14px}
h1{font-family:var(--display);font-weight:400;font-size:clamp(38px,8.5vw,72px);
  line-height:.98;letter-spacing:-.015em;margin:30px 0 0}
h1 em{font-style:italic;color:var(--brass)}
.banner{margin-top:22px;border:1px solid var(--brass);border-left-width:3px;
  background:rgba(199,154,62,.07);padding:14px 16px;font-size:12.5px;color:#D8D2C2}
.banner b{display:block;color:var(--brass);font-size:13px;margin-bottom:5px}
.standfirst{max-width:56ch;color:#BDC7C4;margin:16px 0 0;font-size:14.5px}
.rulehead{font-family:var(--display);font-size:26px;margin:64px 0 4px;font-weight:400}
.rulehead+p{color:var(--dim);max-width:60ch;margin:0 0 22px;font-size:13px}
.board{display:flex;margin-top:26px;align-items:flex-start}
.axis{position:relative;width:34px;flex:0 0 34px;height:TRACKpx}
.axis span{position:absolute;left:0;transform:translateY(-50%);font-size:11px;color:var(--dim)}
.scroll{overflow-x:auto;overflow-y:hidden;flex:1 1 auto;padding-bottom:4px;
  -webkit-overflow-scrolling:touch;scrollbar-width:thin}
.boardinner{position:relative;display:flex;min-width:max-content;height:TRACKpx}
.gridline{position:absolute;left:0;right:0;height:1px;background:var(--rule)}
.datum{position:absolute;left:0;right:0;height:1px;background:var(--brass);z-index:2}
.datum::after{content:"E4 · independent reproduction";position:absolute;right:2px;top:-16px;
  font-size:9.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--brass)}
.col{position:relative;width:COLpx;flex:0 0 COLpx;height:TRACKpx}
.stated{position:absolute;left:50%;width:11px;height:11px;margin-left:-5.5px;margin-top:-5.5px;
  border:1px solid var(--oxblood);border-radius:50%;opacity:.85}
.plumb{position:absolute;left:50%;width:1px;margin-left:-.5px;
  background:linear-gradient(var(--oxblood),rgba(168,72,62,.25))}
.weight{position:absolute;left:50%;width:13px;height:13px;margin-left:-6.5px;margin-top:-6.5px;
  border-radius:50%;background:var(--verdigris);z-index:4;
  box-shadow:0 0 0 3px var(--ground)}
.weight.fell{background:var(--oxblood);animation:drop .9s cubic-bezier(.4,0,.25,1) both}
.weight.zero{background:var(--dim)}
@keyframes drop{from{top:var(--from);opacity:.3}to{top:var(--to);opacity:1}}
.names{display:flex;min-width:max-content;margin-top:6px}
.name{width:COLpx;flex:0 0 COLpx;writing-mode:vertical-rl;font-size:10.5px;color:var(--dim);
  height:118px;letter-spacing:.04em;padding-top:2px}
.name.fell{color:var(--oxblood)}
.hint{font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:#40605C;
  margin:4px 0 0;text-align:right}
.legend{display:flex;gap:22px;flex-wrap:wrap;font-size:11px;color:var(--dim);margin-top:10px}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;vertical-align:middle;
  margin-right:6px}
table{border-collapse:collapse;width:100%;font-size:11.5px;margin-top:10px}
th,td{border:1px solid var(--rule);padding:6px 7px;text-align:center}
th{color:var(--dim);font-weight:400;font-size:9.5px;letter-spacing:.1em;text-transform:uppercase}
th.rowhead,td.rowhead{text-align:left;color:var(--bone);white-space:nowrap}
td.same{color:var(--verdigris)}
td.off{color:var(--oxblood);background:rgba(168,72,62,.09)}
td.none{color:#354F4C}
.tablewrap{overflow-x:auto}
.caption{font-size:12px;color:var(--dim);max-width:62ch;margin:12px 0 0}
.caption b{color:var(--bone)}
.cards{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(268px,1fr));margin-top:22px}
.card{background:var(--panel);border:1px solid var(--rule);border-left:2px solid var(--oxblood);
  padding:16px 18px}
.card h3{font-family:var(--display);font-weight:400;font-size:19px;margin:0 0 2px}
.card .tag{font-size:9.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--dim)}
.card p{margin:10px 0 0;font-size:12.5px;color:#BDC7C4}
.card .math{font-size:12px;color:var(--brass);margin-top:12px;padding-top:10px;
  border-top:1px solid var(--rule)}
.figures{display:grid;gap:1px;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
  background:var(--rule);border:1px solid var(--rule);margin-top:26px}
.fig{background:var(--ground);padding:16px 18px}
.fig b{display:block;font-family:var(--display);font-size:34px;font-weight:400;line-height:1;
  color:var(--brass)}
.fig span{font-size:10px;letter-spacing:.13em;text-transform:uppercase;color:var(--dim);
  display:block;margin-top:8px}
footer{margin-top:70px;border-top:1px solid var(--rule);padding-top:20px;font-size:11.5px;
  color:var(--dim)}
footer ul{margin:10px 0 0;padding-left:16px}
footer li{margin-bottom:4px}
.digest{word-break:break-all;color:var(--verdigris);font-size:10.5px;margin-top:16px}
@media (prefers-reduced-motion:reduce){.weight.fell{animation:none;top:var(--to)}}
@media (max-width:640px){.wrap{padding:28px 14px 56px}.rulehead{margin-top:48px}}
"""


def y(ordinal: int) -> float:
    return (6 - ordinal) * (TRACK / 6)


def build(receipt: dict) -> str:
    core = receipt["core"]
    agg = core["aggregate"]
    items = core["artifacts"]

    axis = "".join(
        f'<span style="top:{y(l):.1f}px">E{l}</span>' for l in LEVELS
    )
    grid = "".join(
        f'<div class="gridline" style="top:{y(l):.1f}px"></div>'
        for l in LEVELS
        if l != 4
    )

    cols, names = [], []
    for item in items:
        final = item["evidence_ordinal"]
        reading = item["reading"]
        stated = max(reading["label_reading"] or 0, reading["denotation_reading"] or 0)
        stated = min(stated, 6)
        fell = final < stated
        cls = "weight fell" if fell else ("weight zero" if final == 0 else "weight")
        col = [f'<div class="col">']
        if fell:
            col.append(f'<div class="stated" style="top:{y(stated):.1f}px"></div>')
            col.append(
                f'<div class="plumb" style="top:{y(stated):.1f}px;'
                f'height:{y(final) - y(stated):.1f}px"></div>'
            )
        col.append(
            f'<div class="{cls}" style="top:{y(final):.1f}px;'
            f'--from:{y(stated):.1f}px;--to:{y(final):.1f}px;'
            f'animation-delay:{0.05 * len(cols):.2f}s"></div>'
        )
        col.append("</div>")
        cols.append("".join(col))
        label = SHORT.get(item["artifact_id"], item["artifact_id"].lower())
        names.append(
            f'<div class="name{" fell" if fell else ""}">{html.escape(label)}</div>'
        )

    matrix_e = _matrix(core, "evidence", E_LADDERS, [f"E{i}" for i in range(1, 9)])
    matrix_o = _matrix(core, "authority", O_LADDERS, [f"O{i}" for i in range(0, 6)])

    counts = agg["finding_severity_counts"]
    p0 = counts.get("P0", 0)
    ratification = core["registry"]["ratification"]
    audit = ratification["source_audit"]
    bound = len(items) - sum(
        1
        for item in items
        if any(f["code"] == "G-09_CLAIM_BINDING" for f in item["findings"])
    )

    return (
        TEMPLATE.replace("__CSS__", CSS.replace("TRACKpx", f"{TRACK}px").replace("COLpx", f"{COL}px"))
        .replace("__AXIS__", axis)
        .replace("__GRID__", grid)
        .replace("__DATUM__", f"{y(4):.1f}")
        .replace("__COLS__", "".join(cols))
        .replace("__NAMES__", "".join(names))
        .replace("__MATRIX_E__", matrix_e)
        .replace("__MATRIX_O__", matrix_o)
        .replace("__CEILING__", agg["evidence_ceiling"])
        .replace("__INDEP__", str(agg["independent_reproduction_count"]))
        .replace("__UNSAFE__", str(len(core["unsafe_labels"])))
        .replace("__P0__", str(p0))
        .replace("__DIGEST__", receipt["envelope"]["core_sha256"])
        .replace("__COUNT__", str(len(items)))
        .replace("__UNBOUND__", str(audit["counts"]["unbound"]))
        .replace("__RUNGS__", str(audit["rung_total"]))
        .replace("__BOUND__", str(bound))
        .replace("__ARTIFACTS__", str(len(items)))
    )


def _means(registry, axis: str, ladder_id: str, label: str) -> str | None:
    """What this rung's own definition denotes, placed on the canonical axis."""
    ladder = registry.get(ladder_id)
    rung = ladder.rungs.get(label) if ladder else None
    if rung is None:
        return None
    return axes.label(axis, axes.clamp(axis, axes.denotation_ordinal(axis, rung.denotes)))


def _matrix(core: dict, axis: str, ladders: list[tuple[str, str]], labels: list[str]) -> str:
    """Written label -> what it actually reads as, per ladder.

    Cells come from the translator itself, not from a lookup table, so the
    board cannot drift from the kernel.
    """
    registry = Registry.load()
    canonical_id = ladders[0][0]

    head = "".join(
        f'<th>{html.escape(lid.replace("wn.core.authority", "wn.core"))}'
        f'<br><span style="opacity:.6">{status}</span></th>'
        for lid, status in ladders
    )
    rows = []
    for label in labels:
        canonical_cell = _means(registry, axis, canonical_id, label)
        cells = []
        for lid, _ in ladders:
            means = _means(registry, axis, lid, label)
            if means is None:
                cells.append('<td class="none">·</td>')
                continue
            same = means == canonical_cell
            cells.append(f'<td class="{"same" if same else "off"}">{means}</td>')
        rows.append(f'<tr><td class="rowhead">{label}</td>{"".join(cells)}</tr>')
    return (
        '<div class="tablewrap"><table><tr><th class="rowhead">written</th>'
        + head
        + "</tr>"
        + "".join(rows)
        + "</table></div>"
    )


TEMPLATE = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Crosswalk Board — WN-XWK-001</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=IBM+Plex+Mono:wght@300;400&display=swap" rel="stylesheet">
<style>__CSS__</style>
</head><body>
<div class="wrap">

<div class="eyebrow">
  <span>WN-XWK-001</span><span>crosswalk kernel 0.2.0</span>
  <span>corpus WN-2026-08-06</span><span>baseline WN-MPB-001 v1.1.0</span>
</div>

<div class="banner">
  <b>Registry UNRATIFIED — every result on this page is advisory.</b>
  __UNBOUND__ of __RUNGS__ rungs cite no governing document with a digest, and no
  accountable human has adopted the ladder set. Nothing here may be recorded as a
  portfolio status decision until that changes.
</div>

<h1>Every claim, hung on <em>one axis</em></h1>
<p class="standfirst">
  __COUNT__ artifacts, each stated on whichever ladder its source document used.
  The hollow ring is the strongest reading a claim gives of itself. The weight is
  where it rests once the ruleset is applied. The line between them is the
  distance a label was carrying.
</p>

<div class="board">
  <div class="axis">__AXIS__</div>
  <div class="scroll">
    <div class="boardinner">
      __GRID__
      <div class="datum" style="top:__DATUM__px"></div>
      __COLS__
    </div>
    <div class="names">__NAMES__</div>
  </div>
</div>
<p class="hint">scroll the board sideways \u2192</p>
<div class="legend">
  <span><i class="dot" style="background:var(--verdigris)"></i>holds where stated</span>
  <span><i class="dot" style="background:var(--oxblood)"></i>lowered</span>
  <span><i class="dot" style="background:var(--dim)"></i>carries no runtime evidence</span>
</div>

<div class="figures">
  <div class="fig"><b>__CEILING__</b><span>evidence ceiling</span></div>
  <div class="fig"><b>__INDEP__</b><span>independent reproductions</span></div>
  <div class="fig"><b>O0</b><span>operational authority</span></div>
  <div class="fig"><b>__UNSAFE__</b><span>ambiguous labels</span></div>
  <div class="fig"><b>__P0__</b><span>P0 findings</span></div>
  <div class="fig"><b>__BOUND__/__ARTIFACTS__</b><span>claims that name their bytes</span></div>
</div>

<h2 class="rulehead">What a written label actually means</h2>
<p>
  Read down a column to see one ladder's vocabulary. Read across a row to see
  what a single written label resolves to depending on who wrote it. Green
  agrees with the canonical meaning; red does not; a dot means that ladder has
  no such rung.
</p>
__MATRIX_E__
<p class="caption">Writing <b>E2</b> means locally executed on the canonical axis, merely
implemented in two others, and independently reproduced in a third. The same two
characters, four meanings, one corpus.</p>

<h2 class="rulehead">The authority axis, three ways</h2>
<p>
  Worse than disagreement about degree: these ladders do not measure the same
  kind of thing. Canonical O-levels are organizational standing. One rejected
  ladder reads them as permission to act; a third runs O0–O5 as assurance
  stages. Numbers are refused between kinds rather than mapped, so anything
  stated on the wrong kind reads O0.
</p>
__MATRIX_O__

<h2 class="rulehead">Two ways a label lies</h2>
<p>They point in opposite directions and the same rule catches both.</p>
<div class="cards">
  <div class="card">
    <span class="tag">label inflation</span>
    <h3>Sealkit</h3>
    <p>
      Stated E4 on its own local ladder, where E4 is defined as the gates
      passing on the author's machine. Nineteen gates, 151 tests, all real —
      and all local. The number outran the thing it named.
    </p>
    <div class="math">label E4 · denotes executed_local = E2 · min → <b>E2</b></div>
  </div>
  <div class="card">
    <span class="tag">denotation inflation</span>
    <h3>Handoff 2026-08-03</h3>
    <p>
      Stated E2, on a ladder whose E2 is defined as an independent observer
      being able to reproduce the result. A document reporting a modest ceiling
      across three projects was reporting independent reproduction across three
      projects. Nobody double-checks a low number.
    </p>
    <div class="math">label E2 · denotes reproduced_independent = E4 · min → <b>E2</b></div>
  </div>
  <div class="card">
    <span class="tag">not a level at all</span>
    <h3>ACCEPTED</h3>
    <p>
      Closure asserted on the authority axis with a speech act rather than a
      rung. No number changed, so nothing looked wrong. Reads O0, with a P0
      finding, because declaring a thing accepted does not place it on an axis.
    </p>
    <div class="math">performative token → <b>O0</b></div>
  </div>
</div>

<h2 class="rulehead">A proposed amendment, deliberately not applied</h2>
<p>
  Splitting the O-labels three ways would make the refusals above unnecessary
  rather than merely safe. It would also relabel every existing O-claim in the
  corpus — which is exactly the failure this instrument exists to catch. So it
  is registered, costed, and left for a human to decide.
</p>
<div class="cards">
  <div class="card" style="border-left-color:var(--brass)">
    <span class="tag">AM-001 · proposed</span>
    <h3>S0–S4 · O0–O4 · A0–A5</h3>
    <p>
      Organizational standing moves to S, permission to act keeps O, assurance
      stage takes A. Two ladders that currently read O0 by refusal become
      readable on their own axes. Six preconditions, including restating every
      existing O-claim before the relabel takes effect.
    </p>
    <div class="math">status: <b>not applied</b> — R7 change, needs ratification</div>
  </div>
</div>

<h2 class="rulehead">The brass line is empty</h2>
<p>
  Nothing on the board crosses E4, and the reasons are now two rather than one.
  Most claims are stopped before E2 because they do not identify the bytes they
  say were executed. The ones that clear that bar are stopped at E2 because a
  candidate may not control its own acceptance. The remaining distance is one
  exact release, one frozen packet, one operator who does not answer to the
  author, and one signed result — and this instrument can now check the
  signature on it.
</p>

<footer>
  <b style="color:var(--bone)">This board is evidence about labels, not about artifacts.</b>
  <ul>
    <li>A conformant label is not a correct implementation.</li>
    <li>Producing this adjudication is not an independent reproduction of anything in it.</li>
    <li>No rule in the ruleset can raise a reading; the design invariant is tested.</li>
    <li>No authority is granted by anything shown here.</li>
  </ul>
  <div class="digest">core_sha256 __DIGEST__</div>
</footer>

</div></body></html>
"""


if __name__ == "__main__":
    receipt = json.loads((ROOT / "RECEIPT.json").read_text(encoding="utf-8"))
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "crosswalk-board.html"
    out.write_text(build(receipt), encoding="utf-8")
    print(f"{out}  ({out.stat().st_size} bytes)")
    print("board digest", digest({"html": out.read_text(encoding='utf-8')}))
