# axis_guard — reproduction

Stdlib only. No install.

```
python3 axis_guard.py            # demo: catches F-01 and the §127 ladder
python3 -m unittest test_axis_guard -v
```

Expected: demo prints one AXIS_KIND_MISMATCH (P0), one MERGE_COLLAPSE (P0),
and artifact reads: E0. Suite reports 12 passed, 0 skipped.

## Evidence status of THIS artifact
E0. Unwitnessed. It does not exempt itself from the axis it enforces.
To raise it: run the suite in a fresh container (E3), then have someone
who is not the author run REPRODUCE.md and confirm (E4-A). Same chain as
everything else — C-19 → repro spec → E3 → freeze → dispatch.

## What it enforces (the four properties named in the F-01 acceptance)
- axis_kind        — a value must belong to the scale its field is bound to
- applicability    — competency scales do not apply to artifacts
- composition_rule — FLOOR-within-artifact, computed not remembered
- allowable emission — unknown field / unknown rung / cross-axis => REJECT, fail closed

## Registering a new scale
Add it to registry.json with axis_kind, applies_to, not_applies_to, rungs,
composition_rule. It cannot then be emitted on a field bound to another axis.
This is the mechanism that stops slip #7.
