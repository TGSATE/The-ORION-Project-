#!/usr/bin/env python3
"""Regression tests. The two historical slips are fixtures: if either ever
stops being caught, that is the regression."""
import unittest
from pathlib import Path
from axis_guard import Registry, check_emission, check_ladder, floor_evidence

REG = Registry.load(Path(__file__).with_name("registry.json"))


class TestAxisKind(unittest.TestCase):
    def test_F01_competency_on_evidence_field_is_P0(self):
        fs = check_emission(REG, "evidence_level", "T2")
        self.assertEqual(len(fs), 1)
        self.assertEqual(fs[0].code, "AXIS_KIND_MISMATCH")
        self.assertEqual(fs[0].severity, "P0")

    def test_authority_on_evidence_field_is_P0(self):
        fs = check_emission(REG, "evidence_level", "O1")
        self.assertEqual(fs[0].code, "AXIS_KIND_MISMATCH")

    def test_correct_evidence_emission_passes(self):
        self.assertEqual(check_emission(REG, "evidence_level", "E2"), [])

    def test_competency_in_its_own_field_passes(self):
        self.assertEqual(check_emission(REG, "domain_competency", "T2"), [])

    def test_unknown_rung_fails_closed(self):
        fs = check_emission(REG, "evidence_level", "E9")
        self.assertEqual(fs[0].code, "UNKNOWN_RUNG")

    def test_unknown_field_fails_closed(self):
        fs = check_emission(REG, "vibes", "E2")
        self.assertEqual(fs[0].code, "UNKNOWN_FIELD")


class TestMergeCollapse(unittest.TestCase):
    def test_127_ladder_is_caught_by_arity(self):
        local = ["E0", "E1", "E2", "E3", "E4", "E5"]
        m = {"E0": "E0", "E1": "E1", "E2": "E2",
             "E3": "E4-A", "E4": "E5", "E5": "E6"}
        fs = check_ladder(REG, local, m)
        codes = {f.code for f in fs}
        self.assertIn("MERGE_COLLAPSE", codes)
        self.assertEqual([f for f in fs if f.code == "MERGE_COLLAPSE"][0].severity, "P0")

    def test_identity_ladder_passes(self):
        canon = REG.rungs("evidence")
        m = {r: r for r in canon}
        self.assertEqual(check_ladder(REG, canon, m), [])

    def test_unmapped_rung_flagged(self):
        fs = check_ladder(REG, ["E0", "X"], {"E0": "E0", "X": "nope"})
        self.assertEqual(fs[0].code, "UNMAPPED_RUNG")


class TestFloor(unittest.TestCase):
    def test_floor_takes_minimum(self):
        self.assertEqual(floor_evidence(REG, ["E2", "E0"]), "E0")

    def test_floor_after_c19_closure(self):
        # once C-19 constructs leave E0, the body's E2 governs
        self.assertEqual(floor_evidence(REG, ["E2", "E2", "E2"]), "E2")

    def test_floor_rejects_unknown(self):
        with self.assertRaises(ValueError):
            floor_evidence(REG, ["E2", "T2"])  # competency rung is not evidence


if __name__ == "__main__":
    unittest.main(verbosity=2)
