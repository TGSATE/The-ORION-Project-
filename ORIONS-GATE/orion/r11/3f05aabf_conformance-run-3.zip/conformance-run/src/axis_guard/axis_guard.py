#!/usr/bin/env python3
"""
axis_guard — mechanical enforcement of axis-kind, applicability, and
composition for the MSC scale registry.

Purpose (Ryan, 2026-08-17): the sixth taxonomy slip (F-01) established that
cultural discipline — authors remembering which axis a symbol belongs to —
has reached its limit. This turns the four properties Ryan named
(axis-kind, applicability, composition rule, allowable emissions) into
schema checks that fail closed.

It would have caught, mechanically and before adjudication:
  - F-01: a competency value (T2) emitted in an evidence field.
  - MSC v1.0 §127: a 6-rung local ladder that is not injective into the
    7-rung canon (MERGE_COLLAPSE / proposed G-11).
  - An authority value emitted on the evidence axis.

Stdlib only. Deterministic. Fails closed: an unknown field, an unknown
scale, or an ambiguous emission is a REJECT, never a pass.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------- data ----------

@dataclass(frozen=True)
class Finding:
    code: str            # e.g. AXIS_KIND_MISMATCH
    severity: str        # P0 | P1 | P2
    field: str
    detail: str

    def __str__(self) -> str:
        return f"[{self.severity}] {self.code} @ {self.field}: {self.detail}"


@dataclass
class Registry:
    scales: dict
    field_axis_binding: dict

    @classmethod
    def load(cls, path: str | Path) -> "Registry":
        data = json.loads(Path(path).read_text())
        return cls(scales=data["scales"], field_axis_binding=data["field_axis_binding"])

    def scale_of_field(self, field_name: str) -> Optional[str]:
        return self.field_axis_binding.get(field_name)

    def rungs(self, scale_name: str) -> list[str]:
        return self.scales[scale_name]["rungs"]

    def owns_rung(self, scale_name: str, value: str) -> bool:
        return value in self.scales[scale_name]["rungs"]

    def scale_owning(self, value: str) -> Optional[str]:
        """Which registered scale, if any, owns this rung label. Ambiguity → None."""
        hits = [name for name, s in self.scales.items() if value in s["rungs"]]
        return hits[0] if len(hits) == 1 else None


# ---------- check 1: axis-kind on emission (F-01) ----------

def check_emission(reg: Registry, field_name: str, value: str) -> list[Finding]:
    """A value placed in a field must belong to the scale that field is bound to."""
    out: list[Finding] = []
    bound = reg.scale_of_field(field_name)
    if bound is None:
        return [Finding("UNKNOWN_FIELD", "P1", field_name,
                        f"field not in registry; fail closed. value={value!r}")]
    if bound == "STATUS_ENUM":
        return out  # free-text status field, not an axis
    if reg.owns_rung(bound, value):
        return out  # correct axis
    owner = reg.scale_owning(value)
    if owner is None:
        out.append(Finding("UNKNOWN_RUNG", "P1", field_name,
                            f"value {value!r} is not a rung of any registered scale"))
    else:
        out.append(Finding("AXIS_KIND_MISMATCH", "P0", field_name,
                            f"value {value!r} belongs to scale '{owner}' "
                            f"({reg.scales[owner]['axis_kind']}) but field is bound to "
                            f"'{bound}' ({reg.scales[bound]['axis_kind']}). "
                            f"This is the F-01 class."))
    return out


# ---------- check 2: merge collapse on ladder registration (G-11) ----------

def check_ladder(reg: Registry, local_rungs: list[str], mapping: dict[str, str],
                 canon_scale: str = "evidence") -> list[Finding]:
    """
    A local ladder must be injective into canon. If it merges or deletes a
    canonical rung, every local rung at or above the first merge point reads
    at (merge_point - 1). Detected by ARITY, before any denotation is read.
    """
    out: list[Finding] = []
    canon = reg.rungs(canon_scale)
    canon_idx = {r: i for i, r in enumerate(canon)}

    # every local rung must map somewhere in canon
    for lr in local_rungs:
        if mapping.get(lr) not in canon_idx:
            out.append(Finding("UNMAPPED_RUNG", "P1", lr,
                               f"local rung {lr!r} does not map to a canonical rung"))
    if out:
        return out

    # arity: fewer local rungs than canon => a canonical distinction was dropped
    images = [mapping[lr] for lr in local_rungs]
    # first canonical rung that is either merged (>1 preimage) or absent (0 preimage)
    from collections import Counter
    preimg = Counter(images)
    merge_points = [c for c in canon
                    if canon_idx[c] > 0 and preimg[c] != 1]
    if len(local_rungs) < len(canon) or merge_points:
        # first canonical rung with non-unit preimage, in canonical order
        first = None
        for c in canon:
            if preimg[c] != 1:
                first = c
                break
        deleted = [c for c in canon if preimg[c] == 0]
        cap_idx = max(canon_idx[first] - 1, 0) if first else len(canon) - 1
        out.append(Finding(
            "MERGE_COLLAPSE", "P0", "ladder",
            f"local ladder has {len(local_rungs)} rungs vs canon {len(canon)}; "
            f"first non-injective canonical rung is {first!r}; "
            f"deleted canonical distinction(s): {deleted or 'none (pure merge)'}; "
            f"every local rung at/above the merge reads at '{canon[cap_idx]}'."))
    return out


# ---------- check 3: FLOOR composition within an artifact ----------

def floor_evidence(reg: Registry, part_levels: list[str],
                   scale_name: str = "evidence") -> str:
    """FLOOR-within-artifact: an artifact reads at the minimum of its parts."""
    order = {r: i for i, r in enumerate(reg.rungs(scale_name))}
    unknown = [p for p in part_levels if p not in order]
    if unknown:
        raise ValueError(f"unknown rung(s) for scale '{scale_name}': {unknown}")
    return min(part_levels, key=lambda p: order[p])


# ---------- driver ----------

def audit_frontmatter(reg: Registry, fields: dict[str, str]) -> list[Finding]:
    out: list[Finding] = []
    for fname, value in fields.items():
        out.extend(check_emission(reg, fname, value))
    return out


if __name__ == "__main__":
    reg = Registry.load(Path(__file__).with_name("registry.json"))
    # the exact v3.0 front matter that shipped
    shipped = {"evidence_level": "T2", "authority": "O0", "domain_competency": "T2"}
    print("=== auditing MSC v3.0 shipped front matter ===")
    for f in audit_frontmatter(reg, shipped):
        print(f)
    print("=== auditing the §127 local ladder ===")
    local = ["E0", "E1", "E2", "E3", "E4", "E5"]
    m = {"E0": "E0", "E1": "E1", "E2": "E2",
         "E3": "E4-A", "E4": "E5", "E5": "E6"}
    for f in check_ladder(reg, local, m):
        print(f)
    print("=== corrected MSC artifact reading (parts: E2 body, E0 C-19) ===")
    print("artifact reads:", floor_evidence(reg, ["E2", "E0"]))
