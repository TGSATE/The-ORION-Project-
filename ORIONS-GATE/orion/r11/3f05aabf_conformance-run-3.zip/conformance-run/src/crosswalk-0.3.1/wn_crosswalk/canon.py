"""Canonical encoding and digest.

Fail-closed serialization. Anything that could make two honest runs disagree
is refused at the boundary rather than normalized silently.

Refusals (each one is a recorded portfolio defect class):
  - floats                      : IEEE-754 text form is not stable across runtimes
  - ints beyond 2**53           : silently lossy in JSON consumers
  - non-string object keys      : ordering undefined
  - NFC key collision           : two distinct keys that normalize to one key
  - non-finite / NaN            : not representable
"""

from __future__ import annotations

import hashlib
import json
import unicodedata

MAX_SAFE_INT = 2**53 - 1


class CanonError(ValueError):
    """Refused at the canonicalization boundary."""


def _norm(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def _canonize(value, path: str = "$"):
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int):
        if abs(value) > MAX_SAFE_INT:
            raise CanonError(f"{path}: integer exceeds 2**53-1")
        return value
    if isinstance(value, float):
        raise CanonError(f"{path}: floats are refused; use integers or strings")
    if isinstance(value, str):
        return _norm(value)
    if isinstance(value, (list, tuple)):
        return [_canonize(item, f"{path}[{i}]") for i, item in enumerate(value)]
    if isinstance(value, dict):
        out: dict[str, object] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise CanonError(f"{path}: object keys must be strings, got {type(key).__name__}")
            nkey = _norm(key)
            if nkey in out:
                raise CanonError(f"{path}: key collision after NFC normalization on {nkey!r}")
            out[nkey] = _canonize(item, f"{path}.{nkey}")
        return out
    raise CanonError(f"{path}: unsupported type {type(value).__name__}")


def canonical_bytes(value) -> bytes:
    """Deterministic UTF-8 bytes: NFC text, sorted keys, no insignificant space."""
    return json.dumps(
        _canonize(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def digest(value) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def digest_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()
