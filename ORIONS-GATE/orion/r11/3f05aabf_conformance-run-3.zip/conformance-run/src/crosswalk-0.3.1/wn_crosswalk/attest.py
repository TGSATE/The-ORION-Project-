"""Verify a signed witness receipt.

A witness receipt is signed over the canonical bytes of the receipt with its
`signature.value` removed. That preimage is what the signature commits to, and
recomputing it is the only way to know that the fields you are reading are the
fields that were signed.

What this establishes and what it does not:

  established     the holder of a specific Ed25519 private key signed exactly
                  these receipt fields, and the fields have not changed since
  NOT established that the key belongs to who the receipt says it does, that
                  the signer is organizationally independent, or that they ran
                  anything at all

The second list is why `identity_binding` must point at something externally
checkable and why `conflict_of_interest_declared` is a required field. The tool
verifies the arithmetic. A human still has to check that the fingerprint on the
receipt is the fingerprint that person publishes.
"""

from __future__ import annotations

import copy
from typing import Any

from . import ed25519
from .canon import canonical_bytes, digest_bytes

REQUIRED_IDENTITY_FIELDS = (
    "principal",
    "organization",
    "identity_binding",
    "identity_binding_kind",
    "conflict_of_interest_declared",
)


def preimage(receipt: dict) -> bytes:
    """Canonical bytes of the receipt with the signature value removed."""
    working = copy.deepcopy(receipt)
    signature = working.get("signature")
    if isinstance(signature, dict):
        signature.pop("value", None)
        signature.pop("verified", None)
        signature.pop("key_fingerprint", None)
    return canonical_bytes(working)


def sign_receipt(receipt: dict, seed: bytes) -> dict:
    """Attach a signature. Present so a witness can use one tool end to end."""
    signed = copy.deepcopy(receipt)
    public = ed25519.public_key(seed)
    signed.setdefault("signature", {})
    signed["signature"]["algorithm"] = "ed25519"
    signed["signature"]["public_key"] = public.hex()
    signed["signature"].pop("value", None)
    signed["signature"]["value"] = ed25519.sign(seed, preimage(signed)).hex()
    return signed


def verify_receipt(receipt: dict) -> dict[str, Any]:
    """Check the signature and report what is and is not established."""
    result: dict[str, Any] = {
        "signature_present": False,
        "algorithm": None,
        "verified": False,
        "key_fingerprint": None,
        "preimage_digest": None,
        "identity_fields_complete": False,
        "missing_identity_fields": [],
        "problems": [],
        "establishes": [],
        "does_not_establish": [
            "that the key belongs to the named principal",
            "that the signer is organizationally independent of the author",
            "that the signer executed anything",
        ],
    }

    signature = receipt.get("signature")
    if not isinstance(signature, dict) or not signature.get("value"):
        result["problems"].append("no signature present; an unsigned receipt is a claim, not an attestation")
        return result
    result["signature_present"] = True
    result["algorithm"] = signature.get("algorithm")

    if signature.get("algorithm") != "ed25519":
        result["problems"].append(f"unsupported algorithm {signature.get('algorithm')!r}")
        return result

    try:
        public = bytes.fromhex(signature["public_key"])
        value = bytes.fromhex(signature["value"])
    except (KeyError, ValueError):
        result["problems"].append("public_key or value is not valid hex")
        return result

    message = preimage(receipt)
    result["preimage_digest"] = digest_bytes(message)
    result["verified"] = ed25519.verify(public, message, value)
    result["key_fingerprint"] = ed25519.fingerprint(public)

    if not result["verified"]:
        result["problems"].append(
            "signature does not verify over the receipt as written; either the receipt was "
            "edited after signing or the key does not match"
        )
        return result

    witness = receipt.get("witness") or {}
    missing = [f for f in REQUIRED_IDENTITY_FIELDS if witness.get(f) in (None, "")]
    result["missing_identity_fields"] = missing
    result["identity_fields_complete"] = not missing
    if missing:
        result["problems"].append(
            "signature verifies but the identity block is incomplete: " + ", ".join(missing)
        )

    result["establishes"] = [
        "the holder of this key signed exactly these fields",
        "the receipt has not been altered since it was signed",
    ]
    return result


def witness_block(result: dict[str, Any], witness: dict) -> dict:
    """Corpus-shaped witness record built only from a verification result.

    The `verified` flag cannot be written by hand into a corpus and be believed;
    it comes from here or the claim is classified as unverified.
    """
    return {
        "principal": witness.get("principal"),
        "org": witness.get("organization"),
        "identity_binding": witness.get("identity_binding"),
        "signed": bool(result.get("signature_present")),
        "signature": {
            "algorithm": result.get("algorithm"),
            "verified": bool(result.get("verified")) and result.get("identity_fields_complete", False),
            "key_fingerprint": result.get("key_fingerprint"),
        },
    }
