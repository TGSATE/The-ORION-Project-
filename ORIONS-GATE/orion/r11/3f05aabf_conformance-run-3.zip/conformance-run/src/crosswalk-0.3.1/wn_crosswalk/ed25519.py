"""Ed25519 (RFC 8032) in the standard library only.

The portfolio's root blocker is a *signed* reproduction receipt. A witness
verifier that needs a third-party package is a verifier the witness has to
install, trust, and match versions of. This is ~120 lines of integer
arithmetic over hashlib.sha512, so the dependency closure of the whole
instrument stays empty.

Not constant time. It only ever handles public keys and signatures, so there is
no secret to leak by timing; `sign` exists for tests and for a witness who
wants to produce a receipt with the same tool, and its key handling is
deliberately unhardened. Do not use this module to protect anything.

Conformance is cross-checked against the `cryptography` package in the test
suite when that package happens to be installed. When it is not, the test
skips, and that skip is itself reported rather than hidden.
"""

from __future__ import annotations

import hashlib

P = 2**255 - 19
L = 2**252 + 27742317777372353535851937790883648493
D = -121665 * pow(121666, P - 2, P) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)

IDENTITY = (0, 1, 1, 0)


class SignatureError(ValueError):
    pass


def _sha512(data: bytes) -> bytes:
    return hashlib.sha512(data).digest()


def _recover_x(y: int, sign_bit: int) -> int:
    if y >= P:
        raise SignatureError("y coordinate out of field")
    xx = (y * y - 1) * pow(D * y * y + 1, P - 2, P) % P
    x = pow(xx, (P + 3) // 8, P)
    if (x * x - xx) % P != 0:
        x = x * SQRT_M1 % P
    if (x * x - xx) % P != 0:
        raise SignatureError("point is not on the curve")
    if x == 0 and sign_bit:
        raise SignatureError("non-canonical zero x")
    if x & 1 != sign_bit:
        x = P - x
    return x


def _add(a, b):
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    m = (y1 - x1) * (y2 - x2) % P
    n = (y1 + x1) * (y2 + x2) % P
    o = t1 * 2 * D * t2 % P
    q = z1 * 2 * z2 % P
    e, f, g, h = n - m, q - o, q + o, n + m
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _mul(point, scalar: int):
    result = IDENTITY
    addend = point
    while scalar > 0:
        if scalar & 1:
            result = _add(result, addend)
        addend = _add(addend, addend)
        scalar >>= 1
    return result


def _equal(a, b) -> bool:
    x1, y1, z1, _ = a
    x2, y2, z2, _ = b
    return (x1 * z2 - x2 * z1) % P == 0 and (y1 * z2 - y2 * z1) % P == 0


_BY = 4 * pow(5, P - 2, P) % P
BASE = (_recover_x(_BY, 0), _BY, 1, _recover_x(_BY, 0) * _BY % P)


def _decode(data: bytes):
    if len(data) != 32:
        raise SignatureError("point must be 32 bytes")
    value = int.from_bytes(data, "little")
    y = value & ((1 << 255) - 1)
    x = _recover_x(y, value >> 255)
    return (x, y, 1, x * y % P)


def _encode(point) -> bytes:
    x, y, z, _ = point
    zi = pow(z, P - 2, P)
    x = x * zi % P
    y = y * zi % P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def public_key(seed: bytes) -> bytes:
    if len(seed) != 32:
        raise SignatureError("seed must be 32 bytes")
    h = bytearray(_sha512(seed)[:32])
    h[0] &= 248
    h[31] &= 127
    h[31] |= 64
    return _encode(_mul(BASE, int.from_bytes(h, "little")))


def sign(seed: bytes, message: bytes) -> bytes:
    h = _sha512(seed)
    a = bytearray(h[:32])
    a[0] &= 248
    a[31] &= 127
    a[31] |= 64
    scalar = int.from_bytes(a, "little")
    prefix = h[32:]
    encoded_a = _encode(_mul(BASE, scalar))
    r = int.from_bytes(_sha512(prefix + message), "little") % L
    encoded_r = _encode(_mul(BASE, r))
    k = int.from_bytes(_sha512(encoded_r + encoded_a + message), "little") % L
    s = (r + k * scalar) % L
    return encoded_r + s.to_bytes(32, "little")


def verify(public: bytes, message: bytes, signature: bytes) -> bool:
    """True only if the signature is valid. Malformed input returns False."""
    try:
        if len(signature) != 64 or len(public) != 32:
            return False
        r_point = _decode(signature[:32])
        a_point = _decode(public)
        s = int.from_bytes(signature[32:], "little")
        if s >= L:
            return False  # non-canonical S; malleable signatures are refused
        k = int.from_bytes(_sha512(signature[:32] + public + message), "little") % L
        return _equal(_mul(BASE, s), _add(r_point, _mul(a_point, k)))
    except SignatureError:
        return False


def fingerprint(public: bytes) -> str:
    """Short, externally quotable identifier for a public key."""
    return "ed25519:" + hashlib.sha256(public).hexdigest()[:32]
