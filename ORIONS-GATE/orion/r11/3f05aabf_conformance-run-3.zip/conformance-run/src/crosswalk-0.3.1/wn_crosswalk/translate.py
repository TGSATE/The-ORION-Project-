"""Translate a rung stated in any ladder into the canonical axis.

The rule, in one line:

    normalized = min(what the label says, what the definition says)

Both readings are computed independently. The label reading is the position the
number occupies on the canonical axis. The denotation reading is where the
rung's own written definition lands. When they disagree, the disagreement is
itself the finding, and the lower reading wins.

This generalizes both recorded taxonomy failures:

  HANDOFF-2026-08-03  label E2, definition "an independent observer can
                      reproduce" -> canonical E4.  min = E2.
                      A low label smuggling a high claim.

  Sealkit local       label E4, definition "gates pass on the author machine"
                      -> canonical E2.  min = E2.
                      A high label resting on a local run.

No rule in this module can raise a reading. Combinator within a claim is FLOOR,
matching handoff_adjudicator v0.1.0.

v0.3.0: readings are LEVELS on a partial order (see axes.py). FLOOR is the lattice meet, so a label
naming one E4 facet and a definition landing on another read E3 (FACET_CONFLICT), not "4". Integer
stages remain available as `normalized_ordinal`, `label_reading`, `denotation_reading`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import axes
from .registry import BOUND, CITED, STATUS_FINDING, Registry

SEVERITIES = ("P0", "P1", "P2", "info")


@dataclass
class Finding:
    code: str
    severity: str
    detail: str

    def to_dict(self) -> dict:
        return {"code": self.code, "severity": self.severity, "detail": self.detail}


@dataclass
class Reading:
    axis: str
    ladder_id: str
    stated_label: str
    normalized_level: str
    label_level: str | None = None
    label_reading: int | None = None      # the label's stage, as stated ("E4" is 4)
    denotation_level: str | None = None
    denotes: str | None = None
    findings: list[Finding] = field(default_factory=list)

    # Stages: integers kept for display and backward compatibility. All facets are stage 4,
    # so a stage alone cannot tell E4-A from E4-B; the levels can.
    @property
    def normalized_ordinal(self) -> int:
        return axes.stage(self.axis, self.normalized_level)

    @property
    def denotation_reading(self) -> int | None:
        return None if self.denotation_level is None else axes.stage(self.axis, self.denotation_level)

    @property
    def normalized_label(self) -> str:
        return self.normalized_level

    def to_dict(self) -> dict:
        return {
            "axis": self.axis,
            "ladder_id": self.ladder_id,
            "stated_label": self.stated_label,
            "denotes": self.denotes,
            "label_reading": self.label_reading,
            "denotation_reading": self.denotation_reading,
            "label_level": self.label_level,
            "denotation_level": self.denotation_level,
            "normalized_ordinal": self.normalized_ordinal,
            "normalized_label": self.normalized_label,
            "findings": [f.to_dict() for f in self.findings],
        }


def _floor(reading: Reading, level: str) -> None:
    reading.normalized_level = axes.meet(reading.axis, reading.normalized_level, level)


def _bottom(reading: Reading) -> None:
    reading.normalized_level = axes.levels(reading.axis)[0]


def is_performative(label: str) -> bool:
    token = "".join(ch for ch in label.strip().lower() if ch.isalpha())
    return token in axes.PERFORMATIVE_TOKENS


def translate(registry: Registry, axis: str, ladder_id: str, stated_label: str) -> Reading:
    reading = Reading(
        axis=axis,
        ladder_id=ladder_id,
        stated_label=stated_label,
        normalized_level=axes.levels(axis)[-1],
    )

    if is_performative(stated_label):
        reading.findings.append(
            Finding(
                "PERFORMATIVE_NOT_LEVEL",
                "P0",
                f"{stated_label!r} is a speech act, not a rung. Declaring a thing accepted "
                "does not place it on an axis.",
            )
        )
        _bottom(reading)
        return reading

    ladder = registry.get(ladder_id)
    if ladder is None:
        reading.findings.append(
            Finding("UNKNOWN_LADDER", "P0", f"ladder {ladder_id!r} is not in the registry")
        )
        _bottom(reading)
        return reading

    if ladder.axis != axis:
        reading.findings.append(
            Finding(
                "AXIS_MISMATCH",
                "P0",
                f"ladder {ladder_id!r} is an {ladder.axis} ladder, read as {axis}",
            )
        )
        _bottom(reading)
        return reading

    code, severity = STATUS_FINDING[ladder.status]
    if code:
        reading.findings.append(
            Finding(code, severity, f"ladder {ladder_id!r} has status {ladder.status!r}: {ladder.source}")
        )

    rung = ladder.rungs.get(stated_label)
    if rung is None:
        reading.findings.append(
            Finding(
                "UNKNOWN_RUNG",
                "P0",
                f"{stated_label!r} is not a rung of {ladder_id!r}; missing evidence is not approval",
            )
        )
        _bottom(reading)
        return reading

    reading.denotes = rung.denotes

    # Different kinds of axis are not translatable by number. This is the
    # refusal that keeps three incompatible O0-O4 ladders from being averaged
    # into one meaning.
    if not ladder.is_canonical_kind:
        reading.findings.append(
            Finding(
                "AXIS_KIND_MISMATCH",
                "P0",
                f"{ladder_id!r} is kind {ladder.kind!r}; the canonical {axis} axis is kind "
                f"{axes.CANONICAL_KIND[axis]!r}. Same labels, different meanings; refused rather "
                "than mapped.",
            )
        )
        _bottom(reading)
        return reading

    denotation_level = axes.denotation_level(axis, rung.denotes)
    reading.denotation_level = denotation_level
    _floor(reading, denotation_level)

    if ladder.label_comparable:
        if rung.ordinal > axes.CEILING[axis]:
            reading.findings.append(
                Finding(
                    "OUT_OF_RANGE_RUNG",
                    "P0",
                    f"{stated_label} sits above the canonical ceiling "
                    f"{axes.label(axis, axes.CEILING[axis])}; the rung does not exist on this axis",
                )
            )
        clamped = axes.clamp(axis, rung.ordinal)
        reading.label_reading = clamped
        # Which facet does a stage-4 label name? The one it declares ("level"), else the one its
        # spelling names ("E4-B"; v0.3.1), else none: a bare "E4". A bare E4 is compatible with the
        # facet its definition names; if the definition names none, the label certifies none of
        # the three incomparable rungs.
        named = rung.level
        if named is None and axis == axes.EVIDENCE and rung.label in axes.EVIDENCE_FACETS:
            named = rung.label
        unnamed_facet = (axis == axes.EVIDENCE and clamped == 4 and named is None
                         and denotation_level not in axes.EVIDENCE_FACETS)
        if named is not None:
            label_level = named
        elif axis == axes.EVIDENCE and clamped == 4:
            label_level = denotation_level if not unnamed_facet else "E3"
        else:
            label_level = axes.level_of_stage(axis, clamped)
        reading.label_level = label_level
        _floor(reading, label_level)

        if unnamed_facet:
            shown = "E4"
            den_stage = axes.stage(axis, denotation_level)
            label_above, denot_above, conflict = 4 > den_stage, den_stage > 4, False
            if den_stage > 4:
                reading.findings.append(
                    Finding(
                        "E4_FACET_UNSPECIFIED",
                        "P1",
                        f"{stated_label} sits at stage 4 but names no facet. Its definition "
                        f"{rung.denotes!r} = {denotation_level} sits above stage 4 and does not pick "
                        "one of E4-A, E4-B, E4-C either. The three are incomparable, so the label "
                        "certifies only what they share: read at E3.",
                    )
                )
        else:
            shown = label_level
            label_le = axes.leq(axis, label_level, denotation_level)
            denot_le = axes.leq(axis, denotation_level, label_level)
            label_above = denot_le and not label_le
            denot_above = label_le and not denot_le
            conflict = not label_le and not denot_le
        if label_above:
            reading.findings.append(
                Finding(
                    "LABEL_INFLATION",
                    "P0",
                    f"{stated_label} sits at {shown} by number but "
                    f"denotes {rung.denotes!r} = {denotation_level}. "
                    "The number is stronger than the thing it names.",
                )
            )
        elif denot_above:
            reading.findings.append(
                Finding(
                    "DENOTATION_INFLATION",
                    "P0",
                    f"{stated_label} sits at {shown} by number but "
                    f"denotes {rung.denotes!r} = {denotation_level}. "
                    "A modest-looking label carrying a large claim is the harder failure to "
                    "notice.",
                )
            )
        elif conflict:
            reading.findings.append(
                Finding(
                    "FACET_CONFLICT",
                    "P0",
                    f"{stated_label} names {label_level} but denotes {rung.denotes!r} = "
                    f"{denotation_level}. None of E4-A, E4-B, E4-C implies another; the reading is "
                    f"their meet, {axes.meet(axis, label_level, denotation_level)}.",
                )
            )
    else:
        reading.findings.append(
            Finding(
                "LABEL_NOT_COMPARABLE",
                "info",
                f"{ladder_id!r} does not share the canonical label space; read by denotation only",
            )
        )

    if rung.binding != BOUND:
        reading.findings.append(
            Finding(
                "UNBOUND_RUNG" if rung.binding != CITED else "UNDIGESTED_RUNG",
                "P1",
                f"{ladder_id}:{stated_label} does not cite a governing document with a "
                "digest, so this mapping is recorded but not ratified; the result is "
                "advisory",
            )
        )

    if not rung.pinned:
        reading.findings.append(
            Finding(
                "DERIVED_MAPPING",
                "P2",
                f"the mapping for {stated_label} in {ladder_id!r} is derived, not ratified; "
                "it may only lower a reading, never support one",
            )
        )

    return reading
