"""Minimal structural validation, standard library only.

Not a general JSON Schema implementation. It checks the shapes this kernel
actually reads, refuses unknown keys where a typo would otherwise be silently
ignored, and returns every problem at once rather than dying on the first.

A silently ignored key is how a corpus grows a field that nobody reads. That is
the same class of failure as a label nobody translates.
"""

from __future__ import annotations

STRING, INT, BOOL, OBJECT, ARRAY, ANY = "string", "int", "bool", "object", "array", "any"


class SchemaError(ValueError):
    pass


def _kind(value) -> str:
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, str):
        return STRING
    if isinstance(value, dict):
        return OBJECT
    if isinstance(value, list):
        return ARRAY
    return "null" if value is None else type(value).__name__


def _check(node, spec: dict, path: str, problems: list[str]) -> None:
    required = spec.get("required", ())
    optional = spec.get("optional", ())
    types = spec.get("types", {})
    allow_extra = spec.get("allow_extra", False)

    if not isinstance(node, dict):
        problems.append(f"{path}: expected object, got {_kind(node)}")
        return

    for key in required:
        if key not in node:
            problems.append(f"{path}.{key}: required field missing")

    known = set(required) | set(optional)
    if not allow_extra:
        for key in sorted(set(node) - known):
            problems.append(f"{path}.{key}: unknown field (typo, or a field nobody reads)")

    for key, expected in types.items():
        if key not in node or node[key] is None:
            continue
        actual = _kind(node[key])
        if expected == ANY:
            continue
        if expected == INT and actual == BOOL:
            problems.append(f"{path}.{key}: expected int, got bool")
        elif actual != expected:
            problems.append(f"{path}.{key}: expected {expected}, got {actual}")

    for key, child in spec.get("children", {}).items():
        if key in node and node[key] is not None:
            _check(node[key], child, f"{path}.{key}", problems)

    for key, child in spec.get("each", {}).items():
        items = node.get(key)
        if isinstance(items, list):
            for index, item in enumerate(items):
                _check(item, child, f"{path}.{key}[{index}]", problems)


SOURCE = {
    "required": ["audit_status"],
    "optional": ["document", "version", "document_digest", "locator", "decided_by", "decided_on"],
    "types": {
        "document": STRING, "version": STRING, "document_digest": STRING,
        "locator": STRING, "decided_by": STRING, "decided_on": STRING, "audit_status": STRING,
    },
}

RUNG = {
    "required": ["label", "ordinal", "denotes"],
    "optional": ["pinned", "gloss", "source", "level"],
    "types": {"label": STRING, "ordinal": INT, "denotes": STRING, "pinned": BOOL, "gloss": STRING,
              "level": STRING},
    "children": {"source": SOURCE},
}

LADDER = {
    "required": ["ladder_id", "axis", "kind", "status", "label_comparable", "rungs"],
    "optional": ["source", "axis_if_amended"],
    "types": {
        "ladder_id": STRING, "axis": STRING, "kind": STRING, "status": STRING,
        "label_comparable": BOOL, "source": STRING, "axis_if_amended": STRING, "rungs": ARRAY,
    },
    "each": {"rungs": RUNG},
}

REGISTRY = {
    "required": ["schema", "registry_version", "ladders"],
    "optional": ["note", "amendments", "adoption"],
    "types": {"schema": STRING, "registry_version": STRING, "note": STRING,
              "ladders": ARRAY, "amendments": ARRAY, "adoption": OBJECT},
    "each": {"ladders": LADDER},
}

CLAIM = {"required": ["ladder", "label"], "types": {"ladder": STRING, "label": STRING}}

BINDINGS = {
    "required": [],
    "optional": ["artifact_digest", "receipt_digest", "manifest_digest", "evidence_record_digest"],
    "types": {k: STRING for k in
              ("artifact_digest", "receipt_digest", "manifest_digest", "evidence_record_digest")},
}

EXTRACTION = {
    "required": ["extraction_status"],
    "optional": ["source_document", "source_version", "source_digest", "locator",
                 "extracted_by", "reviewed_by"],
    "types": {k: STRING for k in
              ("extraction_status", "source_document", "source_version", "source_digest",
               "locator", "extracted_by", "reviewed_by")},
}

SIGNATURE = {
    "required": [],
    "optional": ["algorithm", "verified", "key_fingerprint"],
    "types": {"algorithm": STRING, "verified": BOOL, "key_fingerprint": STRING},
}

WITNESS = {
    "required": [],
    "optional": ["principal", "org", "identity_binding", "signed", "signature"],
    "types": {"principal": STRING, "org": STRING, "identity_binding": STRING, "signed": BOOL},
    "children": {"signature": SIGNATURE},
}

ARTIFACT = {
    "required": ["artifact_id", "claim", "authority_claim"],
    "optional": ["name", "track", "status", "owner_org", "owner_principal", "substrate",
                 "components", "bindings", "extraction", "witness", "ratification", "notes"],
    "types": {
        "artifact_id": STRING, "name": STRING, "track": STRING, "status": STRING,
        "owner_org": STRING, "owner_principal": STRING, "substrate": STRING,
        "components": ARRAY, "notes": STRING,
    },
    "children": {"claim": CLAIM, "authority_claim": CLAIM, "bindings": BINDINGS,
                 "extraction": EXTRACTION, "witness": WITNESS,
                 "ratification": {"required": [], "optional": ["principal", "date", "note"],
                                  "types": {"principal": STRING, "date": STRING, "note": STRING}}},
}

CORPUS = {
    "required": ["schema", "corpus_id", "artifacts"],
    "optional": ["baseline", "note"],
    "types": {"schema": STRING, "corpus_id": STRING, "baseline": STRING,
              "note": STRING, "artifacts": ARRAY},
    "each": {"artifacts": ARTIFACT},
}

SPECS = {"registry": REGISTRY, "corpus": CORPUS}


def validate(document: dict, spec_name: str) -> list[str]:
    problems: list[str] = []
    _check(document, SPECS[spec_name], f"${spec_name}", problems)
    return problems


def validate_or_raise(document: dict, spec_name: str) -> None:
    problems = validate(document, spec_name)
    if problems:
        raise SchemaError(
            f"{len(problems)} schema problems in {spec_name}:\n  " + "\n  ".join(problems)
        )
