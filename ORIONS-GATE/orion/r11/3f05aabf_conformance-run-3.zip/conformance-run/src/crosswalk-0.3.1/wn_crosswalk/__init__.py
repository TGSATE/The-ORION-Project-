"""wn_crosswalk -- the Weaver Nexus Crosswalk Kernel.

One ratified axis. Every other ladder translated into it at whichever reading
grants the least authority.
"""

__version__ = "0.3.1"
__artifact_id__ = "WN-XWK-001"
