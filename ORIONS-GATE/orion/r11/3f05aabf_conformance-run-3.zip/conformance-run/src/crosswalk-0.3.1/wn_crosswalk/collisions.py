"""Find labels that mean different things in different ladders.

A collision is not a disagreement about facts. It is the same string carrying
two meanings in one corpus, which is how a claim moves between documents and
arrives stronger than it left. Partial alignment is worse than clean
divergence, because it passes as canonical.
"""

from __future__ import annotations

from . import axes
from .registry import CANONICAL_LADDER, Registry


def detect(registry: Registry) -> list[dict]:
    collisions: list[dict] = []

    for axis in (axes.EVIDENCE, axes.AUTHORITY):
        canonical_id = CANONICAL_LADDER[axis]
        seen: dict[str, list[tuple[str, str, int, str]]] = {}

        for ladder in registry.by_axis(axis):
            for label, rung in sorted(ladder.rungs.items()):
                ordinal = axes.denotation_ordinal(axis, rung.denotes)
                seen.setdefault(label, []).append(
                    (ladder.ladder_id, rung.denotes, ordinal, ladder.kind)
                )

        for label in sorted(seen):
            uses = sorted(seen[label])
            meanings = {(denotes, ordinal) for _, denotes, ordinal, _ in uses}
            kinds = {kind for *_, kind in uses}
            if len(meanings) <= 1 and len(kinds) <= 1:
                continue

            canonical_use = next((u for u in uses if u[0] == canonical_id), None)
            severity = "P0" if canonical_use else "P1"

            collisions.append(
                {
                    "axis": axis,
                    "label": label,
                    "severity": severity,
                    "distinct_meanings": len(meanings),
                    "distinct_kinds": sorted(kinds),
                    "canonical_meaning": canonical_use[1] if canonical_use else None,
                    "uses": [
                        {
                            "ladder_id": ladder_id,
                            "denotes": denotes,
                            "canonical_ordinal": ordinal,
                            # a level, so the three E4 facets are not printed as one "E4" (v0.3.1)
                            "canonical_label": axes.denotation_level(axis, denotes),
                            "kind": kind,
                        }
                        for ladder_id, denotes, ordinal, kind in uses
                    ],
                }
            )

    return collisions


def unsafe_labels(collisions: list[dict]) -> list[str]:
    """Labels that must never be written unqualified in portfolio prose."""
    return sorted({f"{c['axis']}:{c['label']}" for c in collisions})
