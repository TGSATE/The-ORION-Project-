"""Canonical axes and the shared denotation vocabulary.

A ladder is never translated label-to-label. Every rung declares a *denotation*
drawn from a fixed vocabulary, and translation runs through the denotation.
Labels are compared separately, and only ever to lower a reading.

Four kinds of axis are defined. They measure different things and are not
interchangeable:

  evidence   E0-E6  epistemic_support        what has been shown
  authority  O0-O4  organizational_standing  who stands behind it
  standing   S0-S4  organizational_standing  proposed replacement for authority
  permission O0-O4  permission_to_act        proposed; what a system may do
  assurance  A0-A5  assurance_stage          proposed; how far assurance has run

v0.3.0: the evidence axis is FACETED. E4 is three incomparable rungs, E4-A (independent
reproduction), E4-B (independent review), E4-C (adversarial assessment): none implies the others
(July 2026 adoption). Evidence is therefore a partial order, not an integer:

    E0 < E1 < E2 < E3 < {E4-A, E4-B, E4-C} < E5 < E6      (facets pairwise incomparable)

and every place two evidence readings meet uses the lattice meet, so E4-A meet E4-B = E3. The
portfolio ceiling is an aggregation, never a join: the set of maximal readings, each one a reading
some artifact actually holds (ruling 2026-10-04). Integer "ordinals" survive only as the STAGE of a
level (all three facets are stage 4), for display and backward compatibility.

`evidence` and `authority` are in force. `standing`, `permission` and
`assurance` are registered because amendment AM-001 proposes splitting the
overloaded O0-O4 label space three ways. The amendment is NOT applied here:
adopting it would relabel every existing O-claim in the corpus, which is a
constitutional change and not a code change. See `wn_crosswalk amendments`.
"""

from __future__ import annotations

EVIDENCE = "evidence"
AUTHORITY = "authority"
STANDING = "standing"
PERMISSION = "permission"
ASSURANCE = "assurance"

ALL_AXES = (EVIDENCE, AUTHORITY, STANDING, PERMISSION, ASSURANCE)
IN_FORCE = (EVIDENCE, AUTHORITY)

CANONICAL_KIND = {
    EVIDENCE: "epistemic_support",
    AUTHORITY: "organizational_standing",
    STANDING: "organizational_standing",
    PERMISSION: "permission_to_act",
    ASSURANCE: "assurance_stage",
}

PREFIX = {EVIDENCE: "E", AUTHORITY: "O", STANDING: "S", PERMISSION: "O", ASSURANCE: "A"}
CEILING = {EVIDENCE: 6, AUTHORITY: 4, STANDING: 4, PERMISSION: 4, ASSURANCE: 5}

# --- evidence ---------------------------------------------------------------
# No E7/E8: deleted by HANDOFF-2026-07-26-CORRECTED; recurrence is class B-001.
EVIDENCE_LEVELS = ("E0", "E1", "E2", "E3", "E4-A", "E4-B", "E4-C", "E5", "E6")
EVIDENCE_FACETS = ("E4-A", "E4-B", "E4-C")
EVIDENCE_STAGE = {level: (4 if level in EVIDENCE_FACETS else int(level[1])) for level in EVIDENCE_LEVELS}

# The three stage-4 denotations name different facets.
FACET_OF_DENOTATION = {
    "reproduced_independent": "E4-A",
    "independent_review": "E4-B",
    "adversarial_assessment": "E4-C",
}

EVIDENCE_DENOTATIONS: dict[str, int] = {
    "assertion": 0,
    "unbound_claim": 0,
    "narrative": 0,
    "specified": 1,
    "documented_architecture": 1,
    "implemented": 1,
    "inspected_artifact": 1,
    "executed_local": 2,
    "project_reported": 2,
    "tests_pass_author_machine": 2,
    "replayed_fresh_same_org": 3,
    "replayed_fresh_same_author": 3,
    "reproduced_independent": 4,
    "independent_review": 4,
    "adversarial_assessment": 4,
    "operational_validation": 5,
    "monitored_realistic_use": 5,
    "qualified_external_assessment": 6,
    "production_authorized": 6,
}

# Every stage-4 definition must name its facet. A new stage-4 denotation without one would be an
# E4 that certifies no facet, so refuse to load rather than guess.
if {k for k, v in EVIDENCE_DENOTATIONS.items() if v == 4} != set(FACET_OF_DENOTATION):
    raise ImportError("every stage-4 evidence denotation must be assigned a facet in FACET_OF_DENOTATION")

# --- organizational standing (axis `authority` now, `standing` under AM-001) -
STANDING_DENOTATIONS: dict[str, int] = {
    "individual_research_artifact": 0,
    "no_authority": 0,
    "internal_organizational": 1,
    "external_collaborator_validated": 2,
    "independent_institutional": 3,
    "broad_operational_recognition": 4,
}

# --- permission to act (proposed) -------------------------------------------
PERMISSION_DENOTATIONS: dict[str, int] = {
    "may_not_act": 0,
    "may_act_in_development": 1,
    "may_act_in_staging": 2,
    "may_act_in_limited_operation": 3,
    "may_act_in_production": 4,
}

# --- assurance stage (proposed) ---------------------------------------------
ASSURANCE_DENOTATIONS: dict[str, int] = {
    "assurance_not_assessed": 0,
    "assurance_designed": 1,
    "assurance_implemented": 2,
    "assurance_evaluated": 3,
    "assurance_controlled": 4,
    "assurance_qualified": 5,
}

DENOTATIONS = {
    EVIDENCE: EVIDENCE_DENOTATIONS,
    AUTHORITY: STANDING_DENOTATIONS,
    STANDING: STANDING_DENOTATIONS,
    PERMISSION: PERMISSION_DENOTATIONS,
    ASSURANCE: ASSURANCE_DENOTATIONS,
}

# Tokens that read as levels but are speech acts. A performative is not a rung;
# accepting one is how the master invariant gets breached without a number
# changing. Recorded failure mode: SXR-2026-08-04 "ACCEPTED".
PERFORMATIVE_TOKENS = frozenset(
    {
        "accepted",
        "approved",
        "canonical",
        "certified",
        "final",
        "frozen",
        "ratified",
        "sealed",
        "signed",
        "validated",
        "verified",
    }
)


def label(axis: str, ordinal: int) -> str:
    return f"{PREFIX[axis]}{ordinal}"


# --- levels: the order every axis is evaluated in ----------------------------
# Non-evidence axes are chains, so their level is just the label of the ordinal.

def levels(axis: str) -> tuple[str, ...]:
    if axis == EVIDENCE:
        return EVIDENCE_LEVELS
    return tuple(label(axis, i) for i in range(CEILING[axis] + 1))


def stage(axis: str, level: str) -> int:
    if axis == EVIDENCE:
        return EVIDENCE_STAGE[level]
    return int(level[len(PREFIX[axis]):])


def level_of_stage(axis: str, ordinal: int) -> str:
    """The unique level at a stage. Stage 4 on the evidence axis has three, so it has none."""
    if axis == EVIDENCE and ordinal == 4:
        raise ValueError("evidence stage 4 is three incomparable facets; name one (E4-A/B/C)")
    return label(axis, ordinal)


def leq(axis: str, a: str, b: str) -> bool:
    """a <= b. Distinct facets are incomparable."""
    return a == b or stage(axis, a) < stage(axis, b)


def meet(axis: str, a: str, b: str) -> str:
    """Greatest common lower bound. For two distinct facets that is E3."""
    lower = [x for x in levels(axis) if leq(axis, x, a) and leq(axis, x, b)]
    best = [x for x in lower if all(leq(axis, y, x) for y in lower)]
    assert len(best) == 1, (a, b, best)
    return best[0]


def meet_all(axis: str, values) -> str:
    result = levels(axis)[-1]
    for v in values:
        result = meet(axis, result, v)
    return result


def ceiling(axis: str, values) -> list[str]:
    """The portfolio ceiling: the maximal readings, in axis order. An aggregation, not a join:
    every element is one of the given readings; nothing is synthesized (E4-A and E4-B give
    [E4-A, E4-B], never E5)."""
    distinct = set(values)
    top = [x for x in distinct if not any(leq(axis, x, y) and x != y for y in distinct)]
    return sorted(top, key=levels(axis).index)


def denotation_level(axis: str, key: str) -> str | None:
    ordinal = denotation_ordinal(axis, key)
    if ordinal is None:
        return None
    ordinal = clamp(axis, ordinal)
    if axis == EVIDENCE and ordinal == 4:
        return FACET_OF_DENOTATION[key]
    return label(axis, ordinal)


def denotation_ordinal(axis: str, key: str) -> int | None:
    return DENOTATIONS[axis].get(key)


def clamp(axis: str, ordinal: int) -> int:
    return max(0, min(ordinal, CEILING[axis]))
