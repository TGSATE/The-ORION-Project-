# Reproducing WN-XWK-001

This artifact was built to be small enough to actually be reproduced. It has no
third-party dependencies, no network access, no build step, and no clock in its
reproducible digest. If a portfolio's root blocker is that nothing has been
reproduced outside the originating control environment, the thing to hand an
outside operator first is the cheapest thing to check.

## What you need

- Python 3.11 or later. Nothing else.
- The package directory as delivered, unmodified.

## Run it

```
cd wn-crosswalk
python3 -m unittest discover -s tests            # expect: 106 tests, OK
python3 -m wn_crosswalk verify --expected witness/EXPECTED.json
```

Expected final line:

```
RESULT: MATCH
```

The digest under test is `core_sha256` in `witness/EXPECTED.json`.

v0.3.1 changed that digest. The chain is v0.1.0 `08c4a75f…`, then v0.2.0
`1b881684…fe2a`, then v0.3.0 `69d94c63…e88f` (a same-day draft), then v0.3.1.
The expectation file records each earlier digest under `supersedes`, with the
reason. On this corpus every artifact's reading is unchanged; the receipt
carries more fields. If you are holding an earlier package, its own digest is
still the right one for it.

Watch for one skip in the test output. `test_conformance_against_reference_library`
cross-checks the pure-Python Ed25519 against the `cryptography` package and
skips when that package is absent. A skip is not a failure, but it does mean
the signature arithmetic is unconfirmed on your machine — please report whether
it ran or skipped.

To see the adjudication itself:

```
python3 -m wn_crosswalk adjudicate corpus/wn-2026-08-06.json --findings
python3 -m wn_crosswalk collisions
python3 -m wn_crosswalk translate evidence sealkit.local E4
python3 -m wn_crosswalk translate evidence weaver.e4class E4-B
python3 -m wn_crosswalk ratification --list-unbound
python3 -m wn_crosswalk amendments
python3 -m wn_crosswalk attest witness/WITNESS_RECEIPT.template.json
```

`ratification` exits 1 and reports UNRATIFIED. That is the expected state and
the honest one: no rung in the registry yet cites the document that fixed it.

`adjudicate` and `collisions` exit non-zero when they find something. That is
the intended behaviour, not a failure of the run. Exit 2 means at least one P0
finding; exit 1 means only lower-severity findings; exit 0 means nothing was
found, which for this corpus would itself be a surprise worth reporting.

## What a match does and does not establish

A match on a machine that is not the originating machine is portability and
determinism evidence **for this tool only**, at E3 if you are inside the same
organization and E4 if you are not. It says nothing about Sealkit, Cathedral
Guard, the Lucifer Latch, or anything else the tool adjudicates. A tool that
correctly reports "no independent reproduction exists" has not thereby produced
one.

## If it diverges

A divergence is a finding, not a nuisance. Do not adjust the expectation file.
Report:

- your platform and `python3 --version`
- the actual `core_sha256` printed
- the full output of `python3 -m unittest discover -s tests -v`
- whether the package directory was modified in any way

The likeliest causes, in order: a modified corpus or registry file, a Python
version whose `unicodedata` NFC tables differ, or a genuine defect in the
canonicalization boundary. All three are worth knowing about.

## Witness receipt

If you are acting as a witness, fill in `witness/WITNESS_RECEIPT.template.json`
and return it. Leave any field you cannot honestly complete as `null`. An
incomplete receipt is useful; a padded one is not.

The receipt asks for an identity binding — something externally checkable, not
a role label. "Independent reviewer" is not an identity. The distinction is the
whole reason the field exists.
