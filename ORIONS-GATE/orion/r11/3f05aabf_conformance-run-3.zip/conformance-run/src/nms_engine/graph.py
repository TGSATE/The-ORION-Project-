"""The Axiom of Non-Monotonic Support, executed.

The handoff ratifies the axiom in prose:

    "Effective evidence of a claim is the minimum of its asserted evidence and
     all its dependencies."

It then reports a portfolio ceiling without applying it. This module applies it.

effective(n) = min(asserted(n), min over d in deps(n) of effective(d))

Two fail-closed cases the prose does not specify, resolved here in the
direction of the Prime Invariant:
  - a dependency cycle collapses to E0 (EVID-CYCLE)
  - a missing dependency collapses to E0 (EVID-MISSING-DEP)
"""

from __future__ import annotations

LEVELS = ["E0", "E1", "E2", "E3self", "E3", "E4", "E5", "E6"]
RANK = {name: i for i, name in enumerate(LEVELS)}

MEANING = {
    "E0": "assertion",
    "E1": "specification",
    "E2": "self-verified",
    "E3self": "author clean-room replay",
    "E3": "independent reproduction",
    "E4": "operational validation",
    "E5": "constitutional acceptance",
    "E6": "external assessment",
}


class GraphError(ValueError):
    pass


class ClaimGraph:
    def __init__(self, nodes: dict):
        if not isinstance(nodes, dict) or not nodes:
            raise GraphError("graph must be a non-empty object")
        self.nodes = {}
        for cid, spec in nodes.items():
            asserted = spec.get("asserted")
            if asserted not in RANK:
                raise GraphError("node %s: unknown level %r" % (cid, asserted))
            self.nodes[cid] = {
                "asserted": asserted,
                "depends_on": list(spec.get("depends_on") or []),
                "note": spec.get("note", ""),
                "kind": spec.get("kind", "claim"),
            }
        self._memo = {}
        self._cyclic = self._find_cycles()

    def _find_cycles(self):
        """Nodes participating in a dependency cycle. Iterative, colour-marked."""
        WHITE, GREY, BLACK = 0, 1, 2
        colour = {cid: WHITE for cid in self.nodes}
        cyclic = set()
        for root in self.nodes:
            if colour[root] != WHITE:
                continue
            stack = [(root, iter(self.nodes[root]["depends_on"]))]
            path = [root]
            colour[root] = GREY
            while stack:
                node, it = stack[-1]
                advanced = False
                for dep in it:
                    if dep not in self.nodes:
                        continue
                    if colour[dep] == GREY:
                        i = path.index(dep)
                        cyclic.update(path[i:])
                    elif colour[dep] == WHITE:
                        colour[dep] = GREY
                        path.append(dep)
                        stack.append((dep, iter(self.nodes[dep]["depends_on"])))
                        advanced = True
                        break
                if not advanced:
                    colour[node] = BLACK
                    stack.pop()
                    path.pop()
        return cyclic

    # -- core operator -------------------------------------------------

    def effective(self, cid: str):
        """Return dict(level, limiters, reason).

        `limiters` is every node that must rise before this claim can rise:
        the claim itself when its own assertion is at the effective level, plus
        the ultimate limiters of any dependency sitting at that same level.
        """
        if cid not in self.nodes:
            return {"level": "E0", "limiters": [cid], "reason": "EVID-MISSING-DEP"}
        if cid in self._cyclic:
            return {"level": "E0", "limiters": [cid], "reason": "EVID-CYCLE"}
        if cid in self._memo:
            return self._memo[cid]

        node = self.nodes[cid]
        level = node["asserted"]
        for dep in node["depends_on"]:
            sub = self.effective(dep)
            if RANK[sub["level"]] < RANK[level]:
                level = sub["level"]

        limiters = set()
        if node["asserted"] == level:
            limiters.add(cid)
        for dep in node["depends_on"]:
            sub = self.effective(dep)
            if sub["level"] == level:
                limiters.update(sub["limiters"])
        if not limiters:
            limiters.add(cid)

        result = {
            "level": level,
            "limiters": sorted(limiters),
            "reason": "self" if limiters == {cid} else "propagated",
        }
        self._memo[cid] = result
        return result

    # -- reporting -----------------------------------------------------

    def table(self):
        rows = []
        for cid in sorted(self.nodes):
            node = self.nodes[cid]
            eff = self.effective(cid)
            rows.append(
                {
                    "id": cid,
                    "kind": node["kind"],
                    "asserted": node["asserted"],
                    "effective": eff["level"],
                    "held": eff["level"] == node["asserted"],
                    "limiters": eff["limiters"],
                    "note": node["note"],
                }
            )
        return rows

    def collapses(self):
        return [r for r in self.table() if not r["held"]]

    def asserting(self):
        """Claims that actually assert something above E0."""
        return [r for r in self.table() if RANK[r["asserted"]] > 0]

    def limiter_census(self):
        """How many OTHER claims each node is a binding constraint for.

        The action register orders blockers by declared severity. This orders
        them by load borne. They are not the same order.
        """
        counts = {}
        for row in self.table():
            for lim in row["limiters"]:
                if lim != row["id"]:
                    counts[lim] = counts.get(lim, 0) + 1
        return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))

    def ceiling(self):
        best = "E0"
        holders = []
        for row in self.table():
            if RANK[row["effective"]] > RANK[best]:
                best = row["effective"]
                holders = [row["id"]]
            elif row["effective"] == best:
                holders.append(row["id"])
        return best, sorted(holders)
