"""The Axiom of Non-Monotonic Support, executed.

The handoff ratifies the axiom in prose:

    "Effective evidence of a claim is the minimum of its asserted evidence and
     all its dependencies."

It then reports a portfolio ceiling without applying it. This module applies it.

effective(n) = asserted(n) MEET (MEET over d in deps(n) of effective(d))

"Minimum" is the meet of the evidence order the graph is evaluated on. On a
chain, such as the CSAA handoff ladder, that is the ordinary minimum. On the
canonical faceted axis it is the lattice meet: a claim resting on independent
reproduction (E4-A) and on independent review (E4-B), with no dependency
holding both, is held at E3.

Two fail-closed cases the prose does not specify, resolved here in the
direction of the Prime Invariant:
  - a dependency cycle collapses to the order's least level, E0 (EVID-CYCLE)
  - a missing dependency collapses to E0 (EVID-MISSING-DEP)

The order is a parameter (ruling D3, 2026-10-04)
------------------------------------------------
    ClaimGraph(nodes)                        the canonical faceted axis (default)
    ClaimGraph(nodes, order=CSAA_HANDOFF)    the handoff's own chain, as before

    CANONICAL     E0 < E1 < E2 < E3 < {E4-A, E4-B, E4-C} < E5 < E6
                  (facets pairwise incomparable; E5 and E6 above every facet,
                  which is the stage order: the 2026-10-04 ruling left that half
                  of the order open, see LatticeCore assumption A1)
    CSAA_HANDOFF  E0 < E1 < E2 < E3self < E3 < E4 < E5 < E6
                  (a chain; the module-level LEVELS, RANK and MEANING)

Any finite meet-semilattice with a least element can be supplied as an Order.
It is checked when it is built; an order that is not one is refused.

CSAA data must pass order=CSAA_HANDOFF. A CSAA-only level (E3self, E4) is refused
under the default, but a graph that only uses names the two ladders share (E0-E3,
E5, E6) builds under the canonical order and is read with canonical meanings:
CSAA's E3 is independent reproduction, canonical E3 is same-organization replay.
"""

from __future__ import annotations

# --- the CSAA handoff ladder (unchanged; kept under its original names) ------

LEVELS = ["E0", "E1", "E2", "E3self", "E3", "E4", "E5", "E6"]
RANK = {name: i for i, name in enumerate(LEVELS)}

MEANING = {
    "E0": "assertion",
    "E1": "specification",
    "E2": "self-verified",
    "E3self": "author clean-room replay",
    "E3": "independent reproduction",
    "E4": "operational validation",
    "E5": "constitutional acceptance",
    "E6": "external assessment",
}

# --- the canonical faceted axis ---------------------------------------------

CANONICAL_LEVELS = ["E0", "E1", "E2", "E3", "E4-A", "E4-B", "E4-C", "E5", "E6"]
CANONICAL_FACETS = ["E4-A", "E4-B", "E4-C"]
_STAGE = {lvl: (4 if lvl in CANONICAL_FACETS else int(lvl[1])) for lvl in CANONICAL_LEVELS}

CANONICAL_MEANING = {
    "E0": "assertion",
    "E1": "specified",
    "E2": "executed locally",
    "E3": "replayed fresh, same organization",
    "E4-A": "independent reproduction",
    "E4-B": "independent review",
    "E4-C": "adversarial assessment",
    "E5": "operational validation",
    "E6": "qualified external assessment",
}


class GraphError(ValueError):
    pass


class OrderError(GraphError):
    pass


class Order:
    """A finite meet-semilattice with a least element: levels and <=.

    Checked on construction: <= must be a partial order; there must be a least
    level (the fail-closed value for cycles and missing dependencies); and every
    pair of levels must have exactly one greatest common lower bound (the meet).
    Meets and covers are tabulated once.
    """

    def __init__(self, name, levels, le, meaning=None):
        levels = list(levels)
        if not levels or len(set(levels)) != len(levels):
            raise OrderError("order %r: levels must be non-empty and distinct" % (name,))
        rel = {(a, b): bool(le(a, b)) for a in levels for b in levels}
        for a in levels:
            if not rel[a, a]:
                raise OrderError("order %r: <= is not reflexive at %r" % (name, a))
            for b in levels:
                if a != b and rel[a, b] and rel[b, a]:
                    raise OrderError("order %r: %r <= %r and %r <= %r" % (name, a, b, b, a))
                for c in levels:
                    if rel[a, b] and rel[b, c] and not rel[a, c]:
                        raise OrderError("order %r: <= is not transitive at %r, %r, %r" % (name, a, b, c))
        least = [a for a in levels if all(rel[a, b] for b in levels)]
        if not least:
            raise OrderError("order %r: no least level to fail closed to" % (name,))
        meets = {}
        for a in levels:
            for b in levels:
                lower = [x for x in levels if rel[x, a] and rel[x, b]]
                best = [x for x in lower if all(rel[y, x] for y in lower)]
                if len(best) != 1:
                    raise OrderError("order %r: %r and %r have no meet; not a meet-semilattice" % (name, a, b))
                meets[a, b] = best[0]
        greatest = [a for a in levels if all(rel[b, a] for b in levels)]

        self.name = name
        self.levels = tuple(levels)
        self.bottom = least[0]
        self.top = greatest[0] if greatest else None
        self.meaning = dict(meaning or {})
        self._index = {lvl: i for i, lvl in enumerate(levels)}
        self._le = rel
        self._meet = meets
        self._covers = {
            a: tuple(x for x in levels if a != x and rel[a, x]
                     and not any(y not in (a, x) and rel[a, y] and rel[y, x] for y in levels))
            for a in levels
        }

    @classmethod
    def chain(cls, name, levels, meaning=None):
        rank = {lvl: i for i, lvl in enumerate(levels)}
        return cls(name, levels, lambda a, b: rank[a] <= rank[b], meaning)

    def has(self, level):
        try:
            return level in self._index
        except TypeError:  # unhashable, so not a level
            return False

    def le(self, a, b):
        return self._le[a, b]

    def meet(self, a, b):
        return self._meet[a, b]

    def meet_all(self, values):
        values = list(values)
        if not values:
            if self.top is None:
                raise OrderError("order %r: the meet of nothing needs a greatest level" % (self.name,))
            return self.top
        result = values[0]
        for v in values[1:]:
            result = self._meet[result, v]
        return result

    def covers(self, level):
        """The levels immediately above `level` (several, for E3 on the canonical axis)."""
        return self._covers[level]

    def maximal(self, values):
        """The distinct maximal values, in the order's level order. Never synthesizes a level."""
        distinct = set(values)
        tops = [x for x in distinct if not any(x != y and self._le[x, y] for y in distinct)]
        return sorted(tops, key=self._index.__getitem__)

    def is_chain(self):
        return all(self._le[a, b] or self._le[b, a] for a in self.levels for b in self.levels)

    def __repr__(self):
        return "Order(%r, %d levels)" % (self.name, len(self.levels))


CANONICAL = Order("canonical-faceted", CANONICAL_LEVELS,
                  lambda a, b: a == b or _STAGE[a] < _STAGE[b], CANONICAL_MEANING)
CSAA_HANDOFF = Order.chain("csaa-handoff", LEVELS, MEANING)
_KNOWN = (("CANONICAL", CANONICAL), ("CSAA_HANDOFF", CSAA_HANDOFF))


class ClaimGraph:
    def __init__(self, nodes: dict, order: Order = CANONICAL):
        if not isinstance(order, Order):
            raise GraphError("order must be an Order, e.g. CANONICAL or CSAA_HANDOFF")
        if not isinstance(nodes, dict) or not nodes:
            raise GraphError("graph must be a non-empty object")
        self.order = order
        self.nodes = {}
        for cid, spec in nodes.items():
            if not isinstance(spec, dict):
                raise GraphError("node %s: must be an object" % (cid,))
            asserted = spec.get("asserted")
            if not order.has(asserted):
                hint = "".join("; %r is a level of %s, pass order=%s" % (asserted, other.name, label)
                               for label, other in _KNOWN if other is not order and other.has(asserted))
                raise GraphError("node %s: unknown level %r on order %s%s" % (cid, asserted, order.name, hint))
            self.nodes[cid] = {
                "asserted": asserted,
                "depends_on": list(spec.get("depends_on") or []),
                "note": spec.get("note", ""),
                "kind": spec.get("kind", "claim"),
            }
        self._memo = {}
        self._cyclic = self._find_cycles()

    def _present_deps(self, cid):
        return [d for d in self.nodes[cid]["depends_on"] if d in self.nodes]

    def _find_cycles(self):
        """Every node that lies on a dependency cycle: the members of each strongly
        connected component with more than one node, or with a self-loop.

        Iterative Tarjan. The previous depth-first search marked only the nodes on
        its current path when it met a back edge, so a node that closes a cycle
        through an already-finished node was missed: with A->B->C->A and A->D->C,
        D is on the cycle D->C->A->D, but was reported as limited by C instead of
        as EVID-CYCLE. Its level was right (E0, through C); its reason was not.
        """
        index, low, on_stack, stack, cyclic = {}, {}, set(), [], set()
        counter = 0
        for root in self.nodes:
            if root in index:
                continue
            index[root] = low[root] = counter
            counter += 1
            stack.append(root)
            on_stack.add(root)
            work = [(root, iter(self._present_deps(root)))]
            while work:
                node, deps = work[-1]
                descended = False
                for dep in deps:
                    if dep not in index:
                        index[dep] = low[dep] = counter
                        counter += 1
                        stack.append(dep)
                        on_stack.add(dep)
                        work.append((dep, iter(self._present_deps(dep))))
                        descended = True
                        break
                    if dep in on_stack:
                        low[node] = min(low[node], index[dep])
                if descended:
                    continue
                work.pop()
                if work:
                    parent = work[-1][0]
                    low[parent] = min(low[parent], low[node])
                if low[node] == index[node]:
                    component = []
                    while True:
                        member = stack.pop()
                        on_stack.discard(member)
                        component.append(member)
                        if member == node:
                            break
                    if len(component) > 1 or node in self.nodes[node]["depends_on"]:
                        cyclic.update(component)
        return cyclic

    # -- core operator -------------------------------------------------

    def effective(self, cid: str):
        """Return dict(level, limiters, reason).

        `level` is the meet of the claim's own assertion and the effective levels
        of its dependencies.

        `limiters`: a claim held at level L can rise only through one of L's covers
        (the levels just above it). For each cover u, the contributions not at or
        above u block that way up. `limiters` is the union of the smallest blocking
        sets, i.e. every contribution whose rise is part of some cheapest way up (the
        claim itself for its own assertion; otherwise that dependency's limiters, so
        they are ultimate). On a chain L has one cover and one blocking set, the
        contributions sitting at L: exactly the previous definition. On the faceted
        axis the union can mix alternatives. Over E4-A and E4-B dependencies both are
        listed, and raising either opens a way up. Over E4-A, E4-B and E4-C all three
        are listed, although each way up needs two of them to rise. A contribution
        in EVERY blocking set must rise for any way up; this list does not single
        those out. At the top level nothing can rise, and the contributions sitting
        there are listed, as before.
        """
        if cid not in self.nodes:
            return {"level": self.order.bottom, "limiters": [cid], "reason": "EVID-MISSING-DEP"}
        if cid in self._cyclic:
            return {"level": self.order.bottom, "limiters": [cid], "reason": "EVID-CYCLE"}
        if cid not in self._memo:
            self._evaluate(cid)
        return self._memo[cid]

    def _evaluate(self, root):
        """Post-order without recursion. Off the cycles the dependency graph is acyclic, so the
        search never meets a node it is still expanding (those form the path from the root). If it
        does, the graph was changed after construction into a cycle the constructor never saw, and it
        refuses rather than loop. It does not revisit results already memoized: a ClaimGraph is not
        meant to be changed after construction."""
        expanding = set()
        stack = [(root, False)]
        while stack:
            cid, ready = stack.pop()
            if cid in self._memo:
                continue
            if ready:
                expanding.discard(cid)
                self._memo[cid] = self._combine(cid)
                continue
            expanding.add(cid)
            stack.append((cid, True))
            for dep in self.nodes[cid]["depends_on"]:
                if dep in self.nodes and dep not in self._cyclic and dep not in self._memo:
                    if dep in expanding:
                        raise GraphError("cycle through %s was not detected at construction; build a new "
                                         "ClaimGraph instead of changing nodes in place" % (dep,))
                    stack.append((dep, False))

    def _combine(self, cid):
        order = self.order
        node = self.nodes[cid]
        contributions = [(None, node["asserted"])]
        contributions += [(dep, self.effective(dep)["level"]) for dep in node["depends_on"]]
        values = [value for _, value in contributions]
        level = order.meet_all(values)

        covers = order.covers(level)
        if covers:
            blocking = {frozenset(i for i, v in enumerate(values) if not order.le(u, v)) for u in covers}
            smallest = [b for b in blocking if not any(other < b for other in blocking)]
            binding = set().union(*smallest)
        else:
            binding = {i for i, v in enumerate(values) if v == level}

        limiters = set()
        for i, (dep, _) in enumerate(contributions):
            if i not in binding:
                continue
            if dep is None:
                limiters.add(cid)
            else:
                limiters.update(self.effective(dep)["limiters"])
        if not limiters:
            limiters.add(cid)

        return {
            "level": level,
            "limiters": sorted(limiters),
            "reason": "self" if limiters == {cid} else "propagated",
        }

    # -- reporting -----------------------------------------------------

    def table(self):
        rows = []
        for cid in sorted(self.nodes):
            node = self.nodes[cid]
            eff = self.effective(cid)
            rows.append(
                {
                    "id": cid,
                    "kind": node["kind"],
                    "asserted": node["asserted"],
                    "effective": eff["level"],
                    "held": eff["level"] == node["asserted"],
                    "limiters": eff["limiters"],
                    "note": node["note"],
                }
            )
        return rows

    def collapses(self):
        return [r for r in self.table() if not r["held"]]

    def asserting(self):
        """Claims that actually assert something above the order's least level (E0)."""
        return [r for r in self.table() if r["asserted"] != self.order.bottom]

    def limiter_census(self):
        """How many OTHER claims each node is a binding constraint for.

        The action register orders blockers by declared severity. This orders
        them by load borne. They are not the same order.
        """
        counts = {}
        for row in self.table():
            for lim in row["limiters"]:
                if lim != row["id"]:
                    counts[lim] = counts.get(lim, 0) + 1
        return sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))

    def ceilings(self):
        """The ceiling as an aggregation: each maximal effective level with the nodes
        holding it. Incomparable maxima are listed side by side. Nothing is joined:
        E4-A beside E4-B is two entries, never an E5 that no node holds."""
        rows = self.table()
        return [(lvl, sorted(r["id"] for r in rows if r["effective"] == lvl))
                for lvl in self.order.maximal(r["effective"] for r in rows)]

    def ceiling(self):
        """(level, holders) when the maximum is a single level, which it always is on
        a chain. With incomparable maxima it refuses rather than pick one."""
        tops = self.ceilings()
        if len(tops) != 1:
            raise GraphError("the ceiling is not one level (%s); use ceilings()"
                             % " + ".join(lvl for lvl, _ in tops))
        return tops[0]
