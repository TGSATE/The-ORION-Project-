"""The table-claim -> Crosswalk-artifact mapping, shared by every Crosswalk adapter.

Moved verbatim out of crosswalk_adapter.py (the v0.2.0 adapter) so that the v0.2.0 and v0.3.1 runs use
one mapping by construction, without one adapter importing the other. Pure data and functions: no
Crosswalk import, no registry built. The mapping itself is documented at the top of
crosswalk_adapter.py.
"""

FACET_LABEL = {"E4A": "E4-A", "E4B": "E4-B", "E4C": "E4-C"}
STAGE = {"E0": 0, "E1": 1, "E2": 2, "E3": 3, "E4A": 4, "E4B": 4, "E4C": 4, "E5": 5, "E6": 6}
E_DENOTES = {"E0": "assertion", "E1": "specified", "E2": "executed_local",
             "E3": "replayed_fresh_same_org", "E4A": "reproduced_independent",
             "E4B": "independent_review", "E4C": "adversarial_assessment",
             "E5": "operational_validation", "E6": "qualified_external_assessment"}
O_DENOTES = {"O0": "individual_research_artifact", "O1": "internal_organizational",
             "O2": "external_collaborator_validated", "O3": "independent_institutional",
             "O4": "broad_operational_recognition"}


def split(reading):
    e, o = reading.split("/")
    return e, o


def artifact_for(claim, reading):
    e, o = split(reading)
    w = claim["witness"]
    witness = {}
    if w != "none":
        witness = {
            "principal": "owner" if w == "self" else "witness",
            "org": "owner-org" if w == "same_org" else ("other-org" if w == "independent" else "owner-org"),
            "identity_binding": "wid:witness" if claim["witness_binding"] else None,
            "signed": bool(claim["signed"]),
            "signature": {"verified": bool(claim["signed"]),
                          "key_fingerprint": "ed25519:fp" if claim["external_identity"] else None},
        }
    elif claim["witness_binding"]:
        witness = {"identity_binding": "wid:witness"}
    if claim["performative"]:
        ev = {"ladder": "wn.core", "label": "SEALED"}
        au = {"ladder": "wn.core.authority", "label": "SEALED"}
    else:
        ev = ({"ladder": "weaver.e4class", "label": FACET_LABEL[e]} if e in FACET_LABEL
              else {"ladder": "wn.core", "label": e})
        au = {"ladder": "csaa.authority" if claim["axis_kind_mismatch"] else "wn.core.authority",
              "label": o}
    return {
        "artifact_id": "probe",
        "owner_principal": "owner",
        "owner_org": "owner-org",
        "witness": witness,
        "bindings": {"receipt_digest": "sha256:r" if claim["receipt_digest"] else None,
                     "artifact_digest": "sha256:a" if claim["artifact_digest"] else None},
        "substrate": "simulation" if claim["simulation"] else "physical",
        "track": claim["track"],
        "ratification": {"principal": "ryan", "date": "2026-08-06"} if claim["ratified"] else {},
        "extraction": {"extraction_status": "hand_extracted" if claim["hand_extracted"] else "verified"},
        "claim": ev,
        "authority_claim": au,
    }


CLEAN = {"receipt_digest": True, "witness_binding": True, "witness": "independent", "signed": True,
         "external_identity": True, "simulation": False, "track": "logos", "ratified": True,
         "artifact_digest": True, "hand_extracted": False, "performative": False,
         "axis_kind_mismatch": False}
