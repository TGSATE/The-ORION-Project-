"""Conformance adapter: wn-crosswalk v0.3.1 (the facet-aware patch, ruling D2 of 2026-10-04, with the
fixes from independent review of the v0.3.0 draft).

Source: src/crosswalk-0.3.1/ (the release tree; digests in SOURCES.md). Own suite 106/106, `verify` ->
RESULT: MATCH.

What changed from the v0.2.0 adapter: nothing is DECODED any more. v0.2.0 returned an integer
ordinal, so a stage-4 output had to be mapped back to a facet by guessing from the input, and two
different facets could not be represented at all. v0.3 returns levels, and the adapter only renames
them (E4-A -> E4A, the table's spelling):

  crosswalk_normalize   `_adjudicate_one(...)["evidence_level"]` + `authority_ordinal`
  crosswalk_translate   `translate(...).normalized_level`, TWICE, and the two must agree:
                          (a) on a probe ladder whose facet rungs DECLARE their level (`level`), and
                          (b) on one ladder per definition whose rungs are SPELLED as canonical levels
                              (E4-A, E4-B, ...) and declare nothing.
                        A label can name its facet either way, so both paths are driven on every row.
                        v0.3.0 read (b) wrong (NF-016); run 3 on v0.3.0 drove only (a) and missed it.
                        Disagreement raises, which the harness records as a mismatch.
  e_ceiling             `adjudicate(...)["aggregate"]["evidence_ceiling_levels"]` (the set of maximal
                        readings, v0.3; v0.2.0 had only a single maximum)
  e_le / e_meet         `axes.leq` / `axes.meet` on the evidence axis: Crosswalk's own order
  o_le / o_meet         the same on the authority axis (a chain)

The artifact mapping (table claim -> Crosswalk artifact record) is the v0.2.0 adapter's, unchanged, in
crosswalk_mapping.py, which both adapters import, so the runs differ only in the system under test.

Not reachable from the tables: a BARE "E4" label (stage 4, no facet named). The Lean model has no such
input; every table label names a facet. v0.3.1's handling of it (take the definition's facet, else
read E3) is covered by Crosswalk's own unit tests, not by this run.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# Overridable only so checks/v030_draft_dual_probe.py can point this same adapter at the v0.3.0 draft.
SRC = os.environ.get("CROSSWALK_SRC") or os.path.join(HERE, "..", "src", "crosswalk-0.3.1")
EXPECT_VERSION = os.environ.get("CROSSWALK_VERSION", "0.3.1")
sys.path.insert(0, SRC)
for name in [m for m in sys.modules if m == "wn_crosswalk" or m.startswith("wn_crosswalk.")]:
    del sys.modules[name]  # never test a previously imported version by accident
from wn_crosswalk import __version__, axes  # noqa: E402
from wn_crosswalk.adjudicate import _adjudicate_one, adjudicate  # noqa: E402
from wn_crosswalk.registry import Registry  # noqa: E402
from wn_crosswalk.translate import translate  # noqa: E402

assert __version__ == EXPECT_VERSION, __version__
assert os.path.realpath(sys.modules["wn_crosswalk"].__file__).startswith(os.path.realpath(SRC))

# the same table-claim -> artifact mapping as the v0.2.0 adapter (one module, shared)
sys.path.insert(0, HERE)
from crosswalk_mapping import CLEAN, E_DENOTES, O_DENOTES, STAGE, artifact_for, split  # noqa: E402

TO_LEVEL = {"E4A": "E4-A", "E4B": "E4-B", "E4C": "E4-C"}
FROM_LEVEL = {v: k for k, v in TO_LEVEL.items()}

REG = Registry.load()


def table(level):
    return FROM_LEVEL.get(level, level)


def level(x):
    return TO_LEVEL.get(x, x)


def _probe_registry():
    def ladder(lid, axis, kind, rungs):
        return Registry._build({"ladder_id": lid, "axis": axis, "kind": kind, "status": "canonical",
                                "label_comparable": True, "source": "conformance probe", "rungs": rungs})

    def e_rung(l, d):
        rung = {"label": f"{l}|{d}", "ordinal": STAGE[l], "denotes": E_DENOTES[d], "pinned": True}
        if l in TO_LEVEL:
            rung["level"] = TO_LEVEL[l]   # the facet the label names, declared, not inferred
        return rung

    e_rungs = [e_rung(l, d) for l in STAGE for d in STAGE]
    o_rungs = [{"label": f"{l}|{d}", "ordinal": int(l[1]), "denotes": O_DENOTES[d], "pinned": True}
               for l in O_DENOTES for d in O_DENOTES]
    ladders = {"probe.e": ladder("probe.e", axes.EVIDENCE, axes.CANONICAL_KIND[axes.EVIDENCE], e_rungs),
               "probe.o": ladder("probe.o", axes.AUTHORITY, axes.CANONICAL_KIND[axes.AUTHORITY], o_rungs)}
    return Registry({"registry_version": "probe"}, ladders)


PROBE = _probe_registry()


def _spelled_registry():
    """One ladder per definition; rungs labelled with the canonical spellings, no `level` anywhere."""
    ladders = {}
    for d in STAGE:
        lid = f"spell.{d}"
        rungs = [{"label": level(l), "ordinal": STAGE[l], "denotes": E_DENOTES[d], "pinned": True} for l in STAGE]
        ladders[lid] = Registry._build({"ladder_id": lid, "axis": axes.EVIDENCE,
                                        "kind": axes.CANONICAL_KIND[axes.EVIDENCE], "status": "canonical",
                                        "label_comparable": True, "source": "conformance probe", "rungs": rungs})
    return Registry({"registry_version": "probe-spelled"}, ladders)


SPELLED = _spelled_registry()


class Adapter:
    def crosswalk_normalize(self, claim, reading):
        result = _adjudicate_one(REG, artifact_for(claim, reading))
        return f"{table(result['evidence_level'])}/O{result['authority_ordinal']}"

    def crosswalk_translate(self, label, denotation):
        (le, lo), (de, do) = split(label), split(denotation)
        declared = translate(PROBE, axes.EVIDENCE, "probe.e", f"{le}|{de}").normalized_level
        spelled = translate(SPELLED, axes.EVIDENCE, f"spell.{de}", level(le)).normalized_level
        if declared != spelled:
            raise AssertionError(f"label {le} over definition {de}: declared level reads {declared}, "
                                 f"spelled label reads {spelled}")
        au = translate(PROBE, axes.AUTHORITY, "probe.o", f"{lo}|{do}").normalized_level
        return f"{table(declared)}/{au}"

    def e_ceiling(self, readings):
        arts = []
        for i, e in enumerate(readings):
            a = artifact_for(CLEAN, f"{e}/O0")
            a["artifact_id"] = f"a{i:02d}"
            arts.append(a)
        agg = adjudicate(REG, {"corpus_id": "ceiling-probe", "artifacts": arts})["aggregate"]
        return [table(x) for x in agg["evidence_ceiling_levels"]]

    def e_le(self, a, b):
        return axes.leq(axes.EVIDENCE, level(a), level(b))

    def e_meet(self, a, b):
        return table(axes.meet(axes.EVIDENCE, level(a), level(b)))

    def o_le(self, a, b):
        return axes.leq(axes.AUTHORITY, a, b)

    def o_meet(self, a, b):
        return axes.meet(axes.AUTHORITY, a, b)


def make_adapter():
    return Adapter()
