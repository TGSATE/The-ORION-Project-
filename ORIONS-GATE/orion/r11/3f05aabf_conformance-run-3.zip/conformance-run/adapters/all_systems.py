"""All three systems behind one adapter, for a single consolidated run.

  crosswalk_*  -> wn-crosswalk v0.2.0   (crosswalk_adapter.py)
  e_le/e_meet, o_* -> axis_guard v0.1.0 (axis_guard_adapter.py)
  e_ceiling    -> wn-crosswalk v0.2.0 portfolio aggregate (crosswalk_adapter.py)
  nms_*        -> nms-engine graph.py   (nms_engine_adapter.py; facet graphs unsupported)
"""
import importlib.util
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def _load(name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.make_adapter()


class AllSystems:
    def __init__(self):
        cw, ag, nm = _load("crosswalk_adapter"), _load("axis_guard_adapter"), _load("nms_engine_adapter")
        self.crosswalk_normalize, self.crosswalk_translate = cw.crosswalk_normalize, cw.crosswalk_translate
        self.e_ceiling = cw.e_ceiling   # the portfolio ceiling is Crosswalk's aggregate
        self.e_le, self.e_meet, self.o_le, self.o_meet = ag.e_le, ag.e_meet, ag.o_le, ag.o_meet
        self.nms_effective, self.nms_supports_facets = nm.nms_effective, nm.nms_supports_facets


def make_adapter():
    return AllSystems()
