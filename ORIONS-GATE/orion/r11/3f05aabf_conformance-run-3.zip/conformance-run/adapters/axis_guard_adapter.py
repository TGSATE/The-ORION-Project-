"""Conformance adapter: axis_guard v0.1.0, as found in Drive.

  axis_guard.py   sha256 3b09abac22e06b03f0409a3baa6d9638ca9b37f14f2fb39d2897b3047a6177f5
  registry.json   sha256 c47eb0f801858cccd4a4db5c899cb02d950bb28b699a0415f92ead302adb30be
                  (Drive title registry-6.json, _meta.version 0.1.0)
  own suite       12/12 pass; demo output matches REPRODUCE.md

What v0.1.0 exposes, and how each table method maps:
  FLOOR  -> floor_evidence(reg, [a, b], scale)            called directly (e_meet, o_meet)
  order  -> v0.1.0 has no order predicate. e_le / o_le are DERIVED from its FLOOR:
            a <= b  iff  FLOOR(a, b) == a. This tests the order FLOOR implies, nothing more.
  MAX    -> v0.1.0 has no MAX. e_join is deliberately absent, so the harness reports
            MAX as UNCONFIRMED rather than testing a function the code does not have.
Rung names: the tables write E4A/E4B/E4C; the registry writes E4-A/E4-B/E4-C.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src", "axis_guard")
sys.path.insert(0, SRC)
from axis_guard import Registry, floor_evidence  # noqa: E402

REG = Registry.load(os.path.join(SRC, "registry.json"))
TO_REG = {"E4A": "E4-A", "E4B": "E4-B", "E4C": "E4-C"}
FROM_REG = {v: k for k, v in TO_REG.items()}


def enc(x):
    return TO_REG.get(x, x)


def dec(x):
    return FROM_REG.get(x, x)


class Adapter:
    def e_meet(self, a, b):
        return dec(floor_evidence(REG, [enc(a), enc(b)], "evidence"))

    def e_le(self, a, b):
        return self.e_meet(a, b) == a

    def o_meet(self, a, b):
        return floor_evidence(REG, [a, b], "authority")

    def o_le(self, a, b):
        return self.o_meet(a, b) == a


def make_adapter():
    return Adapter()
