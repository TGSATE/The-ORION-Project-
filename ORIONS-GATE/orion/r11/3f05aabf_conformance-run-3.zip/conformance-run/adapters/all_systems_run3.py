"""Run 3: the current version of each system behind one adapter, one consolidated verdict.

  crosswalk_*, e_ceiling  -> wn-crosswalk v0.3.1           (crosswalk_v031_adapter.py; ruling D2)
  e_le/e_meet, o_*        -> axis_guard v0.1.0, unchanged   (axis_guard_adapter.py; D1 still open:
                                                             the v0.2.0 candidate was not found)
  nms_effective           -> nms-engine graph.py, patched   (nms_engine_patched_adapter.py; ruling D3;
                                                             facet graphs supported, none skipped)

Crosswalk v0.3.1 also implements the axis order (`axes.leq` / `axes.meet`); that is tested in its own
run (reports/run3_crosswalk_v031.json). Here the axis tables stay with axis_guard, the system that
owns the axis, so its open defect stays visible in the consolidated verdict.
"""
import importlib.util
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def _load(name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.make_adapter()


class AllSystemsRun3:
    def __init__(self):
        cw = _load("crosswalk_v031_adapter")
        ag = _load("axis_guard_adapter")
        nm = _load("nms_engine_patched_adapter")
        self.crosswalk_normalize, self.crosswalk_translate = cw.crosswalk_normalize, cw.crosswalk_translate
        self.e_ceiling = cw.e_ceiling
        self.e_le, self.e_meet, self.o_le, self.o_meet = ag.e_le, ag.e_meet, ag.o_le, ag.o_meet
        self.nms_effective, self.nms_supports_facets = nm.nms_effective, nm.nms_supports_facets


def make_adapter():
    return AllSystemsRun3()
