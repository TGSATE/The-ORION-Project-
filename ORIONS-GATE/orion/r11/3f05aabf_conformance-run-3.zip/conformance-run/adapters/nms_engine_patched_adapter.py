"""Conformance adapter: nms-engine graph.py with the lattice-parameter patch (ruling D3, 2026-10-04).

Source: src/nms_engine_patched/graph.py (digest in SOURCES.md); the patch against the Drive original
(819056d0...bc2c) is nms-engine-graph-lattice.patch.

What changed from the run-1/run-2 adapter: no level mapping, no skips. The patched ClaimGraph is built
with its DEFAULT order, the canonical faceted axis, so this run also tests that the default is right.
The only translation is spelling: the tables write E4A, the canonical axis writes E4-A.

  nms_supports_facets = True     every graph in the table is run, facets included
"""
import importlib.util
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, "..", "src", "nms_engine_patched", "graph.py")

# a private module name: the original module is also called `graph`
_spec = importlib.util.spec_from_file_location("nms_graph_patched", PATH)
graph = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(graph)

TO_NMS = {"E4A": "E4-A", "E4B": "E4-B", "E4C": "E4-C"}
FROM_NMS = {v: k for k, v in TO_NMS.items()}


class Adapter:
    nms_supports_facets = True

    def nms_effective(self, table_graph):
        nodes = {f"n{n['id']}": {"asserted": TO_NMS.get(n["asserted"], n["asserted"]),
                                 "depends_on": [f"n{d}" for d in n["deps"]]} for n in table_graph}
        g = graph.ClaimGraph(nodes)          # default order: canonical faceted
        assert g.order is graph.CANONICAL
        return {n["id"]: FROM_NMS.get(lvl, lvl)
                for n in table_graph for lvl in [g.effective(f"n{n['id']}")["level"]]}


def make_adapter():
    return Adapter()
