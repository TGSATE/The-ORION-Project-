"""Conformance adapter: wn-crosswalk v0.2.0, as found in Drive.

  wn-crosswalk-v0.2.0.zip   sha256 e0d5c4317bc1d7c391587d36870a3a9f5480cfb5485c1992cfe4fc762e7eabe6
                            (matches the registered package digest)
  core digest               1b881684...fe2a, `verify` -> RESULT: MATCH
  own suite                 81/81 pass, 0 skipped (cryptography 50.0.1 present, Ed25519 cross-check ran)

crosswalk_normalize(claim, reading) runs Crosswalk's own end-to-end per-artifact pipeline,
`adjudicate._adjudicate_one` (translate evidence -> evidence_floors; translate authority ->
authority_floors), on an artifact record built from the table claim:

  table claim field      Crosswalk artifact field
  ---------------------  ------------------------------------------------------------------
  witness none           witness = {} (no principal)
  witness self           witness.principal == owner_principal
  witness same_org       witness.principal != owner, witness.org == owner_org
  witness independent    witness.principal != owner, witness.org != owner_org
  witness_binding        witness.identity_binding
  signed                 witness.signed AND witness.signature.verified
  external_identity      witness.signature.key_fingerprint (a quotable key)
  receipt_digest         bindings.receipt_digest
  artifact_digest        bindings.artifact_digest
  simulation             substrate = "simulation" (else "physical")
  track                  track (logos / research / mythos; format v2)
  ratified               ratification = {principal, date} (else {})
  hand_extracted         extraction.extraction_status != "verified"
  performative           both stated labels = "SEALED"
  axis_kind_mismatch     authority stated on csaa.authority (kind assurance_stage)

The input reading is stated on the canonical ladders (wn.core E0-E6, wn.core.authority O0-O4),
whose labels and denotations agree, so translation passes it through unchanged. Facet readings
are stated on weaver.e4class (E4-A/B/C).

FACETS. Crosswalk v0.2.0 has no facets: E4-A, E4-B and E4-C all sit at ordinal 4. Decoding an
output ordinal 4:
  * normalize: rules only lower, so an output of 4 means a stage-4 input passed through untouched;
    the adapter reports the input facet. (An output of 4 from a non-facet input is impossible for
    a lowering rule and is returned raw as "E4", which the harness flags.)
  * translate: if the label and denotation are DIFFERENT facets, no facet is faithful, and the
    adapter returns "E4" raw. That case is where Crosswalk and the canonical axis genuinely differ
    (canonical: distinct facets meet at E3), and the harness reports each instance.

e_ceiling(readings) builds a corpus with one clean artifact per reading, runs Crosswalk's own
`adjudicate`, and reads `aggregate.evidence_ceiling`. v0.2.0 returns ONE rung (max of ordinals); an
output of E4 is reported as a facet only when exactly one distinct facet was given.

crosswalk_translate(label, denotation) calls `translate.translate` on a probe registry built with
Crosswalk's own `Registry._build`: one rung per (label, denotation) pair whose ordinal is the label
reading and whose `denotes` key is a vocabulary term at the denotation reading. That exercises the
min(label, denotation) rule itself, per axis.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src", "crosswalk"))
from wn_crosswalk import axes  # noqa: E402
from wn_crosswalk.adjudicate import _adjudicate_one, adjudicate  # noqa: E402
from wn_crosswalk.registry import Registry  # noqa: E402
from wn_crosswalk.translate import translate  # noqa: E402
sys.path.insert(0, HERE)
from crosswalk_mapping import (CLEAN, E_DENOTES, FACET_LABEL, O_DENOTES, STAGE,  # noqa: E402
                               artifact_for, split)

REG = Registry.load()


def decode_e(ordinal, facets_in):
    if ordinal != 4:
        return f"E{ordinal}"
    distinct = sorted(set(facets_in))
    return distinct[0] if len(distinct) == 1 else "E4"


def _probe_registry():
    def ladder(lid, axis, kind, rungs):
        return Registry._build({"ladder_id": lid, "axis": axis, "kind": kind, "status": "canonical",
                                "label_comparable": True, "source": "conformance probe", "rungs": rungs})
    e_rungs = [{"label": f"{l}|{d}", "ordinal": STAGE[l], "denotes": E_DENOTES[d], "pinned": True}
               for l in STAGE for d in STAGE]
    o_rungs = [{"label": f"{l}|{d}", "ordinal": int(l[1]), "denotes": O_DENOTES[d], "pinned": True}
               for l in O_DENOTES for d in O_DENOTES]
    ladders = {"probe.e": ladder("probe.e", axes.EVIDENCE, axes.CANONICAL_KIND[axes.EVIDENCE], e_rungs),
               "probe.o": ladder("probe.o", axes.AUTHORITY, axes.CANONICAL_KIND[axes.AUTHORITY], o_rungs)}
    return Registry({"registry_version": "probe"}, ladders)


PROBE = _probe_registry()


class Adapter:
    def e_ceiling(self, readings):
        arts = []
        for i, e in enumerate(readings):
            a = artifact_for(CLEAN, f"{e}/O0")
            a["artifact_id"] = f"a{i:02d}"
            arts.append(a)
        agg = adjudicate(REG, {"corpus_id": "ceiling-probe", "artifacts": arts})["aggregate"]
        facets_in = [x for x in readings if x in FACET_LABEL]
        top = agg["evidence_ceiling_ordinal"]
        if top == 4:
            distinct = sorted(set(facets_in))
            return distinct if len(distinct) == 1 else ["E4"]
        return [f"E{top}"]

    def crosswalk_normalize(self, claim, reading):
        e, _ = split(reading)
        result = _adjudicate_one(REG, artifact_for(claim, reading))
        facets_in = [e] if e in FACET_LABEL else []
        return f"{decode_e(result['evidence_ordinal'], facets_in)}/O{result['authority_ordinal']}"

    def crosswalk_translate(self, label, denotation):
        (le, lo), (de, do) = split(label), split(denotation)
        ev = translate(PROBE, axes.EVIDENCE, "probe.e", f"{le}|{de}").normalized_ordinal
        au = translate(PROBE, axes.AUTHORITY, "probe.o", f"{lo}|{do}").normalized_ordinal
        facets_in = [x for x in (le, de) if x in FACET_LABEL]
        return f"{decode_e(ev, facets_in)}/O{au}"


def make_adapter():
    return Adapter()
