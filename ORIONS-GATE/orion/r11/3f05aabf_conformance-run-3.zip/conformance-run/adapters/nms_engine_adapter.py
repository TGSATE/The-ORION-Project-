"""Conformance adapter: nms-engine graph module, as found in Drive.

  graph.py   sha256 819056d0bea91cd8be86f4609e212a1c720cd361be108aaa2cd18fb20e00bc2c  (Drive title graph.py; "The Axiom of Non-Monotonic Support, executed")

What nms-engine is: ClaimGraph(nodes).effective(cid) -> {"level", "limiters", "reason"}.
Cycles and missing dependencies return E0 (reasons EVID-CYCLE / EVID-MISSING-DEP); nothing is
raised for them. GraphError is raised only for malformed input (unknown level, empty graph), so
no refusal policy is needed or applied here: an exception would be a genuine crash, and the
harness records it as a mismatch.

Level mapping. nms-engine runs on the CSAA handoff's own ladder:
    E0 < E1 < E2 < E3self < E3 < E4 < E5 < E6      (no facets; E4 = "operational validation")
The tables use the canonical axis (E0 E1 E2 E3 E4A E4B E4C E5 E6). The adapter maps the canonical
NON-FACET levels by name (E0 E1 E2 E3 E5 E6 -> ranks 0 1 2 4 6 7), an order-preserving injection,
so min is preserved and the run tests the ALGORITHM (min, cycles, missing deps), not the meaning of
any level. Level meaning is Crosswalk's job. Facets have no image in a chain, so graphs containing
them are declared unsupported (nms_supports_facets = False) and reported as skipped.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src", "nms_engine"))
from graph import ClaimGraph  # noqa: E402

TO_NMS = {"E0": "E0", "E1": "E1", "E2": "E2", "E3": "E3", "E5": "E5", "E6": "E6"}
FROM_NMS = {v: k for k, v in TO_NMS.items()}


class Adapter:
    nms_supports_facets = False

    def nms_effective(self, graph):
        nodes = {f"n{n['id']}": {"asserted": TO_NMS[n["asserted"]],
                                 "depends_on": [f"n{d}" for d in n["deps"]]} for n in graph}
        g = ClaimGraph(nodes)
        out = {}
        for n in graph:
            level = g.effective(f"n{n['id']}")["level"]
            out[n["id"]] = FROM_NMS.get(level, f"UNMAPPABLE:{level}")
        return out


def make_adapter():
    return Adapter()
