"""(1) Classify every translate mismatch. (2) Prove each adapter is wired into the real code:
break the real code in-process (no files edited) and require the harness to see it."""
import importlib.util, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
LC = os.path.abspath(os.path.join(HERE, "..", "..", "lattice-core", "conformance"))  # lattice-core as a sibling
sys.path.insert(0, LC)
import harness
TABLES, PIN = os.path.join(LC, "out"), os.path.join(LC, "EXPECTED_SHA256SUMS")
ADP = os.path.abspath(os.path.join(HERE, "..", "adapters"))

def load(name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ADP, name + ".py"))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

# (1) every translate mismatch, classified
cw = load("crosswalk_adapter"); ad = cw.make_adapter()
causes, total = {}, 0
with open(os.path.join(TABLES, "crosswalk_translate.jsonl")) as f:
    for line in f:
        row = json.loads(line)
        got = ad.crosswalk_translate(row["label"], row["denotation"])
        if got != row["out"]:
            total += 1
            le, de = row["label"].split("/")[0], row["denotation"].split("/")[0]
            facet = {"E4A", "E4B", "E4C"}
            key = ("distinct facets: label %s, denotation %s -> expected E3, got E4" % (le, de)
                   if le in facet and de in facet and le != de and row["out"].startswith("E3/")
                   and got.startswith("E4/") and got.split("/")[1] == row["out"].split("/")[1]
                   else "OTHER: %s" % row)
            causes[key] = causes.get(key, 0) + 1
print(f"translate mismatches: {total}")
for k, v in sorted(causes.items()):
    print(f"  {v:3d}  {k}")

# (2) non-vacuity: break the real code, require MISMATCH
def expect_mismatch(label, adapter, tables):
    v, res, d = harness.run(TABLES, adapter, tables=tables, pin=PIN, limit=1)
    n = sum(r.mismatch_count for r in res)
    print(f"  {'caught' if v == 'MISMATCH' and n else 'MISSED'}  {label}: {v}, {n} mismatches")
    assert v == "MISMATCH" and n > 0, label

print("non-vacuity (real code broken in-process):")
import wn_crosswalk.rules as R, wn_crosswalk.adjudicate as A
saved = dict(R.INDEPENDENCE_FLOOR)
R.INDEPENDENCE_FLOOR[R.SAME_ORG] = 6                       # forget the same-org cap
expect_mismatch("Crosswalk: same-org witness no longer capped at E3", ad, ["crosswalk_normalize"])
R.INDEPENDENCE_FLOOR.clear(); R.INDEPENDENCE_FLOOR.update(saved)
real_auth = A.authority_floors
A.authority_floors = lambda artifact, ordinal: (ordinal, [])   # drop G-07/G-08
expect_mismatch("Crosswalk: authority firewall removed", ad, ["crosswalk_normalize"])
A.authority_floors = real_auth

ag = load("axis_guard_adapter"); import axis_guard
real_floor = axis_guard.floor_evidence
ag.floor_evidence = lambda reg, parts, scale="evidence": max(parts, key=lambda p: reg.rungs(scale).index(p))
expect_mismatch("axis_guard: FLOOR replaced by MAX", ag.make_adapter(), ["o_axis_order"])
ag.floor_evidence = real_floor

nm = load("nms_engine_adapter"); import graph
real_eff = graph.ClaimGraph.effective
graph.ClaimGraph.effective = lambda self, cid: ({"level": "E0"} if cid not in self.nodes
                                               else {"level": self.nodes[cid]["asserted"]})  # ignore deps
expect_mismatch("nms-engine: dependencies ignored", nm.make_adapter(), ["nms_effective"])
graph.ClaimGraph.effective = real_eff

# and with everything restored, the real code is back to its verdicts
v1, _, _ = harness.run(TABLES, ad, tables=["crosswalk_normalize"], pin=PIN)
v2, _, _ = harness.run(TABLES, nm.make_adapter(), tables=["nms_effective"], pin=PIN)
print(f"restored: crosswalk_normalize {v1}, nms_effective {v2}")
