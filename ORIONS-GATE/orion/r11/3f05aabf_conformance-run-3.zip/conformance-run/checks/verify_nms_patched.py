"""nms-engine graph.py, lattice-parameter patch (ruling D3): (1) conformance on every nms table node,
facet graphs included, with the exact case count; (2) the adapter is wired into the real patched code:
break it in-process and require the harness to see it; (3) the patched module against the Drive
original on every table graph without facets: identical levels, and a count of the table's nodes that
lie on a cycle but which the original did not tag EVID-CYCLE (the tagging gap; levels never differ)."""
import importlib.util
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LC = os.path.abspath(os.path.join(HERE, "..", "..", "lattice-core", "conformance"))
sys.path.insert(0, LC)
import harness  # noqa: E402

TABLES, PIN = os.path.join(LC, "out"), os.path.join(LC, "EXPECTED_SHA256SUMS")
ADP = os.path.abspath(os.path.join(HERE, "..", "adapters"))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


adapter_mod = load("nms_engine_patched_adapter", os.path.join(ADP, "nms_engine_patched_adapter.py"))
G = adapter_mod.graph  # the real patched module the adapter drives
ad = adapter_mod.make_adapter()

# (1)
verdict, results, detail = harness.run(TABLES, ad, tables=["nms_effective"], pin=PIN, limit=3)
r = results[0]
print(f"(1) nms_effective: {verdict}, {r.cases} node values in {r.rows} graphs, "
      f"{r.mismatch_count} mismatches, skipped: {r.skipped or 'nothing'}")
assert verdict == "CONFORMS" and r.cases == 55119 and not r.skipped, detail


# (2)
def expect_mismatch(label):
    v, res, _ = harness.run(TABLES, ad, tables=["nms_effective"], pin=PIN, limit=1)
    n = res[0].mismatch_count
    print(f"  {'caught' if v == 'MISMATCH' and n else 'MISSED'}  {label}: {n} mismatches")
    assert v == "MISMATCH" and n > 0, label


print("(2) non-vacuity (real patched code broken in-process):")
real_meet = G.Order.meet
real_meet_table = dict(G.CANONICAL._meet)
for (a, b), m in list(G.CANONICAL._meet.items()):   # facets meet by list position (the D2/D3 collapse)
    if a in G.CANONICAL_FACETS and b in G.CANONICAL_FACETS and a != b:
        G.CANONICAL._meet[a, b] = min(a, b)
expect_mismatch("facets meet by list position, not at E3")
G.CANONICAL._meet.clear()
G.CANONICAL._meet.update(real_meet_table)

real_effective = G.ClaimGraph.effective


def cyclic_keeps_assertion(self, cid):
    if cid in self.nodes and cid in self._cyclic:
        return {"level": self.nodes[cid]["asserted"], "limiters": [cid], "reason": "self"}
    return real_effective(self, cid)


G.ClaimGraph.effective = cyclic_keeps_assertion
expect_mismatch("a node on a cycle keeps its assertion")
G.ClaimGraph.effective = real_effective


def missing_is_top(self, cid):
    if cid not in self.nodes:
        return {"level": self.order.top, "limiters": [cid], "reason": "EVID-MISSING-DEP"}
    return real_effective(self, cid)


G.ClaimGraph.effective = missing_is_top
expect_mismatch("a missing dependency counts as E6")
G.ClaimGraph.effective = real_effective

verdict, _, detail = harness.run(TABLES, ad, tables=["nms_effective"], pin=PIN)
assert verdict == "CONFORMS", detail
print(f"  restored: {verdict}")

# (3)
orig = load("nms_graph_original", os.path.join(HERE, "..", "src", "nms_engine", "graph.py"))
graphs = nodes = missed = graphs_missed = 0
with open(os.path.join(TABLES, "nms_effective.jsonl")) as f:
    for line in f:
        row = json.loads(line)
        if row["facets"]:
            continue
        spec = {f"n{n['id']}": {"asserted": n["asserted"], "depends_on": [f"n{d}" for d in n["deps"]]}
                for n in row["graph"]}
        old, new = orig.ClaimGraph(spec), G.ClaimGraph(spec)
        graphs += 1
        here = 0
        for cid in spec:
            nodes += 1
            o, n = old.effective(cid), new.effective(cid)
            assert o["level"] == n["level"], (row["name"], cid, o, n)
            assert not (o["reason"] == "EVID-CYCLE" and n["reason"] != "EVID-CYCLE"), (row["name"], cid)
            if n["reason"] == "EVID-CYCLE" and o["reason"] != "EVID-CYCLE":
                here += 1
        missed += here
        graphs_missed += bool(here)
print(f"(3) against the original on {graphs} facet-free table graphs ({nodes} nodes): levels identical; "
      f"{missed} nodes in {graphs_missed} graphs lie on a cycle but were not tagged EVID-CYCLE by the original")
