"""Crosswalk v0.3.1 (ruling D2, with the review fixes): (1) conformance on every Crosswalk table with the exact case counts;
(2) the adapter is wired into the real code: break the real v0.3.1 code in-process (no files edited)
and require the harness to see each break, in the table it lives in; (3) restored code conforms again.
Each break STANDS IN for a defect (it is not the old code): it shows the tables exercise that behaviour.

Separate from verify_findings.py because both versions are the package `wn_crosswalk`; one process
holds one of them."""
import importlib.util
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LC = os.path.abspath(os.path.join(HERE, "..", "..", "lattice-core", "conformance"))
sys.path.insert(0, LC)
import harness  # noqa: E402

TABLES, PIN = os.path.join(LC, "out"), os.path.join(LC, "EXPECTED_SHA256SUMS")
ADP = os.path.abspath(os.path.join(HERE, "..", "adapters"))
CROSSWALK_TABLES = ["crosswalk_normalize", "crosswalk_translate", "e_axis_order", "e_axis_ceiling",
                    "o_axis_order"]
EXPECTED_CASES = {"crosswalk_normalize": 552960, "crosswalk_translate": 2025, "e_axis_order": 162,
                  "e_axis_ceiling": 511, "o_axis_order": 50}

spec = importlib.util.spec_from_file_location("crosswalk_v031_adapter",
                                              os.path.join(ADP, "crosswalk_v031_adapter.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
ad = mod.make_adapter()
import wn_crosswalk  # noqa: E402  (the v0.3.1 package the adapter loaded)
import wn_crosswalk.adjudicate as A  # noqa: E402
import wn_crosswalk.axes as X  # noqa: E402
import wn_crosswalk.rules as R  # noqa: E402
import wn_crosswalk.translate as TR  # noqa: E402
import types  # noqa: E402

print(f"system under test: wn_crosswalk {wn_crosswalk.__version__} from "
      f"{os.path.relpath(os.path.dirname(wn_crosswalk.__file__), os.path.join(HERE, '..'))}")

# (1) conformance, with the run shown to be non-trivial by its case counts
verdict, results, detail = harness.run(TABLES, ad, tables=CROSSWALK_TABLES, pin=PIN, limit=3)
for r in results:
    print(f"  {r.table:<22} cases {r.cases:>7}  mismatches {r.mismatch_count}")
assert verdict == "CONFORMS", detail
assert {r.table: r.cases for r in results} == EXPECTED_CASES
print(f"(1) {verdict} on {sum(EXPECTED_CASES.values()):,} cases")


# (2) non-vacuity
def expect_mismatch(label, tables):
    v, res, d = harness.run(TABLES, ad, tables=CROSSWALK_TABLES, pin=PIN, limit=1)
    hit = sorted(r.table for r in res if r.mismatch_count)
    where = ", ".join(f"{r.table} {r.mismatch_count}" for r in res if r.mismatch_count) or "nothing"
    ok = v == "MISMATCH" and set(tables) <= set(hit)
    print(f"  {'caught' if ok else 'MISSED'}  {label}: {where}")
    assert ok, (label, v, hit)


print("(2) non-vacuity (real v0.3.1 code broken in-process):")
real_meet, real_leq, real_ceiling = X.meet, X.leq, X.ceiling

# stands in for the D2 collapse: facets meet by list position
X.meet = lambda axis, a, b: (min(a, b, key=X.levels(axis).index)
                             if X.stage(axis, a) == X.stage(axis, b) else real_meet(axis, a, b))
expect_mismatch("facets meet by list position, not at E3", ["e_axis_order", "crosswalk_translate"])
X.meet = real_meet

# facets made comparable (a chain E4-A < E4-B < E4-C)
X.leq = lambda axis, a, b: X.levels(axis).index(a) <= X.levels(axis).index(b)
expect_mismatch("facets ordered as a chain", ["e_axis_order", "e_axis_ceiling"])
X.leq = real_leq

# the portfolio ceiling as v0.2.0 computed it: one maximum, by position
X.ceiling = lambda axis, values: [max(values, key=X.levels(axis).index)] if values else []
expect_mismatch("ceiling is a single maximum, not the maximal set", ["e_axis_ceiling"])
X.ceiling = real_ceiling

# a facet that survives the floors is rewritten as E4-A
real_floors = A.evidence_floors
A.evidence_floors = lambda artifact, value: (lambda out: ("E4-A" if out[0] in X.EVIDENCE_FACETS else out[0],
                                                          out[1]))(real_floors(artifact, value))
expect_mismatch("surviving facets collapsed to E4-A", ["crosswalk_normalize"])
A.evidence_floors = real_floors

# a label SPELLED as a facet is not recognized (translate sees no facet spellings). This stands in for
# NF-016 but is not the draft's behaviour: here those rows read E3; the draft read the definition's
# facet. The draft itself is run by checks/v030_draft_dual_probe.py (300 mismatches).
real_axes = TR.axes
TR.axes = types.SimpleNamespace(**{k: getattr(real_axes, k) for k in dir(real_axes) if not k.startswith("__")})
TR.axes.EVIDENCE_FACETS = ()
expect_mismatch("spelled facet labels not recognized", ["crosswalk_translate"])
TR.axes = real_axes

# G-08 forgets the research track (ruling A5)
real_auth = A.authority_floors
A.authority_floors = lambda artifact, ordinal: real_auth(
    dict(artifact, track="logos") if artifact.get("track") == "research" else artifact, ordinal)
expect_mismatch("G-08 ignores the research track", ["crosswalk_normalize"])
A.authority_floors = real_auth

# same-org witness no longer capped at E3 (G-02)
saved = dict(R.INDEPENDENCE_FLOOR)
R.INDEPENDENCE_FLOOR[R.SAME_ORG] = 6
expect_mismatch("same-org witness uncapped", ["crosswalk_normalize"])
R.INDEPENDENCE_FLOOR.clear()
R.INDEPENDENCE_FLOOR.update(saved)

# (3) restored
verdict, results, detail = harness.run(TABLES, ad, tables=CROSSWALK_TABLES, pin=PIN, limit=3)
assert verdict == "CONFORMS", detail
print(f"(3) restored: {verdict}")
