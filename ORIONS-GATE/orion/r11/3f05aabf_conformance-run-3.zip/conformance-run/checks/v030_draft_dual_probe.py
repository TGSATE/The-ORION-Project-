"""The real Crosswalk v0.3.0 draft under the v0.3.1 adapter's two-way translate probe.

Why: the first run-3 adapter declared a `level` on every facet probe rung, so it drove one of the two
ways a label can name a facet, and the v0.3.0 draft passed it with 0 mismatches. Its defect lived on
the other way (a label SPELLED as a facet was ignored; Crosswalk NF-016). This check points the
current adapter, which drives both ways and requires agreement, at the draft itself
(src/wn-crosswalk-v0.3.0-draft.zip, the exact bytes delivered on 2026-10-04) and records the result.
Expected: 300 translate mismatches (150 rows where the draft moved a facet sideways, 150 where it read
E3 for a facet label over an E5/E6 definition). v0.3.1 on the same probe: 0.
"""
import hashlib
import json
import os
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
LC = os.path.abspath(os.path.join(HERE, "..", "..", "lattice-core", "conformance"))
sys.path.insert(0, LC)
import harness  # noqa: E402

TABLES, PIN = os.path.join(LC, "out"), os.path.join(LC, "EXPECTED_SHA256SUMS")
DRAFT = os.path.join(HERE, "..", "src", "wn-crosswalk-v0.3.0-draft.zip")
DRAFT_SHA256 = "38197b5b1deda2b7f5166ee70a884462808e07d38e461cbb6e09e6793c3ebf2a"
REPORT = os.path.join(HERE, "..", "reports", "run3_v030_draft_translate.json")

with open(DRAFT, "rb") as f:
    assert hashlib.sha256(f.read()).hexdigest() == DRAFT_SHA256, "not the delivered v0.3.0 draft"

with tempfile.TemporaryDirectory(prefix="xwk-v030-") as tree:
    zipfile.ZipFile(DRAFT).extractall(tree)
    os.environ["CROSSWALK_SRC"], os.environ["CROSSWALK_VERSION"] = tree, "0.3.0"
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "crosswalk_v031_adapter_on_draft", os.path.join(HERE, "..", "adapters", "crosswalk_v031_adapter.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    verdict, results, detail = harness.run(TABLES, mod.make_adapter(), tables=["crosswalk_translate"],
                                           pin=PIN, limit=3)
    # classify every mismatching row by what kind of input it is
    facets, kinds = ("E4A", "E4B", "E4C"), {}
    ad = mod.make_adapter()
    for row in map(json.loads, open(os.path.join(TABLES, "crosswalk_translate.jsonl"))):
        try:
            ok = ad.crosswalk_translate(row["label"], row["denotation"]) == row["out"]
        except AssertionError:
            ok = False
        if not ok:
            le, de = row["label"][:3], row["denotation"].split("/")[0]
            kind = ("facet label over a different facet" if le in facets and de in facets and le != de
                    else "facet label over E5/E6" if le in facets and de in ("E5", "E6") else "other")
            kinds[kind] = kinds.get(kind, 0) + 1

r = results[0]
print(f"v0.3.0 draft, two-way probe: crosswalk_translate {verdict}, {r.mismatch_count} of {r.cases} mismatches: "
      + ", ".join(f"{n} {k}" for k, n in sorted(kinds.items())))
assert verdict == "MISMATCH" and r.mismatch_count == 300, (verdict, r.mismatch_count)
assert kinds == {"facet label over a different facet": 150, "facet label over E5/E6": 150}, kinds
with open(REPORT, "w") as f:
    f.write(harness.canonical({"system": "wn-crosswalk v0.3.0 draft", "sha256": DRAFT_SHA256,
                               "adapter": "crosswalk_v031_adapter.py (two-way translate probe)",
                               "verdict": verdict, "table": "crosswalk_translate", "cases": r.cases,
                               "mismatches": r.mismatch_count, "mismatches_by_input": kinds}) + "\n")
print(f"wrote {os.path.relpath(REPORT, os.path.join(HERE, '..'))}")
