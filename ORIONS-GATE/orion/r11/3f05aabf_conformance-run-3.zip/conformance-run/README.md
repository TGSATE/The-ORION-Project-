# Conformance runs 1–3

Read `REPORT.md` (run 3, after the 2026-10-04 rulings). Run 1 is `REPORT-run1.md`.

Lay this folder next to `lattice-core` (v0.3) and run from `lattice-core`:

```bash
scripts/export_conformance.sh --check        # tables regenerate byte-identical to the pin (needs Lean)
T=conformance/out P=conformance/EXPECTED_SHA256SUMS A=../conformance-run/adapters R=../conformance-run/reports
python3 conformance/harness.py $T --sut $A/all_systems_run3.py --pin $P --report $R/run3_all_systems.json
python3 conformance/harness.py $T --sut $A/crosswalk_v031_adapter.py --pin $P \
    --tables crosswalk_normalize,crosswalk_translate,e_axis_order,e_axis_ceiling,o_axis_order
python3 conformance/harness.py $T --sut $A/nms_engine_patched_adapter.py --pin $P --tables nms_effective
python3 ../conformance-run/checks/verify_v031.py          # Crosswalk v0.3.1: conforms; breaks are caught (~3 min)
python3 ../conformance-run/checks/v030_draft_dual_probe.py  # the v0.3.0 draft under the two-way probe: 300
python3 ../conformance-run/checks/verify_nms_patched.py   # nms patch: conforms; breaks caught; vs original
python3 ../conformance-run/checks/verify_findings.py      # runs 1-2: v0.2.0 / axis_guard / original nms
```

Without Lean, skip the first line: the tables are checked against the pinned digests by the harness
itself before any system is called.

| Folder | What |
| --- | --- |
| `src/crosswalk/`, `src/wn-crosswalk-v0.2.0.zip` | Crosswalk v0.2.0 as found in Drive |
| `src/crosswalk-0.3.1/`, `src/wn-crosswalk-v0.3.1.zip` | Crosswalk v0.3.1 (ruling D2 + review fixes), the release tree |
| `src/wn-crosswalk-v0.3.0-draft.zip` | the v0.3.0 draft as delivered (superseded; kept so its defect stays checkable) |
| `src/axis_guard/` | axis_guard v0.1.0 as found in Drive |
| `src/nms_engine/graph.py` | nms-engine `graph.py` as found in Drive |
| `src/nms_engine_patched/graph.py` | the same with the lattice parameter (ruling D3) |
| `adapters/` | one per system and version; every mapping choice is documented at the top |
| `checks/` | non-vacuity: break the real code in-process, require the harness to see it |
| `reports/` | canonical JSON reports per run; `run3_checks.txt` is the checks' output |

Digests and provenance: `SOURCES.md`.
