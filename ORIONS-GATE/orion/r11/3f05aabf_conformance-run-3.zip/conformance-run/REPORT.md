# Conformance run 3: after the 2026-10-04 rulings

**Date:** 2026-10-04 · **Tables:** lattice-core v0.3 (format v2), digests equal
`EXPECTED_SHA256SUMS` (`--pin`) · **Runner:** Claude, in a fresh cloud workspace (Python 3.13.16).
**Lineage:** I wrote the two patches under test and also ran the harness, so this is the author
testing their own code against the model. It is a fresh-environment replay, not an independent one.
The patches were also reviewed twice by a second Claude instance that had not written them. It read
the code against the ruling, probed it, and re-ran the suites and checks. **That review was not
independent either.** It was started by the same session for the same principal, so by the
portfolio's own standard (G-02) it is not E4-B-class evidence. It still found defects in the
Crosswalk v0.3.0 draft that this run, as first configured, had passed (below). Runs 1 and 2 tested
the systems as found in Ryan's Drive. Run 1's report is `REPORT-run1.md`.

## Verdict: 610,827 cases run, 9 mismatches, nothing unconfirmed

| Table | System | Cases | Run 2 (as found) | Run 3 |
| --- | --- | ---: | --- | --- |
| `crosswalk_normalize` | Crosswalk | 552,960 | 0 (v0.2.0) | **0** (v0.3.1) |
| `crosswalk_translate` | Crosswalk | 2,025 | 150 (D2) | **0**, through both declared and spelled facet labels |
| `e_axis_ceiling` | Crosswalk portfolio aggregate | 511 | 64 (D2) | **0** |
| `e_axis_order` | axis_guard v0.1.0 | 162 | 9 (D1) | 9 (D1, unchanged) |
| `o_axis_order` | axis_guard v0.1.0 | 50 | 0 | 0 |
| `nms_effective` | nms-engine `graph.py` | 55,119 | 0 on 25,175; **29,944 unconfirmed** (9,080 facet graphs) | **0 on all 55,119** (patched) |

Crosswalk v0.3.1 also implements the axis order (`axes.leq`, `axes.meet`). Run against the axis
tables itself, it conforms: `e_axis_order` 0 of 162, `o_axis_order` 0 of 50. So **Crosswalk v0.3.1
conforms on all 555,708 of its cases, and the patched nms-engine on all 55,119 of its cases.** The
consolidated verdict stays MISMATCH because of the 9 D1 cases alone (`reports/run3_*.json`).

Progression: run 1 had 159 mismatches and 30,025 cases unconfirmed. Run 2 (format v2) had 223
mismatches and 29,944 unconfirmed. Run 3 has 9 mismatches and none unconfirmed.

## What the review caught, and what changed because of it

The first run-3 adapter for Crosswalk v0.3.0 gave every facet label a declared `level`. With that, it
reported 0 translate mismatches. The review then found three defects in v0.3.0:
- a label **spelled** `E4-B` was ignored, and the definition's facet was taken silently: a sideways
  move with no finding;
- the schema refused the `level` field the README told authors to add;
- the collisions report still printed facets as `E4`.

A second pass found that other spellings (`E4B`, `e4-b`) still slipped through. In **v0.3.1**, a
label-comparable stage-4 rung must be spelled `E4` or `E4-A`/`E4-B`/`E4-C`, or declare its level.
Anything else is refused when the registry loads (Crosswalk NF-016).

The adapter now drives translation both ways on every row: through declared levels, and through one
ladder per definition whose rungs are spelled `E4-A`, `E4-B` and so on. The two readings must agree.
Pointed at the real v0.3.0 draft (`checks/v030_draft_dual_probe.py`, the exact delivered bytes), this
adapter reports **300** translate mismatches (`reports/run3_v030_draft_translate.json`):
- 150 facet labels over a different facet, where the draft moved sideways;
- 150 facet labels over E5/E6, where the draft read E3 instead of the facet.

Pointed at v0.3.1, it reports 0.

The lesson for reading any zero in this report: **a conformance zero covers the paths the adapter
drives.**

## The zeros are not vacuous

For each system, I broke the real code in-process (no files edited) and required the harness to see
the break in the table where it lives (`checks/`, output in `reports/run3_checks.txt`). Each break
**stands in** for a defect; it is not the old code:

| Break, in the real code | Mismatches |
| --- | --- |
| Crosswalk v0.3.1: facets meet by list position | translate 150, e-axis 6 |
| Crosswalk v0.3.1: facets ordered as a chain E4-A < E4-B < E4-C | translate 150, e-axis 9, ceiling 64 |
| Crosswalk v0.3.1: ceiling as one maximum | ceiling 64 |
| Crosswalk v0.3.1: surviving facets rewritten as E4-A | normalize 80, ceiling 96 |
| Crosswalk v0.3.1: spelled facet labels not recognized (read E3; the real draft is run separately, 300) | translate 225 |
| Crosswalk v0.3.1: G-08 ignores the research track (A5) | normalize 18,432 |
| Crosswalk v0.3.1: same-org witness uncapped (G-02) | normalize 800 |
| nms patched: facets meet by list position | 112 |
| nms patched: a node on a cycle keeps its assertion | 40,650 |
| nms patched: a missing dependency counts as E6 | 5,069 |

Each facet break fails the rows sensitive to what it breaks:
- a wrong facet meet fails the 150 translate rows where label and definition are distinct facets,
  plus 6 meet rows;
- a single-maximum ceiling fails the 64 ceiling sets with two or more incomparable maxima;
- facets ordered as a chain fail both, plus axis_guard's 9 (D1).

Those match the numbers the old defects produced, and they show that the tables exercise facet
behaviour in translation, meet and ceiling. They do **not** by themselves show that the fixes
changed nothing else. The evidence for that is separate: the unchanged corpus readings, and
0 mismatches on the 552,960 normalize cases for both Crosswalk versions. After every break, the
restored code conforms again. The harness's own self-test still passes 11 of 11.

## Rulings: status

**D2: closed** by Crosswalk v0.3.1 (`wn-crosswalk-v0.3.1.zip`, with patches from v0.2.0 and from
the v0.3.0 draft). Readings are levels on the faceted order. Translation and G-06 use the lattice
meet. The portfolio ceiling is the set of maximal readings. A facet is named by declaration or by
spelling, and any other spelling of a stage-4 label is refused. 107 tests pass, `verify` gives
RESULT: MATCH, and corpus readings are unchanged. Four
behaviour changes, each stricter than before:
- independent reproduction now means E4-A or above;
- a composite of an E4-A part and an E4-B part reads E3;
- a label naming one facet with a definition naming another reads E3 with `FACET_CONFLICT`;
- a bare `E4` whose definition names no facet reads E3 (Crosswalk NF-013). That affects one
  registered rung, `handoff.2026-08-03:E4`, which no corpus artifact uses.

**A5: closed in the model** (lattice-core v0.3, research track). `crosswalk_normalize` has 0
mismatches against both Crosswalk versions. Breaking G-08 for the research track gives 18,432
mismatches, so those cases are actually exercised.

**D3: closed** by the `graph.py` patch (`nms-engine-graph-lattice.zip`). The order is now a
parameter, and the canonical faceted axis is the default. While making the change I found and fixed
a second defect, **cycle tagging**. The original search marked only the nodes on its current path,
so a node that closes a cycle through an already-finished node got reason `propagated` instead of
`EVID-CYCLE`. Across the 8,308 facet-free table graphs, the original mis-tagged 64 nodes. Their
levels were right in every case (E0, through the cycle), which is why runs 1 and 2 could not see it:
the table records levels only. After review, the patch also refuses instead of looping when a graph
is changed in place after construction.

**A1: half ruled.** The ceiling is an aggregation, never a join, and that is now in the model (the
ceiling table), in Crosswalk (`evidence_ceiling_levels`) and in nms-engine (`ceilings()`). **Still
open:** whether E5 and E6 sit above each facet. That decides FLOOR(E4-x, E5) and whether an E5
artifact counts as an independent reproduction. The model, Crosswalk v0.3.1 and the nms patch all
assume the stage order (yes). If you rule otherwise, the change lands in one definition in each
(`leq` in the Lean model, `axes.leq` in Crosswalk, `CANONICAL` in graph.py), and the tables are
regenerated and re-pinned in the same commit.

**D1: open.** axis_guard v0.1.0 still takes FLOOR of facets by list position. The v0.2.0 candidate
that fixes it is not in Drive. If you send it, the axis tables run in seconds.

## What this run does not show

- **Independence.** The patches, adapters, run and review share one principal. The review was by a
  second instance, which re-ran the checks, but it was not independent. The next real step up is
  someone outside the lineage running `checks/` on their own machine.
- **That the axis is right.** Conformance is agreement with the model on a finite input space. The
  open half of A1 is a decision about the model, and conformance cannot make it.
- **G-06 composition.** No table covers it, because no adapter passes components (manifest assumption
  A4). The G-06 part of "D2 closed" rests on Crosswalk's unit tests, including an exhaustive check
  that composition equals the meet of the value and its parts over all 729 level triples.
- **Reasons and limiters.** The nms table checks levels only. The patch's reasons and limiters are
  covered by its own suite. On chains they match the original algorithm field for field (given the
  true cycle set), across 3,000 random CSAA graphs. On facets, the new limiter definition is covered
  only by hand-written cases. It is the union of the smallest blocking sets, which can list
  alternatives, and the patch README says exactly what it does and does not single out.
- **A bare `E4`.** Every table label names a facet. Crosswalk's handling of an unnamed facet (take
  the definition's facet, else read E3) is covered by its unit tests only.
- **The rest of nms-engine.** Only `graph.py` was available. The default order changed, so every
  caller that builds a graph from CSAA-labelled data must now pass `order=CSAA_HANDOFF`.
  - Data with a CSAA-only level (`E3self`, `E4`) is refused loudly.
  - Data that only uses names the two ladders share (E0–E3, E5, E6) is **not detected**. It builds
    under the canonical order and is read with canonical meanings: CSAA's E3 is independent
    reproduction, while canonical E3 is same-organization replay.

  Whether `canon.py`, `report.py`, `gate.py`, `envelope.py` and `__main__.py` already pass the order
  is unverified.

## Adapter choices (each is a place this run could be wrong)

- **Crosswalk v0.3.1** (`adapters/crosswalk_v031_adapter.py`): nothing is decoded. Levels come
  straight from `evidence_level`, `normalized_level` and `evidence_ceiling_levels`, and the only
  change is spelling (E4-A becomes E4A). The artifact mapping is imported unchanged from the v0.2.0
  adapter, so the runs differ only in the system. Translation is driven through declared levels and
  through spelled labels, and the two must agree.
- **nms patched** (`adapters/nms_engine_patched_adapter.py`): graphs are built with the default
  order, which the adapter asserts is canonical, and there are no skips.
- **axis_guard** (`adapters/axis_guard_adapter.py`): unchanged from run 1; `le` is derived from
  FLOOR.
