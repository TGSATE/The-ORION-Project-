# Sources, as tested

## As found in Ryan's Google Drive (runs 1–3)

| System | Drive title | Drive file id | sha256 |
| --- | --- | --- | --- |
| wn-crosswalk v0.2.0 | wn-crosswalk-v0.2.0.zip | 1UfkpAJoHd5MTusIcOVO0lpOiwbAM64Mr | e0d5c4317bc1d7c391587d36870a3a9f5480cfb5485c1992cfe4fc762e7eabe6 |
| axis_guard v0.1.0 | axis_guard.py | 1inSZpkpovE7EAr4ve96yYUDiHNhdHX9d | 3b09abac22e06b03f0409a3baa6d9638ca9b37f14f2fb39d2897b3047a6177f5 |
| axis_guard tests | test_axis_guard.py | 1sUxaN1wUlDv1C_EIKPgl9kMDwk1jgY4H | 6bc7c8f32e07908924c155ba4c612a160f675a2a1eb067fea3f2772f663afdc1 |
| axis_guard registry v0.1.0 | registry-6.json (used as registry.json) | 1_MM8Uopld2ObACdSrzFH1nf1GPyFuknc | c47eb0f801858cccd4a4db5c899cb02d950bb28b699a0415f92ead302adb30be |
| nms-engine graph module | graph.py | 1AkKGLzJfIksNDNw1yM8YisiLR4iuypes | 819056d0bea91cd8be86f4609e212a1c720cd361be108aaa2cd18fb20e00bc2c |

Not found in Drive: axis_guard v0.2.0 candidate (20 tests, facet meet); the rest of the nms-engine
package (only graph.py is needed for effective levels).

## Produced in this session under the 2026-10-04 rulings (run 3)

Not from Drive: written by Claude, so the runner and the author are the same here.

| System | File | sha256 |
| --- | --- | --- |
| wn-crosswalk v0.3.1 (ruling D2 + review fixes) | wn-crosswalk-v0.3.1.zip (`git archive` of the release commit) | 4ca5902a1e6cf7c61a764edcaafa0133b0400a549b2b5462622d8dfab5063911 |
| wn-crosswalk v0.3.0 draft (superseded) | wn-crosswalk-v0.3.0-draft.zip (the bytes delivered earlier on 2026-10-04) | 38197b5b1deda2b7f5166ee70a884462808e07d38e461cbb6e09e6793c3ebf2a |
| nms-engine graph.py, lattice parameter (ruling D3) | nms_engine_patched/graph.py | 0163947e5f366b424420e7fa9adcfb5a3f3befe6ebe66323c22d4806c266b2c7 |

Crosswalk v0.3.1's receipt digest is `core_sha256 7132fe83de623f982b62bb7f77a7f5ea72eb0d56c3096b9357b36e1c848bb218`.
It supersedes the v0.3.0 draft's `69d94c63…e88f` (Crosswalk NF-016), which superseded v0.2.0's
`1b881684…fe2a`.
