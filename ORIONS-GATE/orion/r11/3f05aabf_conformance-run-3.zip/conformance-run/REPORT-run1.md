# Conformance run 1: LatticeCore models vs the shipped systems

**Date:** 2026-10-04 · **Tables:** lattice-core v0.2, digests equal `EXPECTED_SHA256SUMS` (`--pin`)
· **Runner:** Claude, in a fresh cloud workspace, on the source files in Ryan's Google Drive
(`SOURCES.md`). Same author lineage as the systems: this is a fresh-environment replay, not an
independent one.

## Verdict: MISMATCH — 396,052 cases run, 159 mismatches, 30,025 unconfirmed

| Table | System | Cases run | Mismatches | Result |
| --- | --- | --- | --- | --- |
| `crosswalk_normalize` | wn-crosswalk v0.2.0 | 368,640 | **0** | conforms (every claim × every reading) |
| `crosswalk_translate` | wn-crosswalk v0.2.0 | 2,025 | **150** | MISMATCH: one cause (D2) |
| `e_axis_order` (le, FLOOR) | axis_guard v0.1.0 | 162 | **9** | MISMATCH: one cause (D1) |
| `e_axis_order` (MAX) | axis_guard v0.1.0 | — | — | UNCONFIRMED: v0.1.0 has no MAX |
| `o_axis_order` | axis_guard v0.1.0 | 50 | **0** | conforms |
| `nms_effective` | nms-engine `graph.py` | 25,175 | **0** | conforms where expressible; 9,080 facet graphs UNCONFIRMED (D3) |

The zeros are real: breaking each system's code in-process (no files edited) makes the harness
report 400, 55,296, 40 and 23,165 mismatches respectively (`checks/verify_findings.py`).

## Divergences, triaged

**D1: axis_guard v0.1.0 takes FLOOR of facets by list position.** 9 cases: FLOOR(E4-A, E4-B) = E4-A
(expected E3) for every ordered facet pair, and the implied order puts E4-A ≤ E4-B ≤ E4-C.
`floor_evidence` is `min(parts, key=registry list index)`.
*Class: code bug, already known.* It is the defect the axis_guard v0.2.0 candidate fixed (facet
partial order, meet). The v0.2.0 files are not in Drive. **Action:** locate them, rerun; expect 0,
and a MAX to test (which is where A1 gets settled).

**D2: Crosswalk v0.2.0 collapses the facets into one E4.** 150 cases: wherever the label and the
denotation are different facets, Crosswalk reads E4; the canonical axis reads E3. All three facet
denotations (`reproduced_independent`, `independent_review`, `adversarial_assessment`) sit at ordinal 4.
The same collapse reaches **G-06 composition**: a composite resting on an E4-A component and an
E4-B component reads **E4** in Crosswalk (run directly, `checks/`), although neither part has both.
*Class: code gap against adopted doctrine* (July 2026: E4-A/B/C, "none implies the others").
Crosswalk predates axis_guard's facet meet. **Decision for Ryan:** give Crosswalk facet-aware
ordinals (code change; recommended), or rule that facets collapse at joins (model change, which
gives up "none implies the others" at composition).

**D3: nms-engine runs on the CSAA handoff's own ladder** (`E0 E1 E2 E3self E3 E4 E5 E6`; no facets;
its E4 = operational validation = canonical E5). Its algorithm matches the model on every graph it
can express, including all 8,192 facet-free three-node dependency shapes (self-loops, missing
dependencies, every cycle structure up to three nodes). Graphs containing facets cannot be stated.
*Class: representation gap, not a bug.* **Decision for Ryan:** keep nms-engine handoff-local, or run
it on the canonical faceted axis via Crosswalk translation.

## Modeling assumptions, now checked against code

| # | Status | Evidence |
| --- | --- | --- |
| A1 E5/E6 above all facets | **open** | needs a MAX; v0.1.0 has none; registry v0.1.0 still glosses E6 "production authorized" |
| A2 unverified independent witness caps E3 | **confirmed** | `INDEPENDENCE_FLOOR[claimed_independent_unverified] = 3` |
| A3 mythos reads E0/O0 | **confirmed** | G-05 sets evidence 0; G-08 sets authority O0 for mythos |
| A4 G-04/G-06 are aggregation rules | **confirmed** | `counts_toward_ceiling`, `composition_floor`; code also excludes mythos from the ceiling |
| A5 G-08 not modeled | **model gap, real** | G-08 also lowers **research**-track authority to O0; the model has no research track. Fix: add it to the Lean model, regenerate, re-pin in one commit |
| A6 one O0–O4 authority axis | **confirmed for v0.2.0** | AM-001's S/O/A split is registered but explicitly not applied |
| A7 nms fail-closed semantics | **confirmed** | cycles and missing deps return E0 (`EVID-CYCLE`, `EVID-MISSING-DEP`); nothing is raised, so no refusal policy is needed |

## Adapter choices (each is a place this run could be wrong)

- Crosswalk: `signed` = declared and verified; `external_identity` = a quotable key fingerprint;
  `performative` puts a performative token on both axes; non-mythos claims use the default `logos`
  track. Facet identity: an output of 4 from a facet input is reported as that facet (rules only
  lower); distinct facets in translation are reported raw as `E4`.
- axis_guard: `le` derived from FLOOR (a ≤ b iff FLOOR(a,b) = a); MAX omitted, not invented.
- nms-engine: canonical non-facet levels mapped by name into its ladder (order-preserving), so the
  run tests the algorithm, not level meaning.

## Also observed

- Crosswalk v0.2.0 own suite: 81/81 with **0 skipped** here (`cryptography` 50.0.1 present, so the
  Ed25519 cross-check ran); `verify` → RESULT: MATCH on core digest `1b881684…fe2a`.
- axis_guard v0.1.0 own suite 12/12; demo output matches its REPRODUCE.md.
