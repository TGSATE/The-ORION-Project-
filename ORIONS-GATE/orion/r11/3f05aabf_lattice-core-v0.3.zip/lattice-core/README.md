# LatticeCore v0.3: the deflationary lattice core

One theorem, proved once, applied to five of Ryan's systems: **a rule that can only lower a reading,
composed with others like it, can never raise a reading.** Crosswalk's "no rule can raise a reading",
nms-engine's Axiom of Non-Monotonic Support, axis_guard's facet meet, the Anchored RSI epistemic
diode and the Sovereign Compute Stack's checkpoint rule are all instances of it.

**Toolchain:** `leanprover/lean4:v4.22.0` · **Dependencies:** none (Lean core only, no Mathlib)
· **Build:** 0 errors, 0 warnings, 0 `sorry` in the library · MIT · Copyright Ryan Scott 2026

## Claim, at the strength of its evidence

> The theorems hold for the **Lean models** of each system, as modeled from the system notes,
> with the assumptions listed below. v0.2 added the bridge to the code: the models' complete
> input→output tables, exported as canonical JSON Lines, and a stdlib Python harness that diffs any
> implementation against them. **The harness has now been run against the real code** (runs 1–3,
> below). Where an implementation conforms, it computes the model's function on the tested inputs.
> For the Crosswalk and axis tables those inputs are the model's whole input space. For nms-engine
> they are a generated corpus of graphs, not all graphs. The transfer holds only to the extent that
> each adapter maps faithfully, and every adapter documents its mapping. Kernel replay and the
> conformance results are author-reported until CI runs them on your side. The patches under test in
> run 3 were written by the same author who ran it.

## Run it

```bash
lake build                                                 # library + hostile suite + axiom audit
LEAN4CHECKER=/path/to/lean4checker scripts/check_kernel_replay.sh          # ~10 s
FRESH=1 LEAN4CHECKER=... scripts/check_kernel_replay.sh                    # + Init, ~3 min
```

## Conformance tables (format v2): from the models to the code

```bash
scripts/export_conformance.sh --check                 # tables + SHA256SUMS; must match the pinned oracle
python3 conformance/harness.py conformance/out --sut path/to/adapter.py --pin conformance/EXPECTED_SHA256SUMS
python3 conformance/test_harness.py conformance/out   # proves the harness can fail
```

**Format: canonical JSON Lines + `manifest.json` + `SHA256SUMS`.** One JSON object per line, keys
sorted, no whitespace, ASCII only, integers only, `\n`-terminated. Readings are strings
(`"E4A/O2"`), never stage numbers. Deterministic: two runs are byte-identical, so the digests are
receipts. `conformance/EXPECTED_SHA256SUMS` is the **pinned oracle**: it changes only when a model
changes on purpose, in the same commit.

| Table | Rows | Cases | Inputs |
| --- | --- | --- | --- |
| `crosswalk_normalize.jsonl` | 12,288 | 552,960 | every claim (incl. `track` logos/research/mythos) × every reading (**exhaustive**) |
| `crosswalk_translate.jsonl` | 2,025 | 2,025 | every label × denotation (**exhaustive**) |
| `e_axis_order.jsonl` | 81 | 162 | every pair: `le`, `meet` (FLOOR) (**exhaustive**). No join (see below) |
| `e_axis_ceiling.jsonl` | 511 | 511 | every non-empty set of readings → its ceiling (**exhaustive**) |
| `o_axis_order.jsonl` | 25 | 50 | every pair: `le`, `meet` (**exhaustive**) |
| `nms_effective.jsonl` | 17,388 | 55,119 | all 4,096 three-node dependency shapes × 4 assertion patterns, 1,000 seeded random graphs, 4 fixtures |

**Format v2 (2026-10-04)**, after conformance run 1: claims carry `track` instead of a `mythos`
flag (G-08 track separation is modeled); the evidence axis is evaluated as a **meet-semilattice**,
so the join column is gone; portfolio ceilings are an **aggregation** with their own table.

**The ceiling is not a join.** Joining E4-A and E4-B would synthesize E5, a reading no artifact
earned. The ceiling is the set of maximal readings: `ceiling_sub` (every element is a reading
someone holds), `ceiling_antichain`, `ceiling_covers` (every reading sits under one), and
`ceiling_facets_no_promotion` (ceiling [E4-A, E4-B] = [E4-A, E4-B], E5 ∉ it).

Proved in `Encode.lean`: every code is injective (all 45 reading codes distinct) and every
enumeration is complete (`allClaims_complete`: the Crosswalk table covers the whole claim space).

**Harness order of checks.** Integrity (files vs `SHA256SUMS`, and vs the pin), canonical form,
known values only, completeness (no duplicates, whole input space, case counts equal the manifest);
only then is the system under test called. Verdicts: `CONFORMS` (0), `MISMATCH` (1, includes the
system raising), `INTEGRITY` (2), `UNCONFIRMED` (3, something skipped; NF-009).

**The harness is shown to fail** (`test_harness.py`, 11 tests): the reference conforms on all
**610,827** cases; 11 injected bugs are each caught in exactly the table they live in (same-org
uncapped, receipt rule with OR, authority inferred from evidence, crash on performative tokens,
translation ignoring the denotation, FLOOR of facets by list position, ceiling by join, ceiling by
list position, research track ignored, nms skipping missing dependencies, nms ignoring self-loops);
tampering is refused; a re-signed table with one wrong value is caught only by `--pin`.

**Conformance run 1 (2026-10-04)**, against the shipped systems from Drive (`conformance-run-1`):
Crosswalk v0.2.0 conforms on its whole guard-rail pipeline (now 552,960 cases incl. research track);
the divergences are all one structural fact, facets: axis_guard v0.1.0 FLOOR by list position (9),
Crosswalk v0.2.0 collapsing facets in translation (150) and in the portfolio ceiling (64).

**Conformance run 3 (2026-10-04)**, after the rulings (`conformance-run-3`). **610,827 cases run,
9 mismatches, nothing unconfirmed.** Crosswalk v0.3.1 (facet-aware, ruling D2) conforms on all
555,708 of its cases across five tables. The first adapter drove only one of the two ways a label
can name a facet. A second review found a defect on the other way, in the v0.3.0 draft. That review
was by another Claude instance with the same principal, so it was not independent. The defect is
fixed in v0.3.1, and the adapter now drives both ways, which catches the draft with 300 mismatches. nms-engine `graph.py` with the lattice parameter (ruling
D3, canonical order by default) conforms on all 55,119 node values, **facet graphs included**; run 2
could only confirm 25,175 of them. The 9 are axis_guard v0.1.0's FLOOR by list position (D1),
unchanged, because its v0.2.0 candidate was not available. The zeros are shown not to be vacuous.
Breaking the real code in-process reproduces the old failures exactly: facets meeting by list
position gives Crosswalk's 150 translate cases, a single-maximum ceiling gives its 64, and facets
ordered as a chain gives the 150, the 64 and axis_guard's 9.

## The core (Layer 1, `Order.lean`, `Deflation.lean`)

| Theorem | Says |
| --- | --- |
| `Deflationary.comp` | Two lowering rules compose to a lowering rule |
| `Deflationary.comp_monotone` | With a monotone outer rule: `g (f x) ≤ g x ≤ x` |
| `meet_deflation`, `cap_deflationary`, `capIf_deflationary` | Meets and (conditional) caps lower |
| `run_deflationary` | Any pipeline of lowering rules lowers (= `foldl`, `run_eq_foldl`) |
| `run_le_of_mem` | A cap anywhere in the pipeline bounds the output, whatever follows it |
| `run_no_raise` | **Safety inversion:** any level the output reaches, the input already had. Uses no axioms. |
| `runS_along`, `runS_prefix_le` | The same along an authority measure on any state space, for every prefix |

## Instances (Layer 2)

| System rule (from the notes) | Lean | Key theorems |
| --- | --- | --- |
| axis_guard: E4-A/B/C incomparable, `FLOOR(E4-A,E4-B) = E3` by meet | `Instances/AxisGuard.lean` | `facets_incomparable`, `facet_meet_eq_e3`, `e3_greatest_below_facets`, **`not_distributive`** |
| Crosswalk: `normalized = min(label, denotation)`, refusals, G-01…G-10, FLOOR, ceiling | `Instances/Crosswalk.lean` | `normalize_le` (no rule can raise, for **every** claim and reading), `reading_le`, `e3_requires`, `e4_requires`, `authority_requires`, `track_separation`, `clean_claim_unchanged`, `ceiling_sub`, `ceiling_antichain`, `ceiling_covers`, `ceiling_facets_no_promotion`, `ceiling_dominated_by_raw`, `ceiling_filter_dominated` |
| nms-engine: `effective(n) = min(asserted(n), min over deps)`, cycles/missing fail closed | `Instances/NMS.lean` | `effective_le_asserted`, `effective_edge`, `effective_path`, `effective_cycle`, `effective_missing_dep`, `effective_pos_inversion`, `effective_le_fixpoint` |
| RSI diode: "subtract authority but never create it"; SCS: `Authority(resume(cp)) ≤ Authority_current`; RSI fast path: "Δa ≤ 0, no netting" | `Instances/Diode.lean` | `diode_chain`, `trace_prefixes`, `resume_le_current`, `resume_le_checkpoint`, `resume_resume`, `checkpoint_le_start`, `fastPath_trans`, `fastPath_refuses_rise` |

Crosswalk's inversions say exactly what a high reading requires:
- **E3 or above** ⇒ receipt digest ∧ witness identity binding ∧ witness same-org or independent ∧
  artifact digest ∧ not simulation ∧ not mythos ∧ not hand-extracted ∧ not performative.
- **Any E4 facet** ⇒ additionally an independent witness, signed, with an external identity.
- **Authority above O0** ⇒ ratification record ∧ matching axis kind ∧ not performative ∧ track `logos`
  (research and mythos carry no runtime authority, `track_separation`).

## What formalizing found

1. **The blueprint's refutation test is too weak on a partial order.** "∃ x, r(x) > x" misses a
   rule that swaps E4-A and E4-B: it never produces anything strictly greater, yet it isn't
   deflationary (`facetSwap_never_strictly_raises`, `facetSwap_refused`). The library uses
   `∃ x, ¬ r(x) ≤ x`.
2. **The evidence axis is not distributive** (under the stage-order assumption below):
   `E4-A ⊓ (E4-B ⊔ E4-C) = E4-A` but `(E4-A ⊓ E4-B) ⊔ (E4-A ⊓ E4-C) = E3`. The order in which FLOOR
   and MAX are applied is part of a result's meaning; regrouping them changes portfolio readings.
3. **The library is constructive.** Of 178 theorem constants, 125 use no axioms, the rest only
   `propext`/`Quot.sound`; none use `Classical.choice`. The audit now enforces this.
4. **My own fuel claim was wrong, and the suite caught it.** I wrote that one unit less fuel would
   lower a 10-node chain; `decide` showed fuel equal to the node count still suffices. `effective`
   has exactly one unit of margin, now pinned by a test.
5. **What the tables cannot see.** `nms_effective` records levels, not reasons or limiters. The
   original nms-engine failed to tag some nodes that lie on a cycle as `EVID-CYCLE` (64 of the
   table's facet-free nodes). It still gave them the right level, E0, through the cycle. So it
   conformed, and the bug was found by reading the code, then measured. A level-only oracle
   certifies levels.

## Modeling assumptions, checked against the shipped code (conformance runs 1–3)

| # | Assumption | Status |
| --- | --- | --- |
| A1 | Order: E5 and E6 sit above all three E4 facets (stage order) | **half ruled** (2026-10-04): the ceiling is an aggregation, never a join (modeled; implemented in Crosswalk v0.3.1 and the nms patch). **Still open:** whether E5/E6 sit above each facet, which decides FLOOR(E4-x, E5). The model, Crosswalk v0.3.1 and the nms patch all assume the stage order |
| A2 | G-02: independent witness without signature and external identity caps at E3 | **confirmed** (`claimed_independent_unverified` → 3) |
| A3 | G-05 mythos reads E0 evidence; G-08 gives mythos O0 authority | **confirmed** |
| A4 | G-04 / G-06 are aggregation rules | **confirmed** |
| A5 | G-08 track separation | **modeled** in v0.3 (research and mythos → O0); 0 mismatches vs Crosswalk v0.2.0 and v0.3.1 |
| A6 | Authority is the O0–O4 chain | **confirmed** for Crosswalk v0.2.0 and v0.3.1 (AM-001 registered, not applied) |
| A7 | nms evaluation by path with fuel `|g| + 1`; failure modes read ⊥ | **confirmed** (cycles and missing deps read E0; the patched module agrees on every table graph) |

## Hostile suite (Layer 3, all enforced by `lake build`)

- Inflation (`bump`) and facet swap refused; a corner-case raiser appended to the Crosswalk kernel
  breaks deflation on one claim and one reading.
- Crosswalk regressions: LABEL_INFLATION and DENOTATION_INFLATION both read E2; performative → E0/O0;
  self-witnessed E4 → E2; same-org → E3; unratified → O0; no artifact digest → E1.
- nms-engine: a 3-cycle asserted at E6 reads E0, as does a node depending on it, while an
  independent node keeps E6; a missing dependency reads E0; **a claim resting on E4-A and E4-B
  reads E3** through the DAG; a diamond takes the min over all paths; the fuel margin is pinned.
- No netting: a change whose rank sum is unchanged but one component rises is refused.
- The checks can fail: a false `decide` claim is refused, with the message pinned.
- **Axiom audit** walks every `LatticeCore` theorem and fails the build on `sorry`, a foreign
  axiom, or `Classical.choice`; `Test/AuditCanFail.lean` plants a `sorry`'d theorem and requires
  the audit to name it.

## Verified (author-reported until your CI runs)

| Check | Result |
| --- | --- |
| `lake build` from zero | 0 errors, 0 warnings |
| Library | 129 hand-written theorems (207 theorem constants), no `sorry`, no foreign axioms, no choice |
| Hostile suite | 6 theorems + 21 `decide`-checked examples + audit + its non-vacuity test |
| Kernel replay (lean4checker v4.22.0) | 10 / 10 modules, discovered from the tree |
| Fresh replay (all imports + Init) | 2 leaf modules covering every library module (import closure checked), 181 s |
| Conformance export | deterministic: two runs byte-identical; digests equal the pin |
| Harness self-test | 11 / 11; reference conforms on 610,827 cases; 11 / 11 injected bugs caught |

## Open items

1. **Remaining conformance.** Done (runs 1–3): Crosswalk v0.2.0 and v0.3.1, axis_guard v0.1.0,
   nms-engine `graph.py` original and patched. Not done: axis_guard v0.2.0 (not found), the rest of
   nms-engine (only `graph.py` was available), and **any run by someone other than the author**.
2. **nms fuel adequacy.** Prove that on an acyclic, complete graph fuel never runs out, which gives
   the other half of the fixpoint equation. A liveness gap, not a safety gap: exhaustion fails closed.
3. **Caps commute.** Every Crosswalk rule is a meet with a constant, so rule order shouldn't matter;
   easy to prove, not yet proved.
4. **Next instances**, from the same sweep: SCS Gate 0.3 and I6 with the eight negative controls
   (`decide`); ANGELA non-self-ratification as a frame condition; Buildability's K gate over all
   weightings. RSI gates 9–11 can't be formalized until they're written down.
5. **Independent review.** Models, theorems and tests share one author. The kernel checks the
   proofs, not that the models match the systems; open item 1 is how to check the second.

## Files

| Path | What |
| --- | --- |
| `LatticeCore/Order.lean` | Meet-semilattice classes, product `Pair`, basic lemmas |
| `LatticeCore/Deflation.lean` | Deflationary algebra, pipelines, inversion, deflation along a measure |
| `LatticeCore/Instances/*.lean` | AxisGuard, Crosswalk, NMS, Diode |
| `Test/Hostile.lean` | Hostile suite and axiom audit |
| `Test/AuditCanFail.lean` | Proves the audit can fail |
| `scripts/check_kernel_replay.sh` | lean4checker replay, modules discovered from the tree |
| `LatticeCore/Encode.lean` | Codes (proved injective) and enumerations (proved complete) |
| `Export/Main.lean` | `lake exe export_tables`: canonical JSONL tables + manifest |
| `scripts/export_conformance.sh` | Export + `SHA256SUMS`; `--check` compares with the pin |
| `conformance/EXPECTED_SHA256SUMS` | The pinned oracle digests |
| `conformance/harness.py` | Stdlib harness: integrity, form, completeness, diff, verdicts |
| `conformance/reference_models.py` | Spec-derived reference adapter (proves the harness works; not your systems) |
| `conformance/adapter_template.py` | What to fill in for a new system (real adapters: `conformance-run-3/adapters/`) |
| `conformance/test_harness.py` | Proves the harness can fail |
| `.github/workflows/ci.yml` | Build + suite + replay per push, fresh replay nightly, record artifact |
