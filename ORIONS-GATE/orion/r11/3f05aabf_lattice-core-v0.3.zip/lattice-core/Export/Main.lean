import LatticeCore

/-!
# Conformance table exporter

`lake exe export_tables [DIR]` (default `conformance/out`) writes the models' input→output tables
as canonical JSON Lines plus `manifest.json`:

| file | rows | cases | inputs |
| --- | --- | --- | --- |
| `crosswalk_normalize.jsonl` | 8192 | 368640 | every claim × every reading (exhaustive) |
| `crosswalk_translate.jsonl` | 2025 | 2025 | every label × denotation reading (exhaustive) |
| `e_axis_order.jsonl` | 81 | 243 | every pair: `le`, `meet`, `join` (exhaustive) |
| `o_axis_order.jsonl` | 25 | 50 | every pair: `le`, `meet` (exhaustive) |
| `nms_effective.jsonl` | 17388 | per node | all 4096 three-node dependency shapes × 4 assertion patterns, 1000 seeded random graphs (4–8 nodes), 4 named fixtures |

Canonical form, checked line by line by the Python harness: keys sorted (by construction, see
`obj`), no whitespace, ASCII only, integers only, every line ends with `\n`. Output is
deterministic (fixed enumeration order, fixed seed, no timestamps), so the files' SHA-256 digests
are reproducible receipts. The manifest describes content, not provenance: it carries no commit
or date, so it hashes the same on every machine.
-/

open LatticeCore LatticeCore.EAxis LatticeCore.OAxis

/-! ## Canonical JSON, by construction -/

/-- Strings are emitted only if they need no escaping: printable ASCII without `"` or `\`. -/
def safe (s : String) : Bool :=
  s.all fun c => c.toNat ≥ 0x20 && c.toNat ≤ 0x7E && c != '"' && c != '\\'

def q (s : String) : String :=
  if safe s then "\"" ++ s ++ "\"" else panic! s!"unsafe string in export: {s}"

def jb (b : Bool) : String := if b then "true" else "false"

/-- Objects sort their keys, so emission order cannot break canonical form. -/
def obj (kvs : List (String × String)) : String :=
  let sorted := (kvs.toArray.qsort (fun a b => a.1 < b.1)).toList
  "{" ++ ",".intercalate (sorted.map fun (k, v) => q k ++ ":" ++ v) ++ "}"

def arr (xs : List String) : String := "[" ++ ",".intercalate xs ++ "]"

/-! ## Crosswalk -/

def claimJson (c : Claim) : String := obj [
  ("receipt_digest", jb c.receiptDigest), ("witness_binding", jb c.witnessBinding),
  ("witness", q c.witness.code), ("signed", jb c.signed),
  ("external_identity", jb c.externalIdentity), ("simulation", jb c.simulation),
  ("track", q c.track.code), ("ratified", jb c.ratified),
  ("artifact_digest", jb c.artifactDigest), ("hand_extracted", jb c.handExtracted),
  ("performative", jb c.performative), ("axis_kind_mismatch", jb c.axisKindMismatch)]

def crosswalkRow (c : Claim) : String :=
  obj [("claim", claimJson c),
       ("out", obj (allReadings.map fun r => (r.code, q (Crosswalk.normalize c r).code)))]

def translateRows : List String :=
  allReadings.flatMap fun l => allReadings.map fun d =>
    obj [("label", q l.code), ("denotation", q d.code), ("out", q (Crosswalk.translate l d).code)]

/-! ## Axes -/

/-- Order and FLOOR only. No join: per the 2026-10-04 ruling the evidence axis is evaluated as a
meet-semilattice, and portfolio ceilings are an aggregation (`e_axis_ceiling.jsonl`). -/
def eAxisRows : List String :=
  allE.flatMap fun a => allE.map fun b =>
    obj [("a", q a.code), ("b", q b.code), ("le", jb (decide (a ≤ b))), ("meet", q (a ⊓ b).code)]

/-- Every non-empty set of readings and its ceiling (the maximal readings), in axis order. -/
def ceilingRows : List String :=
  allReadingSets.map fun xs =>
    let c := Crosswalk.ceiling xs
    obj [("readings", arr (xs.map (q ·.code))),
         ("ceiling", arr ((allE.filter (· ∈ c)).map (q ·.code)))]

def oAxisRows : List String :=
  allO.flatMap fun a => allO.map fun b =>
    obj [("a", q a.code), ("b", q b.code), ("le", jb (decide (a ≤ b))), ("meet", q (a ⊓ b).code)]

/-! ## nms-engine corpus -/

abbrev G := NMS.Graph EAxis

def nodeJson (n : NMS.Node EAxis) : String :=
  obj [("id", toString n.id), ("asserted", q n.asserted.code), ("deps", arr (n.deps.map toString))]

def nmsRow (name : String) (g : G) : String :=
  obj [("name", q name),
       ("facets", jb (g.any fun n => EAxis.stage n.asserted == 4)),
       ("graph", arr (g.map nodeJson)),
       ("effective", arr (g.map fun n => arr [toString n.id, q (NMS.effective g n.id).code]))]

def depsOfMask (m : Nat) : List Nat := (List.range 4).filter fun j => (m >>> j) % 2 == 1

def patterns : List (List EAxis) := [[e6, e6, e6], [e4A, e4B, e6], [e6, e2, e5], [e3, e6, e4C]]

/-- All 4096 dependency shapes on three nodes (deps ⊆ {0,1,2,3}; 3 is a missing node, a node in its
own deps is a self-loop), each under four assertion patterns. -/
def shapeGraphs : List (String × G) :=
  (List.range 16).flatMap fun m0 => (List.range 16).flatMap fun m1 => (List.range 16).flatMap fun m2 =>
    (List.range patterns.length).filterMap fun k =>
      match patterns[k]? with
      | some [a0, a1, a2] =>
        some (s!"shape3-{m0}-{m1}-{m2}-p{k}",
              [⟨0, a0, depsOfMask m0⟩, ⟨1, a1, depsOfMask m1⟩, ⟨2, a2, depsOfMask m2⟩])
      | _ => none

/-- xorshift64, fixed seed. -/
def xs (s : UInt64) : UInt64 :=
  let s := s ^^^ (s <<< 13); let s := s ^^^ (s >>> 7); s ^^^ (s <<< 17)

def randomGraph (seed : UInt64) : G × UInt64 := Id.run do
  let mut s := xs seed
  let n := 4 + (s % 5).toNat
  let mut g : G := []
  for i in List.range n do
    s := xs s
    let a := allE[(s % 9).toNat]!
    s := xs s
    let deg := (s % 3).toNat
    let mut deps : List Nat := []
    for _ in List.range deg do
      s := xs s
      let missing := s % 10 == 0
      s := xs s
      let d := if missing then n else (s % n.toUInt64).toNat
      unless deps.contains d do deps := deps ++ [d]
    g := g ++ [⟨i, a, deps.mergeSort⟩]
  return (g, s)

def randomGraphs : List (String × G) := Id.run do
  let mut s : UInt64 := 0x5EED5EED5EED5EED
  let mut out : List (String × G) := []
  for k in List.range 1000 do
    let (g, s') := randomGraph s
    s := s'
    out := out ++ [(s!"rand-{k}", g)]
  return out

def fixtureGraphs : List (String × G) := [
  ("fixture-cycle", [⟨1, e6, [2]⟩, ⟨2, e6, [3]⟩, ⟨3, e6, [1]⟩, ⟨4, e6, [1]⟩, ⟨5, e6, []⟩]),
  ("fixture-facets", [⟨1, e6, [2, 3]⟩, ⟨2, e4A, []⟩, ⟨3, e4B, []⟩]),
  ("fixture-diamond", [⟨1, e6, [2, 3]⟩, ⟨2, e5, [4]⟩, ⟨3, e6, [4]⟩, ⟨4, e2, []⟩]),
  ("fixture-chain10", (List.range 10).map fun i => ⟨i, e6, if i + 1 < 10 then [i + 1] else []⟩)]

/-- One list feeds both the rows and the case count, so they cannot disagree. -/
def nmsGraphs : List (String × G) := shapeGraphs ++ randomGraphs ++ fixtureGraphs

/-! ## Manifest and main -/

def assumptions : List String := [
  "A1 order: E5 and E6 sit above all three E4 facets (stage order) - OPEN; join is not used: ceilings are maximal antichains",
  "A2 G-02 independent witness without signature and external identity caps at E3 - confirmed against wn-crosswalk v0.2.0",
  "A3 G-05 mythos reads E0 evidence; G-08 gives mythos O0 authority - confirmed",
  "A4 G-04 supersession and G-06 composition floor are aggregation rules - confirmed",
  "A5 G-08 track separation: research and mythos read O0 authority - modeled 2026-10-04",
  "A6 authority is the O0-O4 chain; AM-001 S/O/A split registered but not applied in v0.2.0 - confirmed",
  "A7 nms evaluation by path with fuel |g|+1; cycle, missing node and fuel exhaustion read E0"]

def tableEntry (file model inputs : String) (rows cases : Nat) : String :=
  obj [("file", q file), ("model", q model), ("inputs", q inputs),
       ("rows", toString rows), ("cases", toString cases)]

def writeTable (dir name : String) (rows : List String) : IO Unit :=
  IO.FS.writeFile (dir ++ "/" ++ name) (String.join (rows.map (· ++ "\n")))

def main (args : List String) : IO UInt32 := do
  let dir := args.headD "conformance/out"
  IO.FS.createDirAll dir
  let toolchain ← (do pure (← IO.FS.readFile "lean-toolchain").trim) <|> pure "unknown"
  let cw := allClaims.map crosswalkRow
  let tr := translateRows
  let ea := eAxisRows
  let ce := ceilingRows
  let oa := oAxisRows
  let nms := nmsGraphs.map fun (name, g) => nmsRow name g
  let nmsNodes := (nmsGraphs.map fun (_, g) => g.length).foldl (· + ·) 0
  writeTable dir "crosswalk_normalize.jsonl" cw
  writeTable dir "crosswalk_translate.jsonl" tr
  writeTable dir "e_axis_order.jsonl" ea
  writeTable dir "e_axis_ceiling.jsonl" ce
  writeTable dir "o_axis_order.jsonl" oa
  writeTable dir "nms_effective.jsonl" nms
  let manifest := obj [
    ("format", q "lattice-core-conformance/2"),
    ("generator", q "lake exe export_tables"),
    ("lean_toolchain", q toolchain),
    ("assumptions", arr (assumptions.map q)),
    ("enums", obj [("e_axis", arr (allE.map (q ·.code))), ("o_axis", arr (allO.map (q ·.code))),
                   ("witness", arr (allWitness.map (q ·.code))),
                   ("track", arr (allTrack.map (q ·.code)))]),
    ("tables", arr [
      tableEntry "crosswalk_normalize.jsonl" "LatticeCore.Crosswalk.normalize"
        "every claim x every reading (exhaustive)" cw.length (cw.length * allReadings.length),
      tableEntry "crosswalk_translate.jsonl" "LatticeCore.Crosswalk.translate"
        "every label x denotation reading (exhaustive)" tr.length tr.length,
      tableEntry "e_axis_order.jsonl" "LatticeCore.EAxis le/meet"
        "every pair (exhaustive); 2 checks per row" ea.length (ea.length * 2),
      tableEntry "e_axis_ceiling.jsonl" "LatticeCore.Crosswalk.ceiling"
        "every non-empty set of readings (exhaustive)" ce.length ce.length,
      tableEntry "o_axis_order.jsonl" "LatticeCore.OAxis le/meet"
        "every pair (exhaustive); 2 checks per row" oa.length (oa.length * 2),
      tableEntry "nms_effective.jsonl" "LatticeCore.NMS.effective"
        "4096 three-node shapes x 4 patterns, 1000 seeded random graphs, 4 fixtures"
        nms.length nmsNodes])]
  IO.FS.writeFile (dir ++ "/manifest.json") (manifest ++ "\n")
  IO.println s!"wrote {dir}: crosswalk {cw.length} rows / {cw.length * allReadings.length} cases, translate {tr.length}, e-axis {ea.length}, ceiling {ce.length}, o-axis {oa.length}, nms {nms.length} graphs / {nmsNodes} nodes"
  return 0
