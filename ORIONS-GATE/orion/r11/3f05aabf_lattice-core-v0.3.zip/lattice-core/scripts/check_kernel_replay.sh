#!/usr/bin/env bash
# Independent kernel replay: lean4checker re-checks every compiled module in a fresh kernel,
# outside the process that built it. Modules are discovered from the tree, so a new file cannot
# escape the check by being left off a list.
#
#   git clone https://github.com/leanprover/lean4checker && cd lean4checker
#   git checkout v4.22.0 && lake build lean4checker
#   export LEAN4CHECKER=$PWD/.lake/build/bin/lean4checker
#
# Usage: scripts/check_kernel_replay.sh        (FRESH=1 also replays Init and all dependencies)
set -u
cd "$(dirname "$0")/.."
LC="${LEAN4CHECKER:-lean4checker}"
command -v "$LC" >/dev/null 2>&1 || [ -x "$LC" ] || { echo "lean4checker not found (set LEAN4CHECKER)"; exit 1; }
lake build >/dev/null || { echo "FAIL: lake build"; exit 1; }

fail=0; n=0
mods=$( (find LatticeCore Test -name '*.lean' | sed 's/\.lean$//; s#/#.#g'; echo LatticeCore) | sort -u)
for m in $mods; do
  if out=$(lake env "$LC" "$m" 2>&1); then echo "  replay ok   $m"
  else echo "  FAIL        $m"; echo "$out" | tail -3; fail=1; fi
  n=$((n+1))
done
[ "$n" -ge 9 ] || { echo "  FAIL        only $n modules discovered; expected at least 9"; fail=1; }

# --fresh takes one module. Leaves = library modules nothing else in the library imports; together
# they import every module. Encode pulls in Crosswalk, AxisGuard, NMS, Deflation and Order.
if [ "${FRESH:-0}" = "1" ]; then
  for leaf in LatticeCore.Encode LatticeCore.Instances.Diode; do
    if lake env "$LC" --fresh "$leaf" >/dev/null 2>&1; then echo "  fresh ok    $leaf (+ all imports, + Init)"
    else echo "  FAIL        fresh replay of $leaf"; fail=1; fi
  done
fi
[ $fail -eq 0 ] && echo "KERNEL REPLAY: PASS ($n modules)" || echo "KERNEL REPLAY: FAIL"
exit $fail
