#!/usr/bin/env bash
# Regenerate the conformance tables and their digests.
#   scripts/export_conformance.sh [DIR]          tables + SHA256SUMS (default conformance/out)
#   scripts/export_conformance.sh --check [DIR]  also require SHA256SUMS == conformance/EXPECTED_SHA256SUMS
#
# EXPECTED_SHA256SUMS is the pinned oracle. It changes only when a model changes on purpose, in the
# same commit, so every change to what "conformant" means shows up as a reviewable diff.
set -euo pipefail
export LC_ALL=C
cd "$(dirname "$0")/.."
check=0
if [ "${1:-}" = "--check" ]; then check=1; shift; fi
dir="${1:-conformance/out}"
lake exe export_tables "$dir"
( cd "$dir" && sha256sum *.jsonl manifest.json > SHA256SUMS )
if [ $check -eq 1 ]; then
  if diff -u conformance/EXPECTED_SHA256SUMS "$dir/SHA256SUMS"; then
    echo "DETERMINISTIC: regenerated digests match conformance/EXPECTED_SHA256SUMS"
  else
    echo "FAIL: regenerated tables differ from the pinned digests"; exit 1
  fi
fi
