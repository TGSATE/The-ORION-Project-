import LatticeCore.Instances.Crosswalk
import LatticeCore.Instances.NMS

/-!
# Encodings and enumerations for the conformance tables

The exporter (`Export/Main.lean`) writes the models' complete input→output tables as canonical
JSON Lines. Two things here make those tables trustworthy as an oracle:

* **Encodings are injective** (proved): no two axis values, witness kinds or readings share a
  code, so a table can never conflate E4-A with E4-B.
* **Enumerations are complete** (proved): every value of every input type appears, so the
  Crosswalk table covers the whole claim × reading space, not a sample.
-/

namespace LatticeCore

open EAxis OAxis

/-! ## Codes -/

def EAxis.code : EAxis → String
  | e0 => "E0" | e1 => "E1" | e2 => "E2" | e3 => "E3" | e4A => "E4A" | e4B => "E4B"
  | e4C => "E4C" | e5 => "E5" | e6 => "E6"

def OAxis.code : OAxis → String
  | o0 => "O0" | o1 => "O1" | o2 => "O2" | o3 => "O3" | o4 => "O4"

def WitnessKind.code : WitnessKind → String
  | .none => "none" | .self => "self" | .sameOrg => "same_org" | .independent => "independent"

def Track.code : Track → String
  | .logos => "logos" | .research => "research" | .mythos => "mythos"

def Reading.code (r : Reading) : String := r.fst.code ++ "/" ++ r.snd.code

theorem EAxis.code_injective : ∀ a b : EAxis, a.code = b.code → a = b := by
  intro a b; cases a <;> cases b <;> decide

theorem OAxis.code_injective : ∀ a b : OAxis, a.code = b.code → a = b := by
  intro a b; cases a <;> cases b <;> decide

theorem WitnessKind.code_injective : ∀ a b : WitnessKind, a.code = b.code → a = b := by
  intro a b; cases a <;> cases b <;> decide

theorem Track.code_injective : ∀ a b : Track, a.code = b.code → a = b := by
  intro a b; cases a <;> cases b <;> decide

/-- Reading codes are the table keys: all 45 are distinct (checked over all 2,025 pairs). -/
theorem Reading.code_injective : ∀ a b : Reading, a.code = b.code → a = b := by
  intro a b
  cases a with | mk e o => cases b with | mk e' o' =>
  cases e <;> cases o <;> cases e' <;> cases o' <;> decide

/-! ## Enumerations -/

def allE : List EAxis := [e0, e1, e2, e3, e4A, e4B, e4C, e5, e6]
def allO : List OAxis := [o0, o1, o2, o3, o4]
def allWitness : List WitnessKind := [.none, .self, .sameOrg, .independent]
def allTrack : List Track := [.logos, .research, .mythos]
def bools : List Bool := [false, true]

theorem allE_complete (a : EAxis) : a ∈ allE := by cases a <;> decide
theorem allO_complete (a : OAxis) : a ∈ allO := by cases a <;> decide
theorem allWitness_complete (w : WitnessKind) : w ∈ allWitness := by cases w <;> decide
theorem allTrack_complete (t : Track) : t ∈ allTrack := by cases t <;> decide
theorem bools_complete (b : Bool) : b ∈ bools := by cases b <;> decide

def allReadings : List Reading := allE.flatMap fun e => allO.map fun o => ⟨e, o⟩

theorem allReadings_complete (r : Reading) : r ∈ allReadings := by
  cases r with
  | mk e o =>
    simp only [allReadings, List.mem_flatMap, List.mem_map]
    exact ⟨e, allE_complete e, o, allO_complete o, rfl⟩

/-- Every claim, fields in declaration order, `false` before `true`. -/
def allClaims : List Claim :=
  bools.flatMap fun rd => bools.flatMap fun wb => allWitness.flatMap fun w =>
  bools.flatMap fun sg => bools.flatMap fun ei => bools.flatMap fun sim =>
  allTrack.flatMap fun tr => bools.flatMap fun rt => bools.flatMap fun ad =>
  bools.flatMap fun he => bools.flatMap fun pf => bools.flatMap fun ak =>
  [{ receiptDigest := rd, witnessBinding := wb, witness := w, signed := sg,
     externalIdentity := ei, simulation := sim, track := tr, ratified := rt,
     artifactDigest := ad, handExtracted := he, performative := pf, axisKindMismatch := ak }]

/-- The Crosswalk table is exhaustive: every claim is enumerated. -/
theorem allClaims_complete (c : Claim) : c ∈ allClaims := by
  cases c with
  | mk rd wb w sg ei sim tr rt ad he pf ak =>
    simp only [allClaims, List.mem_flatMap, List.mem_singleton]
    exact ⟨rd, bools_complete _, wb, bools_complete _, w, allWitness_complete _,
      sg, bools_complete _, ei, bools_complete _, sim, bools_complete _, tr, allTrack_complete _,
      rt, bools_complete _, ad, bools_complete _, he, bools_complete _, pf, bools_complete _,
      ak, bools_complete _, rfl⟩

/-- Every non-empty set of evidence readings (as a list in axis order), for the ceiling table. -/
def allReadingSets : List (List EAxis) :=
  (List.range (2 ^ allE.length)).filterMap fun mask =>
    let xs := (List.range allE.length).filterMap fun i =>
      if (mask >>> i) % 2 == 1 then allE[i]? else none
    if xs.isEmpty then none else some xs

end LatticeCore
