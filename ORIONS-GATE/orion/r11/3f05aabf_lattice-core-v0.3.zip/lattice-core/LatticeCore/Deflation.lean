import LatticeCore.Order

/-!
# Deflationary algebra

`Deflationary f` means `f x ≤ x` for every `x`: a rule that can lower a reading or leave it, never
raise it. Everything in this library is a corollary of the few lemmas here.

**On refutation.** On a *partial* order, "never raises" is not "never produces something
strictly greater". A rule mapping `E4-A` to `E4-B` produces nothing greater (the facets are
incomparable) yet is not deflationary. So the refutation condition is `∃ x, ¬ f x ≤ x`, and
`Test/Hostile.lean` proves the facet swap is caught by it and missed by the `>` version.
-/

namespace LatticeCore

universe u v w

open MeetSemilattice

section
variable {α : Type u} [MeetSemilattice α]

def Deflationary (f : α → α) : Prop := ∀ x, f x ≤ x

def Monotone (f : α → α) : Prop := ∀ x y, x ≤ y → f x ≤ f y

theorem Deflationary.id : Deflationary (fun x : α => x) := fun x => le_refl x

/-- Composition closed. -/
theorem Deflationary.comp {f g : α → α} (hf : Deflationary f) (hg : Deflationary g) :
    Deflationary (g ∘ f) := fun x => le_trans' (hg (f x)) (hf x)

/-- With a monotone outer rule: `g (f x) ≤ g x ≤ x`. -/
theorem Deflationary.comp_monotone {f g : α → α} (hf : Deflationary f) (hg : Deflationary g)
    (hgm : Monotone g) (x : α) : g (f x) ≤ g x ∧ g x ≤ x :=
  ⟨hgm _ _ (hf x), hg x⟩

/-- Meet deflation: `x ⊓ y` is below both. -/
theorem meet_deflation (x y : α) : x ⊓ y ≤ x ∧ x ⊓ y ≤ y :=
  ⟨meet_le_left x y, meet_le_right x y⟩

/-- Capping at `c` is deflationary and monotone. -/
theorem cap_deflationary (c : α) : Deflationary (fun x => x ⊓ c) := fun x => meet_le_left x c
theorem cap_monotone (c : α) : Monotone (fun x : α => x ⊓ c) :=
  fun _ _ h => meet_mono h (le_refl c)

/-- A conditional cap: if `p` holds, the reading is capped at `c`. -/
def capIf (p : Prop) [Decidable p] (c : α) (x : α) : α := if p then x ⊓ c else x

theorem capIf_deflationary (p : Prop) [Decidable p] (c : α) : Deflationary (capIf p c) := by
  intro x; unfold capIf; split
  · exact meet_le_left x c
  · exact le_refl x

theorem capIf_le {p : Prop} [Decidable p] (hp : p) (c x : α) : capIf p c x ≤ c := by
  unfold capIf; rw [if_pos hp]; exact meet_le_right x c

/-- A refutation: one input that is not lowered or kept is enough. -/
theorem not_deflationary_of {f : α → α} (x : α) (h : ¬ f x ≤ x) : ¬ Deflationary f :=
  fun hf => h (hf x)

/-! ## Pipelines -/

/-- Apply rules left to right. -/
def run : List (α → α) → α → α
  | [], x => x
  | f :: fs, x => run fs (f x)

omit [MeetSemilattice α] in
theorem run_eq_foldl (fs : List (α → α)) (x : α) : run fs x = fs.foldl (fun y f => f y) x := by
  induction fs generalizing x with
  | nil => rfl
  | cons f fs ih => exact ih (f x)

omit [MeetSemilattice α] in
theorem run_append (fs gs : List (α → α)) (x : α) : run (fs ++ gs) x = run gs (run fs x) := by
  induction fs generalizing x with
  | nil => rfl
  | cons f fs ih => exact ih (f x)

/-- Iterated lowering: a pipeline of deflationary rules is deflationary. -/
theorem run_deflationary {fs : List (α → α)} (h : ∀ f ∈ fs, Deflationary f) :
    Deflationary (run fs) := by
  induction fs with
  | nil => exact Deflationary.id
  | cons f fs ih =>
    intro x
    exact le_trans' (ih (fun g hg => h g (List.mem_cons_of_mem f hg)) (f x))
      (h f List.mem_cons_self x)

/-- Extending a pipeline never raises its output. -/
theorem run_le_prefix {fs gs : List (α → α)} (h : ∀ g ∈ gs, Deflationary g) (x : α) :
    run (fs ++ gs) x ≤ run fs x := by
  rw [run_append]; exact run_deflationary h _

/-- A cap anywhere in a deflationary pipeline bounds its output, whatever comes after it. -/
theorem run_le_of_mem {fs : List (α → α)} (h : ∀ g ∈ fs, Deflationary g) {f : α → α}
    (hf : f ∈ fs) {c : α} (hc : ∀ x, f x ≤ c) (x : α) : run fs x ≤ c := by
  induction fs generalizing x with
  | nil => cases hf
  | cons g gs ih =>
    have hgs : ∀ g' ∈ gs, Deflationary g' := fun g' hg' => h g' (List.mem_cons_of_mem g hg')
    rcases List.mem_cons.mp hf with rfl | hmem
    · exact le_trans' (run_deflationary hgs (f x)) (hc x)
    · exact ih hgs hmem (g x)

/-- **Safety inversion.** Any level the output reaches, the input had already reached:
no pipeline of deflationary rules can lift a reading to a level it was not already at. -/
theorem run_no_raise {fs : List (α → α)} (h : ∀ f ∈ fs, Deflationary f) {x y : α}
    (hy : y ≤ run fs x) : y ≤ x :=
  le_trans' hy (run_deflationary h x)
end

/-! ## Deflation along a metric

For state machines: a transition `τ` never increases the authority `μ` of a state. With
`S = α` and `μ = id` this is `Deflationary`. -/

section
variable {S : Type v} {α : Type u} [MeetSemilattice α]

def DeflationaryAlong (μ : S → α) (τ : S → S) : Prop := ∀ s, μ (τ s) ≤ μ s

/-- Generic pipeline over any carrier. -/
def runS : List (S → S) → S → S
  | [], s => s
  | τ :: τs, s => runS τs (τ s)

theorem runS_append (τs σs : List (S → S)) (s : S) : runS (τs ++ σs) s = runS σs (runS τs s) := by
  induction τs generalizing s with
  | nil => rfl
  | cons τ τs ih => exact ih (τ s)

theorem runS_along {μ : S → α} {τs : List (S → S)} (h : ∀ τ ∈ τs, DeflationaryAlong μ τ) :
    ∀ s, μ (runS τs s) ≤ μ s := by
  induction τs with
  | nil => exact fun s => le_refl _
  | cons τ τs ih =>
    intro s
    exact le_trans' (ih (fun σ hσ => h σ (List.mem_cons_of_mem τ hσ)) (τ s))
      (h τ List.mem_cons_self s)

/-- Every prefix of a trace has authority at most the start; every extension at most the prefix. -/
theorem runS_prefix_le {μ : S → α} {τs σs : List (S → S)} (h : ∀ σ ∈ σs, DeflationaryAlong μ σ)
    (s : S) : μ (runS (τs ++ σs) s) ≤ μ (runS τs s) := by
  rw [runS_append]; exact runS_along h _
end

end LatticeCore
