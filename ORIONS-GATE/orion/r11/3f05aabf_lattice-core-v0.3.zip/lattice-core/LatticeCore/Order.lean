/-!
# Order core

Bounded meet-semilattices in plain Lean 4 core (no Mathlib), so the library stays small enough
to review line by line. Notation `⊓` / `⊔` is local to this library.
-/

namespace LatticeCore

universe u v

class MeetSemilattice (α : Type u) extends LE α where
  meet : α → α → α
  le_refl : ∀ a : α, a ≤ a
  le_trans : ∀ a b c : α, a ≤ b → b ≤ c → a ≤ c
  le_antisymm : ∀ a b : α, a ≤ b → b ≤ a → a = b
  meet_le_left : ∀ a b : α, meet a b ≤ a
  meet_le_right : ∀ a b : α, meet a b ≤ b
  le_meet : ∀ a b c : α, a ≤ b → a ≤ c → a ≤ meet b c

infixl:69 " ⊓ " => MeetSemilattice.meet

class BoundedMeetSemilattice (α : Type u) extends MeetSemilattice α where
  bot : α
  top : α
  bot_le : ∀ a : α, bot ≤ a
  le_top : ∀ a : α, a ≤ top

/-- Joins, needed only where the portfolio aggregates with MAX. -/
class JoinLattice (α : Type u) extends MeetSemilattice α where
  join : α → α → α
  le_join_left : ∀ a b : α, a ≤ join a b
  le_join_right : ∀ a b : α, b ≤ join a b
  join_le : ∀ a b c : α, a ≤ c → b ≤ c → join a b ≤ c

infixl:68 " ⊔ " => JoinLattice.join

section
variable {α : Type u} [MeetSemilattice α]
open MeetSemilattice

theorem le_rfl' {a : α} : a ≤ a := le_refl a
theorem le_trans' {a b c : α} (h₁ : a ≤ b) (h₂ : b ≤ c) : a ≤ c := le_trans a b c h₁ h₂

theorem le_meet_iff {a b c : α} : a ≤ b ⊓ c ↔ a ≤ b ∧ a ≤ c :=
  ⟨fun h => ⟨le_trans' h (meet_le_left b c), le_trans' h (meet_le_right b c)⟩,
   fun ⟨h₁, h₂⟩ => le_meet a b c h₁ h₂⟩

theorem meet_mono {a a' b b' : α} (ha : a ≤ a') (hb : b ≤ b') : a ⊓ b ≤ a' ⊓ b' :=
  le_meet _ _ _ (le_trans' (meet_le_left a b) ha) (le_trans' (meet_le_right a b) hb)

theorem meet_comm (a b : α) : a ⊓ b = b ⊓ a :=
  le_antisymm _ _ (le_meet _ _ _ (meet_le_right a b) (meet_le_left a b))
    (le_meet _ _ _ (meet_le_right b a) (meet_le_left b a))

theorem meet_eq_left {a b : α} (h : a ≤ b) : a ⊓ b = a :=
  le_antisymm _ _ (meet_le_left a b) (le_meet _ _ _ (le_refl a) h)

theorem meet_idem (a : α) : a ⊓ a = a := meet_eq_left (le_refl a)
end

/-! ## Product of two semilattices (componentwise)

Used for a reading on two independent axes (evidence × authority). A structure rather than
`Prod`, so no order instance from elsewhere can collide with it. -/

structure Pair (α : Type u) (β : Type v) where
  fst : α
  snd : β
deriving DecidableEq, Repr

instance {α : Type u} {β : Type v} [MeetSemilattice α] [MeetSemilattice β] :
    MeetSemilattice (Pair α β) where
  le x y := x.fst ≤ y.fst ∧ x.snd ≤ y.snd
  meet x y := ⟨x.fst ⊓ y.fst, x.snd ⊓ y.snd⟩
  le_refl x := ⟨MeetSemilattice.le_refl _, MeetSemilattice.le_refl _⟩
  le_trans _ _ _ h₁ h₂ := ⟨le_trans' h₁.1 h₂.1, le_trans' h₁.2 h₂.2⟩
  le_antisymm x y h₁ h₂ := by
    cases x; cases y
    simp only at h₁ h₂
    rw [MeetSemilattice.le_antisymm _ _ h₁.1 h₂.1, MeetSemilattice.le_antisymm _ _ h₁.2 h₂.2]
  meet_le_left _ _ := ⟨MeetSemilattice.meet_le_left _ _, MeetSemilattice.meet_le_left _ _⟩
  meet_le_right _ _ := ⟨MeetSemilattice.meet_le_right _ _, MeetSemilattice.meet_le_right _ _⟩
  le_meet _ _ _ h₁ h₂ := ⟨MeetSemilattice.le_meet _ _ _ h₁.1 h₂.1, MeetSemilattice.le_meet _ _ _ h₁.2 h₂.2⟩

instance {α : Type u} {β : Type v} [BoundedMeetSemilattice α] [BoundedMeetSemilattice β] :
    BoundedMeetSemilattice (Pair α β) where
  bot := ⟨BoundedMeetSemilattice.bot, BoundedMeetSemilattice.bot⟩
  top := ⟨BoundedMeetSemilattice.top, BoundedMeetSemilattice.top⟩
  bot_le _ := ⟨BoundedMeetSemilattice.bot_le _, BoundedMeetSemilattice.bot_le _⟩
  le_top _ := ⟨BoundedMeetSemilattice.le_top _, BoundedMeetSemilattice.le_top _⟩

instance {α : Type u} {β : Type v} [MeetSemilattice α] [MeetSemilattice β]
    [DecidableRel (α := α) (· ≤ ·)] [DecidableRel (α := β) (· ≤ ·)] :
    DecidableRel (α := Pair α β) (· ≤ ·) :=
  fun x y => inferInstanceAs (Decidable (x.fst ≤ y.fst ∧ x.snd ≤ y.snd))

end LatticeCore
