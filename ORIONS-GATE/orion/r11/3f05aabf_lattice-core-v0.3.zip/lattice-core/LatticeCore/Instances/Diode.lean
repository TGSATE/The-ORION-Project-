import LatticeCore.Deflation

/-!
# Epistemic diode, checkpoint resumption, and the no-netting fast path

* Anchored RSI's epistemic diode: "I may subtract authority but never create it" — a
  deflationary operation on authority.
* Transitions with an authority measure `μ`: if every transition is deflationary along `μ`,
  authority never increases over any trace, and every extension of a trace has at most the
  authority of its prefix.
* Sovereign Compute Stack: `Authority(resume(checkpoint)) ≤ Authority_current`. Resumption
  takes the meet of the recorded and the current authority, so a stale checkpoint cannot
  restore authority that has since been withdrawn, and cannot exceed what it recorded.
* Anchored RSI fast path: "∀λ, Δa_q(λ) ≤ 0, no netting". Each component must not rise; a rise in
  one component cannot be paid for by a fall in another. `Test/Hostile.lean` exhibits a change
  that nets to zero yet is refused.
-/

namespace LatticeCore
namespace Diode

universe u v w
variable {L : Type u} [MeetSemilattice L]
open MeetSemilattice

/-- An epistemic diode: an operation on authority that can only subtract. -/
abbrev IsDiode (op : L → L) : Prop := Deflationary op

theorem diode_comp {op₁ op₂ : L → L} (h₁ : IsDiode op₁) (h₂ : IsDiode op₂) :
    IsDiode (op₂ ∘ op₁) := Deflationary.comp h₁ h₂

theorem diode_chain {ops : List (L → L)} (h : ∀ op ∈ ops, IsDiode op) : IsDiode (run ops) :=
  run_deflationary h

/-! ## Traces -/

section traces
variable {S : Type v}

/-- Authority never increases over a trace of authority-deflationary transitions. -/
theorem trace_authority_le {μ : S → L} {τs : List (S → S)} (h : ∀ τ ∈ τs, DeflationaryAlong μ τ)
    (s : S) : μ (runS τs s) ≤ μ s := runS_along h s

/-- Along any trace, each extension has at most the authority of its prefix, and every prefix at
most the start: authority change is ≤ 0 across all prefixes. -/
theorem trace_prefixes {μ : S → L} {pre post : List (S → S)}
    (hpre : ∀ τ ∈ pre, DeflationaryAlong μ τ) (hpost : ∀ τ ∈ post, DeflationaryAlong μ τ)
    (s : S) : μ (runS (pre ++ post) s) ≤ μ (runS pre s) ∧ μ (runS pre s) ≤ μ s :=
  ⟨runS_prefix_le hpost s, runS_along hpre s⟩
end traces

/-! ## Checkpoints -/

section checkpoints
variable {S : Type v}

structure Checkpoint (S : Type v) (L : Type u) where
  state     : S
  authority : L

/-- Resume: the recorded authority, capped by the authority in force now. -/
def resume (cp : Checkpoint S L) (current : L) : L := cp.authority ⊓ current

theorem resume_le_current (cp : Checkpoint S L) (current : L) : resume cp current ≤ current :=
  meet_le_right _ _

theorem resume_le_checkpoint (cp : Checkpoint S L) (current : L) :
    resume cp current ≤ cp.authority := meet_le_left _ _

/-- Resuming as a transition is a diode on current authority. -/
theorem resume_is_diode (cp : Checkpoint S L) : IsDiode (resume cp) :=
  fun current => resume_le_current cp current

/-- Resuming twice from the same checkpoint gains nothing over resuming once. -/
theorem resume_resume (cp : Checkpoint S L) (current : L) :
    resume cp (resume cp current) = resume cp current := by
  unfold resume
  apply le_antisymm
  · exact le_meet _ _ _ (meet_le_left _ _)
      (le_trans' (meet_le_right _ _) (meet_le_right _ _))
  · exact le_meet _ _ _ (meet_le_left _ _) (le_refl _)

/-- A checkpoint written after a deflationary trace records at most the starting authority. -/
def checkpointAfter (μ : S → L) (τs : List (S → S)) (s : S) : Checkpoint S L :=
  ⟨runS τs s, μ (runS τs s)⟩

theorem checkpoint_le_start {μ : S → L} {τs : List (S → S)}
    (h : ∀ τ ∈ τs, DeflationaryAlong μ τ) (s : S) :
    (checkpointAfter μ τs s).authority ≤ μ s := runS_along h s
end checkpoints

/-! ## Fast path: componentwise, no netting -/

section fastpath
variable {ι : Type w}

/-- A change qualifies for the fast path only if no component rises. -/
def FastPathOK (old new : ι → L) : Prop := ∀ i, new i ≤ old i

theorem fastPath_refl (a : ι → L) : FastPathOK a a := fun _ => le_refl _

/-- Two fast-path changes in sequence are one fast-path change. -/
theorem fastPath_trans {a b c : ι → L} (h₁ : FastPathOK a b) (h₂ : FastPathOK b c) :
    FastPathOK a c := fun i => le_trans' (h₂ i) (h₁ i)

/-- A single rising component disqualifies the change, whatever the others do. -/
theorem fastPath_refuses_rise {a b : ι → L} (i : ι) (h : ¬ b i ≤ a i) : ¬ FastPathOK a b :=
  fun hok => h (hok i)
end fastpath

end Diode
end LatticeCore
