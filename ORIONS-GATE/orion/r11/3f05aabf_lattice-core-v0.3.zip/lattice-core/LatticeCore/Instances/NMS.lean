import LatticeCore.Deflation

/-!
# nms-engine: the Axiom of Non-Monotonic Support

`effective(n) = min(asserted(n), min over dependencies)`, with cycles and missing dependencies
failing closed to E0. Stated over any bounded meet-semilattice, so it applies to the faceted
E-axis, the O-axis, or their product.

Evaluation follows dependencies while tracking the current path (`vis`): revisiting a node on
the path is a cycle and yields ⊥; a missing node yields ⊥; running out of fuel yields ⊥. All
three fail closed. `effective` uses fuel `|g| + 1`.

Proved here, for every graph:
* `effective_le_asserted`: no node reads above its own assertion;
* `effective_edge` / `effective_path`: no node reads above anything it depends on, directly or
  transitively;
* `effective_cycle`: every node on a dependency cycle reads ⊥;
* `effective_missing_dep`: a node with a missing dependency reads ⊥;
* `effective_pos_inversion`: a node above ⊥ reaches no cycle and no missing node;
* `effective_le_fixpoint`: the soundness half of `ε(v) = α(v) ⊓ ⨅ ε(deps)`.

**Not proved (open):** the other half, that on an acyclic, complete graph the fuel never runs
out, so nothing is lowered spuriously. Fuel exhaustion fails closed, so this is a liveness gap,
not a safety gap; `Test/Hostile.lean` checks it on concrete graphs, including a chain whose depth
equals the node count.
-/

namespace LatticeCore
namespace NMS

universe u
variable {L : Type u} [BoundedMeetSemilattice L]
open MeetSemilattice BoundedMeetSemilattice

structure Node (L : Type u) where
  id       : Nat
  asserted : L
  deps     : List Nat

abbrev Graph (L : Type u) := List (Node L)

def Graph.lookup (g : Graph L) (v : Nat) : Option (Node L) := g.find? (·.id == v)

/-- Meet of a list; the empty meet is ⊤ (a node with no dependencies keeps its assertion). -/
def meetAll : List L → L := List.foldr (· ⊓ ·) top

def eval (g : Graph L) : Nat → List Nat → Nat → L
  | 0, _, _ => bot
  | f + 1, vis, v =>
    if v ∈ vis then bot else
    match g.lookup v with
    | none => bot
    | some n => n.asserted ⊓ meetAll (n.deps.map (eval g f (v :: vis)))

def effective (g : Graph L) (v : Nat) : L := eval g (g.length + 1) [] v

def Dep (g : Graph L) (v u : Nat) : Prop := ∃ n, g.lookup v = some n ∧ u ∈ n.deps

inductive Path (g : Graph L) : Nat → Nat → Prop
  | step {a b : Nat} : Dep g a b → Path g a b
  | cons {a b c : Nat} : Dep g a b → Path g b c → Path g a c

/-! ## List meet -/

theorem meetAll_le {xs : List L} {x : L} (h : x ∈ xs) : meetAll xs ≤ x := by
  induction xs with
  | nil => cases h
  | cons y ys ih =>
    rcases List.mem_cons.mp h with rfl | hm
    · exact meet_le_left _ _
    · exact le_trans' (meet_le_right _ _) (ih hm)

theorem le_meetAll {xs : List L} {x : L} (h : ∀ y ∈ xs, x ≤ y) : x ≤ meetAll xs := by
  induction xs with
  | nil => exact le_top x
  | cons y ys ih =>
    exact le_meet _ _ _ (h y List.mem_cons_self) (ih (fun z hz => h z (List.mem_cons_of_mem y hz)))

theorem meetAll_map_mono {β : Type} {xs : List β} {f h : β → L} (hle : ∀ x ∈ xs, f x ≤ h x) :
    meetAll (xs.map f) ≤ meetAll (xs.map h) := by
  apply le_meetAll
  intro y hy
  obtain ⟨x, hx, rfl⟩ := List.mem_map.mp hy
  exact le_trans' (meetAll_le (List.mem_map.mpr ⟨x, hx, rfl⟩)) (hle x hx)

theorem eq_bot_of_le_bot {x : L} (h : x ≤ bot) : x = bot := le_antisymm _ _ h (bot_le x)

/-! ## Evaluation lemmas -/

/-- One unfolding step, leaving the recursive calls folded. -/
theorem eval_succ (g : Graph L) (f : Nat) (vis : List Nat) (v : Nat) :
    eval g (f + 1) vis v =
      if v ∈ vis then bot else
      match g.lookup v with
      | none => bot
      | some n => n.asserted ⊓ meetAll (n.deps.map (eval g f (v :: vis))) := rfl

theorem eval_visited (g : Graph L) (f : Nat) {vis : List Nat} {v : Nat} (h : v ∈ vis) :
    eval g f vis v = bot := by
  cases f with
  | zero => rfl
  | succ f => simp [eval, h]

theorem eval_missing (g : Graph L) (f : Nat) (vis : List Nat) {v : Nat} (h : g.lookup v = none) :
    eval g f vis v = bot := by
  cases f with
  | zero => rfl
  | succ f =>
    unfold eval
    split
    · rfl
    · rw [h]

theorem eval_le_asserted (g : Graph L) (f : Nat) (vis : List Nat) {v : Nat} {n : Node L}
    (h : g.lookup v = some n) : eval g f vis v ≤ n.asserted := by
  cases f with
  | zero => exact bot_le _
  | succ f =>
    unfold eval
    split
    · exact bot_le _
    · rw [h]; exact meet_le_left _ _

/-- More fuel never lowers a reading. -/
theorem eval_fuel_mono (g : Graph L) (f : Nat) : ∀ (vis : List Nat) (v : Nat),
    eval g f vis v ≤ eval g (f + 1) vis v := by
  induction f with
  | zero => intro _ _; exact bot_le _
  | succ f ih =>
    intro vis v
    show eval g (f + 1) vis v ≤ eval g (f + 1 + 1) vis v
    unfold eval
    split
    · exact le_refl _
    · cases g.lookup v with
      | none => exact le_refl _
      | some n => exact meet_mono (le_refl _) (meetAll_map_mono (fun u _ => ih (v :: vis) u))

/-- A longer path (more visited nodes) never raises a reading. -/
theorem eval_vis_antitone (g : Graph L) (f : Nat) : ∀ (vis vis' : List Nat) (v : Nat),
    (∀ x, x ∈ vis → x ∈ vis') → eval g f vis' v ≤ eval g f vis v := by
  induction f with
  | zero => intro _ _ _ _; exact bot_le _
  | succ f ih =>
    intro vis vis' v hsub
    by_cases hv' : v ∈ vis'
    · rw [eval_visited g _ hv']; exact bot_le _
    · have hv : v ∉ vis := fun h => hv' (hsub v h)
      unfold eval
      simp only [hv, hv', if_false]
      cases g.lookup v with
      | none => exact le_refl _
      | some n =>
        refine meet_mono (le_refl _) (meetAll_map_mono (fun u _ => ih (v :: vis) (v :: vis') u ?_))
        intro x hx
        rcases List.mem_cons.mp hx with rfl | hx
        · exact List.mem_cons_self
        · exact List.mem_cons_of_mem _ (hsub x hx)

/-- One step along a dependency edge. -/
theorem eval_step (g : Graph L) (f : Nat) (vis : List Nat) {v u : Nat} (hd : Dep g v u) :
    eval g (f + 1) vis v ≤ eval g f (v :: vis) u := by
  obtain ⟨n, hn, hu⟩ := hd
  rw [eval_succ]
  split
  · exact bot_le _
  · rw [hn]
    exact le_trans' (meet_le_right _ _) (meetAll_le (List.mem_map.mpr ⟨u, hu, rfl⟩))

/-! ## The theorems -/

theorem effective_le_asserted (g : Graph L) {v : Nat} {n : Node L} (h : g.lookup v = some n) :
    effective g v ≤ n.asserted := eval_le_asserted g _ _ h

/-- No node reads above a node it depends on. -/
theorem effective_edge (g : Graph L) {v u : Nat} (hd : Dep g v u) :
    effective g v ≤ effective g u := by
  unfold effective
  exact le_trans' (eval_step g _ [] hd)
    (le_trans' (eval_vis_antitone g _ [] [v] u (fun x hx => by cases hx))
      (eval_fuel_mono g _ [] u))

/-- No node reads above anything it transitively depends on. -/
theorem effective_path (g : Graph L) {v w : Nat} (hp : Path g v w) :
    effective g v ≤ effective g w := by
  induction hp with
  | step hd => exact effective_edge g hd
  | cons hd _ ih => exact le_trans' (effective_edge g hd) ih

/-- Following a path back into the visited set reaches ⊥, whatever the fuel. -/
theorem eval_path_to_visited (g : Graph L) {a c : Nat} (hp : Path g a c) :
    ∀ (f : Nat) (vis : List Nat), (c = a ∨ c ∈ vis) → eval g f vis a = bot := by
  induction hp with
  | @step a c hd =>
    intro f vis hc
    cases f with
    | zero => rfl
    | succ f =>
      apply eq_bot_of_le_bot
      refine le_trans' (eval_step g f vis hd) (le_of_eq_bot ?_)
      apply eval_visited
      rcases hc with rfl | hc
      · exact List.mem_cons_self
      · exact List.mem_cons_of_mem _ hc
  | @cons a b c hd _ ih =>
    intro f vis hc
    cases f with
    | zero => rfl
    | succ f =>
      apply eq_bot_of_le_bot
      refine le_trans' (eval_step g f vis hd) (le_of_eq_bot (ih f (a :: vis) (Or.inr ?_)))
      rcases hc with rfl | hc
      · exact List.mem_cons_self
      · exact List.mem_cons_of_mem _ hc
where
  le_of_eq_bot {x : L} (h : x = bot) : x ≤ bot := h ▸ le_refl _

/-- **Cycles fail closed.** Every node on a dependency cycle reads ⊥. -/
theorem effective_cycle (g : Graph L) {v : Nat} (hc : Path g v v) : effective g v = bot :=
  eval_path_to_visited g hc _ [] (Or.inl rfl)

theorem effective_missing (g : Graph L) {v : Nat} (h : g.lookup v = none) :
    effective g v = bot := eval_missing g _ _ h

/-- **Missing dependencies fail closed.** -/
theorem effective_missing_dep (g : Graph L) {v u : Nat} (hd : Dep g v u)
    (hu : g.lookup u = none) : effective g v = bot :=
  eq_bot_of_le_bot ((effective_missing g hu) ▸ effective_edge g hd)

/-- Anything that reaches a cycle or a missing node reads ⊥. -/
theorem effective_reaches_bad (g : Graph L) {v w : Nat} (hp : Path g v w)
    (hbad : Path g w w ∨ g.lookup w = none) : effective g v = bot := by
  apply eq_bot_of_le_bot
  have hw : effective g w = bot := by
    rcases hbad with hc | hm
    · exact effective_cycle g hc
    · exact effective_missing g hm
  exact hw ▸ effective_path g hp

/-- **Safety inversion.** A node reading above ⊥ is present, and every node it depends on,
directly or transitively, is present and on no cycle. -/
theorem effective_pos_inversion (g : Graph L) {v : Nat} (hpos : effective g v ≠ bot) :
    g.lookup v ≠ none ∧ ∀ w, Path g v w → ¬ Path g w w ∧ g.lookup w ≠ none := by
  refine ⟨fun h => hpos (effective_missing g h), fun w hp => ⟨fun hc => ?_, fun hm => ?_⟩⟩
  · exact hpos (effective_reaches_bad g hp (Or.inl hc))
  · exact hpos (effective_reaches_bad g hp (Or.inr hm))

/-- Soundness half of the fixpoint equation: `ε(v) ≤ α(v) ⊓ ⨅ ε(u)` over its dependencies. -/
theorem effective_le_fixpoint (g : Graph L) {v : Nat} {n : Node L} (h : g.lookup v = some n) :
    effective g v ≤ n.asserted ⊓ meetAll (n.deps.map (effective g)) := by
  refine le_meet _ _ _ (effective_le_asserted g h) (le_meetAll ?_)
  intro y hy
  obtain ⟨u, hu, rfl⟩ := List.mem_map.mp hy
  exact effective_edge g ⟨n, h, hu⟩

end NMS
end LatticeCore
