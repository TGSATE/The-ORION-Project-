import LatticeCore.Instances.AxisGuard

/-!
# Crosswalk Kernel (WN-XWK-001) as deflation

A reading is a pair: evidence (canonical E-axis with facets) × authority (O0–O4).

* Translation: `normalized = min(label reading, denotation reading)`. One meet catches both
  LABEL_INFLATION and DENOTATION_INFLATION.
* Refusals: performative tokens (ACCEPTED, SEALED, FINAL, VERIFIED, CANONICAL) read E0/O0;
  AXIS_KIND_MISMATCH reads O0.
* Guard rails, each a conditional cap:
  - G-01 receipt rule: E3+ needs receipt digest AND witness identity binding, else E2.
  - G-02 witness independence: no witness or self → E2; same org → E3; independent needs a
    signature and an external identity (**assumption:** independent without both caps at E3).
  - G-03 simulation caps E2.
  - G-05 mythos quarantine: mythos-track claims read E0 evidence (confirmed against
    wn-crosswalk v0.2.0 `rules.py`).
  - G-07 authority firewall: O>0 needs a ratification record naming a human and a date.
  - G-08 track separation: research- and mythos-track claims carry no runtime authority (O0).
    Added 2026-10-04 after conformance run 1 showed the code enforces it and the model lacked it.
  - G-09 claim binding: a claim above E1 must record an artifact_digest, else E1.
  - G-10 extraction unverified: hand-extracted-from-prose claims cap at E2.
* Aggregation: FLOOR within an artifact (G-06 composition floor). The portfolio ceiling is an
  **aggregation, not a join** (ruling 2026-10-04): the set of maximal readings, each one a reading
  some artifact actually earned. E4-A and E4-B side by side give the ceiling {E4-A, E4-B}, never a
  synthesized E5. Superseded claims are excluded from the ceiling (G-04).

Theorems: every rule is deflationary; so the whole kernel never raises a reading (v0.2.0 checks
this with a test walking every rung; here it holds for every claim and every reading); each high
reading implies its preconditions; and a clean claim is left untouched (non-vacuity).
-/

namespace LatticeCore

/-! ## Authority axis: a chain -/

inductive OAxis where
  | o0 | o1 | o2 | o3 | o4
deriving DecidableEq, Repr, Inhabited

namespace OAxis
def rank : OAxis → Nat | o0 => 0 | o1 => 1 | o2 => 2 | o3 => 3 | o4 => 4
def leb (a b : OAxis) : Bool := decide (rank a ≤ rank b)
def meetO (a b : OAxis) : OAxis := if leb a b then a else b

instance : MeetSemilattice OAxis where
  le a b := leb a b = true
  meet := meetO
  le_refl := by intro a; cases a <;> decide
  le_trans := by intro a b c; cases a <;> cases b <;> cases c <;> decide
  le_antisymm := by intro a b; cases a <;> cases b <;> decide
  meet_le_left := by intro a b; cases a <;> cases b <;> decide
  meet_le_right := by intro a b; cases a <;> cases b <;> decide
  le_meet := by intro a b c; cases a <;> cases b <;> cases c <;> decide

instance (a b : OAxis) : Decidable (a ≤ b) := inferInstanceAs (Decidable (leb a b = true))

instance : BoundedMeetSemilattice OAxis :=
  { (inferInstance : MeetSemilattice OAxis) with
    bot := o0, top := o4
    bot_le := by intro a; cases a <;> decide
    le_top := by intro a; cases a <;> decide }
end OAxis

open EAxis OAxis MeetSemilattice

abbrev Reading := Pair EAxis OAxis

theorem Reading.le_iff {x y : Reading} : x ≤ y ↔ x.fst ≤ y.fst ∧ x.snd ≤ y.snd := Iff.rfl

/-! ## Claims and rules -/

/-- Which track a claim belongs to (Crosswalk `artifact.track`; default `logos`). -/
inductive Track where
  | logos | research | mythos
deriving DecidableEq, Repr

inductive WitnessKind where
  | none | self | sameOrg | independent
deriving DecidableEq, Repr

structure Claim where
  receiptDigest    : Bool
  witnessBinding   : Bool
  witness          : WitnessKind
  signed           : Bool
  externalIdentity : Bool
  simulation       : Bool
  track            : Track
  ratified         : Bool   -- ratification record naming a human and a date
  artifactDigest   : Bool
  handExtracted    : Bool
  performative     : Bool   -- label is ACCEPTED / SEALED / FINAL / VERIFIED / CANONICAL
  axisKindMismatch : Bool
deriving DecidableEq, Repr

namespace Crosswalk

/-- Caps that touch only evidence leave authority at ⊤ (no-op), and vice versa. -/
def capE (e : EAxis) : Reading := ⟨e, o4⟩
def capO (o : OAxis) : Reading := ⟨e6, o⟩
def zero : Reading := ⟨e0, o0⟩

def translate (label denotation : Reading) : Reading := label ⊓ denotation

def performativeRule (c : Claim) := capIf (c.performative = true) zero
def axisKindRule (c : Claim) := capIf (c.axisKindMismatch = true) (capO o0)
def g01 (c : Claim) := capIf (¬ (c.receiptDigest = true ∧ c.witnessBinding = true)) (capE e2)
def g02a (c : Claim) := capIf (c.witness = .none ∨ c.witness = .self) (capE e2)
def g02b (c : Claim) := capIf (c.witness = .sameOrg) (capE e3)
def g02c (c : Claim) :=
  capIf (c.witness = .independent ∧ ¬ (c.signed = true ∧ c.externalIdentity = true)) (capE e3)
def g03 (c : Claim) := capIf (c.simulation = true) (capE e2)
def g05 (c : Claim) := capIf (c.track = .mythos) (capE e0)
def g07 (c : Claim) := capIf (c.ratified = false) (capO o0)
def g08 (c : Claim) := capIf (c.track = .research ∨ c.track = .mythos) (capO o0)
def g09 (c : Claim) := capIf (c.artifactDigest = false) (capE e1)
def g10 (c : Claim) := capIf (c.handExtracted = true) (capE e2)

def rules (c : Claim) : List (Reading → Reading) :=
  [performativeRule c, axisKindRule c, g01 c, g02a c, g02b c, g02c c, g03 c, g05 c, g07 c,
   g08 c, g09 c, g10 c]

/-- The kernel: translate, then apply every guard rail. -/
def normalize (c : Claim) (r : Reading) : Reading := run (rules c) r

def reading (c : Claim) (label denotation : Reading) : Reading :=
  normalize c (translate label denotation)

/-! ## Every rule is deflationary, so the kernel never raises a reading -/

theorem rules_deflationary (c : Claim) : ∀ f ∈ rules c, Deflationary f := by
  intro f hf
  simp only [rules, List.mem_cons, List.not_mem_nil, or_false] at hf
  rcases hf with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
    exact capIf_deflationary _ _

/-- **No rule can raise a reading**, for every claim and every reading. -/
theorem normalize_le (c : Claim) (r : Reading) : normalize c r ≤ r :=
  run_deflationary (rules_deflationary c) r

theorem translate_le (l d : Reading) : translate l d ≤ l ∧ translate l d ≤ d :=
  meet_deflation l d

/-- The final reading is below both the label and the denotation reading. -/
theorem reading_le (c : Claim) (l d : Reading) : reading c l d ≤ l ∧ reading c l d ≤ d :=
  ⟨le_trans' (normalize_le c _) (translate_le l d).1,
   le_trans' (normalize_le c _) (translate_le l d).2⟩

/-! ## Safety inversions: what a high reading implies -/

/-- A cap that applies bounds the whole kernel's output. -/
theorem normalize_le_cap {c : Claim} {f : Reading → Reading} (hf : f ∈ rules c) {cap : Reading}
    (hc : ∀ x, f x ≤ cap) (r : Reading) : normalize c r ≤ cap :=
  run_le_of_mem (rules_deflationary c) hf hc r

private theorem not_e3_le_e2 : ¬ e3 ≤ e2 := by decide
private theorem not_e3_le_e1 : ¬ e3 ≤ e1 := by decide
private theorem not_e3_le_e0 : ¬ e3 ≤ e0 := by decide

/-! Each rule, stated as the cap it imposes when its condition holds. -/

section caps
variable {c : Claim}
theorem mem_perf : performativeRule c ∈ rules c := by simp [rules]
theorem mem_axis : axisKindRule c ∈ rules c := by simp [rules]
theorem mem_g01 : g01 c ∈ rules c := by simp [rules]
theorem mem_g02a : g02a c ∈ rules c := by simp [rules]
theorem mem_g02b : g02b c ∈ rules c := by simp [rules]
theorem mem_g02c : g02c c ∈ rules c := by simp [rules]
theorem mem_g03 : g03 c ∈ rules c := by simp [rules]
theorem mem_g05 : g05 c ∈ rules c := by simp [rules]
theorem mem_g07 : g07 c ∈ rules c := by simp [rules]
theorem mem_g08 : g08 c ∈ rules c := by simp [rules]
theorem mem_g09 : g09 c ∈ rules c := by simp [rules]
theorem mem_g10 : g10 c ∈ rules c := by simp [rules]

theorem perf_le (h : c.performative = true) (x : Reading) : performativeRule c x ≤ zero :=
  capIf_le h zero x
theorem axis_le (h : c.axisKindMismatch = true) (x : Reading) : axisKindRule c x ≤ capO o0 :=
  capIf_le h (capO o0) x
theorem g01_le (h : ¬ (c.receiptDigest = true ∧ c.witnessBinding = true)) (x : Reading) :
    g01 c x ≤ capE e2 := capIf_le h (capE e2) x
theorem g02a_le (h : c.witness = .none ∨ c.witness = .self) (x : Reading) : g02a c x ≤ capE e2 :=
  capIf_le h (capE e2) x
theorem g02b_le (h : c.witness = .sameOrg) (x : Reading) : g02b c x ≤ capE e3 :=
  capIf_le h (capE e3) x
theorem g02c_le (h : c.witness = .independent ∧ ¬ (c.signed = true ∧ c.externalIdentity = true))
    (x : Reading) : g02c c x ≤ capE e3 := capIf_le h (capE e3) x
theorem g03_le (h : c.simulation = true) (x : Reading) : g03 c x ≤ capE e2 :=
  capIf_le h (capE e2) x
theorem g05_le (h : c.track = .mythos) (x : Reading) : g05 c x ≤ capE e0 := capIf_le h (capE e0) x
theorem g07_le (h : c.ratified = false) (x : Reading) : g07 c x ≤ capO o0 :=
  capIf_le h (capO o0) x
theorem g08_le (h : c.track = .research ∨ c.track = .mythos) (x : Reading) : g08 c x ≤ capO o0 :=
  capIf_le h (capO o0) x
theorem g09_le (h : c.artifactDigest = false) (x : Reading) : g09 c x ≤ capE e1 :=
  capIf_le h (capE e1) x
theorem g10_le (h : c.handExtracted = true) (x : Reading) : g10 c x ≤ capE e2 :=
  capIf_le h (capE e2) x
end caps

/-- Evidence projection of a capped kernel output. -/
theorem fst_le_of_cap {c : Claim} {f : Reading → Reading} (hf : f ∈ rules c) {cap : Reading}
    (hc : ∀ x, f x ≤ cap) (r : Reading) : (normalize c r).fst ≤ cap.fst :=
  (Reading.le_iff.mp (normalize_le_cap hf hc r)).1

theorem snd_le_of_cap {c : Claim} {f : Reading → Reading} (hf : f ∈ rules c) {cap : Reading}
    (hc : ∀ x, f x ≤ cap) (r : Reading) : (normalize c r).snd ≤ cap.snd :=
  (Reading.le_iff.mp (normalize_le_cap hf hc r)).2

/-- Evidence at E3 or above implies every precondition the guard rails name. -/
theorem e3_requires (c : Claim) (r : Reading) (h : e3 ≤ (normalize c r).fst) :
    c.receiptDigest = true ∧ c.witnessBinding = true ∧
    (c.witness = .sameOrg ∨ c.witness = .independent) ∧
    c.simulation = false ∧ c.track ≠ .mythos ∧ c.artifactDigest = true ∧
    c.handExtracted = false ∧ c.performative = false := by
  -- a cap at `e` with `¬ e3 ≤ e` contradicts `h`
  have no : ∀ {e : EAxis}, (normalize c r).fst ≤ e → ¬ e3 ≤ e → False :=
    fun hle hne => hne (le_trans' h hle)
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · cases hn : c.receiptDigest
    · exact (no (fst_le_of_cap mem_g01 (g01_le (by simp [hn])) r) not_e3_le_e2).elim
    · rfl
  · cases hn : c.witnessBinding
    · exact (no (fst_le_of_cap mem_g01 (g01_le (by simp [hn])) r) not_e3_le_e2).elim
    · rfl
  · cases hw : c.witness
    · exact (no (fst_le_of_cap mem_g02a (g02a_le (Or.inl hw)) r) not_e3_le_e2).elim
    · exact (no (fst_le_of_cap mem_g02a (g02a_le (Or.inr hw)) r) not_e3_le_e2).elim
    · exact Or.inl rfl
    · exact Or.inr rfl
  · cases hs : c.simulation
    · rfl
    · exact (no (fst_le_of_cap mem_g03 (g03_le hs) r) not_e3_le_e2).elim
  · intro hm
    exact no (fst_le_of_cap mem_g05 (g05_le hm) r) not_e3_le_e0
  · cases ha : c.artifactDigest
    · exact (no (fst_le_of_cap mem_g09 (g09_le ha) r) not_e3_le_e1).elim
    · rfl
  · cases hx : c.handExtracted
    · rfl
    · exact (no (fst_le_of_cap mem_g10 (g10_le hx) r) not_e3_le_e2).elim
  · cases hp : c.performative
    · rfl
    · exact (no (fst_le_of_cap mem_perf (perf_le hp) r) not_e3_le_e0).elim

/-- Reaching any E4 facet additionally requires an independent, signed witness with an external
identity. -/
theorem e4_requires (c : Claim) (r : Reading)
    (h : e4A ≤ (normalize c r).fst ∨ e4B ≤ (normalize c r).fst ∨ e4C ≤ (normalize c r).fst) :
    c.witness = .independent ∧ c.signed = true ∧ c.externalIdentity = true := by
  have h3 : e3 ≤ (normalize c r).fst := by
    rcases h with h | h | h <;> exact le_trans' (by decide) h
  have no : (normalize c r).fst ≤ e3 → False := by
    intro hle
    rcases h with h | h | h <;> exact absurd (le_trans' h hle) (by decide)
  rcases (e3_requires c r h3).2.2.1 with hw | hw
  · exact (no (fst_le_of_cap mem_g02b (g02b_le hw) r)).elim
  · refine ⟨hw, ?_⟩
    cases hs : c.signed <;> cases he : c.externalIdentity
    all_goals first
      | exact ⟨rfl, rfl⟩
      | exact (no (fst_le_of_cap mem_g02c (g02c_le ⟨hw, by simp [hs, he]⟩) r)).elim

/-- Any authority above O0 requires a ratification record, a matching axis kind, no performative
label, and the `logos` track (research and mythos carry no runtime authority). -/
theorem authority_requires (c : Claim) (r : Reading) (h : o1 ≤ (normalize c r).snd) :
    c.ratified = true ∧ c.axisKindMismatch = false ∧ c.performative = false ∧ c.track = .logos := by
  have no : (normalize c r).snd ≤ o0 → False := fun hle => absurd (le_trans' h hle) (by decide)
  refine ⟨?_, ?_, ?_, ?_⟩
  · cases hr : c.ratified
    · exact (no (snd_le_of_cap mem_g07 (g07_le hr) r)).elim
    · rfl
  · cases hk : c.axisKindMismatch
    · rfl
    · exact (no (snd_le_of_cap mem_axis (axis_le hk) r)).elim
  · cases hp : c.performative
    · rfl
    · exact (no (snd_le_of_cap mem_perf (perf_le hp) r)).elim
  · cases ht : c.track
    · rfl
    · exact (no (snd_le_of_cap mem_g08 (g08_le (Or.inl ht)) r)).elim
    · exact (no (snd_le_of_cap mem_g08 (g08_le (Or.inr ht)) r)).elim

/-- **G-08 track separation.** A research- or mythos-track claim reads O0, whatever it asserts. -/
theorem track_separation (c : Claim) (r : Reading) (h : c.track = .research ∨ c.track = .mythos) :
    (normalize c r).snd = o0 := by
  have hle := snd_le_of_cap mem_g08 (g08_le h) r
  exact MeetSemilattice.le_antisymm _ _ hle (BoundedMeetSemilattice.bot_le _)

/-! ## Non-vacuity: a clean claim passes through unchanged

A kernel that sent everything to E0/O0 would satisfy every theorem above. This one does not. -/

def cleanClaim : Claim :=
  { receiptDigest := true, witnessBinding := true, witness := .independent, signed := true,
    externalIdentity := true, simulation := false, track := .logos, ratified := true,
    artifactDigest := true, handExtracted := false, performative := false,
    axisKindMismatch := false }

theorem clean_claim_unchanged (r : Reading) : normalize cleanClaim r = r := by
  simp [normalize, rules, run, capIf, performativeRule, axisKindRule, g01, g02a, g02b, g02c, g03,
    g05, g07, g08, g09, g10, cleanClaim]

/-! ## Aggregation: FLOOR within an artifact; the portfolio ceiling without promotion

FLOOR (G-06) is the meet. The portfolio ceiling is **not** a join (ruling 2026-10-04): joining E4-A
and E4-B would synthesize E5, a reading no artifact earned. The ceiling is the set of maximal
readings: every element is a reading some artifact holds (`ceiling_sub`), the elements are pairwise
incomparable (`ceiling_antichain`), and every reading sits under one of them (`ceiling_covers`). -/

def floorAll : List EAxis → EAxis := List.foldr (· ⊓ ·) e6

theorem floorAll_le {xs : List EAxis} {x : EAxis} (h : x ∈ xs) : floorAll xs ≤ x := by
  induction xs with
  | nil => cases h
  | cons y ys ih =>
    rcases List.mem_cons.mp h with rfl | hm
    · exact meet_le_left _ _
    · exact le_trans' (meet_le_right _ _) (ih hm)

/-- `x` lies strictly below some reading in `xs`. -/
def belowSome (xs : List EAxis) (x : EAxis) : Bool := xs.any fun y => decide (x ≤ y) && x != y

/-- Duplicates removed, membership preserved. -/
def dedup : List EAxis → List EAxis
  | [] => []
  | x :: xs => if x ∈ dedup xs then dedup xs else x :: dedup xs

theorem mem_dedup {x : EAxis} {xs : List EAxis} : x ∈ dedup xs ↔ x ∈ xs := by
  induction xs with
  | nil => simp [dedup]
  | cons y ys ih =>
    unfold dedup
    split
    · constructor
      · intro h; exact List.mem_cons_of_mem _ (ih.mp h)
      · intro h
        rcases List.mem_cons.mp h with rfl | h
        · assumption
        · exact ih.mpr h
    · simp [List.mem_cons, ih]

/-- The portfolio ceiling: the maximal readings, without duplicates. -/
def ceiling (xs : List EAxis) : List EAxis := dedup (xs.filter fun x => !belowSome xs x)

/-- **No promotion.** Every element of the ceiling is a reading some artifact actually holds. -/
theorem ceiling_sub {xs : List EAxis} {m : EAxis} (h : m ∈ ceiling xs) : m ∈ xs :=
  (List.mem_filter.mp (mem_dedup.mp h)).1

/-- Nothing in the portfolio sits strictly above an element of the ceiling. -/
theorem ceiling_maximal {xs : List EAxis} {m : EAxis} (h : m ∈ ceiling xs) :
    ∀ y ∈ xs, m ≤ y → y = m := by
  intro y hy hle
  have hnot : belowSome xs m = false := by
    have := (List.mem_filter.mp (mem_dedup.mp h)).2
    simpa using this
  by_cases hne : m = y
  · exact hne.symm
  · exfalso
    have : belowSome xs m = true :=
      List.any_eq_true.mpr ⟨y, hy, by simp [hle, hne]⟩
    rw [hnot] at this; cases this

/-- The ceiling is an antichain. -/
theorem ceiling_antichain {xs : List EAxis} {m m' : EAxis} (h : m ∈ ceiling xs) (h' : m' ∈ ceiling xs)
    (hle : m ≤ m') : m = m' :=
  (ceiling_maximal h m' (ceiling_sub h') hle).symm

private theorem stage_lt_of_lt : ∀ x y : EAxis, x ≤ y → x ≠ y → EAxis.stage x < EAxis.stage y := by
  intro x y; cases x <;> cases y <;> decide

private theorem stage_le_six : ∀ x : EAxis, EAxis.stage x ≤ 6 := by
  intro x; cases x <;> decide

private theorem covers_aux (xs : List EAxis) :
    ∀ n x, 6 - EAxis.stage x ≤ n → x ∈ xs → ∃ m ∈ ceiling xs, x ≤ m := by
  intro n
  induction n with
  | zero =>
    intro x hn hx
    refine ⟨x, mem_dedup.mpr (List.mem_filter.mpr ⟨hx, ?_⟩), MeetSemilattice.le_refl x⟩
    cases hb : belowSome xs x
    · rfl
    · obtain ⟨y, _, hy⟩ := List.any_eq_true.mp hb
      simp only [Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne, ne_eq] at hy
      have := stage_lt_of_lt x y hy.1 hy.2
      have := stage_le_six y
      omega
  | succ n ih =>
    intro x hn hx
    cases hb : belowSome xs x
    · exact ⟨x, mem_dedup.mpr (List.mem_filter.mpr ⟨hx, by simp [hb]⟩), MeetSemilattice.le_refl x⟩
    · obtain ⟨y, hy, hxy⟩ := List.any_eq_true.mp hb
      simp only [Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne, ne_eq] at hxy
      have hlt := stage_lt_of_lt x y hxy.1 hxy.2
      have := stage_le_six y
      obtain ⟨m, hm, hym⟩ := ih y (by omega) hy
      exact ⟨m, hm, le_trans' hxy.1 hym⟩

/-- Every reading sits under some element of the ceiling. -/
theorem ceiling_covers {xs : List EAxis} {x : EAxis} (h : x ∈ xs) : ∃ m ∈ ceiling xs, x ≤ m :=
  covers_aux xs _ x (Nat.le_refl _) h

/-- Two facets side by side: the ceiling is both of them, and nothing is synthesized. -/
theorem ceiling_facets_no_promotion :
    ceiling [e4A, e4B] = [e4A, e4B] ∧ e5 ∉ ceiling [e4A, e4B] := by decide

/-- G-04: excluding superseded claims can only lower the ceiling. -/
theorem ceiling_filter_dominated (p : EAxis → Bool) (xs : List EAxis) :
    ∀ m ∈ ceiling (xs.filter p), ∃ m' ∈ ceiling xs, m ≤ m' := fun _ hm =>
  ceiling_covers (List.mem_filter.mp (ceiling_sub hm)).1

/-- After the kernel, every element of the ceiling is dominated by an element of the raw ceiling. -/
theorem ceiling_dominated_by_raw (ps : List (Claim × Reading)) :
    ∀ m ∈ ceiling (ps.map fun p => (normalize p.1 p.2).fst),
      ∃ m' ∈ ceiling (ps.map fun p => p.2.fst), m ≤ m' := by
  intro m hm
  obtain ⟨p, hp, rfl⟩ := List.mem_map.mp (ceiling_sub hm)
  obtain ⟨m', hm', hle⟩ := ceiling_covers (List.mem_map.mpr ⟨p, hp, rfl⟩)
  exact ⟨m', hm', le_trans' (Reading.le_iff.mp (normalize_le p.1 p.2)).1 hle⟩

end Crosswalk
end LatticeCore
