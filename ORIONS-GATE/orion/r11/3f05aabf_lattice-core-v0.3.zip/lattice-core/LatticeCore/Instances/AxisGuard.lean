import LatticeCore.Deflation

/-!
# AxisGuard: the canonical evidence axis as a partial order

Canonical E0–E6 with the E4 class split into three incomparable facets (adopted July 2026):
E4-A independent reproduction, E4-B independent constitutional review, E4-C adversarial
assessment — "none implies the others". axis_guard v0.2.0 rebuilt the axis as a partial order of
(stage, facet) so that FLOOR(E4-A, E4-B) = E3 "by lattice meet, not list position".

**Modeling assumption (stated, not taken from the notes):** order is by stage, with E4-A/B/C
sharing stage 4. So E5 and E6 sit above all three facets, and E4-A ⊔ E4-B = E5. If the canonical
axis intends something else for E5, change `stage`/`leb` and every theorem re-checks.

Consequence proved below: the axis is the lattice M₃ embedded in a chain, which is **not
distributive**. FLOOR and MAX do not distribute over each other, so the order in which a
pipeline floors and maxes is part of its meaning; regrouping changes the answer.
-/

namespace LatticeCore

inductive EAxis where
  | e0 | e1 | e2 | e3 | e4A | e4B | e4C | e5 | e6
deriving DecidableEq, Repr, Inhabited

namespace EAxis

def stage : EAxis → Nat
  | e0 => 0 | e1 => 1 | e2 => 2 | e3 => 3 | e4A => 4 | e4B => 4 | e4C => 4 | e5 => 5 | e6 => 6

/-- `a ≤ b` iff `a` is at a strictly lower stage, or `a = b`. Facets share a stage, so distinct
facets are incomparable. -/
def leb (a b : EAxis) : Bool := decide (stage a < stage b) || a == b

/-- Meet: the lower of two comparable readings; for two distinct facets, E3. -/
def meetE (a b : EAxis) : EAxis := if leb a b then a else if leb b a then b else e3

/-- Join: the higher of two comparable readings; for two distinct facets, E5. -/
def joinE (a b : EAxis) : EAxis := if leb a b then b else if leb b a then a else e5

instance : MeetSemilattice EAxis where
  le a b := leb a b = true
  meet := meetE
  le_refl := by intro a; cases a <;> decide
  le_trans := by intro a b c; cases a <;> cases b <;> cases c <;> decide
  le_antisymm := by intro a b; cases a <;> cases b <;> decide
  meet_le_left := by intro a b; cases a <;> cases b <;> decide
  meet_le_right := by intro a b; cases a <;> cases b <;> decide
  le_meet := by intro a b c; cases a <;> cases b <;> cases c <;> decide

instance (a b : EAxis) : Decidable (a ≤ b) := inferInstanceAs (Decidable (leb a b = true))

instance : BoundedMeetSemilattice EAxis :=
  { (inferInstance : MeetSemilattice EAxis) with
    bot := e0, top := e6
    bot_le := by intro a; cases a <;> decide
    le_top := by intro a; cases a <;> decide }

instance : JoinLattice EAxis :=
  { (inferInstance : MeetSemilattice EAxis) with
    join := joinE
    le_join_left := by intro a b; cases a <;> cases b <;> decide
    le_join_right := by intro a b; cases a <;> cases b <;> decide
    join_le := by intro a b c; cases a <;> cases b <;> cases c <;> decide }

end EAxis

open EAxis

/-! ## The facet theorems -/

/-- The three E4 facets are pairwise incomparable: none implies another. -/
theorem facets_incomparable :
    ¬ e4A ≤ e4B ∧ ¬ e4B ≤ e4A ∧ ¬ e4A ≤ e4C ∧ ¬ e4C ≤ e4A ∧ ¬ e4B ≤ e4C ∧ ¬ e4C ≤ e4B := by
  decide

/-- FLOOR of two distinct facets is E3, by meet. -/
theorem facet_meet_eq_e3 :
    e4A ⊓ e4B = e3 ∧ e4A ⊓ e4C = e3 ∧ e4B ⊓ e4C = e3 := by decide

/-- The blueprint's form: any two distinct facets meet at or below E3. -/
theorem facet_meet_le_e3 (x y : EAxis) (hx : stage x = 4) (hy : stage y = 4) (hne : x ≠ y) :
    x ⊓ y ≤ e3 := by
  cases x <;> cases y <;> simp_all [stage] <;> decide

/-- E3 is the greatest reading below two distinct facets (it is the meet, not just a bound). -/
theorem e3_greatest_below_facets (z : EAxis) (h₁ : z ≤ e4A) (h₂ : z ≤ e4B) : z ≤ e3 := by
  have := MeetSemilattice.le_meet z e4A e4B h₁ h₂
  rwa [facet_meet_eq_e3.1] at this

/-- Under the stage-order assumption, MAX of two distinct facets is E5. -/
theorem facet_join_eq_e5 : e4A ⊔ e4B = e5 ∧ e4A ⊔ e4C = e5 ∧ e4B ⊔ e4C = e5 := by decide

/-- **The axis is not distributive.** Floor-then-max and max-then-floor disagree:
`E4-A ⊓ (E4-B ⊔ E4-C) = E4-A`, but `(E4-A ⊓ E4-B) ⊔ (E4-A ⊓ E4-C) = E3`. -/
theorem not_distributive :
    e4A ⊓ (e4B ⊔ e4C) = e4A ∧ (e4A ⊓ e4B) ⊔ (e4A ⊓ e4C) = e3 := by decide

/-- On a chain (all comparable), FLOOR is just the minimum; the facets are the only place the
axis is not a chain. -/
theorem comparable_unless_distinct_facets (x y : EAxis) :
    x ≤ y ∨ y ≤ x ∨ (stage x = 4 ∧ stage y = 4 ∧ x ≠ y) := by
  cases x <;> cases y <;> decide

end LatticeCore
