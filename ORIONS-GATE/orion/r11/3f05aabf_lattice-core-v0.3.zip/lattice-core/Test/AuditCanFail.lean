import Test.Hostile

/-!
# The axiom audit can fail

A deliberately `sorry`'d theorem under the `LatticeCore` prefix (this test library only; never in
`LatticeCore` itself). The audit must name it. If the audit ever stops seeing it, this file
fails to build.
-/

/-- warning: declaration uses 'sorry' -/
#guard_msgs in
theorem LatticeCore.plantedForAudit : (1 : Nat) = 2 := sorry

/-- error: theorems with disallowed axioms: [(LatticeCore.plantedForAudit, [sorryAx])] -/
#guard_msgs in
#audit_axioms
