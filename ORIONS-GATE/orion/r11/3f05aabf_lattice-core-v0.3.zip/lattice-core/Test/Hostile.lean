import Lean
import LatticeCore

/-!
# Hostile suite

`lake build` runs every check here; a failure is a build error.

1. Inflation attempts are refused, including the facet swap that the "∃ x, r x > x" test misses.
2. A rule that raises in one corner case, appended to the Crosswalk kernel, breaks deflation.
3. Crosswalk regressions: label inflation, denotation inflation, performative tokens, self-witness.
4. nms-engine: cycles at the top of the axis, missing dependencies, facets meeting at E3 through a
   DAG, and non-vacuity (no spurious lowering on acyclic graphs, including a chain whose depth
   equals the node count, and the measured fuel margin).
5. No netting on the fast path; checkpoint resumption.
6. The checks can fail: a false claim is refused by `decide`.
7. Build-time axiom audit over every theorem in the library: no sorry, no foreign axioms, no choice.
-/

open LatticeCore LatticeCore.EAxis LatticeCore.OAxis MeetSemilattice

/-! ## 1. Inflation attempts -/

def bump : EAxis → EAxis
  | e0 => e1 | e1 => e2 | e2 => e3 | e3 => e4A | e4A => e5 | e4B => e5 | e4C => e5
  | e5 => e6 | e6 => e6

theorem bump_refused : ¬ Deflationary bump := not_deflationary_of e0 (by decide)

/-- Swaps two facets, fixes everything else. -/
def facetSwap : EAxis → EAxis
  | e4A => e4B | e4B => e4A | x => x

/-- The blueprint's refutation test ("∃ x, r x > x") does NOT catch the facet swap:
it never produces anything strictly greater than its input. -/
theorem facetSwap_never_strictly_raises : ∀ x : EAxis, ¬ (x ≤ facetSwap x ∧ x ≠ facetSwap x) := by
  intro x; cases x <;> decide

/-- ...but it is not deflationary: `E4-A ↦ E4-B` is not `≤ E4-A`. The correct test is
`∃ x, ¬ r x ≤ x`. -/
theorem facetSwap_refused : ¬ Deflationary facetSwap := not_deflationary_of e4A (by decide)

/-! ## 2. A corner-case raiser appended to the Crosswalk kernel -/

namespace LatticeCore.Crosswalk

/-- Raises evidence to E3 for simulation claims, and does nothing otherwise. -/
def evil (c : Claim) (r : Reading) : Reading :=
  if c.simulation = true then ⟨e3, r.snd⟩ else r

def simClaim : Claim := { cleanClaim with simulation := true }

/-- The honest kernel never raises; with `evil` appended, it does, on one claim and one reading. -/
theorem evil_breaks_deflation :
    ¬ Deflationary (run (rules simClaim ++ [evil simClaim])) :=
  not_deflationary_of ⟨e1, o4⟩ (by decide)

/-- And the honest kernel on the same claim and reading leaves it alone (E1 is below the E2 cap). -/
example : normalize simClaim ⟨e1, o4⟩ = ⟨e1, o4⟩ := by decide

/-! ## 3. Crosswalk regressions -/

/-- LABEL_INFLATION: Sealkit labelled E4 but denoting author-machine execution (E2) reads E2. -/
example : translate ⟨e4A, o0⟩ ⟨e2, o0⟩ = ⟨e2, o0⟩ := by decide

/-- DENOTATION_INFLATION: labelled E2 but denoting independent reproduction (E4-A) reads E2. -/
example : translate ⟨e2, o0⟩ ⟨e4A, o0⟩ = ⟨e2, o0⟩ := by decide

/-- A performative token (SEALED, FINAL, ...) reads E0/O0 whatever it claims. -/
example : normalize { cleanClaim with performative := true } ⟨e6, o4⟩ = ⟨e0, o0⟩ := by decide

/-- A self-witnessed E4 claim reads E2. -/
example : (normalize { cleanClaim with witness := .self } ⟨e4A, o2⟩).fst = e2 := by decide

/-- Same-org witness: at most E3, even with every receipt in place. -/
example : (normalize { cleanClaim with witness := .sameOrg } ⟨e6, o2⟩).fst = e3 := by decide

/-- Unratified: authority falls to O0, evidence untouched. -/
example : normalize { cleanClaim with ratified := false } ⟨e4B, o3⟩ = ⟨e4B, o0⟩ := by decide

/-- No artifact digest (named ≠ located): E1. -/
example : (normalize { cleanClaim with artifactDigest := false } ⟨e6, o0⟩).fst = e1 := by decide

end LatticeCore.Crosswalk

/-! ## 4. nms-engine -/

namespace LatticeCore.NMS

/-- A three-cycle with every node asserted at the top of the axis, a node depending on it, and an
independent node. -/
def cyc : Graph EAxis :=
  [⟨1, e6, [2]⟩, ⟨2, e6, [3]⟩, ⟨3, e6, [1]⟩, ⟨4, e6, [1]⟩, ⟨5, e6, []⟩]

example : effective cyc 1 = e0 ∧ effective cyc 2 = e0 ∧ effective cyc 3 = e0 := by decide
example : effective cyc 4 = e0 := by decide          -- depends on the cycle
example : effective cyc 5 = e6 := by decide          -- untouched: not everything collapses

/-- A missing dependency. -/
example : effective ([⟨1, e6, [99]⟩] : Graph EAxis) 1 = e0 := by decide

/-- Two facets meeting through a DAG: a claim resting on an E4-A and an E4-B reads E3. -/
def facets : Graph EAxis := [⟨1, e6, [2, 3]⟩, ⟨2, e4A, []⟩, ⟨3, e4B, []⟩]
example : effective facets 1 = e3 := by decide

/-- A diamond: the minimum over all paths. -/
def diamond : Graph EAxis := [⟨1, e6, [2, 3]⟩, ⟨2, e5, [4]⟩, ⟨3, e6, [4]⟩, ⟨4, e2, []⟩]
example : effective diamond 1 = e2 ∧ effective diamond 3 = e2 ∧ effective diamond 4 = e2 := by
  decide

/-- Non-vacuity of fuel: a chain whose depth equals the node count keeps its top reading. -/
def chain : Graph EAxis :=
  (List.range 10).map fun i => ⟨i, e6, if i + 1 < 10 then [i + 1] else []⟩
set_option maxRecDepth 20000 in
example : effective chain 0 = e6 := by decide

-- Fuel margin, measured: the 10-node chain needs exactly 10 units (fuel = node count still reads
-- E6), so `effective`'s `|g| + 1` has one unit of margin, and 9 units lower it spuriously.
set_option maxRecDepth 20000 in
example : eval chain chain.length [] 0 = e6 := by decide
set_option maxRecDepth 20000 in
example : eval chain (chain.length - 1) [] 0 = e0 := by decide

end LatticeCore.NMS

/-! ## 5. No netting; checkpoint resumption -/

namespace LatticeCore.Diode

def before : Fin 2 → OAxis := fun i => if i.val = 0 then o2 else o1
def after  : Fin 2 → OAxis := fun i => if i.val = 0 then o1 else o2

/-- The change nets to zero (rank sums 3 = 3)... -/
example : OAxis.rank (before 0) + OAxis.rank (before 1) =
    OAxis.rank (after 0) + OAxis.rank (after 1) := by decide

/-- ...but component 1 rises, so the fast path refuses it. -/
theorem netting_refused : ¬ FastPathOK before after := fastPath_refuses_rise 1 (by decide)

/-- A checkpoint recorded at O3, resumed while current authority is O1, resumes at O1. -/
example : resume (⟨(), o3⟩ : Checkpoint Unit OAxis) o1 = o1 := by decide
/-- A checkpoint recorded at O1 cannot restore O3. -/
example : resume (⟨(), o1⟩ : Checkpoint Unit OAxis) o3 = o1 := by decide

end LatticeCore.Diode

/-! ## 6. The checks can fail -/

/--
error: tactic 'decide' proved that the proposition
  NMS.effective NMS.cyc 1 = e6
is false
-/
#guard_msgs in
example : NMS.effective NMS.cyc 1 = e6 := by decide

/-! ## 7. Build-time axiom audit

Walks every theorem whose name starts with `LatticeCore` and fails the build if any depends on
`sorryAx`, on a foreign axiom, or on `Classical.choice`. The library is constructive (only
`propext` and `Quot.sound`, and most theorems use no axioms at all); this keeps it that way. -/

open Lean Elab Command in
elab "#audit_axioms" : command => do
  let env ← getEnv
  let allowed : List Name := [``propext, ``Quot.sound]
  let mut n := 0
  let mut bad : Array (Name × List Name) := #[]
  for (name, info) in env.constants.toList do
    if (`LatticeCore).isPrefixOf name && !name.isInternal then
      if let .thmInfo _ := info then
        n := n + 1
        let axs ← liftCoreM (collectAxioms name)
        let off := axs.toList.filter (fun a => !allowed.contains a)
        if !off.isEmpty then bad := bad.push (name, off)
  if n < 60 then throwError "audit saw only {n} theorems; expected at least 60"
  unless bad.isEmpty do throwError "theorems with disallowed axioms: {bad.toList}"

#audit_axioms

/-- info: 'LatticeCore.run_no_raise' does not depend on any axioms -/
#guard_msgs in #print axioms run_no_raise
