#!/usr/bin/env python3
"""LatticeCore conformance harness (Python stdlib only).

Diffs a system under test (SUT) against the tables exported from the verified Lean models
(`lake exe export_tables`, format `lattice-core-conformance/1`).

    python3 harness.py TABLE_DIR --sut reference
    python3 harness.py TABLE_DIR --sut path/to/adapter.py --pin EXPECTED_SHA256SUMS

Order of checks (the SUT is never called on a table that fails 1-3):
  1. Integrity: every file matches SHA256SUMS; with --pin, SHA256SUMS matches the pinned digests
     committed in lattice-core (catches an edited table whose sums were regenerated).
  2. Form: every line is canonical JSON (sorted keys, no whitespace, ASCII, trailing newline),
     with known enum values only.
  3. Completeness: no duplicate inputs; exhaustive tables cover their whole input space.
  4. Diff: every case is run through the SUT and compared. A SUT exception is a mismatch.

Verdicts and exit codes:
  CONFORMS     0  every requested table ran in full, zero mismatches
  MISMATCH     1  at least one case differs (or the SUT raised)
  INTEGRITY    2  a table failed checks 1-3; nothing about the SUT is concluded
  UNCONFIRMED  3  no mismatches, but something was skipped (a missing adapter method, or rows the
                  adapter declared unsupported). A skipped conformance test is an unconfirmed
                  implementation (Crosswalk NF-009).

Adapter interface (implement what applies; see adapter_template.py):
  crosswalk_normalize(claim: dict, reading: str) -> str        e.g. ("E4A/O2") -> "E2/O0"
  crosswalk_translate(label: str, denotation: str) -> str
  e_le(a, b) -> bool;  e_meet(a, b) -> str
  e_ceiling(readings: list[str]) -> list[str]                  the maximal readings (order ignored)
  o_le(a, b) -> bool;  o_meet(a, b) -> str
  nms_effective(graph: list[dict]) -> dict[int, str]           graph nodes: {"id","asserted","deps"}
  nms_supports_facets: bool (optional; False skips facet rows -> UNCONFIRMED)
"""
import argparse
import hashlib
import importlib.util
import json
import os
import sys

FORMAT = "lattice-core-conformance/2"
EXIT = {"CONFORMS": 0, "MISMATCH": 1, "INTEGRITY": 2, "UNCONFIRMED": 3}
CLAIM_BOOLS = ["artifact_digest", "axis_kind_mismatch", "external_identity", "hand_extracted",
               "performative", "ratified", "receipt_digest", "signed", "simulation", "witness_binding"]
CLAIM_KEYS = set(CLAIM_BOOLS) | {"witness", "track"}


class IntegrityError(Exception):
    pass


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


# ---------------------------------------------------------------------------- 1. integrity

def read_sums(path):
    sums = {}
    with open(path, "r", encoding="ascii") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            digest, sep, name = line.partition("  ")
            if not sep or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise IntegrityError(f"malformed digest line: {line!r}")
            name = name.lstrip("*")
            if name in sums:
                raise IntegrityError(f"{name} listed twice")
            sums[name] = digest
    return sums


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_integrity(table_dir, pin=None):
    sums_path = os.path.join(table_dir, "SHA256SUMS")
    if not os.path.exists(sums_path):
        raise IntegrityError("SHA256SUMS missing: the tables are unverifiable")
    sums = read_sums(sums_path)
    for name, digest in sums.items():
        path = os.path.join(table_dir, name)
        if not os.path.exists(path):
            raise IntegrityError(f"{name} listed in SHA256SUMS but missing")
        if sha256_file(path) != digest:
            raise IntegrityError(f"{name}: SHA-256 does not match SHA256SUMS")
    if pin is not None:
        pinned = read_sums(pin)
        if pinned != sums:
            changed = sorted(n for n in set(pinned) | set(sums) if pinned.get(n) != sums.get(n))
            raise IntegrityError(f"digests differ from the pinned set for: {', '.join(changed)}")
    if "manifest.json" not in sums:
        raise IntegrityError("manifest.json is not covered by SHA256SUMS")
    with open(os.path.join(table_dir, "manifest.json"), "rb") as f:
        raw = f.read()
    if not raw.endswith(b"\n"):
        raise IntegrityError("manifest.json: missing trailing newline")
    manifest = parse_canonical(raw[:-1], "manifest.json", 1)
    if manifest.get("format") != FORMAT:
        raise IntegrityError(f"unsupported format {manifest.get('format')!r}; expected {FORMAT}")
    for t in manifest["tables"]:
        if t["file"] not in sums:
            raise IntegrityError(f"{t['file']} is not covered by SHA256SUMS")
    return manifest


# ---------------------------------------------------------------------------- 2. form

def parse_canonical(raw_line, fname, lineno):
    try:
        line = raw_line.decode("ascii")
    except UnicodeDecodeError:
        raise IntegrityError(f"{fname}:{lineno}: not ASCII")
    try:
        obj = json.loads(line)
    except json.JSONDecodeError as e:
        raise IntegrityError(f"{fname}:{lineno}: not JSON ({e.msg})")
    if canonical(obj) != line:
        raise IntegrityError(f"{fname}:{lineno}: not canonical JSON")
    return obj


def iter_rows(table_dir, fname):
    with open(os.path.join(table_dir, fname), "rb") as f:
        for lineno, raw in enumerate(f, 1):
            if not raw.endswith(b"\n"):
                raise IntegrityError(f"{fname}:{lineno}: missing trailing newline")
            yield lineno, parse_canonical(raw[:-1], fname, lineno)


class Enums:
    def __init__(self, manifest):
        e = manifest["enums"]
        self.E, self.O, self.W = list(e["e_axis"]), list(e["o_axis"]), list(e["witness"])
        self.T = list(e["track"])
        self.readings = [f"{a}/{b}" for a in self.E for b in self.O]
        self.reading_set = set(self.readings)

    def need(self, value, allowed, where):
        if value not in allowed:
            raise IntegrityError(f"{where}: unknown value {value!r}")


# ---------------------------------------------------------------------------- 3-4. tables

class Result:
    def __init__(self, table):
        self.table, self.rows, self.cases, self.mismatch_count = table, 0, 0, 0
        self.mismatches, self.skipped = [], []

    def miss(self, line, inp, expected, got, limit):
        self.mismatch_count += 1
        if len(self.mismatches) < limit:
            self.mismatches.append({"line": line, "input": inp, "expected": expected, "got": got})


def call(fn, *args):
    try:
        return fn(*args)
    except Exception as e:  # a crash is a non-conformance, recorded with the case
        return f"EXCEPTION: {type(e).__name__}: {e}"


def check_crosswalk_normalize(d, m, en, sut, entry, limit):
    r = Result("crosswalk_normalize")
    fn = getattr(sut, "crosswalk_normalize", None)
    if fn is None:
        r.skipped.append("adapter has no crosswalk_normalize")
    seen = set()
    for line, row in iter_rows(d, entry["file"]):
        if set(row) != {"claim", "out"}:
            raise IntegrityError(f"{entry['file']}:{line}: unexpected keys")
        claim = row["claim"]
        if set(claim) != CLAIM_KEYS or any(not isinstance(claim[k], bool) for k in CLAIM_BOOLS):
            raise IntegrityError(f"{entry['file']}:{line}: malformed claim")
        en.need(claim["witness"], en.W, f"{entry['file']}:{line}")
        en.need(claim["track"], en.T, f"{entry['file']}:{line}")
        key = canonical(claim)
        if key in seen:
            raise IntegrityError(f"{entry['file']}:{line}: duplicate claim")
        seen.add(key)
        out = row["out"]
        if set(out) != en.reading_set:
            raise IntegrityError(f"{entry['file']}:{line}: row does not cover every reading")
        r.rows += 1
        for reading in en.readings:
            expected = out[reading]
            en.need(expected, en.reading_set, f"{entry['file']}:{line}")
            if fn is None:
                continue
            got = call(fn, dict(claim), reading)
            r.cases += 1
            if got != expected:
                r.miss(line, {"claim": claim, "reading": reading}, expected, got, limit)
    space = (2 ** len(CLAIM_BOOLS)) * len(en.W) * len(en.T)
    if len(seen) != space or r.rows != entry["rows"]:
        raise IntegrityError(f"{entry['file']}: {len(seen)} claims, the claim space has {space}")
    return r


def check_crosswalk_translate(d, m, en, sut, entry, limit):
    r = Result("crosswalk_translate")
    fn = getattr(sut, "crosswalk_translate", None)
    if fn is None:
        r.skipped.append("adapter has no crosswalk_translate")
    seen = set()
    for line, row in iter_rows(d, entry["file"]):
        if set(row) != {"label", "denotation", "out"}:
            raise IntegrityError(f"{entry['file']}:{line}: unexpected keys")
        for k in row:
            en.need(row[k], en.reading_set, f"{entry['file']}:{line}")
        pair = (row["label"], row["denotation"])
        if pair in seen:
            raise IntegrityError(f"{entry['file']}:{line}: duplicate pair")
        seen.add(pair)
        r.rows += 1
        if fn is not None:
            got = call(fn, *pair)
            r.cases += 1
            if got != row["out"]:
                r.miss(line, {"label": pair[0], "denotation": pair[1]}, row["out"], got, limit)
    if len(seen) != len(en.readings) ** 2:
        raise IntegrityError(f"{entry['file']}: {len(seen)} pairs, expected {len(en.readings) ** 2}")
    return r


def check_axis(d, m, en, sut, entry, limit, prefix, values, fields):
    r = Result(entry["file"].replace(".jsonl", ""))
    fns = {f: getattr(sut, f"{prefix}_{f}", None) for f in fields}
    for f, fn in fns.items():
        if fn is None:
            r.skipped.append(f"adapter has no {prefix}_{f}")
    seen = set()
    for line, row in iter_rows(d, entry["file"]):
        if set(row) != {"a", "b"} | set(fields):
            raise IntegrityError(f"{entry['file']}:{line}: unexpected keys")
        en.need(row["a"], values, f"{entry['file']}:{line}")
        en.need(row["b"], values, f"{entry['file']}:{line}")
        pair = (row["a"], row["b"])
        if pair in seen:
            raise IntegrityError(f"{entry['file']}:{line}: duplicate pair")
        seen.add(pair)
        r.rows += 1
        for f in fields:
            if f != "le":
                en.need(row[f], values, f"{entry['file']}:{line}")
            elif not isinstance(row[f], bool):
                raise IntegrityError(f"{entry['file']}:{line}: le is not a boolean")
            if fns[f] is None:
                continue
            got = call(fns[f], *pair)
            r.cases += 1
            if got != row[f]:
                r.miss(line, {"op": f, "a": pair[0], "b": pair[1]}, row[f], got, limit)
    if len(seen) != len(values) ** 2:
        raise IntegrityError(f"{entry['file']}: {len(seen)} pairs, expected {len(values) ** 2}")
    return r


def check_ceiling(d, m, en, sut, entry, limit):
    r = Result("e_axis_ceiling")
    fn = getattr(sut, "e_ceiling", None)
    if fn is None:
        r.skipped.append("adapter has no e_ceiling")
    order = {v: i for i, v in enumerate(en.E)}
    seen = set()
    for line, row in iter_rows(d, entry["file"]):
        if set(row) != {"readings", "ceiling"}:
            raise IntegrityError(f"{entry['file']}:{line}: unexpected keys")
        readings, expected = row["readings"], row["ceiling"]
        for v in readings + expected:
            en.need(v, en.E, f"{entry['file']}:{line}")
        key = tuple(readings)
        if key in seen or len(set(readings)) != len(readings) or not readings:
            raise IntegrityError(f"{entry['file']}:{line}: duplicate or malformed reading set")
        seen.add(key)
        r.rows += 1
        if fn is None:
            continue
        got = call(fn, list(readings))
        r.cases += 1
        if isinstance(got, str):
            r.miss(line, {"readings": readings}, expected, got, limit)
            continue
        try:
            norm = sorted(got, key=lambda v: order[v])
        except (KeyError, TypeError):
            norm = got
        if norm != expected or len(set(got)) != len(got):
            r.miss(line, {"readings": readings}, expected, got, limit)
    if len(seen) != 2 ** len(en.E) - 1:
        raise IntegrityError(f"{entry['file']}: {len(seen)} reading sets, expected {2 ** len(en.E) - 1}")
    return r


def check_nms(d, m, en, sut, entry, limit):
    r = Result("nms_effective")
    fn = getattr(sut, "nms_effective", None)
    facets_ok = getattr(sut, "nms_supports_facets", True)
    if fn is None:
        r.skipped.append("adapter has no nms_effective")
    names, facet_rows_skipped = set(), 0
    for line, row in iter_rows(d, entry["file"]):
        if set(row) != {"name", "facets", "graph", "effective"}:
            raise IntegrityError(f"{entry['file']}:{line}: unexpected keys")
        if row["name"] in names:
            raise IntegrityError(f"{entry['file']}:{line}: duplicate graph name")
        names.add(row["name"])
        graph = row["graph"]
        for node in graph:
            if set(node) != {"id", "asserted", "deps"}:
                raise IntegrityError(f"{entry['file']}:{line}: malformed node")
            en.need(node["asserted"], en.E, f"{entry['file']}:{line}")
        expected = {}
        for node_id, level in row["effective"]:
            en.need(level, en.E, f"{entry['file']}:{line}")
            expected[node_id] = level
        r.rows += 1
        if fn is None:
            continue
        if row["facets"] and not facets_ok:
            facet_rows_skipped += 1
            continue
        got = call(fn, [dict(n, deps=list(n["deps"])) for n in graph])
        if isinstance(got, str):  # exception
            r.cases += len(expected)
            r.miss(line, {"graph": row["name"]}, "(all nodes)", got, limit)
            continue
        for node_id, level in expected.items():
            r.cases += 1
            g = got.get(node_id) if isinstance(got, dict) else None
            if g != level:
                r.miss(line, {"graph": row["name"], "node": node_id}, level, g, limit)
    if r.rows != entry["rows"]:
        raise IntegrityError(f"{entry['file']}: {r.rows} graphs, manifest says {entry['rows']}")
    if facet_rows_skipped:
        r.skipped.append(f"{facet_rows_skipped} graphs with facets (adapter: nms_supports_facets=False)")
    return r


CHECKS = {
    "crosswalk_normalize.jsonl": check_crosswalk_normalize,
    "crosswalk_translate.jsonl": check_crosswalk_translate,
    "e_axis_order.jsonl": lambda d, m, en, s, e, l: check_axis(d, m, en, s, e, l, "e", en.E, ["le", "meet"]),
    "e_axis_ceiling.jsonl": check_ceiling,
    "o_axis_order.jsonl": lambda d, m, en, s, e, l: check_axis(d, m, en, s, e, l, "o", en.O, ["le", "meet"]),
    "nms_effective.jsonl": check_nms,
}


# ---------------------------------------------------------------------------- driver

def load_sut(spec):
    if spec == "reference":
        here = os.path.dirname(os.path.abspath(__file__))
        sys.path.insert(0, here)
        import reference_models
        return reference_models.ReferenceAdapter()
    mod_spec = importlib.util.spec_from_file_location("sut_adapter", spec)
    mod = importlib.util.module_from_spec(mod_spec)
    mod_spec.loader.exec_module(mod)
    return mod.make_adapter()


def run(table_dir, sut, tables=None, pin=None, limit=20):
    """Returns (verdict, results, detail). Raises nothing: integrity failures become a verdict."""
    try:
        manifest = verify_integrity(table_dir, pin)
        en = Enums(manifest)
        entries = [t for t in manifest["tables"] if tables is None or t["file"].replace(".jsonl", "") in tables]
        if tables is not None and len(entries) != len(tables):
            raise IntegrityError(f"requested tables not in manifest: {sorted(set(tables) - {t['file'].replace('.jsonl', '') for t in entries})}")
        results = []
        for entry in entries:
            check = CHECKS.get(entry["file"])
            if check is None:
                raise IntegrityError(f"no checker for {entry['file']} (newer table format?)")
            res = check(table_dir, manifest, en, sut, entry, limit)
            if not res.skipped and res.cases != entry["cases"]:
                raise IntegrityError(f"{entry['file']}: ran {res.cases} cases, manifest says {entry['cases']}")
            results.append(res)
    except IntegrityError as e:
        return "INTEGRITY", [], str(e)
    if any(r.mismatch_count for r in results):
        return "MISMATCH", results, ""
    if any(r.skipped for r in results):
        return "UNCONFIRMED", results, ""
    return "CONFORMS", results, ""


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("table_dir")
    ap.add_argument("--sut", required=True, help="'reference' or a path to an adapter .py with make_adapter()")
    ap.add_argument("--tables", help="comma-separated subset, e.g. crosswalk_normalize,nms_effective")
    ap.add_argument("--pin", help="pinned SHA256SUMS (e.g. lattice-core conformance/EXPECTED_SHA256SUMS)")
    ap.add_argument("--max-report", type=int, default=20)
    ap.add_argument("--report", help="write a canonical JSON report here")
    a = ap.parse_args(argv)
    tables = a.tables.split(",") if a.tables else None
    verdict, results, detail = run(a.table_dir, load_sut(a.sut), tables, a.pin, a.max_report)
    for r in results:
        status = "MISMATCH" if r.mismatch_count else ("SKIPPED PARTS" if r.skipped else "ok")
        print(f"  {r.table:22s} rows {r.rows:6d}  cases {r.cases:7d}  mismatches {r.mismatch_count:6d}  {status}")
        for s in r.skipped:
            print(f"      skipped: {s}")
        for mm in r.mismatches:
            print(f"      line {mm['line']}: {canonical(mm['input'])}\n        expected {mm['expected']!r}, got {mm['got']!r}")
    if detail:
        print(f"  {detail}")
    print(f"VERDICT: {verdict}")
    if a.report:
        with open(a.report, "w", encoding="ascii") as f:
            f.write(canonical({"verdict": verdict, "detail": detail, "tables": [
                {"table": r.table, "rows": r.rows, "cases": r.cases, "mismatches": r.mismatch_count,
                 "skipped": r.skipped, "first_mismatches": r.mismatches} for r in results]}) + "\n")
    return EXIT[verdict]


if __name__ == "__main__":
    sys.exit(main())
