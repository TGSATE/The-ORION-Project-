"""Spec-derived reference adapter: exists only to prove the harness works.

Written from the stated rules (README, system notes), not translated from the Lean code, and
deliberately different where it can be: nms effective levels are computed by reachability and
cycle detection with no fuel, where the Lean model follows paths with a fuel bound. Agreement on
the corpus is therefore also empirical evidence for the open fuel-adequacy property.

This is NOT Crosswalk v0.2.0, axis_guard or nms-engine, and passing the harness here says nothing
about them. Point the harness at their adapters for that (adapter_template.py).
"""

E = ["E0", "E1", "E2", "E3", "E4A", "E4B", "E4C", "E5", "E6"]
O = ["O0", "O1", "O2", "O3", "O4"]
STAGE = {"E0": 0, "E1": 1, "E2": 2, "E3": 3, "E4A": 4, "E4B": 4, "E4C": 4, "E5": 5, "E6": 6}


def e_le(a, b):
    return a == b or STAGE[a] < STAGE[b]


def e_meet(a, b):
    if e_le(a, b):
        return a
    if e_le(b, a):
        return b
    return "E3"  # two distinct facets: greatest common lower bound


def e_ceiling(readings):
    """The maximal readings: an aggregation, never a join (no rung is synthesized)."""
    distinct = list(dict.fromkeys(readings))
    return [x for x in distinct if not any(e_le(x, y) and x != y for y in distinct)]


def o_le(a, b):
    return O.index(a) <= O.index(b)


def o_meet(a, b):
    return a if o_le(a, b) else b


def split(reading):
    e, o = reading.split("/")
    return e, o


def meet_reading(x, y):
    (ex, ox), (ey, oy) = split(x), split(y)
    return f"{e_meet(ex, ey)}/{o_meet(ox, oy)}"


def cap_e(e):
    return f"{e}/O4"


def cap_o(o):
    return f"E6/{o}"


ZERO = "E0/O0"


def crosswalk_caps(c):
    """The caps that apply to a claim, in kernel order."""
    w = c["witness"]
    caps = []
    if c["performative"]:
        caps.append(ZERO)                                        # performative token
    if c["axis_kind_mismatch"]:
        caps.append(cap_o("O0"))                                 # AXIS_KIND_MISMATCH
    if not (c["receipt_digest"] and c["witness_binding"]):
        caps.append(cap_e("E2"))                                 # G-01 receipt rule
    if w in ("none", "self"):
        caps.append(cap_e("E2"))                                 # G-02
    if w == "same_org":
        caps.append(cap_e("E3"))
    if w == "independent" and not (c["signed"] and c["external_identity"]):
        caps.append(cap_e("E3"))                                 # assumption A2
    if c["simulation"]:
        caps.append(cap_e("E2"))                                 # G-03
    if c["track"] == "mythos":
        caps.append(cap_e("E0"))                                 # G-05 mythos quarantine
    if not c["ratified"]:
        caps.append(cap_o("O0"))                                 # G-07 authority firewall
    if c["track"] in ("research", "mythos"):
        caps.append(cap_o("O0"))                                 # G-08 track separation
    if not c["artifact_digest"]:
        caps.append(cap_e("E1"))                                 # G-09 claim binding
    if c["hand_extracted"]:
        caps.append(cap_e("E2"))                                 # G-10
    return caps


class ReferenceAdapter:
    nms_supports_facets = True

    def crosswalk_normalize(self, claim, reading):
        for cap in crosswalk_caps(claim):
            reading = meet_reading(reading, cap)
        return reading

    def crosswalk_translate(self, label, denotation):
        return meet_reading(label, denotation)

    def e_le(self, a, b):
        return e_le(a, b)

    def e_meet(self, a, b):
        return e_meet(a, b)

    def e_ceiling(self, readings):
        return e_ceiling(readings)

    def o_le(self, a, b):
        return o_le(a, b)

    def o_meet(self, a, b):
        return o_meet(a, b)

    def nms_effective(self, graph):
        """E0 if the node reaches a missing node or a cycle; otherwise the meet of every
        assertion it reaches (itself included)."""
        nodes = {n["id"]: n for n in graph}
        out = {}
        for v in nodes:
            out[v] = self._effective(nodes, v)
        return out

    def _effective(self, nodes, v):
        WHITE, GREY, BLACK = 0, 1, 2
        color, level, bad = {}, "E6", False

        def visit(u):
            nonlocal level, bad
            if u not in nodes:
                bad = True
                return
            if color.get(u) == GREY:
                bad = True  # back edge: a cycle is reachable
                return
            if color.get(u) == BLACK:
                return
            color[u] = GREY
            level = e_meet(level, nodes[u]["asserted"])
            for d in nodes[u]["deps"]:
                visit(d)
            color[u] = BLACK

        visit(v)
        return "E0" if bad else level


def make_adapter():
    return ReferenceAdapter()
