#!/usr/bin/env python3
"""Proves the conformance harness can fail.

    python3 conformance/test_harness.py [TABLE_DIR]      (default conformance/out)

1. Baseline: the spec-derived reference adapter CONFORMS on every case (and the case counts are the
   manifest's, so the run is not vacuous).
2. Injected bugs: each mutated adapter must get MISMATCH, in the table the bug lives in.
3. Integrity attacks on the tables: each must get INTEGRITY, before the SUT is trusted.
4. Skips: a missing adapter method or an unsupported row class gives UNCONFIRMED, never CONFORMS.
"""
import hashlib
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import harness  # noqa: E402
import reference_models as ref  # noqa: E402

TABLES = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(HERE, "out")
PIN = os.path.join(HERE, "EXPECTED_SHA256SUMS")


def run(sut, tables=None, table_dir=TABLES, pin=PIN):
    return harness.run(table_dir, sut, tables=tables, pin=pin, limit=5)


# ----------------------------------------------------------------- injected bugs

class SameOrgUncapped(ref.ReferenceAdapter):
    """Forgets G-02's same-org cap at E3."""
    def crosswalk_normalize(self, claim, reading):
        if claim["witness"] == "same_org":
            claim = dict(claim, witness="independent")
        return super().crosswalk_normalize(claim, reading)


class ReceiptRuleOr(ref.ReferenceAdapter):
    """G-01 with OR instead of AND: a receipt digest alone admits E3+."""
    def crosswalk_normalize(self, claim, reading):
        if claim["receipt_digest"] or claim["witness_binding"]:
            claim = dict(claim, receipt_digest=True, witness_binding=True)
        return super().crosswalk_normalize(claim, reading)


class AuthorityFromEvidence(ref.ReferenceAdapter):
    """Skips the authority firewall when the evidence is high (authority inferred from evidence)."""
    def crosswalk_normalize(self, claim, reading):
        if ref.STAGE[reading.split("/")[0]] >= 4:
            claim = dict(claim, ratified=True)
        return super().crosswalk_normalize(claim, reading)


class CrashOnPerformative(ref.ReferenceAdapter):
    def crosswalk_normalize(self, claim, reading):
        if claim["performative"]:
            raise ValueError("unhandled performative token")
        return super().crosswalk_normalize(claim, reading)


class TranslateLabelOnly(ref.ReferenceAdapter):
    """Ignores the denotation reading: LABEL_INFLATION goes uncaught."""
    def crosswalk_translate(self, label, denotation):
        return label


class FacetMeetByListPosition(ref.ReferenceAdapter):
    """FLOOR of two facets by list position (the bug axis_guard v0.2.0 fixed), not by meet."""
    def e_meet(self, a, b):
        if ref.STAGE[a] == ref.STAGE[b] == 4 and a != b:
            return min(a, b)
        return super().e_meet(a, b)


class CeilingByJoin(ref.ReferenceAdapter):
    """Portfolio ceiling as a join: E4-A and E4-B promote to a synthesized E5."""
    def e_ceiling(self, readings):
        top = super().e_ceiling(readings)
        facets = [x for x in top if ref.STAGE[x] == 4]
        return ["E5"] + [x for x in top if ref.STAGE[x] != 4] if len(facets) > 1 else top


class CeilingByListPosition(ref.ReferenceAdapter):
    """Portfolio ceiling as the single highest reading by list position."""
    def e_ceiling(self, readings):
        return [max(readings, key=ref.E.index)]


class ResearchTrackIgnored(ref.ReferenceAdapter):
    """G-08 forgets the research track: research claims keep their authority."""
    def crosswalk_normalize(self, claim, reading):
        if claim["track"] == "research":
            claim = dict(claim, track="logos")
        return super().crosswalk_normalize(claim, reading)


class NmsSkipsMissingDeps(ref.ReferenceAdapter):
    """Drops dependencies on missing nodes instead of failing closed."""
    def nms_effective(self, graph):
        ids = {n["id"] for n in graph}
        return super().nms_effective([dict(n, deps=[d for d in n["deps"] if d in ids]) for n in graph])


class NmsIgnoresSelfLoops(ref.ReferenceAdapter):
    """Treats a node depending on itself as no dependency, not as a cycle."""
    def nms_effective(self, graph):
        return super().nms_effective([dict(n, deps=[d for d in n["deps"] if d != n["id"]]) for n in graph])


BUGS = [
    (SameOrgUncapped, "crosswalk_normalize"),
    (ReceiptRuleOr, "crosswalk_normalize"),
    (AuthorityFromEvidence, "crosswalk_normalize"),
    (CrashOnPerformative, "crosswalk_normalize"),
    (TranslateLabelOnly, "crosswalk_translate"),
    (FacetMeetByListPosition, "e_axis_order"),
    (CeilingByJoin, "e_axis_ceiling"),
    (CeilingByListPosition, "e_axis_ceiling"),
    (ResearchTrackIgnored, "crosswalk_normalize"),
    (NmsSkipsMissingDeps, "nms_effective"),
    (NmsIgnoresSelfLoops, "nms_effective"),
]


# ----------------------------------------------------------------- table tampering helpers

_TEMP_DIRS = []


def tampered_copy(edit, resum=True, file="crosswalk_normalize.jsonl"):
    """Copy the tables, apply edit(lines) -> lines to one file, optionally regenerate SHA256SUMS."""
    d = tempfile.mkdtemp(prefix="lct-")
    _TEMP_DIRS.append(d)
    for name in os.listdir(TABLES):
        shutil.copy(os.path.join(TABLES, name), d)
    path = os.path.join(d, file)
    with open(path, "rb") as f:
        lines = f.read().split(b"\n")[:-1]
    with open(path, "wb") as f:
        f.write(b"".join(l + b"\n" for l in edit(lines)))
    if resum:
        with open(os.path.join(d, "SHA256SUMS"), "w") as f:
            for name in sorted(n for n in os.listdir(d) if n != "SHA256SUMS"):
                with open(os.path.join(d, name), "rb") as g:
                    f.write(f"{hashlib.sha256(g.read()).hexdigest()}  {name}\n")
    return d


def flip_out_value(lines):
    row = json.loads(lines[100])
    key = "E6/O4"
    row["out"][key] = "E5/O4" if row["out"][key] != "E5/O4" else "E4A/O4"
    lines[100] = harness.canonical(row).encode()
    return lines


class HarnessCanFail(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not os.path.exists(os.path.join(TABLES, "SHA256SUMS")):
            raise SystemExit(f"no tables at {TABLES}: run scripts/export_conformance.sh first")

    @classmethod
    def tearDownClass(cls):
        for d in _TEMP_DIRS:
            shutil.rmtree(d, ignore_errors=True)

    # 1. baseline -------------------------------------------------------
    def test_reference_conforms_on_every_case(self):
        verdict, results, detail = run(ref.ReferenceAdapter())
        self.assertEqual(verdict, "CONFORMS", detail)
        cases = {r.table: r.cases for r in results}
        self.assertEqual(cases, {"crosswalk_normalize": 552960, "crosswalk_translate": 2025,
                                 "e_axis_order": 162, "e_axis_ceiling": 511, "o_axis_order": 50,
                                 "nms_effective": 55119})

    # 2. injected bugs ----------------------------------------------------
    def test_each_injected_bug_is_caught_where_it_lives(self):
        for bug, table in BUGS:
            with self.subTest(bug=bug.__name__):
                verdict, results, detail = run(bug())
                self.assertEqual(verdict, "MISMATCH", f"{bug.__name__}: {verdict} {detail}")
                hit = {r.table for r in results if r.mismatch_count}
                self.assertEqual(hit, {table}, f"{bug.__name__} caught in {hit}")

    # 3. integrity attacks ------------------------------------------------
    def assertIntegrity(self, table_dir, fragment, pin=None):
        verdict, _, detail = run(ref.ReferenceAdapter(), table_dir=table_dir, pin=pin)
        self.assertEqual(verdict, "INTEGRITY", detail)
        self.assertIn(fragment, detail)

    def test_byte_flip_without_resum(self):
        d = tampered_copy(lambda ls: ls[:5] + [ls[5].replace(b'"E2/O0"', b'"E3/O0"', 1)] + ls[6:], resum=False)
        self.assertIntegrity(d, "does not match SHA256SUMS")

    def test_missing_sums(self):
        d = tampered_copy(lambda ls: ls)
        os.remove(os.path.join(d, "SHA256SUMS"))
        self.assertIntegrity(d, "SHA256SUMS missing")

    def test_truncated_table_resummed(self):
        self.assertIntegrity(tampered_copy(lambda ls: ls[:-1]), "the claim space has 12288")

    def test_duplicate_row_resummed(self):
        self.assertIntegrity(tampered_copy(lambda ls: ls[:-1] + [ls[0]]), "duplicate claim")

    def test_noncanonical_line_resummed(self):
        self.assertIntegrity(tampered_copy(lambda ls: [ls[0].replace(b",", b", ", 1)] + ls[1:]), "not canonical")

    def test_removed_rung_E7_resummed(self):
        # E7 was removed from the canonical axis; a table that reintroduces it is refused
        d = tampered_copy(lambda ls: [ls[0].replace(b'"E0/O0":"E0/O0"', b'"E0/O0":"E7/O0"', 1)] + ls[1:])
        self.assertIntegrity(d, "unknown value 'E7/O0'")

    def test_wrong_oracle_value_resummed_is_caught_only_by_pin(self):
        d = tampered_copy(flip_out_value)
        # Without the pin, a re-signed table with a wrong expected value looks valid,
        # and the honest reference adapter is reported as a MISMATCH:
        verdict, _, _ = run(ref.ReferenceAdapter(), table_dir=d, pin=None)
        self.assertEqual(verdict, "MISMATCH")
        # With the pinned digests from lattice-core, the edited oracle is refused outright:
        self.assertIntegrity(d, "digests differ from the pinned set", pin=PIN)

    # 4. skips are not passes ---------------------------------------------
    def test_missing_method_is_unconfirmed(self):
        class NoCeiling(ref.ReferenceAdapter):
            e_ceiling = None
        verdict, results, _ = run(NoCeiling(), tables=["e_axis_ceiling"])
        self.assertEqual(verdict, "UNCONFIRMED")

    def test_linear_only_nms_is_unconfirmed(self):
        class LinearOnly(ref.ReferenceAdapter):
            nms_supports_facets = False
        verdict, results, _ = run(LinearOnly(), tables=["nms_effective"])
        self.assertEqual(verdict, "UNCONFIRMED")
        self.assertTrue(any("graphs with facets" in s for r in results for s in r.skipped))


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0], "-v"])
