"""Adapter template: point the conformance harness at the real systems.

    python3 harness.py TABLE_DIR --sut adapter.py --pin EXPECTED_SHA256SUMS

Copy this file next to the system under test, fill in the bodies, delete what doesn't apply.
A method you leave out makes that table UNCONFIRMED (not a pass).

The table encoding, fixed by the export:
  evidence     "E0" "E1" "E2" "E3" "E4A" "E4B" "E4C" "E5" "E6"
  authority    "O0" "O1" "O2" "O3" "O4"
  reading      "<evidence>/<authority>", e.g. "E4A/O2"
  claim        dict with booleans artifact_digest, axis_kind_mismatch, external_identity,
               hand_extracted, performative, ratified, receipt_digest, signed, simulation,
               witness_binding; witness in {"none","self","same_org","independent"};
               track in {"logos","research","mythos"}
  nms graph    list of {"id": int, "asserted": evidence, "deps": [int, ...]}; a dep id with no node
               is a missing dependency; a node listing itself is a self-loop

Mapping notes (see README "Modeling assumptions"; a mismatch can be a code bug OR a model gap):
  * A6: Crosswalk v0.2.0 splits standing / permission / assurance (S0-S4 / O0-O4 / A0-A5). The
    tables have one authority column, O0-O4. Map it to the axis the authority firewall (G-07)
    governs, and write down which one you chose.
  * A2/A3/A5 were checked against wn-crosswalk v0.2.0 in conformance run 1 (format v2 models G-08).
  * The portfolio ceiling is an aggregation, not a join: e_ceiling returns the maximal readings.
    A join that turns E4-A + E4-B into E5 is a mismatch by design (ruling 2026-10-04).
  * nms-engine levels like "E3[self]": project to the bare evidence level the engine compares
    on, and say so. If the engine has no facets, set nms_supports_facets = False (facet rows are
    then skipped and the verdict is UNCONFIRMED until they are covered).
"""


class Adapter:
    nms_supports_facets = True

    # ---- Crosswalk v0.2.0 -------------------------------------------------------------
    def crosswalk_normalize(self, claim: dict, reading: str) -> str:
        # e.g. build the v0.2.0 claim record from `claim`, run the kernel on `reading`,
        # and return the resulting "<evidence>/<authority>".
        raise NotImplementedError

    def crosswalk_translate(self, label: str, denotation: str) -> str:
        # the min() translation rule: label reading vs denotation reading
        raise NotImplementedError

    # ---- axis_guard v0.2.0 --------------------------------------------------------------
    def e_le(self, a: str, b: str) -> bool:
        raise NotImplementedError

    def e_meet(self, a: str, b: str) -> str:      # FLOOR
        raise NotImplementedError

    def e_ceiling(self, readings: list) -> list:  # portfolio ceiling: the maximal readings
        raise NotImplementedError

    def o_le(self, a: str, b: str) -> bool:
        raise NotImplementedError

    def o_meet(self, a: str, b: str) -> str:
        raise NotImplementedError

    # ---- nms-engine v0.1.0 --------------------------------------------------------------
    def nms_effective(self, graph: list) -> dict:
        # build the engine's claim DAG from `graph`, run it, return {node_id: evidence}
        raise NotImplementedError


def make_adapter():
    return Adapter()
