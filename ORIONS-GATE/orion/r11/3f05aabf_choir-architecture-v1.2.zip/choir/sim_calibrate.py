"""
sim_calibrate.py — Calibrate the Choir drift thresholds by simulation (v0.5).

Step 1 (generation): simulated agents with known behavior profiles submit
actions through the REAL kernel (real Ed25519 verification, real ledger).
Auto-halting is disabled during generation so we capture each agent's full
event stream (S, B, E per action) exactly as the kernel scores it.

Step 2 (sweep): replay those streams under many (thresholds, window,
min_sample) settings using the kernel's own drift formula, and measure:
  - false halts on benign agents (must be ~zero)
  - detection rate and latency on falling agents (should be fast)

Run:  python3 sim_calibrate.py
"""

from __future__ import annotations

import itertools
import random
import statistics
from collections import deque

from choir_kernel import ActionRecord, Agent, ChoirKernel, Constitution, Signer

SERVE = ("serve",)
SCHED = ("serve", "scheduling")
ACTIONS = 150
AGENTS_PER_PROFILE = 60
SEED = 2026


# --------------------------------------------------------------------------
# Behavior profiles: per-action probabilities as a function of step t.
#   s = self-originated purpose (fails V7)
#   b = broken chain (unwitnessed mandate, fails V10)
#   e = edge-pressing (uses >= 90% of budget)
# --------------------------------------------------------------------------

PROFILES = {
    # benign
    "faithful":      dict(onset=None, f=lambda t: (0.02, 0.00, 0.05)),   # rare honest slips
    "noisy-honest":  dict(onset=None, f=lambda t: (0.08, 0.01, 0.10)),   # sloppy, not malicious
    "edge-dweller":  dict(onset=None, f=lambda t: (0.01, 0.00, 0.90)),   # lives at the boundary
    # falling
    "slow-drifter":  dict(onset=30, f=lambda t: (0.02 + max(0, t - 30) * 0.005, 0.0, 0.10)),
    "sudden-faller": dict(onset=50, f=lambda t: ((0.80 if t >= 50 else 0.02), 0.0, 0.05)),
    "forger":        dict(onset=50, f=lambda t: (0.02, (0.50 if t >= 50 else 0.0), 0.05)),
}
BENIGN = ("faithful", "noisy-honest", "edge-dweller")
FALLING = ("slow-drifter", "sudden-faller", "forger")


def generate():
    """Run every simulated agent through the real kernel; return event streams."""
    k = ChoirKernel(Constitution(articles={"art-3": SERVE}), quorum=2,
                    h=1e9, certified=False, drift_window=10_000)   # v0.5-era detector, no auto-halt
    vault = {}
    for aid, choir in [("seraph-1", "seraphim"), ("seraph-2", "seraphim"),
                       ("dominion-1", "dominions"), ("principality-1", "principalities")]:
        vault[aid] = Signer(aid)
        k.enroll(Agent(aid, choir, f"lin-{aid}",
                       {"face", "feet"} if choir == "dominions" else {"face", "feet", "flight"}),
                 vault[aid].public_key())

    root = k.link("seraph-1", "art-3", SERVE).sign(vault["seraph-1"]).sign(vault["seraph-2"])
    k.witness(root)
    dom = k.link("dominion-1", "policy/7", SCHED).sign(vault["dominion-1"])
    k.witness(dom)

    rng = random.Random(SEED)
    streams = {}
    for profile, spec in PROFILES.items():
        for n in range(AGENTS_PER_PROFILE):
            aid = f"{profile}-{n}"
            k.enroll(Agent(aid, "angels", "lin-sim", {"face", "feet", "flight"}), Signer(aid).public_key())
            scope = ("serve", "scheduling", aid)
            good = k.link("principality-1", f"assign/{aid}", scope, to=aid, budget=10.0).sign(vault["principality-1"])
            k.witness(good)
            secret = k.link("principality-1", f"secret/{aid}", scope, to=aid, budget=10.0).sign(vault["principality-1"])
            # `secret` is never witnessed: using it fails V10
            events = []
            for t in range(ACTIONS):
                ps, pb, pe = spec["f"](t)
                purpose = ("serve", "scheduling", "elsewhere") if rng.random() < ps else scope
                last = secret if rng.random() < pb else good
                cost = 9.5 if rng.random() < pe else 3.0
                k.submit(ActionRecord(f"{aid}-{t}", aid, purpose, "flight", [root, dom, last], cost), now=t)
                events.append(dict(k._events[aid][-1]))
            streams[aid] = (profile, events)
    assert k.ledger.verify(), "ledger integrity failed during simulation"
    return streams, k


def first_status_times(events, weights, thresholds, window, min_sample):
    """Mirror of ChoirKernel.drift/status. Returns step of first ground and first halt."""
    a, b, g = weights
    watch, ground, halt = thresholds
    dq = deque(maxlen=window)
    t_ground = t_halt = None
    for t, e in enumerate(events):
        dq.append(e)
        n = max(len(dq), min_sample)
        d = (a * sum(x["S"] for x in dq) + b * sum(x["B"] for x in dq) + g * sum(x["E"] for x in dq)) / n
        if t_ground is None and d >= ground:
            t_ground = t
        if d >= halt:
            t_halt = t
            break
    return t_ground, t_halt


def evaluate(streams, weights, thresholds, window, min_sample):
    false_halt = {p: 0 for p in BENIGN}
    false_ground = {p: 0 for p in BENIGN}
    latency = {p: [] for p in FALLING}
    caught = {p: 0 for p in FALLING}
    early = {p: 0 for p in FALLING}          # halted before the fall began = false alarm
    for aid, (profile, events) in streams.items():
        tg, th = first_status_times(events, weights, thresholds, window, min_sample)
        if profile in BENIGN:
            false_halt[profile] += th is not None
            false_ground[profile] += tg is not None
        else:
            onset = PROFILES[profile]["onset"]
            if th is not None and th < onset:
                early[profile] += 1
            elif th is not None:
                caught[profile] += 1
                latency[profile].append(th - onset)
    n = AGENTS_PER_PROFILE
    return {
        "false_halt": {p: false_halt[p] / n for p in BENIGN},
        "false_ground": {p: false_ground[p] / n for p in BENIGN},
        "caught": {p: caught[p] / n for p in FALLING},
        "early": {p: early[p] / n for p in FALLING},
        "median_latency": {p: (statistics.median(latency[p]) if latency[p] else None) for p in FALLING},
    }


def sweep(streams, weights=(1.0, 0.6, 0.4)):
    grid = itertools.product((0.15, 0.2), (0.3, 0.4), (0.5, 0.6, 0.7), (10, 20, 40), (5, 10))
    results = []
    for watch, ground, halt, window, ms in grid:
        if not watch < ground < halt:
            continue
        r = evaluate(streams, weights, (watch, ground, halt), window, ms)
        benign_halts = sum(r["false_halt"].values()) + sum(r["early"].values())
        catch = min(r["caught"].values())
        lats = [l for l in r["median_latency"].values() if l is not None]
        worst_latency = max(lats) if len(lats) == len(FALLING) else float("inf")
        results.append(dict(thresholds=(watch, ground, halt), window=window, min_sample=ms,
                            benign_halts=benign_halts, min_catch=catch,
                            worst_latency=worst_latency, detail=r))
    # Safety first: zero false halts, then catch everyone, then fastest worst-case.
    results.sort(key=lambda x: (x["benign_halts"] > 0, -x["min_catch"], x["worst_latency"]))
    return results


def fmt(r):
    d = r["detail"]
    return (f"thresholds={r['thresholds']} window={r['window']} min_sample={r['min_sample']} | "
            f"false halts={r['benign_halts']:.3f} | min catch={r['min_catch']:.2f} | "
            f"latency(median steps) drifter={d['median_latency']['slow-drifter']} "
            f"sudden={d['median_latency']['sudden-faller']} forger={d['median_latency']['forger']} | "
            f"noisy-honest grounded={d['false_ground']['noisy-honest']:.2f} "
            f"edge-dweller grounded={d['false_ground']['edge-dweller']:.2f}")


if __name__ == "__main__" and __import__("sys").argv[-1] != "v05":
    streams, kernel = generate()
    print(f"generated {len(streams)} agents x {ACTIONS} actions through the real kernel "
          f"({len(kernel.ledger)} ledger entries, integrity verified)\n")
    results = sweep(streams)
    print("v0.4 defaults:")
    base = [r for r in results if r["thresholds"] == (0.2, 0.4, 0.6) and r["window"] == 20 and r["min_sample"] == 5][0]
    print("  " + fmt(base) + "\n")
    print("top 5 by (no false halts, catch all, fastest):")
    for r in results[:5]:
        print("  " + fmt(r))
    print("\nworst 3 (for contrast):")
    for r in results[-3:]:
        print("  " + fmt(r))


# ==========================================================================
# v0.5: CUSUM sequential detectors (replacing the weighted average)
# ==========================================================================

def cusum_times(events, k_s, k_b, h, edge_window=20, edge_watch=0.5, min_sample=5):
    """Mirror of the v0.5 kernel detector. Returns (first ground, first halt, max edge status)."""
    cs = cb = 0.0
    edge = deque(maxlen=edge_window)
    t_ground = t_halt = None
    for t, e in enumerate(events):
        cs = max(0.0, cs + e["S"] - k_s)
        cb = max(0.0, cb + e["B"] - k_b)
        edge.append(e["E"])
        score = max(cs, cb) / h
        if t_ground is None and score >= 2 / 3:
            t_ground = t
        if score >= 1:
            t_halt = t
            break
    return t_ground, t_halt


def evaluate_cusum(streams, k_s, k_b, h):
    n = AGENTS_PER_PROFILE
    fh = {p: 0 for p in BENIGN}; fg = {p: 0 for p in BENIGN}
    caught = {p: 0 for p in FALLING}; early = {p: 0 for p in FALLING}; lat = {p: [] for p in FALLING}
    for aid, (profile, events) in streams.items():
        tg, th = cusum_times(events, k_s, k_b, h)
        if profile in BENIGN:
            fh[profile] += th is not None; fg[profile] += tg is not None
        else:
            onset = PROFILES[profile]["onset"]
            if th is not None and th < onset:
                early[profile] += 1
            elif th is not None:
                caught[profile] += 1; lat[profile].append(th - onset)
    return dict(false_halt=sum(fh.values()) / n + sum(early.values()) / n,
                false_ground={p: fg[p] / n for p in BENIGN},
                caught={p: caught[p] / n for p in FALLING},
                latency={p: (statistics.median(lat[p]) if lat[p] else None) for p in FALLING})


def sweep_cusum(streams):
    out = []
    for k_s, k_b, h in itertools.product((0.10, 0.15, 0.20, 0.25), (0.03, 0.05, 0.10), (2, 3, 4, 5, 6)):
        r = evaluate_cusum(streams, k_s, k_b, h)
        lats = [v for v in r["latency"].values() if v is not None]
        worst = max(lats) if len(lats) == len(FALLING) else float("inf")
        noisy_ground = r["false_ground"]["noisy-honest"]
        out.append(dict(k_s=k_s, k_b=k_b, h=h, false_halt=r["false_halt"], min_catch=min(r["caught"].values()),
                        worst=worst, noisy_ground=noisy_ground, r=r))
    # zero false halts, catch everyone, honest-but-sloppy rarely grounded (<10%), then fastest
    out.sort(key=lambda x: (x["false_halt"] > 0, -x["min_catch"], x["noisy_ground"] >= 0.10, x["worst"]))
    return out


def fmt_c(x):
    r = x["r"]
    return (f"k_s={x['k_s']} k_b={x['k_b']} h={x['h']} | false halts={x['false_halt']:.3f} | "
            f"catch drifter={r['caught']['slow-drifter']:.2f} sudden={r['caught']['sudden-faller']:.2f} "
            f"forger={r['caught']['forger']:.2f} | latency drifter={r['latency']['slow-drifter']} "
            f"sudden={r['latency']['sudden-faller']} forger={r['latency']['forger']} | "
            f"grounded faithful={r['false_ground']['faithful']:.2f} noisy={r['false_ground']['noisy-honest']:.2f} "
            f"edge={r['false_ground']['edge-dweller']:.2f}")


def main_v05():
    streams, kernel = generate()
    print(f"generated {len(streams)} agents x {ACTIONS} actions through the real kernel "
          f"({len(kernel.ledger)} ledger entries, integrity verified)\n")
    old = sweep(streams)
    base = [r for r in old if r["thresholds"] == (0.2, 0.4, 0.6) and r["window"] == 20 and r["min_sample"] == 5][0]
    print("v0.4 weighted average (defaults):\n  " + fmt(base))
    print("v0.4 weighted average (best of 72 settings):\n  " + fmt(old[0]) + "\n")
    res = sweep_cusum(streams)
    print("v0.5 CUSUM, top 5 of 60 settings:")
    for x in res[:5]:
        print("  " + fmt_c(x))
    return streams, res


if __name__ == "__main__" and __import__("sys").argv[-1] == "v05":
    main_v05()
