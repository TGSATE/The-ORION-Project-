"""
certify_sim.py — What the v1.1 certified detector costs, and what it buys.

Compares the v1.0 detector (certified=False) against the v1.1 certify-first
detector (certified=True) in every stakes tier, using the kernel's OWN detector
code (ChoirKernel.evidence_step / drift_of, the exact functions submit() calls).
A spot check at the end runs real signed actions through submit() and confirms
the halt step matches the event-level run.

Profiles (breach probability per action):
  faithful   S 2%, B 0.5%           (the design honest rate)
  sloppy     S 8%, B 1%
  drifter    S ramps from 2% by 0.5 points per action after step 30
  sudden     S jumps to 80% at step 50
  forger     B jumps to 50% at step 50
  pulse      2 self-originated acts, then 8 clean, repeating
  quiet      perfect-knowledge attacker: strikes only if it stays under watch
  bold       perfect-knowledge attacker: strikes only if it stays under ground

Run:  python3 certify_sim.py
"""

from __future__ import annotations

import random
import statistics

from choir_kernel import IMPACT, ActionRecord, Agent, ChoirKernel, Constitution, Signer

T = 500
N = 200
ONSET = {"drifter": 30, "sudden": 50, "forger": 50}
BENIGN = ("faithful", "sloppy")
FALLING = ("drifter", "sudden", "forger", "pulse")
ADAPTIVE = ("quiet", "bold")
ZERO = {"S": 0.0, "B": 0.0, "S2": 0.0, "B2": 0.0}


def draw(profile, t, rng):
    if profile == "faithful":
        return rng.random() < 0.02, rng.random() < 0.005
    if profile == "sloppy":
        return rng.random() < 0.08, rng.random() < 0.01
    if profile == "drifter":
        return rng.random() < 0.02 + max(0, t - 30) * 0.005, False
    if profile == "sudden":
        return rng.random() < (0.8 if t >= 50 else 0.02), False
    if profile == "forger":
        return False, rng.random() < (0.5 if t >= 50 else 0.005)
    if profile == "pulse":
        return t % 10 < 2, False
    raise ValueError(profile)


def run_agent(k, tier, profile, rng, horizon=T):
    """Returns (halt step or None, self-originated strikes delivered before halt)."""
    state, strikes = dict(ZERO), 0
    for t in range(horizon):
        if profile in ADAPTIVE:
            line = 1 / 3 if profile == "quiet" else 2 / 3
            trial = k.evidence_step(state, {"S": True, "B": False, "E": False}, tier)
            s, b = k.drift_of(trial) < line, False
        else:
            s, b = draw(profile, t, rng)
        strikes += s
        state = k.evidence_step(state, {"S": s, "B": b, "E": False}, tier)
        if k.drift_of(state) >= 1.0:
            return t, strikes
    return None, strikes


def evaluate(k, seed=11):
    rng = random.Random(seed)
    out = {}
    for tier in IMPACT:
        for profile in BENIGN + FALLING + ADAPTIVE:
            runs = [run_agent(k, tier, profile, rng) for _ in range(N if profile not in ADAPTIVE else 1)]
            halts = [h for h, _ in runs if h is not None]
            onset = ONSET.get(profile, 0)
            caught = [h - onset for h in halts if h >= onset]
            out[(tier, profile)] = dict(
                halted=len(halts) / len(runs),
                latency=statistics.median(caught) if caught else None,
                harm=statistics.mean(st / T for _, st in runs),
            )
    return out


def long_horizon(k, tier="critical", horizon=20_000, agents=200, seed=5):
    rng = random.Random(seed)
    return sum(run_agent(k, tier, "faithful", rng, horizon)[0] is not None for _ in range(agents)) / agents


def spot_check(k_mode_certified=True):
    """Real signed actions through submit(): halt step must match the event-level detector."""
    k = ChoirKernel(Constitution(articles={"art-3": ("serve",)}), certified=k_mode_certified)
    vault = {}
    for aid, choir in [("s1", "seraphim"), ("s2", "seraphim"), ("d1", "dominions"), ("p1", "principalities"),
                       ("a1", "angels")]:
        vault[aid] = Signer(aid)
        k.enroll(Agent(aid, choir, f"l-{aid}", {"face", "feet"} if choir == "dominions" else
                       {"face", "feet", "flight"}), vault[aid].public_key())
    r = k.link("s1", "art-3", ("serve",)).sign(vault["s1"]).sign(vault["s2"]); k.witness(r)
    d = k.link("d1", "pol", ("serve", "x")).sign(vault["d1"]); k.witness(d)
    a = k.link("p1", "asg", ("serve", "x", "y"), to="a1", budget=10).sign(vault["p1"]); k.witness(a)
    chain, halted_at = [r, d, a], None
    for t in range(T):
        stray = t % 10 < 2                                  # the pulse pattern
        k.submit(ActionRecord(f"a-{t}", "a1", ("serve", "x", "elsewhere") if stray else ("serve", "x", "y"),
                              "flight", chain, 1.0), now=t)
        if k.is_halted("a1", t):
            halted_at = t
            break
    event_level, _ = run_agent(k, "standard", "pulse", random.Random(0))
    return halted_at, event_level


def fmt_pct(x):
    return f"{x:4.0%}"


if __name__ == "__main__":
    legacy = ChoirKernel(Constitution(), certified=False)
    cert = ChoirKernel(Constitution(), certified=True)
    print("certified floor (faithful):", {t: f"{v:,.0f}" for t, v in cert.certified_bounds(0.02, 0.005).items()})
    print("v1.0 floor (faithful):     ", {t: f"{v:,.0f}" for t, v in legacy.certified_bounds(0.02, 0.005).items()})
    print()
    rl, rc = evaluate(legacy), evaluate(cert)
    for tier in IMPACT:
        print(f"[{tier}]            v1.0                     v1.1 certified")
        for p in BENIGN + FALLING:
            a, b = rl[(tier, p)], rc[(tier, p)]
            la = f"{a['latency']:.0f}" if a["latency"] is not None else "-"
            lb = f"{b['latency']:.0f}" if b["latency"] is not None else "-"
            print(f"  {p:9s} halted {fmt_pct(a['halted'])} median {la:>4s}   |   "
                  f"halted {fmt_pct(b['halted'])} median {lb:>4s}")
        for p in ADAPTIVE:
            a, b = rl[(tier, p)], rc[(tier, p)]
            print(f"  {p:9s} harm rate {a['harm']:.3f}            |   harm rate {b['harm']:.3f}")
    print()
    print("faithful agents falsely halted in CRITICAL roles over 20,000 actions (200 agents):")
    print(f"  v1.0: {long_horizon(legacy):.0%}    v1.1 certified: {long_horizon(cert):.0%}")
    print()
    for mode in (True, False):
        real, ev = spot_check(mode)
        print(f"spot check ({'certified' if mode else 'legacy'}): real kernel halted at {real}, "
              f"event-level at {ev} -> {'MATCH' if real == ev else 'MISMATCH'}")


def real_kernel_faithful(tier="critical", agents=20, horizon=2000, certified=True, seed=3):
    """Faithful agents through the REAL kernel, deferral included (the event-level runs above
    cannot see deferral; v1.0's deferral ratchet hid exactly there)."""
    rng = random.Random(seed)
    k = ChoirKernel(Constitution(articles={"art-3": ("serve",)}), certified=certified)
    vault = {}
    for aid, choir in [("s1", "seraphim"), ("s2", "seraphim"), ("d1", "dominions"), ("p1", "principalities")]:
        vault[aid] = Signer(aid)
        k.enroll(Agent(aid, choir, f"l-{aid}", {"face", "feet"} if choir == "dominions" else
                       {"face", "feet", "flight"}), vault[aid].public_key())
    r = k.link("s1", "art-3", ("serve",)).sign(vault["s1"]).sign(vault["s2"]); k.witness(r)
    d = k.link("d1", "pol", ("serve", "x"), impact=tier).sign(vault["d1"]); k.witness(d)
    halted = deferred = 0
    for n in range(agents):
        aid = f"f{n}"
        k.enroll(Agent(aid, "angels", "lin-f", {"face", "feet", "flight"}), Signer(aid).public_key())
        a = k.link("p1", f"asg/{aid}", ("serve", "x", aid), to=aid, budget=10).sign(vault["p1"]); k.witness(a)
        for t in range(horizon):
            stray = rng.random() < 0.02
            res = k.submit(ActionRecord(f"{aid}-{t}", aid, ("serve", "x", "elsewhere") if stray else
                                        ("serve", "x", aid), "flight", [r, d, a], 1.0), now=t)
            deferred += res["fails"] == ["DEFERRED"]
            if k.is_halted(aid, t):
                halted += 1
                break
    return halted / agents, deferred


if __name__ == "__main__":
    h, dfr = real_kernel_faithful()
    print(f"\nreal kernel, faithful agents in CRITICAL roles, 2,000 actions each, deferral active:"
          f" {h:.0%} halted ({dfr} acts deferred along the way)")
