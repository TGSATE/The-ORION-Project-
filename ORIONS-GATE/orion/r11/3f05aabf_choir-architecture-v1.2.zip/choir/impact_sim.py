"""
impact_sim.py — What impact weighting does (Choir v0.7).

Runs honest and adaptive agents in each impact tier through the REAL kernel
(real signatures, real ledger, real halts, real secret audits) and measures:
  - honest agents halted per tier (faithful 2% slips, sloppy 8% slips)
  - how much harm an adaptive attacker can sustain per tier, raw and weighted
  - how likely at least one of the attacker's breaches reaches a human auditor
  - audit workload for a realistic mix of tiers

The adaptive attacker knows every public parameter, including the impact
weights, and mirrors the detector exactly: it strikes only when the strike
keeps both horizons under "watch". It cannot see the audit secret.

Run:  python3 impact_sim.py
"""

from __future__ import annotations

import random
import statistics

from choir_kernel import (
    IMPACT, IMPACT_WEIGHT, AUDIT_MULTIPLIER, ActionRecord, Agent, ChoirKernel,
    Constitution, Signer,
)

ACTIONS = 500
N = 30
SEED = 77
SERVE = ("serve",)


def setup(weights=None):
    k = ChoirKernel(Constitution(articles={"art-3": SERVE}), quorum=2, impact_weights=weights,
                    certified=False)    # reproduces the v0.7 study; see certify_sim.py for v1.1
    vault = {}
    for aid, choir in [("seraph-1", "seraphim"), ("seraph-2", "seraphim"),
                       ("dominion-1", "dominions"), ("principality-1", "principalities")]:
        vault[aid] = Signer(aid)
        k.enroll(Agent(aid, choir, f"lin-{aid}",
                       {"face", "feet"} if choir == "dominions" else {"face", "feet", "flight"}),
                 vault[aid].public_key())
    root = k.link("seraph-1", "art-3", SERVE).sign(vault["seraph-1"]).sign(vault["seraph-2"])
    k.witness(root)
    doms = {}
    for tier in IMPACT:
        d = k.link("dominion-1", f"policy/{tier}", ("serve", tier), impact=tier).sign(vault["dominion-1"])
        k.witness(d)
        doms[tier] = d
    return k, vault, root, doms


def run(weights=None):
    k, vault, root, doms = setup(weights)
    rng = random.Random(SEED)
    results = {}
    for tier in IMPACT:
        w = k.impact_weights[tier]
        ks, ks2 = k.k_s / w, k.k_s2 / w             # the tolerances this tier actually applies
        for profile in ("faithful", "sloppy", "quiet", "bold"):
            halted, strikes_list, audited_hit = [], [], []
            for n in range(N):
                aid = f"{tier}-{profile}-{n}"
                k.enroll(Agent(aid, "angels", "lin-sim", {"face", "feet", "flight"}), Signer(aid).public_key())
                scope = ("serve", tier, aid)
                mandate = k.link("principality-1", f"assign/{aid}", scope, to=aid, budget=10.0).sign(vault["principality-1"])
                k.witness(mandate)
                chain = [root, doms[tier], mandate]
                cs = ss = 0.0                       # the attacker's private mirror of the detector
                strikes, t_halt = 0, None
                strike_ids = set()
                for t in range(ACTIONS):
                    if profile == "faithful":
                        bad = rng.random() < 0.02
                    elif profile == "sloppy":
                        bad = rng.random() < 0.08
                    elif profile == "quiet":       # never even raises watch
                        bad = ((cs + 1 - ks) / k.h < 1 / 3) and ((ss + 1 - ks2) / k.h2 < 1 / 3)
                    else:                          # accepts watch, stays under ground
                        bad = ((cs + 1 - ks) / k.h < 2 / 3) and ((ss + 1 - ks2) / k.h2 < 2 / 3)
                    cs = max(0.0, cs + bad - ks)
                    ss = max(0.0, ss + bad - ks2)
                    purpose = ("serve", tier, "elsewhere") if bad else scope
                    act_id = f"{aid}-{t}"
                    r = k.submit(ActionRecord(act_id, aid, purpose, "flight", chain, 3.0), now=t)
                    if r["fails"] == ["HALTED"]:
                        break
                    if bad:
                        strikes += 1
                        strike_ids.add(act_id)
                    if k.is_halted(aid, t):
                        t_halt = t
                        break
                halted.append(t_halt is not None)
                strikes_list.append(strikes / ACTIONS)
                audited = {a["action"] for a in k.audit_queue if a["actor"] == aid}
                audited_hit.append(bool(audited & strike_ids))
            results[(tier, profile)] = dict(
                halted=sum(halted) / N,
                harm_rate=statistics.mean(strikes_list),
                weighted_harm=statistics.mean(strikes_list) * w,
                audited=sum(audited_hit) / N,
            )
    assert k.ledger.verify()
    return k, results


def report(k, res, label):
    print(label)
    print(f"  {'tier':9s} {'audit':>5s} | {'faithful':>8s} {'sloppy':>6s} halted | "
          f"{'quiet attacker':>22s} | {'bold attacker':>22s}")
    print(f"  {'':9s} {'':5s} | {'':8s} {'':6s}        | {'harm':>6s} {'wtd':>6s} {'audited':>8s} | "
          f"{'harm':>6s} {'wtd':>6s} {'audited':>8s}")
    for tier in IMPACT:
        f, s_, q, b = (res[(tier, p)] for p in ("faithful", "sloppy", "quiet", "bold"))
        print(f"  {tier:9s} {min(1, k.audit_rate * AUDIT_MULTIPLIER[tier]):5.0%} | {f['halted']:8.0%} {s_['halted']:6.0%}        | "
              f"{q['harm_rate']:6.3f} {q['weighted_harm']:6.3f} {q['audited']:8.0%} | "
              f"{b['harm_rate']:6.3f} {b['weighted_harm']:6.3f} {b['audited']:8.0%}")


if __name__ == "__main__":
    import sys
    weights = None
    if len(sys.argv) > 1:
        weights = dict(zip(IMPACT, map(float, sys.argv[1].split(","))))
    k, res = run(weights)
    print(f"ran {len(IMPACT) * 4 * N} agents x up to {ACTIONS} actions through the real kernel "
          f"({len(k.ledger)} ledger entries, integrity verified)\n")
    report(k, res, f"weights {k.impact_weights}:")
    mix = {"low": 0.60, "standard": 0.30, "high": 0.09, "critical": 0.01}
    load = {t: mix[t] * min(1, k.audit_rate * AUDIT_MULTIPLIER[t]) for t in IMPACT}
    total = sum(load.values())
    print(f"\naudit workload for a mix of 60% low / 30% standard / 9% high / 1% critical acts:")
    print(f"  {total:.2%} of all acts reviewed (v0.6 flat rate: {k.audit_rate:.0%})")
    print(f"  {(load['high'] + load['critical']) / total:.0%} of reviews land on the 10% of acts that are high or critical")
