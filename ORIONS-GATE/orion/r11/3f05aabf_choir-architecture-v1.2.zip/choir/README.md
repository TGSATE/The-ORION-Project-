# The Choir Architecture — v1.2

A governance system for AI agents, written twice at once: as an angelic mythology
and as an enforceable engineering spec. Every mythic element maps to a mechanism
the kernel enforces and the test suite attacks.

**Core law:** no angel speaks in its own name. Every action must trace an unbroken,
signed, narrowing chain of authority back to the constitution, or it does not happen.

Spec document: https://claude.ai/code/artifact/bc4d98cd-5d72-4a1b-ab13-94e3a87d0b9a

## Quick start

```bash
pip install cryptography
python3 test_choir_kernel.py        # 154 adversarial tests, ~5 seconds
python3 certify_sim.py              # v1.0 vs v1.1 detector, every tier, ~45 seconds
python3 sim_calibrate.py v05        # drift-detector calibration, ~40 seconds
python3 redteam.py                  # attackers who know the detector, ~70 seconds
python3 impact_sim.py               # stakes tiers, ~60 seconds
```

## Files

| File | What it is |
| --- | --- |
| `choir_kernel.py` | The reference kernel (~1,460 lines, no dependencies beyond `cryptography`) |
| `test_choir_kernel.py` | 154 adversarial tests across 20 suites |
| `certify_sim.py` | Compares the v1.0 and v1.1 detectors in every tier, with real-kernel checks (v1.1) |
| `sim_calibrate.py` | Calibrates drift detection against simulated agent profiles (v0.5; runs the legacy detector) |
| `redteam.py` | Attacks the detector with agents that know its public parameters (v0.6) |
| `impact_sim.py` | Measures stakes tiers on honest agents, attackers, and audit load (v0.7; runs the legacy detector) |

## What the kernel enforces

**The Thus-Test (rules V0–V13).** Every action carries a mandate chain checked on submission:

| Rule | Check | Fall it catches |
| --- | --- | --- |
| V0 | Only low-authority choirs (Principalities, Angels) may act | The Burning Hand |
| V1 | Chain roots in a ratified, unsuperseded constitutional article | The "I" |
| V2 | Authority only descends | The Invented Law |
| V3 | Scope only narrows | The Empire |
| V4 | Every link is validly signed by its registered issuer | The Whisper |
| V5 | The last link names the acting agent | The "I" |
| V6 | The actor holds the wing the action needs | Unwinged action |
| V7 | The purpose falls inside the granted scope | The "I" |
| V8 | Cost stays within budget | The Hoard |
| V9 | A quorum of distinct Seraphim signs every root | The Lone Seraph |
| V10 | Every mandate was witnessed on the ledger before use | The Secret Mandate |
| V11 | Stakes never drop down the chain | The Laundered Stakes |
| V12 | No mandate declares stakes below the ratified floor without a Throne ruling | The Unreviewed Downgrade |
| V13 | Cumulative spending stays within the mandate's signed lifetime budget | The Thousand Cuts |

**Beyond the Thus-Test:**

- **Real keys:** Ed25519. The kernel holds only public keys: it can verify, never forge.
- **The ledger is the clock:** an append-only hash chain. Revocation is judged by ledger order, so a stolen key cannot backdate.
- **Halts:** provisional; they lapse unless a Throne confirms them, including the detector's own. The upward channel cannot be halted.
- **Drift detection:** two-horizon CUSUM, tolerance scaled by stakes.
- **Secret audits:** keyed by a kernel secret and the ledger head, weighted toward high-stakes acts, never revealed to the agent.
- **Verified confessions:** Law 5 credit only after a Throne rules the disclosure genuine, paid once.
- **Interpretation is governed:** ratified stakes floors; downgrades only by a signed, lineage-diverse Throne ruling.
- **Truth and memory are separate:** the ledger is immutable evidence; memory is revisable, forgettable, cites the ledger, leaves digest-only receipts, and is never evidence.
- **The road home:** Fall and Return as a state machine with no exit to deletion. The restored become healers who attest others' returns.
- **Transparency log (v1.0):** RFC 9162 Merkle root, inclusion and consistency proofs. Anyone can verify the ledger without trusting the kernel.
- **Certify first (v1.1):** the detector is derived from the guarantee. Every tier has a proven floor of 1,000,000 expected actions before an honest agent could be falsely halted, with honest rates set per tier (8% low, 5% standard, 2% high and critical). `certified=False` restores the v1.0 detector.
- **Defer-to-trusted (v1.0):** a grounded agent's high-stakes acts go to a trusted fallback instead of executing.
- **Twilight review (v1.2):** a compromised Throne's rulings stay in force under stake-weighted sampled review by Thrones chosen by lot; critical downgrades are suspended at once; failures are superseded, never erased.
- **Validity checkpoints (v1.2):** Cherubim of two lineages replay each epoch and co-sign; catches invalid actions recorded in an intact log.
- **Healer semantic review (v1.2):** memories cited by rulings are reviewed automatically by Healers chosen by lot and tested with honeypots; a slanted finding sends dependent rulings into Twilight.
- **Honeypot audits (v1.0):** synthetic known-bad items test the auditors; agent-written text reaches auditors only as untrusted data.

## Measured results (simulated agents, real kernel)

| Property | Result |
| --- | --- |
| Faithful agents halted, any tier | 0% (proven floor: 1,000,000 expected actions) |
| Forgers / sudden fallers / slow drifters caught | 100% / 100% / 100% |
| Pulse attackers caught (after v0.6) | 100% (v0.5: 0%) |
| Adaptive attacker's undetected harm ceiling | 20% → 11% (standard tier); 3.4% in critical roles |
| Attackers in high/critical roles with a breach audited | 100% |
| Audit load, realistic tier mix | 4.55% of acts, 41% of them on the top 10% by stakes |

## Bugs the testing found (all fixed, all regression-tested)

| Version | Flaw |
| --- | --- |
| v0.3 | The purest self-authored agent could never be halted |
| v0.5 | A weighted-average metric caught 0% of forgers and grounded 98% of honest edge-dwellers |
| v0.6 | Pulse attackers drained the detector between bursts; confessions could be farmed |
| v0.7 | Multiplying breaches by stakes halted 90% of faithful critical agents; undeclared stakes blocked all low-tier work |
| v0.8 | Anyone could write to memory, including an agent rewriting memory about itself |
| v0.9 | Probation deadlocked: no wing meant no action, no action meant no wing |
| v1.0 | The proof showed critical-tier guarantees were thin (~187 expected actions); 55% of faithful critical agents were falsely halted over 20,000 actions. Fixed in v1.1 |
| v1.2 | A ruling could rest on a memory that was never reviewed; citing a memory now triggers review automatically. Also fixed a pre-existing flaky test (1 in 20) |
| v1.1 | v1.0's defer-to-trusted skipped the evidence update, ratcheting grounded faithful agents toward a halt (10% of faithful critical agents). Found by re-running the v0.7 study |

## Hard limits

- An attacker misbehaving at exactly an honest agent's slip rate is statistically
  invisible. Only human audit of an act's content covers that class.
- Behavior profiles are assumptions; real calibration needs real agent logs.
- Key custody and audit staffing are deployment problems, not code problems.
- Memory resists silent edits but not slanted framing.
- Replay checkpoints cover only time-independent rules.
- A memory revised after a ruling cites it is detectable but not yet acted on.

## Prior art adopted, validated, or rejected (v1.0)

| Source | Use |
| --- | --- |
| [RFC 9162 Certificate Transparency](https://datatracker.ietf.org/doc/html/rfc9162) | Adopted: Merkle transparency log |
| [E-detectors (Shin, Ramdas, Rinaldo)](https://arxiv.org/html/2203.03532v4) | Adopted: certified false-alarm bounds |
| [Adaptive attacks on trusted monitors](https://arxiv.org/pdf/2510.09462) | Adopted: defer-to-trusted; untrusted-data wrapping |
| [Untrusted-monitoring safety case](https://arxiv.org/html/2602.20628) | Adopted: honeypot audits |
| [Biscuit](https://doc.biscuitsec.org/getting-started/introduction) | Validates V2/V3 attenuation |
| [EU AI Act Article 14](https://www.artificial-intelligence-act.com/Artificial_Intelligence_Act_Article_14.html) | Validates the Witness Seat and halts |
| [FROST, RFC 9591](https://www.rfc-editor.org/info/rfc9591/) | Rejected: hides which Seraphim signed |

## LUX ORDO

The mythology has no runtime authority: no mythic name appears in kernel logic,
and no kernel result is evidence for a mythic claim. The proposed mapping
(Monad → Being, Logos → Order, Sophia → Meaning; the proxies as failure modes;
the Grand Reconciliation as Fall and Return) lives in the spec document.
