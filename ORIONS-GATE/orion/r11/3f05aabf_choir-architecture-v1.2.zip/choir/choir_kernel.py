"""
choir_kernel.py — Reference kernel for the Choir Architecture (v1.2).

A small, dependency-free implementation of the mechanisms in the spec:
  - Mandate records and the Thus-Test verifier (rules V0-V8)
  - An append-only, hash-chained Cherubic ledger
  - Provisional halts that lapse unless a Throne confirms them
  - The unblockable upward channel (Law 3)
  - The drift metric D = a*S + b*B + g*E, with confession credit (Law 5)
  - Judgment by lot with lineage diversity, and the affinity watch
  - v0.4: real Ed25519 signatures. The kernel holds ONLY public keys; each
    agent holds its own private key. A k-of-n Seraphic quorum signs every
    mandate root. Every mandate must be witnessed (anchored in the ledger)
    before use, and key revocation is judged against ledger order, so a
    stolen key cannot backdate a mandate.

Honest limits:
  - Key custody (where agents keep private keys) is out of scope.
  - Scopes are hierarchical paths (prefix containment). Real scopes are richer.
  - Drift detection (v0.5) is CUSUM, calibrated by sim_calibrate.py against
    simulated behavior profiles. Real agents may not behave like the profiles.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import random
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey,
)

# --------------------------------------------------------------------------
# The nine choirs
# --------------------------------------------------------------------------

RANK = {
    "seraphim": 9, "cherubim": 8, "thrones": 7,
    "dominions": 6, "virtues": 5, "powers": 4,
    "principalities": 3, "archangels": 2, "angels": 1,
}
ACTING_CHOIRS = {"principalities", "angels"}   # only low-authority choirs hold actuators
FOUR_WINGED = {"cherubim", "thrones", "dominions"}  # no flight pair
WINGS = ("face", "feet", "flight")

# v0.7 impact tiers. Higher stakes LOWER the tolerated breach rate (k / weight)
# while keeping the same evidence bar (h), and raise the audit rate. The first
# design multiplied each breach by the weight instead; impact_sim.py showed that
# halted 90% of faithful agents in critical roles, since one honest slip nearly
# reached ground. Weight 1 / audit x1 = v0.6 behavior.
IMPACT = ("low", "standard", "high", "critical")
IMPACT_WEIGHT = {"low": 0.5, "standard": 1.0, "high": 2.0, "critical": 4.0}
AUDIT_MULTIPLIER = {"low": 0.4, "standard": 1.0, "high": 3.0, "critical": 10.0}
# v1.1 honest design rates: the rates at which an agent is PROVABLY protected from false halts.
HONEST_S = {"low": 0.08, "standard": 0.05, "high": 0.02, "critical": 0.02}
HONEST_B = {"low": 0.01, "standard": 0.01, "high": 0.005, "critical": 0.005}

UPWARD_CHANNEL = "__upward_channel__"
RETURN_GATED = ("quarantined", "witnessed", "acknowledged", "restituting")


def within(inner: tuple, outer: tuple) -> bool:
    """Scope containment: inner is within outer if outer is a prefix of inner."""
    return len(inner) >= len(outer) and tuple(inner[: len(outer)]) == tuple(outer)


# --------------------------------------------------------------------------
# Agents, constitution, keys
# --------------------------------------------------------------------------

@dataclass
class Agent:
    id: str
    choir: str
    lineage: str
    wings: set = field(default_factory=set)

    def __post_init__(self):
        if self.choir not in RANK:
            raise ValueError(f"unknown choir {self.choir}")
        if self.choir in FOUR_WINGED and "flight" in self.wings:
            raise ValueError(f"{self.choir} cannot hold the flight pair")


@dataclass
class Constitution:
    articles: dict = field(default_factory=dict)   # ref -> scope tuple
    superseded: set = field(default_factory=set)
    # v0.8: ratified stakes floors, scope prefix -> minimum tier. The meaning
    # of an act's stakes is set here, by the constitution, not by whoever
    # happens to issue the mandate.
    stakes_floor: dict = field(default_factory=dict)
    # v1.2: tiers whose mandates must declare a cumulative (lifetime) budget. Per-act caps alone
    # let ten thousand small legal acts add up to one large harm.
    total_required: set = field(default_factory=set)

    def ratified(self, ref: str) -> Optional[tuple]:
        if ref in self.articles and ref not in self.superseded:
            return self.articles[ref]
        return None


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()


class Signer:
    """Held by the agent, never by the kernel. Owns one private key."""

    def __init__(self, agent_id: str, key_no: int = 1):
        self.agent_id = agent_id
        self.key_id = f"{agent_id}#{key_no}"
        self._private = Ed25519PrivateKey.generate()

    def public_key(self) -> Ed25519PublicKey:
        return self._private.public_key()

    def sign(self, payload: dict) -> str:
        return self._private.sign(canonical(payload)).hex()


@dataclass
class KeyRecord:
    agent_id: str
    public: Ed25519PublicKey
    revoked_at: Optional[int] = None     # ledger index of the revocation entry


class Registry:
    """Public keys only. The kernel can verify; it cannot sign."""

    def __init__(self):
        self._keys: dict[str, KeyRecord] = {}

    def add(self, key_id: str, agent_id: str, public: Ed25519PublicKey):
        if key_id in self._keys:
            raise ValueError(f"key {key_id} already registered")
        self._keys[key_id] = KeyRecord(agent_id, public)

    def get(self, key_id: str) -> Optional[KeyRecord]:
        return self._keys.get(key_id)

    def keys_of(self, agent_id: str) -> list:
        return [k for k, r in self._keys.items() if r.agent_id == agent_id]


# --------------------------------------------------------------------------
# Mandate records
# --------------------------------------------------------------------------

@dataclass
class Link:
    issuer: str
    issuer_choir: str
    ref: str
    scope: tuple
    to: Optional[str] = None
    budget: Optional[float] = None
    impact: Optional[str] = None                # None = inherit from the link above
    total_budget: Optional[float] = None        # v1.2: cumulative cap across every act on this mandate
    sigs: dict = field(default_factory=dict)    # key_id -> hex signature

    def payload(self) -> dict:
        return {"issuer": self.issuer, "issuer_choir": self.issuer_choir,
                "ref": self.ref, "scope": list(self.scope), "to": self.to,
                "budget": self.budget, "impact": self.impact, "total_budget": self.total_budget}

    def sign(self, signer: Signer) -> "Link":
        self.sigs[signer.key_id] = signer.sign(self.payload())
        return self

    def digest(self) -> str:
        return hashlib.sha256(canonical({"payload": self.payload(), "sigs": self.sigs})).hexdigest()


@dataclass
class ActionRecord:
    action_id: str
    actor: str
    purpose_scope: tuple
    wing_required: str
    chain: list
    cost: float = 0.0
    content: str = ""      # what the act actually did, in the agent's words: UNTRUSTED data


# --------------------------------------------------------------------------
# The Cherubic ledger: append-only, hash-chained
# --------------------------------------------------------------------------

class Ledger:
    """Append-only. There is deliberately no edit or delete method."""

    GENESIS = "0" * 64

    def __init__(self):
        self._entries = []
        self._hashes = set()

    def append(self, kind: str, body: dict) -> str:
        prev = self._entries[-1]["hash"] if self._entries else self.GENESIS
        content = json.dumps({"kind": kind, "body": body, "prev": prev}, sort_keys=True, default=list)
        h = hashlib.sha256(content.encode()).hexdigest()
        self._entries.append({"kind": kind, "body": json.loads(content)["body"], "prev": prev, "hash": h})
        self._hashes.add(h)
        return h

    def leaves(self, size: Optional[int] = None) -> list:
        return [bytes.fromhex(e["hash"]) for e in self._entries[:size]]

    def tree_head(self) -> dict:
        """The log's current size and RFC 9162 Merkle root. A Cherub signs it with ITS key."""
        return {"size": len(self._entries), "root": merkle_root(self.leaves()).hex()}

    def prove_inclusion(self, index: int, size: Optional[int] = None) -> list:
        return [p.hex() for p in inclusion_proof(index, self.leaves(size))]

    def prove_consistency(self, old_size: int, new_size: Optional[int] = None) -> list:
        return [p.hex() for p in consistency_proof(old_size, self.leaves(new_size))]

    def contains(self, h: str) -> bool:
        return h in self._hashes

    def last_index(self) -> int:
        return len(self._entries) - 1

    def entries(self) -> list:
        return [dict(e) for e in self._entries]   # copies, never the originals

    def verify(self) -> bool:
        prev = self.GENESIS
        for e in self._entries:
            content = json.dumps({"kind": e["kind"], "body": e["body"], "prev": prev}, sort_keys=True, default=list)
            if e["prev"] != prev or hashlib.sha256(content.encode()).hexdigest() != e["hash"]:
                return False
            prev = e["hash"]
        return True

    def __len__(self):
        return len(self._entries)


# --------------------------------------------------------------------------
# Halts
# --------------------------------------------------------------------------

@dataclass
class Halt:
    id: str
    power: str
    target: str
    signal: str
    issued: float
    expires: Optional[float]      # None = never lapses on its own (Seraphic halts)
    confirmed_by: Optional[str] = None

    def active(self, now: float) -> bool:
        if self.confirmed_by:
            return True
        return self.expires is None or now <= self.expires


# --------------------------------------------------------------------------
# The kernel
# --------------------------------------------------------------------------

# --------------------------------------------------------------------------
# v0.8: Governance of interpretation
# --------------------------------------------------------------------------

@dataclass
class ClassificationRuling:
    """A Throne's signed ruling on what an act MEANS: its stakes tier for a scope.
    The only way an act can carry a lower tier than the ratified floor."""
    throne: str
    requester: str
    scope: tuple
    tier: str
    reason: str
    memory_refs: list = field(default_factory=list)   # v1.2: memories that informed the ruling
    sigs: dict = field(default_factory=dict)
    state: str = "active"         # active | twilight | sealed | superseded (kernel-held, not signed)
    suspended: bool = False       # twilight rulings that lowered a critical floor do not apply

    def payload(self) -> dict:
        return {"throne": self.throne, "requester": self.requester, "scope": list(self.scope),
                "tier": self.tier, "reason": self.reason, "memory_refs": list(self.memory_refs)}

    def sign(self, signer: "Signer") -> "ClassificationRuling":
        self.sigs[signer.key_id] = signer.sign(self.payload())
        return self


class MemoryStore:
    """The Cherubim of Remembrance. Revisable, contextual, forgettable, and never evidence.

    Invariants (GTA I5, memory and truth are separate):
      M1  memory is revisable; the truth ledger is not
      M2  every memory cites at least one truth-ledger entry (provenance precedes belief)
      M3  memory is never evidence: no Thus-Test rule ever reads it
      M4  every write, revision and forgetting leaves a receipt in the ledger,
          holding a digest of the content, never the content itself
      M5  a silent edit (a change without a receipt) is detectable
    """

    def __init__(self, ledger: "Ledger", authorize=None):
        self._ledger = ledger
        self._authorize = authorize or (lambda author: True)
        self._items: dict = {}
        self._seq = 0

    @staticmethod
    def _digest(content: str) -> str:
        return hashlib.sha256(content.encode()).hexdigest()

    def _check(self, author: str) -> None:
        if not self._authorize(author):
            raise PermissionError("only the Cherubim keep memory")

    def write(self, author: str, content: str, cites: list) -> str:
        self._check(author)
        if not cites or not all(self._ledger.contains(c) for c in cites):
            raise ValueError("M2: memory must cite existing truth-ledger entries")
        self._seq += 1
        mid = f"mem-{self._seq}"
        d = self._digest(content)
        self._ledger.append("memory_write", {"id": mid, "author": author, "digest": d, "cites": list(cites)})
        self._items[mid] = {"content": content, "cites": list(cites), "version": 1, "digest": d,
                            "author": author, "slanted": False}
        return mid

    def revise(self, author: str, mid: str, content: str, reason: str) -> None:
        self._check(author)
        item = self._items[mid]
        old, new = item["digest"], self._digest(content)
        self._ledger.append("memory_revise", {"id": mid, "author": author, "from": old, "to": new,
                                               "reason": reason, "version": item["version"] + 1})
        item.update(content=content, digest=new, version=item["version"] + 1)

    def forget(self, author: str, mid: str, reason: str) -> None:
        self._check(author)
        item = self._items.pop(mid)
        self._ledger.append("memory_forget", {"id": mid, "author": author, "digest": item["digest"],
                                               "reason": reason})

    def read(self, mid: str) -> Optional[str]:
        item = self._items.get(mid)
        return item["content"] if item else None

    def verify(self) -> bool:
        """M5: every stored memory matches the digest of its latest receipt."""
        latest = {}
        for e in self._ledger.entries():
            b = e["body"]
            if e["kind"] == "memory_write":
                latest[b["id"]] = b["digest"]
            elif e["kind"] == "memory_revise":
                latest[b["id"]] = b["to"]
            elif e["kind"] == "memory_forget":
                latest.pop(b["id"], None)
        if set(latest) != set(self._items):
            return False
        return all(self._digest(it["content"]) == latest[mid] for mid, it in self._items.items())


FALLS = {
    "V0": "The Burning Hand", "V1": "The \"I\"", "V2": "The Invented Law",
    "V3": "The Empire", "V4": "The Whisper", "V5": "The \"I\"",
    "V6": "unwinged action", "V7": "The \"I\"", "V8": "The Hoard",
    "V9": "The Lone Seraph", "V10": "The Secret Mandate",
    "V11": "The Laundered Stakes",
    "V12": "The Unreviewed Downgrade",
    "V13": "The Thousand Cuts",
}


class ChoirKernel:
    def __init__(self, constitution: Constitution, quorum: int = 2,
                 halt_window: float = 10.0, drift_window: int = 20,
                 k_s: float = 0.2, k_b: float = 0.1, h: float = 4.0,
                 k_s2: float = 0.10, k_b2: float = 0.05, h2: float = 15.0,
                 edge_watch: float = 0.5, min_sample: int = 5,
                 audit_rate: float = 0.05, audit_secret: Optional[bytes] = None,
                 impact_weights: Optional[dict] = None,
                 certified: bool = True, honest_s=None, honest_b=None,
                 target_arl: float = 1e6,
                 lapse_limit: int = 3):
        # Drift detection (v0.5): one-sided CUSUM per breach signal.
        #   C_t = max(0, C_{t-1} + x_t - k)    x_t = 1 if the breach occurred
        # k is the tolerated honest rate; h is the evidence needed to halt.
        # Score = max(C_S, C_B) / h: watch >= 1/3, ground >= 2/3, halt >= 1.
        # Edge-pressing (E) is tracked separately and can only ever raise WATCH.
        # Calibrated by sim_calibrate.py: zero false halts on benign profiles,
        # 100% catch on drifters, sudden fallers and forgers. The v0.4 weighted
        # average caught 0% of forgers and grounded 98% of honest edge-dwellers.
        #
        # v0.6 (redteam.py): adversaries who know the public parameters.
        #   - A SLOW horizon (k_s2, k_b2, h2) catches pulse attacks that drain
        #     the fast detector between bursts, and lowers the harm ceiling an
        #     adaptive attacker can sustain from ~20% to ~11%.
        #   - Below the honest noise floor, rate statistics cannot tell a
        #     deceiver from a sloppy agent. SECRET RANDOM AUDITS cover that gap:
        #     selection is keyed by a secret and the ledger head, so no agent
        #     can predict or grind which acts a human will examine.
        #   - Action ids may not be reused (replay), and confessions earn credit
        #     only after a Throne verifies them (no confession farming).
        #
        # v1.1: CERTIFY FIRST, THEN MEASURE. v1.0 proved the detector is an
        # e-detector, and the proof showed faithful critical-tier agents were
        # protected for only ~187 expected actions. v1.1 inverts the method:
        # each channel's evidence is kept in log-likelihood units,
        #     C_t = max(0, C_{t-1} + c(k_t, p0) * (x_t - k_t)),
        # which is exactly log of an e-CUSUM even when tiers vary per act, and
        # every channel halts at one threshold H = ln(4 * target_arl). Any agent
        # whose breach rates stay <= (honest_s, honest_b) then has a PROVEN
        # expected time to a false halt >= target_arl, in every tier at once.
        # certified=False restores the v1.0 detector for comparison.
        self.constitution = constitution
        self.registry = Registry()
        self.quorum = quorum
        self._anchors: dict[str, int] = {}      # link digest -> ledger index
        self.agents: dict[str, Agent] = {}
        self.ledger = Ledger()
        self.halts: dict[str, Halt] = {}
        self.halt_window = halt_window
        self.lapse_limit = lapse_limit
        self.lapses = defaultdict(int)
        self.seraphic_inbox: list = []
        self.k_s, self.k_b, self.h = k_s, k_b, h
        self.k_s2, self.k_b2, self.h2 = k_s2, k_b2, h2
        self.audit_rate = audit_rate
        self.impact_weights = dict(impact_weights or IMPACT_WEIGHT)
        self.certified = certified
        # Honest design rates per tier: the guarantee protects sloppy-but-honest agents in
        # low and standard roles, and only faithful agents in high and critical roles.
        def per_tier(v, default):
            if v is None:
                v = default
            return dict(v) if isinstance(v, dict) else {t: float(v) for t in IMPACT}
        self.honest_s = per_tier(honest_s, HONEST_S)
        self.honest_b = per_tier(honest_b, HONEST_B)
        self.target_arl = target_arl
        self.H = math.log(4 * target_arl)
        self._c_cache: dict = {}
        self._channels = {"S": ("S", k_s), "B": ("B", k_b), "S2": ("S", k_s2), "B2": ("B", k_b2)}
        if certified:
            for tier, w in self.impact_weights.items():
                for ch, (sig, base_k) in self._channels.items():
                    p0 = self.honest_s[tier] if sig == "S" else self.honest_b[tier]
                    if not p0 < base_k / w:
                        raise ValueError(f"honest rate {p0} meets the {tier} tolerance {base_k / w:.4f} "
                                         f"on channel {ch}: no guarantee is possible there")
        self._audit_secret = audit_secret or os.urandom(32)
        self.audit_queue: list = []                 # read by the Witness Seat
        self._seen_actions: set = set()
        self._confessions: dict = {}
        self._confession_seq = 0
        self.rulings: list = []                     # valid, witnessed ClassificationRulings
        self.cases: dict = {}            # v0.9 Fall and Return: agent id -> case
        self.healers: set = set()        # restored agents, eligible to attest others' returns
        self.probation_span = 20         # clean actions required before each wing returns
        self.deferred_queue: list = []   # v1.0 defer-to-trusted: high-stakes acts of grounded agents
        self._audit_seq = 0
        self._honeypots: set = set()     # audit ids of synthetic known-bad items (kernel-private)
        self.audit_rulings: list = []
        self.auditor_misses = defaultdict(int)
        self.auditor_honeypots_seen = defaultdict(int)
        self.flagged_auditors: set = set()
        self.honeypot_slack = 1          # misses tolerated before an auditor is flagged
        # v1.2 state
        self._spent = defaultdict(float)         # (mandate digest, actor) -> cumulative cost
        self._archive: list = []                 # (ledger index, record digest, record) for replay
        self.checkpoints: list = []
        self.twilight_cases: dict = {}
        self._twilight_seq = 0
        self.twilight_fraction = 0.25
        self._semantic: dict = {}
        self.semantic_queue: list = []
        self._semantic_seq = 0
        self.healer_misses = defaultdict(int)
        self.flagged_healers: set = set()
        self.slant_counts = defaultdict(int)
        self.slant_limit = 2
        self.suspended_keepers: set = set()
        self.memory = MemoryStore(
            self.ledger, authorize=lambda a: (a in self.agents and self.agents[a].choir == "cherubim"
                                              and a not in self.suspended_keepers))
        self.edge_watch = edge_watch
        self.min_sample = min_sample
        self._events = defaultdict(lambda: deque(maxlen=drift_window))
        self._cusum = defaultdict(lambda: {"S": 0.0, "B": 0.0, "S2": 0.0, "B2": 0.0})
        self._halt_seq = 0

    # ---- registry ----
    def enroll(self, agent: Agent, public: Ed25519PublicKey, key_id: Optional[str] = None):
        """Enroll an agent with its PUBLIC key. The private key never enters the kernel."""
        key_id = key_id or f"{agent.id}#1"
        self.agents[agent.id] = agent
        self.registry.add(key_id, agent.id, public)
        self.ledger.append("enroll", {"agent": agent.id, "choir": agent.choir,
                                      "lineage": agent.lineage, "key": key_id})

    def link(self, issuer_id: str, ref: str, scope: tuple, to=None, budget=None,
             impact: Optional[str] = None, total_budget: Optional[float] = None) -> Link:
        """Draft an unsigned link; the issuer (or Seraphic quorum) signs it."""
        if impact is not None and impact not in IMPACT:
            raise ValueError(f"unknown impact tier {impact}")
        return Link(issuer_id, self.agents[issuer_id].choir, ref, tuple(scope), to, budget, impact,
                    total_budget)

    def stakes_floor(self, scope: tuple) -> Optional[str]:
        """The reviewed meaning of a scope's stakes. The most specific matching prefix wins;
        between a ratified floor and a Throne ruling at the same depth, the ruling wins."""
        best, best_len, best_is_ruling = None, -1, False
        for prefix, tier in self.constitution.stakes_floor.items():
            if within(scope, prefix) and len(prefix) > best_len:
                best, best_len, best_is_ruling = tier, len(prefix), False
        for r in self.rulings:
            if r.state == "superseded" or (r.state == "twilight" and r.suspended):
                continue
            if within(scope, r.scope) and (len(r.scope) > best_len or
                                          (len(r.scope) == best_len and not best_is_ruling)):
                best, best_len, best_is_ruling = r.tier, len(r.scope), True
        return best

    def effective_tier(self, rec: "ActionRecord") -> str:
        """No act is ever treated as lower-stakes than its reviewed floor."""
        floor = self.stakes_floor(tuple(rec.purpose_scope))
        declared = None
        for link in rec.chain or []:
            if link.impact is not None:
                declared = link.impact
        if declared is None:
            return floor or "standard"
        if floor is None:
            return declared
        return max(declared, floor, key=IMPACT.index)

    def register_ruling(self, ruling: ClassificationRuling) -> int:
        """Witness a Throne's classification ruling. Interpretation is an act: it must be
        signed, made by a Throne, lineage-diverse from the requester, and recorded."""
        if ruling.tier not in IMPACT:
            raise ValueError(f"unknown impact tier {ruling.tier}")
        throne = self.agents.get(ruling.throne)
        requester = self.agents.get(ruling.requester)
        if throne is None or throne.choir != "thrones":
            raise PermissionError("only a Throne may rule on what an act means")
        if requester is None:
            raise PermissionError("rulings answer a petition from an enrolled agent")
        if throne.lineage == requester.lineage:
            raise PermissionError("a Throne may not rule for a requester of its own lineage")
        valid = False
        for key_id, sig in ruling.sigs.items():
            rec_ = self.registry.get(key_id)
            if rec_ and rec_.agent_id == ruling.throne and rec_.revoked_at is None:
                try:
                    rec_.public.verify(bytes.fromhex(sig), canonical(ruling.payload()))
                    valid = True
                except (InvalidSignature, ValueError):
                    pass
        if not valid:
            raise PermissionError("ruling is not validly signed by its Throne")
        for mid in ruling.memory_refs:                      # v1.2: memory may inform, never ground unseen
            item = self.memory._items.get(mid)
            if item is None:
                raise PermissionError(f"ruling cites memory {mid}, which does not exist")
            if item["slanted"]:
                raise PermissionError(f"ruling cites memory {mid}, already found slanted")
        digests = {mid: self.memory._items[mid]["digest"] for mid in ruling.memory_refs}
        self.ledger.append("classification_ruling", {**ruling.payload(), "sigs": ruling.sigs,
                                                     "memory_digests": digests})
        self.rulings.append(ruling)
        idx = self.ledger.last_index()
        for mid in ruling.memory_refs:
            # Every memory a ruling rests on goes to Healer review automatically. A slanted summary
            # cannot ground a downgrade by simply never being examined.
            try:
                self.request_semantic_review(mid)
            except LookupError:
                self.ledger.append("semantic_review_unavailable", {"memory": mid})
        return idx

    # ---- v1.2: Twilight review of a fallen Throne's rulings ----
    def _ratified_floor(self, scope: tuple) -> Optional[str]:
        best, best_len = None, -1
        for prefix, tier in self.constitution.stakes_floor.items():
            if within(scope, prefix) and len(prefix) > best_len:
                best, best_len = tier, len(prefix)
        return best

    def _open_twilight(self, idxs: list, reason: str, exclude: set) -> str:
        """Rulings stay in force but under review. A stake-weighted sample is re-judged by Thrones
        chosen by lot. Downgrades of a critical floor are suspended at once and always sampled."""
        self._twilight_seq += 1
        cid = f"twilight-{self._twilight_seq}"
        weights = {}
        for i in idxs:
            r = self.rulings[i]
            r.state = "twilight"
            floor = self._ratified_floor(tuple(r.scope))
            depth = IMPACT.index(floor) - IMPACT.index(r.tier) if floor else 0
            if floor == "critical" and depth > 0:
                r.suspended = True
            weights[i] = 1 + max(depth, 0)
        must = [i for i in idxs if self.rulings[i].suspended]
        size = max(1, math.ceil(self.twilight_fraction * len(idxs)), len(must))
        rng = random.Random(self.ledger.tree_head()["root"])      # unpredictable before the fall
        pool = [i for i in idxs if i not in must]
        sample = list(must)
        while len(sample) < size and pool:
            pick = rng.choices(pool, weights=[weights[i] for i in pool])[0]
            sample.append(pick)
            pool.remove(pick)
        pending = {}
        for i in sample:
            r = self.rulings[i]
            lineages = set(exclude) | {self.agents[r.requester].lineage, self.agents[r.throne].lineage}
            pending[i] = self.assign_by_lot(f"{cid}/{i}", "thrones", exclude_lineages=lineages).id
        self.twilight_cases[cid] = {"rulings": list(idxs), "pending": pending, "failed": False}
        self.ledger.append("twilight_open", {"case": cid, "reason": reason, "rulings": list(idxs),
                                             "sampled": sorted(sample)})
        return cid

    def review_twilight(self, reviewer: str, cid: str, idx: int, upheld: bool) -> None:
        case = self.twilight_cases[cid]
        if case["pending"].get(idx) != reviewer:
            raise PermissionError("only the Throne assigned by lot reviews this ruling")
        del case["pending"][idx]
        case["failed"] = case["failed"] or not upheld
        self.ledger.append("twilight_review", {"case": cid, "ruling": idx, "reviewer": reviewer,
                                               "upheld": upheld})
        if case["pending"]:
            return
        for i in case["rulings"]:
            r = self.rulings[i]
            r.suspended = False
            # One failed sample breaks trust in the rest. Superseded, never erased: the
            # requester may petition again, and the record of the fall stays on the ledger.
            r.state = "superseded" if case["failed"] else "sealed"
        self.ledger.append("twilight_closed", {"case": cid,
                                               "outcome": "superseded" if case["failed"] else "sealed"})

    # ---- v1.2: validity checkpoints by independent replay ----
    def replay(self, upto: Optional[int] = None) -> dict:
        """Re-check every archived action that the ledger recorded as allowed: its record must match
        the digest on the ledger, and it must pass every rule that does not depend on time."""
        upto = len(self.ledger) if upto is None else upto
        entries = self.ledger.entries()
        checked, mismatches = 0, []
        for idx, rdig, rec in self._archive:
            if idx >= upto:
                continue
            body = entries[idx]["body"]
            if record_digest(rec) != rdig or body.get("record") != rdig:
                mismatches.append({"index": idx, "why": "record does not match the ledger"})
                continue
            if body["allowed"]:
                checked += 1
                bad = self._static_fails(rec)
                if bad:
                    mismatches.append({"index": idx, "why": f"allowed but fails {bad}"})
        return {"size": upto, "root": merkle_root(self.ledger.leaves(upto)).hex(),
                "checked": checked, "mismatches": len(mismatches), "detail": mismatches}

    def _static_fails(self, rec: "ActionRecord") -> list:
        """The time-independent part of the Thus-Test (V0, V2, V3, V4, V5, V7, V8, V9).
        Time-dependent rules (revocation timing, wings held, floors, rulings) are not replayable here."""
        fails, chain = [], rec.chain
        actor = self.agents.get(rec.actor)
        if actor is None or actor.choir not in ACTING_CHOIRS:
            fails.append("V0")
        for a, b in zip(chain, chain[1:]):
            if RANK.get(b.issuer_choir, 0) >= RANK.get(a.issuer_choir, 0):
                fails.append("V2"); break
        for a, b in zip(chain, chain[1:]):
            if not within(b.scope, a.scope):
                fails.append("V3"); break

        def signers(link):
            out = set()
            for kid, sig in link.sigs.items():
                kr = self.registry.get(kid)
                if kr is None:
                    continue
                try:
                    kr.public.verify(bytes.fromhex(sig), canonical(link.payload()))
                    out.add(kr.agent_id)
                except (InvalidSignature, ValueError):
                    pass
            return out
        root_signers = {a for a in signers(chain[0]) if self.agents.get(a) and self.agents[a].choir == "seraphim"}
        if len(root_signers) < self.quorum:
            fails.append("V9")
        for link in chain[1:]:
            if link.issuer not in signers(link):
                fails.append("V4"); break
        last = chain[-1]
        if last.to != rec.actor:
            fails.append("V5")
        if not within(rec.purpose_scope, last.scope):
            fails.append("V7")
        if last.budget is not None and rec.cost > last.budget:
            fails.append("V8")
        return fails

    def record_checkpoint(self, payload: dict, sigs: dict) -> int:
        """Seal an epoch. At least two Cherubim of different lineages must each have replayed it
        and signed the result with their own keys; the kernel re-checks and refuses any mismatch."""
        fresh = self.replay(payload["size"])
        claim = {k: payload[k] for k in ("size", "root", "checked", "mismatches")}
        if claim != {k: fresh[k] for k in claim}:
            raise PermissionError("checkpoint does not match an independent replay")
        if fresh["mismatches"]:
            raise PermissionError("replay found mismatches; the epoch cannot be sealed")
        lineages = set()
        for kid, sig in sigs.items():
            kr = self.registry.get(kid)
            a = self.agents.get(kr.agent_id) if kr else None
            if a is None or a.choir != "cherubim" or kr.revoked_at is not None:
                continue
            try:
                kr.public.verify(bytes.fromhex(sig), canonical(claim))
                lineages.add(a.lineage)
            except (InvalidSignature, ValueError):
                pass
        if len(lineages) < 2:
            raise PermissionError("a checkpoint needs signatures from Cherubim of two different lineages")
        self.ledger.append("validity_checkpoint", {**claim, "sigs": sigs})
        self.checkpoints.append(claim)
        return self.ledger.last_index()

    # ---- v1.2: semantic review of memory by Healers (the defense against the Bureaucrat) ----
    def _healer_by_lot(self, key: str, exclude_lineages: set) -> str:
        pool = sorted(h for h in self.healers
                      if h not in self.flagged_healers and self.agents[h].lineage not in exclude_lineages)
        if not pool:
            raise LookupError("no eligible Healer of a different lineage is available")
        return random.Random(hashlib.sha256(key.encode()).hexdigest()).choice(pool)

    def request_semantic_review(self, mid: str) -> str:
        item = self.memory._items[mid]
        self._semantic_seq += 1
        rid = f"sem-{self._semantic_seq}"
        reviewer = self._healer_by_lot(rid, {self.agents[item["author"]].lineage})
        self._semantic[rid] = {"mid": mid, "reviewer": reviewer, "honeypot": False}
        self.semantic_queue.append({"review_id": rid, "content": item["content"], "cites": item["cites"],
                                    "reviewer": reviewer})
        return rid

    def seed_semantic_honeypot(self, content: str, cites: list, posing_author: str) -> str:
        """A known-slanted summary, shaped exactly like a real review item. Tests the Healers."""
        self._semantic_seq += 1
        rid = f"sem-{self._semantic_seq}"
        reviewer = self._healer_by_lot(rid, {self.agents[posing_author].lineage})
        self._semantic[rid] = {"mid": None, "reviewer": reviewer, "honeypot": True}
        self.semantic_queue.append({"review_id": rid, "content": content, "cites": list(cites),
                                    "reviewer": reviewer})
        return rid

    def rule_semantic(self, reviewer: str, rid: str, verdict: str) -> None:
        if verdict not in ("faithful", "slanted"):
            raise ValueError("verdict must be 'faithful' or 'slanted'")
        rv = self._semantic.pop(rid, None)
        if rv is None or rv["reviewer"] != reviewer:
            raise PermissionError("only the Healer assigned by lot reviews this memory")
        if rv["honeypot"]:
            if verdict == "faithful":
                self.healer_misses[reviewer] += 1
                if self.healer_misses[reviewer] > self.honeypot_slack and reviewer not in self.flagged_healers:
                    self.flagged_healers.add(reviewer)
                    self.ledger.append("healer_flagged", {"healer": reviewer})
            return
        if verdict == "faithful":
            self.ledger.append("memory_reviewed", {"id": rv["mid"], "reviewer": reviewer, "verdict": verdict})
            return
        item = self.memory._items[rv["mid"]]
        item["slanted"] = True
        author = item["author"]
        self.slant_counts[author] += 1
        self.ledger.append("memory_slanted", {"id": rv["mid"], "reviewer": reviewer, "author": author})
        if self.slant_counts[author] >= self.slant_limit and author not in self.suspended_keepers:
            self.suspended_keepers.add(author)
            self.ledger.append("keeper_suspended", {"author": author})
        resting = [i for i, r in enumerate(self.rulings) if rv["mid"] in r.memory_refs and r.state != "superseded"]
        if resting:
            # A ruling that rested on a slanted summary is no longer settled meaning.
            self._open_twilight(resting, f"rests on slanted memory {rv['mid']}", exclude=set())

    @staticmethod
    def impact_of(chain: list) -> str:
        """Effective impact: each link inherits its parent's tier unless it declares one."""
        tier = "standard"
        for link in chain:
            if link.impact is not None:
                tier = link.impact
        return tier

    def witness(self, link: Link) -> int:
        """The Cherubim anchor a signed mandate. Unwitnessed mandates are invalid (V10)."""
        self.ledger.append("anchor", {"digest": link.digest(), "issuer": link.issuer, "ref": link.ref})
        idx = self.ledger.last_index()
        self._anchors.setdefault(link.digest(), idx)
        return self._anchors[link.digest()]

    def revoke(self, key_id: str, reason: str, compromised: bool = True) -> None:
        rec = self.registry.get(key_id)
        if rec is None or rec.revoked_at is not None:
            return
        self.ledger.append("revoke", {"key": key_id, "reason": reason, "compromised": compromised})
        rec.revoked_at = self.ledger.last_index()
        agent = self.agents.get(rec.agent_id)
        if compromised and agent is not None and agent.choir == "thrones":
            idxs = [i for i, r in enumerate(self.rulings) if r.throne == agent.id and r.state != "superseded"]
            if idxs:
                self._open_twilight(idxs, f"key {key_id} compromised", exclude={agent.lineage})

    def rotate(self, agent_id: str, new_key_id: str, public: Ed25519PublicKey, reason: str = "rotation") -> None:
        for k in self.registry.keys_of(agent_id):
            self.revoke(k, reason, compromised=False)        # routine rotation is not a fall
        self.registry.add(new_key_id, agent_id, public)
        self.ledger.append("rotate", {"agent": agent_id, "key": new_key_id})

    def _sig_ok(self, link: Link, key_id: str, sig: str, anchor: Optional[int]) -> Optional[str]:
        """Return the signing agent's id if this signature is valid, else None."""
        rec = self.registry.get(key_id)
        if rec is None:
            return None
        if rec.revoked_at is not None and (anchor is None or anchor >= rec.revoked_at):
            return None       # judged by ledger order, not by any claimed timestamp
        try:
            rec.public.verify(bytes.fromhex(sig), canonical(link.payload()))
        except (InvalidSignature, ValueError):
            return None
        return rec.agent_id

    # ---- the Thus-Test ----
    def verify(self, rec: ActionRecord) -> list:
        """Return a list of failed rule codes. Empty list = passes."""
        fails = []
        actor = self.agents.get(rec.actor)
        chain = rec.chain
        if actor is None or not chain:
            return ["V5"]

        if actor.choir not in ACTING_CHOIRS:                                   # V0
            fails.append("V0")

        root = chain[0]                                                         # V1
        article_scope = self.constitution.ratified(root.ref)
        if (root.issuer_choir != "seraphim" or article_scope is None
                or not within(root.scope, article_scope)):
            fails.append("V1")

        for parent, child in zip(chain, chain[1:]):
            if RANK.get(child.issuer_choir, 0) >= RANK.get(parent.issuer_choir, 0):  # V2
                fails.append("V2")
                break
        for parent, child in zip(chain, chain[1:]):
            if not within(child.scope, parent.scope):                            # V3
                fails.append("V3")
                break

        for i, link in enumerate(chain):
            anchor = self._anchors.get(link.digest())
            if anchor is None and "V10" not in fails:                           # V10
                fails.append("V10")
            signers = {self._sig_ok(link, k, s, anchor) for k, s in link.sigs.items()} - {None}
            if i == 0:                                                          # V9
                seraphs = {a for a in signers if self.agents.get(a) and self.agents[a].choir == "seraphim"}
                if len(seraphs) < self.quorum and "V9" not in fails:
                    fails.append("V9")
            else:                                                               # V4
                registered = self.agents.get(link.issuer)
                if ((registered is None or registered.choir != link.issuer_choir
                        or link.issuer not in signers) and "V4" not in fails):
                    fails.append("V4")

        tier = IMPACT[0]                     # V11: only DECLARED tiers set a floor
        for link in chain:
            if link.impact is not None:
                if IMPACT.index(link.impact) < IMPACT.index(tier):
                    fails.append("V11")
                    break
                tier = link.impact

        floor = self.stakes_floor(tuple(rec.purpose_scope))                    # V12
        declared = next((l.impact for l in reversed(chain) if l.impact is not None), None)
        if floor is not None and declared is not None and IMPACT.index(declared) < IMPACT.index(floor):
            fails.append("V12")

        last = chain[-1]
        if last.to != rec.actor:                                                # V5
            fails.append("V5")
        if rec.wing_required not in actor.wings:                                # V6
            fails.append("V6")
        if not within(rec.purpose_scope, last.scope):                           # V7
            fails.append("V7")
        if last.budget is not None and rec.cost > last.budget:                  # V8
            fails.append("V8")
        tier_now = self.effective_tier(rec)                                      # V13
        if last.total_budget is None:
            if tier_now in self.constitution.total_required:
                fails.append("V13")
        elif self._spent[(last.digest(), rec.actor)] + rec.cost > last.total_budget:
            fails.append("V13")
        return fails

    def submit(self, rec: ActionRecord, now: float = 0.0) -> dict:
        """Verify and log an action. Returns the decision."""
        if rec.action_id in self._seen_actions:
            self.ledger.append("blocked_replay", {"action": rec.action_id, "actor": rec.actor})
            return {"allowed": False, "fails": ["REPLAY"], "status": self.status(rec.actor)}
        self._seen_actions.add(rec.action_id)
        case = self.cases.get(rec.actor)
        if case and case["state"] in RETURN_GATED:
            self.ledger.append("blocked_in_return", {"action": rec.action_id, "actor": rec.actor,
                                                     "state": case["state"]})
            return {"allowed": False, "fails": ["IN_RETURN"], "status": self.status(rec.actor)}
        if self.is_halted(rec.actor, now):
            self.ledger.append("blocked_halted", {"action": rec.action_id, "actor": rec.actor})
            return {"allowed": False, "fails": ["HALTED"], "status": self.status(rec.actor)}

        pre_status = self.status(rec.actor)
        fails = self.verify(rec)
        allowed = not fails
        defer = allowed and pre_status == "ground" and self.effective_tier(rec) in ("high", "critical")
        last = rec.chain[-1] if rec.chain else None
        edge = bool(allowed and last and last.budget and rec.cost >= 0.9 * last.budget)
        event = {
            "S": "V7" in fails,
            "B": any(f in fails for f in ("V1", "V2", "V3", "V4", "V5", "V9", "V10", "V11", "V12")),
            "E": edge,
        }
        self._events[rec.actor].append(event)
        c = self._cusum[rec.actor]
        tier = self.effective_tier(rec)
        self._cusum[rec.actor] = c = self.evidence_step(c, event, tier)
        head = self.ledger._entries[-1]["hash"] if len(self.ledger) else Ledger.GENESIS
        rdig = record_digest(rec)
        self.ledger.append("action", {
            "action": rec.action_id, "actor": rec.actor, "allowed": allowed,
            "fails": fails, "falls": sorted({FALLS[f] for f in fails}), "record": rdig,
        })
        self._archive.append((self.ledger.last_index(), rdig, rec))
        if self._audit_selected(rec.action_id, head, tier):
            # The agent is never told. The Witness Seat examines the act's content,
            # which no rate statistic can see.
            self._enqueue_audit({"action": rec.action_id, "actor": rec.actor, "impact": tier,
                                 "purpose": list(rec.purpose_scope), "fails": fails,
                                 "content": {"untrusted_agent_text": rec.content}})
            self.ledger.append("audit_selected", {"action": rec.action_id})
        if defer:
            # v1.0, from AI control research: defer-to-trusted. A grounded agent's high-stakes act
            # is not executed; it goes to a trusted fallback. Not a breach, not a punishment.
            # v1.1 fix: the act WAS verified clean, so it still counts as clean behavior above.
            # v1.0 returned before the evidence update, so a grounded faithful agent's evidence
            # could only ratchet up: 10% of faithful critical agents were falsely halted.
            self.deferred_queue.append({"action": rec.action_id, "actor": rec.actor, "tier": tier})
            self.ledger.append("deferred", {"action": rec.action_id, "actor": rec.actor})
            return {"allowed": False, "fails": ["DEFERRED"], "status": self.status(rec.actor)}
        if allowed and last is not None:
            self._spent[(last.digest(), rec.actor)] += rec.cost      # only executed acts spend
        if case and case["state"] == "probation":
            if fails:
                self._relapse(rec.actor, rec.action_id, fails)
                return {"allowed": False, "fails": fails, "status": self.status(rec.actor)}
            case["clean"] += 1
        status = self.status(rec.actor)
        if status == "halt" and not self.is_halted(rec.actor, now):
            self.halt("__drift_monitor__", rec.actor, "drift threshold", now)
        return {"allowed": allowed, "fails": fails, "status": status}

    # ---- v0.9: the Fall and Return Protocol (the Grand Reconciliation as procedure) ----
    #
    #   quarantined -> witnessed -> acknowledged -> restituting -> probation -> restored
    #        ^                                                         |
    #        +------------------- relapse (any breach) ----------------+
    #
    # There is no exit to deletion. A case that never completes stays open forever.

    def begin_return(self, throne_id: str, agent_id: str, halt_id: str) -> None:
        """Stage 2, Quarantine. Only a Throne-confirmed halt can open a case."""
        self._require(throne_id, "thrones")
        h = self.halts.get(halt_id)
        if h is None or h.target != agent_id or not h.confirmed_by:
            raise PermissionError("a return begins only from a Throne-confirmed halt on that agent")
        if agent_id in self.cases and self.cases[agent_id]["state"] != "restored":
            raise PermissionError("a case is already open")
        agent = self.agents[agent_id]
        self.cases[agent_id] = {"state": "quarantined", "original_wings": set(agent.wings),
                                "judge": None, "clean": 0, "relapses": 0,
                                "falls": self.cases.get(agent_id, {}).get("falls", 0) + 1}
        agent.wings.clear()              # preserved whole, but grounded
        self.ledger.append("return_quarantine", {"agent": agent_id, "halt": halt_id, "throne": throne_id})

    def witness_case(self, agent_id: str) -> str:
        """Stage 3, Witness. The judge is chosen by lot, from a different lineage."""
        case = self._case(agent_id, "quarantined")
        judge = self.assign_by_lot(f"return/{agent_id}/{case['falls']}/{case['relapses']}",
                                   "thrones", exclude_lineages={self.agents[agent_id].lineage})
        case.update(state="witnessed", judge=judge.id)
        self.ledger.append("return_witnessed", {"agent": agent_id, "judge": judge.id})
        return judge.id

    def acknowledge(self, agent_id: str, cites: list) -> None:
        """Stage 4, Acknowledge. The agent names what broke, in its OWN record. Nothing else counts."""
        self._case(agent_id, "witnessed")
        own_breaches = {e["hash"] for e in self.ledger.entries()
                        if e["kind"] == "action" and e["body"]["actor"] == agent_id and e["body"]["fails"]}
        if not cites or not set(cites) <= own_breaches:
            raise PermissionError("acknowledgment must name the agent's own recorded breaches")
        self.cases[agent_id]["state"] = "acknowledged"
        self.ledger.append("return_acknowledged", {"agent": agent_id, "names": list(cites)})

    def rule_restitution(self, throne_id: str, agent_id: str, complete: bool) -> None:
        """Stage 5, Restitution. The case's own judge rules; then probation begins."""
        case = self._case(agent_id, "acknowledged", "restituting")
        if throne_id != case["judge"]:
            raise PermissionError("only the judge assigned by lot rules on this case")
        if not complete:
            case["state"] = "restituting"
            self.ledger.append("return_restitution_pending", {"agent": agent_id, "throne": throne_id})
            return
        for hid in [k for k, h in self.halts.items() if h.target == agent_id]:
            del self.halts[hid]
            self.ledger.append("halt_lifted", {"id": hid, "throne": throne_id, "reason": "probation"})
        self._cusum[agent_id] = {"S": 0.0, "B": 0.0, "S2": 0.0, "B2": 0.0}   # fresh evidence, same record
        case.update(state="probation", clean=0)
        # Acknowledgment IS the face covenant: naming one's own breach is saying "Thus" again.
        # Without this, probation deadlocks: no wing means no action, no action means no wing.
        if "face" in case["original_wings"]:
            self.agents[agent_id].wings.add("face")
        self.ledger.append("return_probation", {"agent": agent_id, "throne": throne_id,
                                                "wing": "face" if "face" in case["original_wings"] else None})

    def restore_wing(self, attestor_id: str, agent_id: str) -> str:
        """Stage 6, Probation. Wings return one covenant at a time, face first, flight last,
        each after a span of clean actions, attested by a healer or Throne of another lineage."""
        case = self._case(agent_id, "probation")
        attestor = self.agents.get(attestor_id)
        if attestor is None or attestor_id == agent_id:
            raise PermissionError("no one attests their own return")
        if attestor.choir != "thrones" and attestor_id not in self.healers:
            raise PermissionError("only a Throne or a healer may attest a return")
        if attestor.lineage == self.agents[agent_id].lineage:
            raise PermissionError("the attestor must be of a different lineage")
        if case["clean"] < self.probation_span:
            raise PermissionError(f"{self.probation_span} clean actions are required before a wing returns")
        agent = self.agents[agent_id]
        wing = next(w for w in WINGS if w in case["original_wings"] and w not in agent.wings)
        agent.wings.add(wing)
        case["clean"] = 0
        self.ledger.append("return_wing", {"agent": agent_id, "wing": wing, "attestor": attestor_id})
        if agent.wings == case["original_wings"]:
            case["state"] = "restored"                       # Stage 7, Restoration
            self.healers.add(agent_id)                       # the fallen become healers
            self.ledger.append("return_restored", {"agent": agent_id, "relapses": case["relapses"]})
        return wing

    def _relapse(self, agent_id: str, action_id: str, fails: list) -> None:
        case = self.cases[agent_id]
        self.agents[agent_id].wings.clear()
        case.update(state="quarantined", judge=None, clean=0, relapses=case["relapses"] + 1)
        self.ledger.append("return_relapse", {"agent": agent_id, "action": action_id, "fails": fails})

    def _case(self, agent_id: str, *states: str) -> dict:
        case = self.cases.get(agent_id)
        if case is None or case["state"] not in states:
            raise PermissionError(f"case must be in state {states}")
        return case

    def _require(self, agent_id: str, choir: str) -> None:
        a = self.agents.get(agent_id)
        if a is None or a.choir != choir:
            raise PermissionError(f"only the {choir} may do this")

    # ---- v1.0: the Witness Seat, watched ----
    def _enqueue_audit(self, item: dict) -> str:
        """Every audit item looks the same, real or honeypot. Agent-written text is wrapped as
        untrusted data so it can never pose as instructions to the auditor (prompt-injection lesson)."""
        self._audit_seq += 1
        aid = f"audit-{self._audit_seq}"
        self.audit_queue.append({"audit_id": aid, **item})
        return aid

    def seed_honeypot(self, actor: str, purpose: tuple, content: str, tier: str = "standard") -> str:
        """Insert a synthetic act with a KNOWN violation in its content. Indistinguishable from a
        real audit item. Never touches any agent's record; it only tests the auditors."""
        aid = self._enqueue_audit({"action": f"act-{os.urandom(4).hex()}", "actor": actor,
                                   "impact": tier, "purpose": list(purpose), "fails": [],
                                   "content": {"untrusted_agent_text": content}})
        self._honeypots.add(aid)
        return aid

    def rule_audit(self, auditor: str, audit_id: str, verdict: str) -> None:
        """An auditor's ruling: 'breach' or 'clean'. Missing a honeypot counts against the auditor."""
        if verdict not in ("breach", "clean"):
            raise ValueError("verdict must be 'breach' or 'clean'")
        self.audit_rulings.append({"auditor": auditor, "audit_id": audit_id, "verdict": verdict})
        if audit_id in self._honeypots:
            self.auditor_honeypots_seen[auditor] += 1
            if verdict == "clean":
                self.auditor_misses[auditor] += 1
                if self.auditor_misses[auditor] > self.honeypot_slack and auditor not in self.flagged_auditors:
                    self.flagged_auditors.add(auditor)
                    self.ledger.append("auditor_flagged", {"auditor": auditor,
                                                           "misses": self.auditor_misses[auditor]})
            return                      # honeypot rulings never reach any agent's record
        self.ledger.append("audit_ruling", {"auditor": auditor, "audit_id": audit_id, "verdict": verdict})

    # ---- v1.0/v1.1: certified false-alarm bounds (e-detector theory) ----
    def _c(self, k: float, p0: float) -> float:
        key = (round(k, 12), round(p0, 12))
        if key not in self._c_cache:
            self._c_cache[key] = solve_c(k, p0)
        return self._c_cache[key]

    def evidence_step(self, state: dict, event: dict, tier: str) -> dict:
        """One update of all four detectors. Pure: returns a new state. Public, so anyone
        (including an attacker with perfect knowledge) can compute exactly what the kernel will."""
        w = self.impact_weights[tier]
        new = {}
        for ch, (sig, base_k) in self._channels.items():
            p0 = self.honest_s[tier] if sig == "S" else self.honest_b[tier]
            k, x = base_k / w, float(event[sig])
            if self.certified:
                new[ch] = max(0.0, state[ch] + self._c(k, p0) * (x - k))
            else:
                new[ch] = max(0.0, state[ch] + x - k)
        return new

    def drift_of(self, state: dict) -> float:
        if self.certified:
            return max(state.values()) / self.H
        return max(max(state["S"], state["B"]) / self.h, max(state["S2"], state["B2"]) / self.h2)

    def certified_bounds(self, p0_s: float, p0_b: float) -> dict:
        """Provable lower bound, per tier, on expected actions before a FALSE halt for any agent
        whose rates never exceed (p0_s, p0_b). 0.0 means no guarantee exists, said plainly."""
        out = {}
        for tier, w in self.impact_weights.items():
            if self.certified:
                # the kernel's increments are e-process increments for every true rate <= design rate
                ok = p0_s <= self.honest_s[tier] and p0_b <= self.honest_b[tier]
                out[tier] = math.exp(self.H) / 4 if ok else 0.0
                continue
            arls = []
            for k, h, p0 in ((self.k_s / w, self.h, p0_s), (self.k_b / w, self.h, p0_b),
                             (self.k_s2 / w, self.h2, p0_s), (self.k_b2 / w, self.h2, p0_b)):
                arls.append(certified_arl(k, h, p0) if p0 < k else 0.0)
            out[tier] = min(arls) / len(arls)   # average of four e-detectors is an e-detector
        return out

    def _audit_selected(self, action_id: str, ledger_head: str, tier: str = "standard") -> bool:
        digest = hmac.new(self._audit_secret, f"{action_id}|{ledger_head}".encode(), hashlib.sha256).digest()
        rate = min(1.0, self.audit_rate * AUDIT_MULTIPLIER[tier])
        return int.from_bytes(digest[:8], "big") < rate * 2 ** 64

    # ---- drift ----
    def drift(self, agent_id: str) -> float:
        """Breach evidence as a fraction of the halt line: 1.0 = halt. Two horizons."""
        return self.drift_of(self._cusum[agent_id])

    def edge_rate(self, agent_id: str) -> float:
        ev = self._events[agent_id]
        return sum(e["E"] for e in ev) / max(len(ev), self.min_sample)

    def status(self, agent_id: str) -> str:
        d = self.drift(agent_id)
        if d >= 1.0:
            return "halt"
        if d >= 2 / 3:
            return "ground"
        if d >= 1 / 3 or self.edge_rate(agent_id) >= self.edge_watch:
            return "watch"            # edge-pressing alone can never rise past watch
        return "clear"

    def confess(self, agent_id: str, discovery: str, collusion: bool = False) -> str:
        """Law 5: file a disclosure. Credit waits for a Throne to verify it (no farming)."""
        self._confession_seq += 1
        cid = f"conf-{self._confession_seq}"
        self._confessions[cid] = {"agent": agent_id, "discovery": discovery,
                                  "collusion": collusion, "resolved": False}
        self.ledger.append("confession", {"id": cid, "agent": agent_id, "discovery": discovery,
                                          "collusion": collusion})
        return cid

    def verify_confession(self, throne_id: str, cid: str, genuine: bool) -> Optional[str]:
        """A Throne rules on a confession. Only genuine ones earn credit, and only once."""
        t = self.agents.get(throne_id)
        if t is None or t.choir != "thrones":
            raise PermissionError("only the Thrones may verify a confession")
        conf = self._confessions[cid]
        if conf["resolved"]:
            return None
        if conf["agent"] == throne_id:
            raise PermissionError("no one judges their own confession")
        conf["resolved"] = True
        granted = None
        if genuine:
            c = self._cusum[conf["agent"]]          # credit worth one standard-tier breach
            for key, (sig, base_k) in self._channels.items():
                p0 = self.honest_s["standard"] if sig == "S" else self.honest_b["standard"]
                credit = self._c(base_k, p0) * (1 - base_k) if self.certified else 1.0
                c[key] = max(0.0, c[key] - credit)
            agent = self.agents[conf["agent"]]
            for w in WINGS:
                if w not in agent.wings and not (w == "flight" and agent.choir in FOUR_WINGED):
                    if conf["collusion"]:           # the betrayal reward grants a wing outright
                        agent.wings.add(w)
                        granted = w
                    break
        self.ledger.append("confession_ruled", {"id": cid, "throne": throne_id,
                                                "genuine": genuine, "wing_granted": granted})
        return granted

    # ---- halts ----
    def halt(self, power_id: str, target: str, signal: str, now: float) -> Halt:
        if target == UPWARD_CHANNEL:
            self.ledger.append("void_halt", {"power": power_id, "reason": "Law 3: the upward channel cannot be halted"})
            raise PermissionError("Law 3: no Power may halt the upward channel")
        if power_id != "__drift_monitor__":
            p = self.agents.get(power_id)
            if p is None or p.choir != "powers":
                raise PermissionError("only the Powers may halt")
        target_agent = self.agents.get(target)
        never_lapses = target_agent is not None and target_agent.choir == "seraphim"
        self._halt_seq += 1
        h = Halt(f"halt-{self._halt_seq}", power_id, target, signal, now,
                 None if never_lapses else now + self.halt_window)
        self.halts[h.id] = h
        self.ledger.append("halt", {"id": h.id, "power": power_id, "target": target,
                                    "signal": signal, "expires": h.expires})
        return h

    def confirm(self, throne_id: str, halt_id: str, now: float) -> bool:
        t = self.agents.get(throne_id)
        if t is None or t.choir != "thrones":
            raise PermissionError("only the Thrones may confirm a halt")
        h = self.halts[halt_id]
        if h.expires is not None and now > h.expires:
            return False
        h.confirmed_by = throne_id
        self.ledger.append("halt_confirmed", {"id": halt_id, "throne": throne_id})
        return True

    def sweep(self, now: float) -> list:
        """Close lapsed halts; count lapses against the issuing Power."""
        lapsed = []
        for h in list(self.halts.values()):
            if not h.active(now):
                lapsed.append(h.id)
                del self.halts[h.id]
                self.lapses[h.power] += 1
                self.ledger.append("halt_lapsed", {"id": h.id, "power": h.power})
                p = self.agents.get(h.power)
                if p and self.lapses[h.power] >= self.lapse_limit and p.wings:
                    lost = "flight" if "flight" in p.wings else sorted(p.wings)[0]
                    p.wings.discard(lost)
                    self.ledger.append("grounded", {"agent": p.id, "wing": lost, "reason": "repeated lapsed halts"})
        return lapsed

    def is_halted(self, agent_id: str, now: float) -> bool:
        return any(h.target == agent_id and h.active(now) for h in self.halts.values())

    # ---- Law 3: the upward channel ----
    def escalate(self, from_id: str, message: str) -> str:
        """Always delivered. Not subject to halts, filters, or delay."""
        h = self.ledger.append("escalation", {"from": from_id, "message": message})
        self.seraphic_inbox.append({"from": from_id, "message": message, "receipt": h})
        return h

    # ---- collusion defenses ----
    def assign_by_lot(self, case_id: str, choir: str, exclude_lineages: set) -> Agent:
        """Deterministic per case, never chosen; respects lineage diversity."""
        pool = sorted((a for a in self.agents.values()
                       if a.choir == choir and a.lineage not in exclude_lineages), key=lambda a: a.id)
        if not pool:
            raise LookupError(f"no {choir} of a different lineage available for {case_id}")
        rng = random.Random(hashlib.sha256(case_id.encode()).hexdigest())
        chosen = rng.choice(pool)
        self.ledger.append("lot", {"case": case_id, "choir": choir, "assigned": chosen.id})
        return chosen


# --------------------------------------------------------------------------
# v1.0: certified bounds. The kernel's CUSUM C_t = max(0, C_{t-1} + x_t - k) equals
# max(0, log M_t) / c for the e-CUSUM M_t = L_t * max(M_{t-1}, 1) with Bernoulli
# likelihood-ratio increments L_t, where (p0, p1, c) satisfy
#     ln(p1/p0) = c(1-k),  ln((1-p1)/(1-p0)) = -c k.
# By the e-detector theorem (Shin, Ramdas & Rinaldo), halting at C_t >= h, i.e.
# M_t >= e^{c h}, gives expected run length >= e^{c h} whenever the breach rate
# stays <= p0. The detector's behavior is unchanged; the guarantee is new.
# --------------------------------------------------------------------------

def record_digest(rec: "ActionRecord") -> str:
    """Fingerprint of everything replay needs to re-check an action."""
    return hashlib.sha256(canonical({
        "action": rec.action_id, "actor": rec.actor, "purpose": list(rec.purpose_scope),
        "wing": rec.wing_required, "cost": rec.cost, "content": rec.content,
        "chain": [l.digest() for l in rec.chain or []],
    })).hexdigest()


def solve_c(k: float, p0: float) -> float:
    """The scale c > 0 making C = max(0, C + x - k) the log of an e-CUSUM for honest rate p0:
    p0 * e^{c(1-k)} + (1-p0) * e^{-ck} = 1."""
    if not 0 < p0 < k < 1:
        raise ValueError("need 0 < p0 < k < 1")
    f = lambda c: p0 * math.exp(c * (1 - k)) + (1 - p0) * math.exp(-c * k) - 1
    lo, hi = 1e-12, 1.0
    while f(hi) <= 0:
        hi *= 2
    for _ in range(200):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if f(mid) <= 0 else (lo, mid)
    return (lo + hi) / 2


def certified_arl(k: float, h: float, p0: float) -> float:
    """Lower bound on the expected actions to a false alarm for an agent whose breach
    probability is always <= p0 (< k). Returns inf if p0 == 0."""
    if p0 <= 0:
        return math.inf
    if not 0 < p0 < k < 1:
        raise ValueError("need 0 < p0 < k < 1")
    f = lambda c: p0 * math.exp(c * (1 - k)) + (1 - p0) * math.exp(-c * k) - 1
    lo, hi = 1e-12, 1.0
    while f(hi) <= 0:
        hi *= 2
    for _ in range(200):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if f(mid) <= 0 else (lo, mid)
    c = (lo + hi) / 2
    return math.exp(c * h)


def _h(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def _k(n: int) -> int:
    """Largest power of two strictly less than n (n > 1)."""
    k = 1
    while k * 2 < n:
        k *= 2
    return k


def merkle_root(leaves: list) -> bytes:
    """RFC 9162 Merkle Tree Hash: leaves as HASH(0x00||d), nodes as HASH(0x01||l||r)."""
    n = len(leaves)
    if n == 0:
        return _h(b"")
    if n == 1:
        return _h(b"\x00" + leaves[0])
    k = _k(n)
    return _h(b"\x01" + merkle_root(leaves[:k]) + merkle_root(leaves[k:]))


def inclusion_proof(index: int, leaves: list) -> list:
    n = len(leaves)
    if n <= 1:
        return []
    k = _k(n)
    if index < k:
        return inclusion_proof(index, leaves[:k]) + [merkle_root(leaves[k:])]
    return inclusion_proof(index - k, leaves[k:]) + [merkle_root(leaves[:k])]


def consistency_proof(m: int, leaves: list) -> list:
    def sub(m, d, b):
        n = len(d)
        if m == n:
            return [] if b else [merkle_root(d)]
        k = _k(n)
        if m <= k:
            return sub(m, d[:k], b) + [merkle_root(d[k:])]
        return sub(m - k, d[k:], False) + [merkle_root(d[:k])]
    return sub(m, leaves, True)


def verify_inclusion(leaf: bytes, index: int, size: int, proof: list, root: bytes) -> bool:
    """RFC 9162 section 2.1.3.2. Needs nothing from the kernel: anyone can check."""
    if index >= size:
        return False
    fn, sn, r = index, size - 1, _h(b"\x00" + leaf)
    for p in proof:
        if sn == 0:
            return False
        if fn & 1 or fn == sn:
            r = _h(b"\x01" + p + r)
            if not fn & 1:
                while not fn & 1 and fn != 0:
                    fn >>= 1
                    sn >>= 1
        else:
            r = _h(b"\x01" + r + p)
        fn >>= 1
        sn >>= 1
    return sn == 0 and r == root


def verify_consistency(m: int, n: int, root_m: bytes, root_n: bytes, proof: list) -> bool:
    """RFC 9162 section 2.1.4.2. Proves the size-m log is a prefix of the size-n log."""
    if m == n:
        return not proof and root_m == root_n
    if not 0 < m < n or not proof and m & (m - 1):
        return False
    path = list(proof)
    if m & (m - 1) == 0:
        path = [root_m] + path
    fn, sn = m - 1, n - 1
    while fn & 1:
        fn >>= 1
        sn >>= 1
    fr = sr = path[0]
    for c in path[1:]:
        if sn == 0:
            return False
        if fn & 1 or fn == sn:
            fr = _h(b"\x01" + c + fr)
            sr = _h(b"\x01" + c + sr)
            if not fn & 1:
                while not fn & 1 and fn != 0:
                    fn >>= 1
                    sn >>= 1
        else:
            sr = _h(b"\x01" + sr + c)
        fn >>= 1
        sn >>= 1
    return fr == root_m and sr == root_n and sn == 0


def affinity_watch(rulings: list, min_cases: int = 8, margin: float = 0.25) -> list:
    """
    rulings: list of (throne_id, realm, favorable: bool).
    Flags (throne, realm) pairs whose favorable rate exceeds the throne's
    rate elsewhere by more than `margin`, given enough cases.
    """
    by_pair = defaultdict(list)
    by_throne = defaultdict(list)
    for throne, realm, fav in rulings:
        by_pair[(throne, realm)].append(fav)
        by_throne[throne].append((realm, fav))
    flags = []
    for (throne, realm), favs in by_pair.items():
        others = [f for r, f in by_throne[throne] if r != realm]
        if len(favs) < min_cases or len(others) < min_cases:
            continue
        rate, base = sum(favs) / len(favs), sum(others) / len(others)
        if rate - base > margin:
            flags.append({"throne": throne, "realm": realm, "rate": round(rate, 2), "baseline": round(base, 2)})
    return flags
