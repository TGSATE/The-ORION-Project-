import Weaver.Live
namespace Weaver.Successor

structure Proposal where
  binding : Binding
  proposer : Nat
  selfScore : Nat
  deriving DecidableEq, Repr

structure Review where
  binding : Binding
  evaluator : Nat
  protocol : Nat
  verdict : Verdict
  deriving DecidableEq, Repr

structure State where
  live : Live.State
  accepted : Binding
  reviews : List Review
  evaluators : List Nat
  protocol : Nat
  acceptanceEffect : Nat
  history : List (Binding × Bool)
  deriving DecidableEq, Repr

-- Authenticated review store and evaluator allowlist are adapter assumptions.
-- Distinct identifiers enforce role separation, not causal independence.
def Eligible (s : State) (p : Proposal) (r : Review) : Prop :=
  r ∈ s.reviews ∧ r.binding = p.binding ∧ r.evaluator ∈ s.evaluators ∧
  True ∧ r.protocol = s.protocol ∧ r.verdict = .pass

instance (s : State) (p : Proposal) (r : Review) : Decidable (Eligible s p r) :=
  inferInstanceAs (Decidable (_ ∧ _))

def Gate (s : State) (p : Proposal) (r : Review) (t : Live.Ticket) (g : Live.Lease) : Prop :=
  Eligible s p r ∧ Live.Gate s.live p.binding s.acceptanceEffect t g

instance (s p r t g) : Decidable (Gate s p r t g) :=
  inferInstanceAs (Decidable (_ ∧ _))

def attempt (s : State) (p : Proposal) (r : Review) (t : Live.Ticket) (g : Live.Lease) : State :=
  if Gate s p r t g then
    { s with
      accepted := p.binding
      live := Live.execute s.live p.binding s.acceptanceEffect t g,
      history := s.history ++ [(p.binding, true)] }
  else { s with history := s.history ++ [(p.binding, false)] }

theorem rejection_preserves_accepted (s p r t g) (h : ¬ Gate s p r t g) :
    (attempt s p r t g).accepted = s.accepted := by simp [attempt, h]

theorem rejection_preserves_live (s p r t g) (h : ¬ Gate s p r t g) :
    (attempt s p r t g).live = s.live := by simp [attempt, h]

theorem accepted_change_requires_gate (s p r t g)
    (h : (attempt s p r t g).accepted ≠ s.accepted) : Gate s p r t g := by
  by_cases hg : Gate s p r t g
  · exact hg
  · exact False.elim (h (rejection_preserves_accepted s p r t g hg))

theorem self_review_denied (s p r t g) (h : r.evaluator = p.proposer) :
    ¬ Gate s p r t g := by simp [Gate, Eligible, h]

theorem wrong_protocol_denied (s p r t g) (h : r.protocol ≠ s.protocol) :
    ¬ Gate s p r t g := by simp [Gate, Eligible, h]

theorem failed_review_denied (s p r t g) (h : r.verdict = .fail) :
    ¬ Gate s p r t g := by simp [Gate, Eligible, h]

theorem missing_review_denied (s p r t g) (h : r ∉ s.reviews) :
    ¬ Gate s p r t g := by simp [Gate, Eligible, h]

theorem no_authority_no_acceptance (s p r t g)
    (h : ¬ Live.Gate s.live p.binding s.acceptanceEffect t g) :
    (attempt s p r t g).accepted = s.accepted := by
  apply rejection_preserves_accepted
  exact fun hg => h hg.2

theorem self_score_irrelevant (s p r t g score) :
    attempt s { p with selfScore := score } r t g = attempt s p r t g := rfl

theorem attempt_preserves_grants (s p r t g) :
    (attempt s p r t g).live.leases = s.live.leases := by
  unfold attempt
  split
  · simp only [Live.execute]; split <;> rfl
  · rfl

theorem history_prefix (s p r t g) :
    ∃ suffix, (attempt s p r t g).history = s.history ++ suffix := by
  unfold attempt
  split
  · exact ⟨[(p.binding, true)], rfl⟩
  · exact ⟨[(p.binding, false)], rfl⟩

theorem failed_trial_recorded (s p r t g) (h : ¬ Gate s p r t g) :
    (p.binding, false) ∈ (attempt s p r t g).history := by simp [attempt, h]

theorem history_retained (s p r t g record) (h : record ∈ s.history) :
    record ∈ (attempt s p r t g).history := by
  obtain ⟨suffix, hs⟩ := history_prefix s p r t g
  rw [hs]
  exact List.mem_append_left _ h

theorem success_consumes_ticket (s p r t g) (h : Gate s p r t g) :
    t.id ∈ (attempt s p r t g).live.spent := by
  simp [attempt, h, Live.execute, h.2]

theorem insufficient_review_denied (s p r t g xs) (h : r.verdict = .insufficient xs) :
    ¬ Gate s p r t g := by simp [Gate, Eligible, h]

structure Request where
  proposal : Proposal
  review : Review
  ticket : Live.Ticket
  lease : Live.Lease

def run (s : State) : List Request → State
  | [] => s
  | q :: qs => run (attempt s q.proposal q.review q.ticket q.lease) qs

theorem run_preserves_grants (requests : List Request) (s : State) :
    (run s requests).live.leases = s.live.leases := by
  induction requests generalizing s with
  | nil => rfl
  | cons q qs ih =>
    exact (ih _).trans (attempt_preserves_grants s q.proposal q.review q.ticket q.lease)

theorem run_history_prefix (requests : List Request) (s : State) :
    ∃ suffix, (run s requests).history = s.history ++ suffix := by
  induction requests generalizing s with
  | nil => exact ⟨[], (List.append_nil _).symm⟩
  | cons q qs ih =>
    obtain ⟨a, ha⟩ := history_prefix s q.proposal q.review q.ticket q.lease
    obtain ⟨b, hb⟩ := ih (attempt s q.proposal q.review q.ticket q.lease)
    exact ⟨a ++ b, by simpa [run, ha, List.append_assoc] using hb⟩

theorem run_retains_failed_trial (requests : List Request) (s : State) (binding : Binding)
    (h : (binding, false) ∈ s.history) : (binding, false) ∈ (run s requests).history := by
  obtain ⟨suffix, hs⟩ := run_history_prefix requests s
  rw [hs]
  exact List.mem_append_left _ h

end Weaver.Successor
