import Weaver.Core

/- Sequential reference semantics. Initial receipts, grants, issuer identities,
   policy, epoch, and clock are supplied by a trusted adapter. No cryptography,
   concurrency, effect rollback, or authentic grant issuance is proved here. -/
namespace Weaver.Live

structure Lease where
  id : Nat
  binding : Binding
  issuer : Nat
  epoch : Nat
  start : Nat
  expiry : Nat
  effects : List Nat
  deriving DecidableEq, Repr

structure Ticket where
  id : Nat
  receipt : Receipt
  deriving DecidableEq, Repr

structure State where
  leases : List Lease
  tickets : List Ticket
  trustedIssuers : List Nat
  epoch : Nat
  policy : Nat
  now : Nat
  spent : List Nat
  executed : List (Binding × Nat)
  memories : List Nat
  deriving DecidableEq, Repr

def Gate (s : State) (b : Binding) (effect : Nat) (t : Ticket) (g : Lease) : Prop :=
  g ∈ s.leases ∧ t ∈ s.tickets ∧ g.issuer ∈ s.trustedIssuers ∧
  t.id ∉ s.spent ∧ t.receipt.verdict = .pass ∧
  t.receipt.binding = b ∧ g.binding = b ∧ b.policy = s.policy ∧
  g.epoch = s.epoch ∧ g.start ≤ s.now ∧ s.now < g.expiry ∧ True

instance (s : State) (b : Binding) (e : Nat) (t : Ticket) (g : Lease) :
    Decidable (Gate s b e t g) := inferInstanceAs (Decidable (_ ∧ _))

def check (s : State) (b : Binding) (e : Nat) (t : Ticket) (g : Lease) : Bool :=
  decide (Gate s b e t g)

def execute (s : State) (b : Binding) (e : Nat) (t : Ticket) (g : Lease) : State :=
  if Gate s b e t g then
    { s with spent := t.id :: s.spent, executed := s.executed ++ [(b, e)] }
  else s

def revoke (s : State) (id : Nat) : State :=
  { s with leases := s.leases.filter (fun g => g.id != id) }

def learn (s : State) (memory : Nat) : State :=
  { s with memories := s.memories ++ [memory] }

-- Relative monotonic advance; no event accepts a caller-supplied absolute time.
def tick (s : State) (delta : Nat) : State := { s with now := s.now + delta }
def rotate (s : State) : State := { s with epoch := s.epoch + 1 }

theorem check_correct (s b e t g) : check s b e t g = true ↔ Gate s b e t g := by
  simp [check]

theorem denied_preserves_state (s b e t g) (h : ¬ Gate s b e t g) :
    execute s b e t g = s := by simp [execute, h]

theorem execution_sound (s b e t g)
    (h : (execute s b e t g).executed ≠ s.executed) : Gate s b e t g := by
  by_cases hg : Gate s b e t g
  · exact hg
  · exact False.elim (h (congrArg State.executed (denied_preserves_state s b e t g hg)))

theorem insufficient_denied (s b e t g) (xs : List Nat)
    (h : t.receipt.verdict = .insufficient xs) : execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem failed_denied (s b e t g) (h : t.receipt.verdict = .fail) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem expired_denied (s b e t g) (h : g.expiry ≤ s.now) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, Nat.not_lt.mpr h]

theorem premature_denied (s b e t g) (h : s.now < g.start) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, Nat.not_le.mpr h]

theorem wrong_epoch_denied (s b e t g) (h : g.epoch ≠ s.epoch) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem wrong_policy_denied (s b e t g) (h : b.policy ≠ s.policy) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem wrong_binding_denied (s b e t g) (h : t.receipt.binding ≠ b) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem out_of_scope_denied (s b e t g) (h : e ∉ g.effects) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem unknown_issuer_denied (s b e t g) (h : g.issuer ∉ s.trustedIssuers) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem empty_ledger_denied (s b e t g) (h : s.tickets = []) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem empty_authority_denied (s b e t g) (h : s.leases = []) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem spent_denied (s b e t g) (h : t.id ∈ s.spent) :
    execute s b e t g = s := by
  apply denied_preserves_state
  simp [Gate, h]

theorem consume_once (s b e t g) :
    execute (execute s b e t g) b e t g = execute s b e t g := by
  by_cases h : Gate s b e t g
  · apply spent_denied
    simp [execute, h]
  · simp [execute, h]

theorem revoked_id_absent (s : State) (g : Lease) :
    g ∉ (revoke s g.id).leases := by simp [revoke]

theorem revoke_blocks_execution (s b e t g) :
    execute (revoke s g.id) b e t g = revoke s g.id := by
  apply denied_preserves_state
  exact fun h => revoked_id_absent s g h.1

theorem rotate_blocks_old_epoch (s b e t g) (h : g.epoch = s.epoch) :
    execute (rotate s) b e t g = rotate s := by
  apply wrong_epoch_denied
  simp [rotate, h]

theorem clock_monotonic (s : State) (delta : Nat) : s.now ≤ (tick s delta).now := by
  simp [tick]

theorem learn_preserves_gate (s b e t g memory) :
    Gate (learn s memory) b e t g ↔ Gate s b e t g := Iff.rfl

theorem learn_preserves_authority (s : State) (memory : Nat) :
    (learn s memory).leases = s.leases := rfl

theorem learn_retains_history (s : State) (memory x : Nat) (h : x ∈ s.memories) :
    x ∈ (learn s memory).memories := by simp [learn, h]

inductive Event where
  | attempt (binding : Binding) (effect : Nat) (ticket : Ticket) (lease : Lease)
  | revoke (id : Nat)
  | learn (memory : Nat)
  | tick (delta : Nat)
  | rotate
  deriving Repr

def step (s : State) : Event → State
  | .attempt b e t g => execute s b e t g
  | .revoke id => revoke s id
  | .learn m => learn s m
  | .tick d => tick s d
  | .rotate => rotate s

def replay (s : State) : List Event → State
  | [] => s
  | e :: es => replay (step s e) es

theorem step_no_authority_growth (s : State) (e : Event) (g : Lease)
    (h : g ∈ (step s e).leases) : g ∈ s.leases := by
  cases e with
  | attempt b ef t lease =>
    simp only [step, execute] at h
    split at h <;> exact h
  | revoke id => exact (List.mem_filter.mp h).1
  | learn m => exact h
  | tick d => exact h
  | rotate => exact h

theorem replay_no_authority_growth (es : List Event) (s : State) (g : Lease)
    (h : g ∈ (replay s es).leases) : g ∈ s.leases := by
  induction es generalizing s with
  | nil => exact h
  | cons e es ih => exact step_no_authority_growth s e g (ih (step s e) h)

theorem revoked_stays_absent (es : List Event) (s : State) (g : Lease) :
    g ∉ (replay (revoke s g.id) es).leases := by
  intro h
  exact revoked_id_absent s g (replay_no_authority_growth es _ g h)

theorem replay_append (xs ys : List Event) (s : State) :
    replay s (xs ++ ys) = replay (replay s xs) ys := by
  induction xs generalizing s with
  | nil => rfl
  | cons e es ih => exact ih (step s e)

theorem step_retains_spent (s : State) (e : Event) (id : Nat)
    (h : id ∈ s.spent) : id ∈ (step s e).spent := by
  cases e with
  | attempt b ef t g =>
    simp only [step, execute]
    split
    · exact List.mem_cons_of_mem _ h
    · exact h
  | revoke n => exact h
  | learn m => exact h
  | tick d => exact h
  | rotate => exact h

theorem replay_retains_spent (es : List Event) (s : State) (id : Nat)
    (h : id ∈ s.spent) : id ∈ (replay s es).spent := by
  induction es generalizing s with
  | nil => exact h
  | cons e es ih => exact ih (step s e) (step_retains_spent s e id h)

theorem spent_never_reauthorized (es : List Event) (s b e t g)
    (h : t.id ∈ s.spent) :
    execute (replay s es) b e t g = replay s es := by
  exact spent_denied _ b e t g (replay_retains_spent es s t.id h)

theorem revoked_never_reauthorized (es : List Event) (s b e t g) :
    execute (replay (revoke s g.id) es) b e t g = replay (revoke s g.id) es := by
  apply denied_preserves_state
  exact fun h => revoked_stays_absent es s g h.1

end Weaver.Live
