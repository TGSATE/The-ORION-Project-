# Weaver Formal Core v0.3

2026-10-05. A locally checked abstract reference model. W0 / O0 WITHHELD.
Production PROHIBITED. No runtime refinement or independent reproduction claimed.

This release adds 33 named theorems to v0.2: 87 total, plus 39 concrete
kernel-checked examples. The inherited Core, Live, Support, and Fixtures sources
are unchanged. There are no external Lean dependencies; the toolchain is pinned
to Lean 4.22.0. Exact declarations and axiom dependencies are inventoried in
`THEOREMS.json` and `evidence/verification.json`.

## New formalization

| Module | Result | Explicit limit |
|---|---|---|
| Delegation | Permission attenuation is reflexive and transitive; child permissions imply parent permissions | Relation on exact identity, epoch, time window, and effect set; no issuer/subject authentication |
| Delegation | Every modeled chain ancestor must remain live; ancestor revocation blocks the chain persistently | Separate `AuthorizedChain` predicate; not installed into `Live.execute`; no grant issuance |
| Successor | Changing the accepted binding requires a recorded PASS review and the existing live acceptance grant | Trusted input stores, evaluator allowlist, configured protocol and acceptance-effect ID |
| Successor | Self-review, wrong protocol, FAIL, INSUFFICIENT, or missing review deny acceptance | Distinct IDs do not establish causal independence or trustworthy evaluation |
| Successor | Self-score has no influence; acceptance consumes the authorization ticket; grants remain unchanged | Candidate identity is a Binding, not a trained model or runtime deployment |
| Successor | Failed trials are recorded and retained; histories remain prefixes across arbitrarily long request sequences | In-memory event semantics, not durable crash-safe persistence |
| History | Execution history remains a prefix under every modeled event trace | Does not authenticate historical entries or hash chains |
| History | Time never decreases across a trace; expired grants remain unusable | Trusted integer clock and restricted event language; no restore/rollback operation |

The successor model composes directly with `Live.Gate` and `Live.execute`.
Its `acceptanceEffect` is supplied by the trusted configuration and must denote
successor acceptance in a real adapter. A receipt/grant must bind the proposed
artifact, policy, experiment, and action. Rejected attempts preserve the accepted
binding and full live state but append a negative trial record, intentionally.
The model does not infer a grant from a favorable review.

Delegation adds a relation and a chain-level policy obligation. **Existing
`Live.execute` still checks only a single lease.** A runtime adapter implementing
delegated execution must enforce `AuthorizedChain` at its consumption point;
ancestor revocation is not inherited automatically by the old execution API.
`ChainValid` checks list structure and attenuation, not signatures, parent IDs,
unique IDs, acyclicity, or whether an issuer is entitled to delegate. Duplicate
list entries are permitted by the current definition. These are open lifecycle
and provenance obligations, not hidden assumptions of a complete delegation system.

The successor request runner does not model interleaved clock/revocation events.
A caller can update its nested live state before an attempt; a combined concurrent
or interleaved controller and its correspondence proof remain future work.

## Reproduce and inspect

With the pinned Lean toolchain and Python 3 installed:

```sh
python3 verify.py
python3 mutations.py
```

The verifier cleans `.lake/build`, builds every imported module and example,
checks all named proofs with `lake env lean -t 0 Audit.lean`, and requires the
theorem registry to exactly match source declarations. It rejects proof shortcuts
and any axiom dependency outside `propext`, `Quot.sound`, and `Classical.choice`.
Per-theorem dependencies, source hashes, and build/audit logs are preserved.
No `sorryAx` is permitted. This script audits this fixed package layout; it is
not a general secure verifier for arbitrary adversarial Lean projects.

Fourteen targeted mutation probes cover eight inherited guards and six new
successor/delegation obligations. A kill requires a compilation error inside
the designated proof; syntax/unknown-name failures are rejected as invalid probes.
Mutation sources intentionally fail compilation and live outside the import graph.
These probes are local diagnostics, not an exhaustive or independent audit.

This host still requires the application-path compatibility shim used for v0.2.
It supplies a configured executable path without reading procfs, with the
official Lean kernel/elaborator binaries unchanged. The local evidence records
the shim's use. See `docs/README-v0.2.md` for the exact optional setup commands
and the inherited model boundaries. Its release counts and status describe v0.2
only. A fresh ordinary-host build without the shim is still unperformed here.

## Provenance and remaining work

Parent: `weaver-formal-core-v0.2-lean-verified.zip`, SHA-256
`62562f3aa09f96935357ba70a70a88b422fd193ad2f1c290dda1b0768cf8a2a9`.
The source requirements remain the Academy formalization specification read for
v0.2, especially I3/I4/I7/I8 and the bounded successor acceptance rule. Delegation
attenuation is an additional candidate relation formalizing permission narrowing;
it is not a proof of the Sift implementation.

The largest next obligations are authentic grant issuance and parent provenance,
runtime state/transition refinement, a combined controller with a revocation
linearization point, durable authenticated history and freshness anchors, and
independent exact-byte reproduction. E4 facets remain unspecified/unformalized.
No claim about general RSI, empirical improvement, AGI/ASI, or production safety
follows from these proofs. No GitHub repository was modified by this release.
