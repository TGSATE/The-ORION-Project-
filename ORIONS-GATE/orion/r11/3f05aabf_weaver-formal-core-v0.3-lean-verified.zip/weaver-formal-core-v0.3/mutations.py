#!/usr/bin/env python3
"""Targeted source mutations; require an error inside the intended proof."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'evidence' / 'mutations'
OUT.mkdir(parents=True, exist_ok=True)
CASES = [
    ('expiry_removed', 'Live', 's.now < g.expiry', 'True', 'expired_denied'),
    ('start_removed', 'Live', 'g.start ≤ s.now', 'True', 'premature_denied'),
    ('spent_gate_removed', 'Live', 't.id ∉ s.spent', 'True', 'spent_denied'),
    ('scope_removed', 'Live', 'effect ∈ g.effects', 'True', 'out_of_scope_denied'),
    ('epoch_removed', 'Live', 'g.epoch = s.epoch ∧ g.start', 'True ∧ g.start', 'wrong_epoch_denied'),
    ('revocation_disabled', 'Live', 'g.id != id', 'true', 'revoked_id_absent'),
    ('clock_can_rewind', 'Live', 'now := s.now + delta', 'now := delta', 'clock_monotonic'),
    ('empty_support_allowed', 'Support', 'path ≠ [] ∧', 'True ∧', 'empty_path_denied'),
    ('self_review_allowed', 'Successor', 'r.evaluator ≠ p.proposer ∧', 'True ∧', 'self_review_denied'),
    ('protocol_gate_removed', 'Successor', 'r.protocol = s.protocol ∧', 'True ∧', 'wrong_protocol_denied'),
    ('failed_review_allowed', 'Successor', 'r.verdict = .pass', 'True', 'failed_review_denied'),
    ('review_membership_removed', 'Successor', 'r ∈ s.reviews ∧', 'True ∧', 'missing_review_denied'),
    ('failure_erases_history', 'Successor', 'else { s with history := s.history ++ [(p.binding, false)] }',
     'else { s with history := [] }', 'failed_trial_recorded'),
    ('delegation_scope_widened', 'Delegation', '∀ e ∈ child.effects, e ∈ parent.effects', 'True',
     'child_permission_implies_parent'),
]

def main():
    results = []
    for label, module, old, new, target in CASES:
        original = (ROOT/'Weaver'/f'{module}.lean').read_text()
        if original.count(old) != 1:
            raise RuntimeError('Mutation target not unique: ' + label)
        mutated = original.replace(old, new)
        path = OUT / f'{label}.lean'
        path.write_text(mutated)
        lines = mutated.splitlines()
        start = next(i+1 for i,s in enumerate(lines) if s.startswith('theorem '+target+' '))
        end = next((i+1 for i in range(start,len(lines)) if lines[i].startswith(('theorem ','end '))),len(lines)+1)
        p = subprocess.run(['lake','env','lean',str(path)],cwd=ROOT,text=True,
                           stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (OUT/f'{label}.log').write_text(p.stdout)
        error_lines = [int(n) for n in re.findall(r':(\d+):\d+: error:',p.stdout)]
        killed = p.returncode != 0 and any(start <= n < end for n in error_lines)
        # Parser/name errors do not constitute a successful semantic probe.
        killed = killed and not any(x in p.stdout for x in ['unexpected token','unknown identifier','unknown tactic'])
        results.append({'mutation':label,'expected_proof':target,'status':'KILLED' if killed else 'FAIL',
                        'returncode':p.returncode,'source_sha256':hashlib.sha256(mutated.encode()).hexdigest()})
    report = {'status':'PASS' if all(r['status']=='KILLED' for r in results) else 'FAIL',
              'scope':'Fourteen targeted semantic source mutations, not exhaustive robustness', 'results':results}
    (ROOT/'evidence'/'mutations.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 1

if __name__ == '__main__':
    sys.exit(main())
