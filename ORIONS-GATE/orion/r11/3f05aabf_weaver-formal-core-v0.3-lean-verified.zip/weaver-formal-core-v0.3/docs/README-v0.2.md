# Weaver Formal Core v0.2 — live consumption and evidence scope

2026-10-05. Local abstract-model verification. W0; O0 WITHHELD; production PROHIBITED.

This package extends the recovered Formal Core v0.1 with 37 named theorems,
for 54 total, and 15 new kernel-checked concrete examples (25 including the
inherited examples). It preserves the original `Core.lean` bytes and namespace.
It is a separate candidate extension, not an update to a GitHub branch or a
claim that the portfolio's runtime implementations satisfy these definitions.

## What is formalized

| Area | Mechanically checked result | Boundary |
|---|---|---|
| Consumption gate | Membership, PASS, full binding, live policy and epoch, start/expiry, issuer allowlist, effect scope, unspent ticket | Adapter supplies authentic initial state; identity is exact Nat equality |
| Rejection | A denied execution leaves the entire modeled state unchanged | No external effects or concurrent processes |
| Revocation | Removing a lease ID blocks execution; that lease cannot return through any modeled event trace | Event language has no issuance/regrant operation |
| Single use | Repeating a consumed ticket cannot execute; spent IDs survive any modeled event trace | No coherent rollback of the initial state; IDs must be assigned faithfully |
| Learning | Memory updates preserve grants and the entire authorization predicate; existing memory items remain present | Memory is an abstract list of Nat records |
| Replay | Replay composes across concatenated event lists; grants never grow | Deterministic transition replay, not hash-chain validation |
| Clock | Relative tick cannot rewind time; start and expiry gates reject invalid windows | Trusted tick source and integer time; no clock authenticity proof |
| Evidence | Empirical support requires a nonempty path; invalidation cannot create support; unrelated paths retain support | Already-expanded evidence leaves, no cyclic graph resolution |

`Gate` is a declarative proposition and `check` uses `decide Gate`. Its equivalence
theorem checks this executable wrapper, not an independently implemented policy
engine. The more substantive trace theorems concern persistent revocation,
persistent spent IDs, and absence of authority growth.

The new live state is an explicit reference design. Its epoch and time are read
from state rather than accepted from an execution caller. `revoke`, `tick`, and
`rotate` represent trusted control-plane transitions; their caller authorization
is outside this model. There is no receipt-ingestion or grant-issuance operation.
The receipt list retains spent records, while a separate spent-ID list denies reuse.
An ID collision conservatively denies reuse; uniqueness and authentic issuance
remain adapter obligations.

## Reproduce

Install the official toolchain pinned in `lean-toolchain` using your normal Lean
installation. Python 3 is needed for the evidence scripts; mathlib is not used.

```sh
python3 verify.py
python3 mutations.py
```

`verify.py` removes only this package's generated `.lake/build`, performs a fresh
`lake build`, then runs `lake env lean -t 0 Audit.lean`. It requires all 54 axiom
reports and rejects proof shortcuts or dependencies outside the standard allowlist
`propext`, `Quot.sound`, `Classical.choice`. All three occur in this build; exact
per-theorem lists are in `evidence/verification.json`. None uses `sorryAx`.
The build includes the 25 concrete examples. `Audit.lean` prints dependencies of
all named theorems, not separate per-example reports.

The theorem count is an inventory, not a measure of system assurance. Generic
lemmas, guard rejection theorems, and inductive trace results are distinguished
by their source and statements in `THEOREMS.json` and the Lean files.

`mutations.py` makes eight isolated source variants and requires each one to fail
inside its named target proof. Syntax errors and unknown-name errors do not count
as kills. The unmodified clean build is the positive control. Mutant files under
`evidence/mutations/` intentionally do not compile and are excluded from the
package import graph. These are targeted probes, not exhaustive mutation coverage.

## Local environment compatibility

This host denied Lean's `/proc/<own-pid>/exe` lookup. The included optional
`compat/lean_app_path.c` supplies an explicitly configured executable path without
reading procfs. It does not modify Lean's kernel, elaborator, proof terms, or
type-checking result. It delegates all unrelated readlink calls unchanged.
The local run used the official Lean 4.22.0 release binaries with this shim.
This extra runtime component is part of the local reproduction boundary;
an ordinary-host reproduction without it remains desirable and is not claimed.

Only if your environment has the same application-path issue:

```sh
cc -shared -fPIC compat/lean_app_path.c -ldl -o compat/lean_app_path.so
# Set this to the actual downloaded Lean binary, not an elan proxy:
export WEAVER_LEAN_EXECUTABLE=/absolute/toolchain/bin/lean
export LD_PRELOAD="$PWD/compat/lean_app_path.so"
export PATH="$(dirname "$WEAVER_LEAN_EXECUTABLE"):$PATH"
python3 verify.py
python3 mutations.py
```

## Source lineage

- Parent: `WEAVER_FORMAL_CORE_v0.1_2026-09-22.zip`, Library ID
  `libfile_a8179007046481918a79378b9d0a5fd5`.
- Parent archive SHA-256:
  `aa9b238391fb6afdcb80937c608988c0104772879f1a5761dc38f66ac4231b0b`.
- `Weaver/Core.lean` is byte-identical to the recovered parent's `Core.lean`.
  Its 17 named theorems were recompiled here under 4.22.0. The parent originally
  pinned 4.19.0; this package does not claim a new 4.19.0 reproduction.
- Requirements: `PROTO_ASI_ACADEMY_FORMALIZATION_v0.1_2026-09-23.md`, Library ID
  `libfile_f9eac3c22f5c8191aca2301aca4b3d92`, read in full on 2026-10-05.
  Sections 2–4 motivate live authorization, authority separation, and nonempty
  empirical support; single-use consumption is a deliberately stricter candidate
  design addition, not asserted to be present in the original Core.
- This is separate from `LatticeCore/Deflation.lean` and its 16 generic theorems.
  No E4 facet taxonomy, facet meet, or evidence-level promotion has been added.

## Remaining obligations

1. Freeze a concrete runtime adapter and show its state/transition correspondence
   to this model, including receipt ingestion, issuer validation, and ID assignment.
2. Define the runtime execution linearization point and solve the revocation race.
   These sequential proofs do not cancel already committed physical effects.
3. Prove or test authentic history, external checkpoint freshness, rollback
   detection, and real hash/serialization binding. The Chronicle stale-hash
   counterexample is not closed by this work.
4. Add an explicitly authorized issuance/regrant language before claiming this
   model covers a full grant lifecycle. Revisit the no-growth theorem accordingly.
5. Formalize successor acceptance after specifying the evaluator and owner
   interfaces. This package does not prove evaluator independence or learning gains.
6. Define the evidence taxonomy before attempting E4 facet meet laws.
7. Independently reproduce exact packaged bytes on an ordinary host.

There is no proof here of AGI, ASI, general RSI, consciousness, learned moral
restraint, safe autonomous deployment, or cryptographic security.
