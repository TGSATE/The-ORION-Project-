#!/usr/bin/env python3
"""Clean local reproduction; exit nonzero on any missing or failed gate."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)

def run(args, log):
    p = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / log).write_text(p.stdout)
    if p.returncode:
        print(p.stdout)
        raise RuntimeError(f'{args} exited {p.returncode}')
    return p.stdout

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    version = run(['lean', '--version'], 'version.log').strip()
    if not re.search(r'version 4\.22\.0[, )]', version):
        raise RuntimeError('Expected Lean 4.22.0')
    for p in list((ROOT / 'Weaver').glob('*.lean')) + [ROOT / 'Weaver.lean', ROOT / 'Audit.lean']:
        if re.search(r'\b(sorry|admit|axiom|native_decide|unsafe)\b', p.read_text()):
            raise RuntimeError(f'Forbidden proof shortcut in {p.name}')
    # This directory is generated output owned by this package.
    shutil.rmtree(ROOT / '.lake' / 'build', ignore_errors=True)
    run(['lake', 'build'], 'build.log')
    audit = run(['lake', 'env', 'lean', '-t', '0', 'Audit.lean'], 'axioms.log')
    registry = json.loads((ROOT / 'THEOREMS.json').read_text())
    discovered = set()
    for source in (ROOT / 'Weaver').glob('*.lean'):
        text = source.read_text()
        namespace = re.search(r'^namespace ([\w.]+)', text, re.M)
        names = re.findall(r'^theorem (\w+)', text, re.M)
        if names and not namespace:
            raise RuntimeError('Missing namespace in ' + source.name)
        discovered.update(namespace.group(1) + '.' + name for name in names)
    if discovered != {t['name'] for t in registry} or len(registry) != len(discovered):
        raise RuntimeError('Theorem registry does not cover the source declarations exactly')
    allowed = {'propext', 'Quot.sound', 'Classical.choice'}
    rows = []
    for t in registry:
        match = re.search("'" + re.escape(t['name']) + "' (?:does not depend on any axioms|depends on axioms: \\[([^\\]]*)\\])", audit)
        if not match:
            raise RuntimeError('Missing axiom report: ' + t['name'])
        axioms = [] if not match.group(1) else [x.strip() for x in match.group(1).split(',')]
        if set(axioms) - allowed:
            raise RuntimeError('Unapproved axioms: ' + str(axioms))
        rows.append({**t, 'axioms': axioms})
    inputs = [p for p in ROOT.rglob('*') if p.is_file() and
              '.lake' not in p.parts and 'evidence' not in p.parts and p.suffix != '.so'
              and p.name != 'MANIFEST.sha256']
    receipt = {
        'status': 'PASS', 'claim': 'Local abstract Lean semantics only',
        'lean': version, 'trust_level_audit': 0,
        'theorem_count': len(rows), 'new_theorem_count': sum(t['origin'] == 'new' for t in rows),
        'axiom_dependencies': rows,
        'compatibility_path_override': bool(os.environ.get('WEAVER_LEAN_EXECUTABLE')),
        'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sorted(inputs)},
        'log_sha256': {n: digest(OUT/n) for n in ['build.log','axioms.log','version.log']},
        'independent_reproduction': False,
        'runtime_correspondence': False, 'witness': 'W0', 'authority': 'O0 WITHHELD'
    }
    (OUT / 'verification.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(f'PASS: {len(rows)} named theorems; {receipt["new_theorem_count"]} new; no unapproved axioms.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        (OUT / 'verification.json').write_text(json.dumps({'status':'FAIL','reason':str(exc)},indent=2)+'\n')
        print(str(exc), file=sys.stderr)
        sys.exit(1)
