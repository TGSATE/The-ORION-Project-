import Weaver.Live
import Weaver.Support
namespace Weaver.Live.Fixtures
def binding : Binding := ⟨1, 2, 3, 4⟩
def ticket : Ticket := ⟨10, ⟨binding, .pass⟩⟩
def lease : Lease := ⟨7, binding, 42, 0, 5, 20, [8]⟩
def initial : State := ⟨[lease], [ticket], [42], 0, 2, 10, [], [], []⟩

example : check initial binding 8 ticket lease = true := by decide
example : (execute initial binding 8 ticket lease).executed = [(binding, 8)] := by decide
example : (replay initial [.attempt binding 8 ticket lease,
    .learn 999, .attempt binding 8 ticket lease]).executed = [(binding, 8)] := by decide
example : (replay initial [.revoke 7, .learn 999,
    .attempt binding 8 ticket lease]).executed = [] := by decide
example : (replay initial [.tick 10, .attempt binding 8 ticket lease]).executed = [] := by decide
example : (replay initial [.rotate, .attempt binding 8 ticket lease]).executed = [] := by decide
example : check { initial with now := 4 } binding 8 ticket lease = false := by decide
example : check initial binding 9 ticket lease = false := by decide
example : check { initial with policy := 99 } binding 8 ticket lease = false := by decide
example : check { initial with trustedIssuers := [] } binding 8 ticket lease = false := by decide
example : check { initial with tickets := [] } binding 8 ticket lease = false := by decide
example : check { initial with leases := [] } binding 8 ticket lease = false := by decide
example : check initial { binding with experiment := 99 } 8 ticket lease = false := by decide
example : check initial binding 8 { ticket with receipt := ⟨binding, .insufficient []⟩ }
    lease = false := by decide
-- A duplicate ticket ID cannot be spent again even if an alternative record exists.
example : check { initial with spent := [ticket.id] } binding 8 ticket lease = false := by decide
end Weaver.Live.Fixtures
