import Weaver.Core
namespace Weaver.Empirical

-- Empty conjunctions remain mathematically true in Core. Empirical claims
-- require at least one evidence leaf on the surviving support path.
def Supported (paths : Weaver.Supports) (valid : Nat → Prop) : Prop :=
  ∃ path ∈ paths, path ≠ [] ∧ ∀ e ∈ path, valid e

theorem empty_path_denied (valid : Nat → Prop) : ¬ Supported [[]] valid := by
  simp [Supported]

theorem no_paths_denied (valid : Nat → Prop) : ¬ Supported [] valid := by
  simp [Supported]

theorem refines_core (paths valid) : Supported paths valid → Weaver.Supported paths valid := by
  rintro ⟨p, hp, _, hv⟩
  exact ⟨p, hp, hv⟩

theorem invalidation_no_promotion (paths valid bad) :
    Supported paths (Weaver.invalidate bad valid) → Supported paths valid := by
  rintro ⟨p, hp, hn, hv⟩
  exact ⟨p, hp, hn, fun e he => (hv e he).1⟩

theorem required_dependency_invalidates (paths valid bad)
    (h : ∀ p ∈ paths, bad ∈ p) : ¬ Supported paths (Weaver.invalidate bad valid) := by
  intro hs
  exact Weaver.required_dependency_invalidates paths valid bad h (refines_core _ _ hs)

theorem unrelated_unchanged (paths valid bad) (hscope : ∀ p ∈ paths, bad ∉ p) :
    Supported paths (Weaver.invalidate bad valid) ↔ Supported paths valid := by
  constructor
  · exact invalidation_no_promotion paths valid bad
  · rintro ⟨p, hp, hn, hv⟩
    refine ⟨p, hp, hn, ?_⟩
    intro e he
    refine ⟨hv e he, ?_⟩
    intro eq
    subst e
    exact hscope p hp he

end Weaver.Empirical
