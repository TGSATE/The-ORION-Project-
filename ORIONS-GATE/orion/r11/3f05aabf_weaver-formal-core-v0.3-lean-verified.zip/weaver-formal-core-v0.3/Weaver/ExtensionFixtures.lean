import Weaver.Fixtures
import Weaver.Delegation
import Weaver.Successor
import Weaver.History
namespace Weaver.ExtensionFixtures
open Live.Fixtures

def proposal : Successor.Proposal := ⟨binding, 42, 1000⟩
def review : Successor.Review := ⟨binding, 43, 17, .pass⟩
def state : Successor.State := ⟨initial, ⟨0,0,0,0⟩, [review], [43], 17, 8, []⟩

example : (Successor.attempt state proposal review ticket lease).accepted = binding := by decide
example : (Successor.attempt state proposal review ticket lease).live.spent = [10] := by decide
example : (Successor.attempt state proposal review ticket lease).history = [(binding,true)] := by decide
example : (Successor.attempt { state with live := { initial with leases := [] } }
    proposal review ticket lease).accepted = state.accepted := by decide
example : (Successor.attempt { state with protocol := 99 }
    proposal review ticket lease).history = [(binding,false)] := by decide
example : (Successor.attempt state { proposal with proposer := 43 }
    review ticket lease).accepted = state.accepted := by decide
example : (Successor.attempt state { proposal with selfScore := 0 }
    review ticket lease).accepted = binding := by decide
example : (Successor.attempt (Successor.attempt state proposal review ticket lease)
    proposal review ticket lease).history = [(binding,true),(binding,false)] := by decide
example : (Successor.attempt { state with reviews := [] } proposal review ticket lease).accepted
    = state.accepted := by decide
example : (Successor.attempt { state with evaluators := [] } proposal review ticket lease).accepted
    = state.accepted := by decide

def parent : Live.Lease := { lease with id := 77, start := 0, expiry := 30, effects := [8,9] }
def delegatedState : Live.State := { initial with leases := [lease,parent] }
example : Delegation.Attenuates lease parent := by
  simp [Delegation.Attenuates, lease, parent]
example : Delegation.ChainValid delegatedState [lease,parent] := by
  simp [Delegation.ChainValid, delegatedState, Delegation.Attenuates, lease, parent]
example : ¬ Delegation.ChainValid (Live.revoke delegatedState parent.id) [lease,parent] := by
  exact Delegation.revoked_ancestor_blocks_chain _ _ parent (by simp)
example : ¬ Delegation.Attenuates { lease with effects := [10] } parent := by
  simp [Delegation.Attenuates, lease, parent]
end Weaver.ExtensionFixtures
