import Weaver.Live
namespace Weaver.Delegation

-- Permission attenuation only. This relation does not authenticate issuance.
def Attenuates (child parent : Live.Lease) : Prop :=
  child.binding = parent.binding ∧ child.epoch = parent.epoch ∧
  parent.start ≤ child.start ∧ child.expiry ≤ parent.expiry ∧
  ∀ e ∈ child.effects, e ∈ parent.effects

theorem attenuation_refl (g : Live.Lease) : Attenuates g g := by
  exact ⟨rfl, rfl, Nat.le_refl _, Nat.le_refl _, fun _ h => h⟩

theorem attenuation_trans (a b c : Live.Lease)
    (hab : Attenuates a b) (hbc : Attenuates b c) : Attenuates a c := by
  exact ⟨hab.1.trans hbc.1, hab.2.1.trans hbc.2.1,
    Nat.le_trans hbc.2.2.1 hab.2.2.1,
    Nat.le_trans hab.2.2.2.1 hbc.2.2.2.1,
    fun e he => hbc.2.2.2.2 e (hab.2.2.2.2 e he)⟩

def Permits (g : Live.Lease) (b : Binding) (epoch now effect : Nat) : Prop :=
  g.binding = b ∧ g.epoch = epoch ∧ g.start ≤ now ∧ now < g.expiry ∧ effect ∈ g.effects

theorem child_permission_implies_parent (child parent b epoch now effect)
    (h : Attenuates child parent) (hp : Permits child b epoch now effect) :
    Permits parent b epoch now effect := by
  exact ⟨h.1.symm.trans hp.1, h.2.1.symm.trans hp.2.1,
    Nat.le_trans h.2.2.1 hp.2.2.1,
    Nat.lt_of_lt_of_le hp.2.2.2.1 h.2.2.2.1, h.2.2.2.2 effect hp.2.2.2.2⟩

-- A chain is supplied leaf first. Every ancestor must be live at consumption.
def ChainValid (s : Live.State) : List Live.Lease → Prop
  | [] => False
  | [g] => g ∈ s.leases
  | child :: parent :: rest =>
      child ∈ s.leases ∧ Attenuates child parent ∧ ChainValid s (parent :: rest)

theorem chain_member_live (s : Live.State) (chain : List Live.Lease)
    (h : ChainValid s chain) (g : Live.Lease) (hg : g ∈ chain) : g ∈ s.leases := by
  induction chain with
  | nil => exact False.elim h
  | cons a rest ih =>
    cases rest with
    | nil => simpa using (List.mem_singleton.mp hg ▸ h)
    | cons b tail =>
      rcases List.mem_cons.mp hg with heq | hin
      · subst g; exact h.1
      · exact ih h.2.2 hin

theorem revoked_ancestor_blocks_chain (s : Live.State) (chain : List Live.Lease)
    (g : Live.Lease) (hg : g ∈ chain) : ¬ ChainValid (Live.revoke s g.id) chain := by
  intro h
  exact Live.revoked_id_absent s g (chain_member_live _ chain h g hg)

theorem revoked_ancestor_stays_blocked (s : Live.State) (chain : List Live.Lease)
    (g : Live.Lease) (hg : g ∈ chain) (events : List Live.Event) :
    ¬ ChainValid (Live.replay (Live.revoke s g.id) events) chain := by
  intro h
  exact Live.revoked_stays_absent events s g (chain_member_live _ chain h g hg)

theorem empty_chain_denied (s : Live.State) : ¬ ChainValid s [] := by
  exact fun h => h

def AuthorizedChain (s : Live.State) (b : Binding) (effect : Nat)
    (ticket : Live.Ticket) (leaf : Live.Lease) (ancestors : List Live.Lease) : Prop :=
  Live.Gate s b effect ticket leaf ∧ ChainValid s (leaf :: ancestors)

theorem delegated_execution_requires_live_gate (s b effect ticket leaf ancestors)
    (h : AuthorizedChain s b effect ticket leaf ancestors) :
    Live.Gate s b effect ticket leaf := h.1

theorem revoked_ancestor_denies_delegated_authorization (s b effect ticket leaf ancestors g)
    (hg : g ∈ leaf :: ancestors) :
    ¬ AuthorizedChain (Live.revoke s g.id) b effect ticket leaf ancestors := by
  intro h
  exact revoked_ancestor_blocks_chain s _ g hg h.2

end Weaver.Delegation
