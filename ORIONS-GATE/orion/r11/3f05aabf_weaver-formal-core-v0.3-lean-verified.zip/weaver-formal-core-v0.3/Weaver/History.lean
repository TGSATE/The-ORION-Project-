import Weaver.Live
namespace Weaver.History

theorem step_execution_prefix (s : Live.State) (event : Live.Event) :
    ∃ suffix, (Live.step s event).executed = s.executed ++ suffix := by
  cases event with
  | attempt b e t g =>
    simp only [Live.step, Live.execute]
    split
    · exact ⟨[(b,e)], rfl⟩
    · exact ⟨[], (List.append_nil _).symm⟩
  | revoke id => exact ⟨[], (List.append_nil _).symm⟩
  | learn m => exact ⟨[], (List.append_nil _).symm⟩
  | tick d => exact ⟨[], (List.append_nil _).symm⟩
  | rotate => exact ⟨[], (List.append_nil _).symm⟩

theorem replay_execution_prefix (events : List Live.Event) (s : Live.State) :
    ∃ suffix, (Live.replay s events).executed = s.executed ++ suffix := by
  induction events generalizing s with
  | nil => exact ⟨[], (List.append_nil _).symm⟩
  | cons e es ih =>
    obtain ⟨a, ha⟩ := step_execution_prefix s e
    obtain ⟨b, hb⟩ := ih (Live.step s e)
    exact ⟨a ++ b, by simpa [Live.replay, ha, List.append_assoc] using hb⟩

theorem execution_record_retained (events : List Live.Event) (s : Live.State) (record)
    (h : record ∈ s.executed) : record ∈ (Live.replay s events).executed := by
  obtain ⟨suffix, hs⟩ := replay_execution_prefix events s
  rw [hs]
  exact List.mem_append_left _ h

theorem step_clock_monotonic (s : Live.State) (e : Live.Event) :
    s.now ≤ (Live.step s e).now := by
  cases e with
  | attempt b ef t g =>
    simp only [Live.step, Live.execute]; split <;> exact Nat.le_refl _
  | tick d => exact Live.clock_monotonic s d
  | revoke id => exact Nat.le_refl _
  | learn m => exact Nat.le_refl _
  | rotate => exact Nat.le_refl _

theorem replay_clock_monotonic (events : List Live.Event) (s : Live.State) :
    s.now ≤ (Live.replay s events).now := by
  induction events generalizing s with
  | nil => exact Nat.le_refl _
  | cons e es ih => exact Nat.le_trans (step_clock_monotonic s e) (ih (Live.step s e))

theorem expiry_persistent (events : List Live.Event) (s b e t g)
    (h : g.expiry ≤ s.now) :
    Live.execute (Live.replay s events) b e t g = Live.replay s events := by
  exact Live.expired_denied _ b e t g (Nat.le_trans h (replay_clock_monotonic events s))

end Weaver.History
