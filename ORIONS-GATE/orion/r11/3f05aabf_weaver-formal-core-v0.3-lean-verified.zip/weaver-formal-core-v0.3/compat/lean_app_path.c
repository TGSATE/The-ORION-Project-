#define _GNU_SOURCE
#include <unistd.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/* Provide an explicitly configured application path, without reading procfs. */
ssize_t readlink(const char *path, char *buf, size_t size) {
    char own[80];
    snprintf(own, sizeof(own), "/proc/%d/exe", (int)getpid());
    const char *configured = getenv("WEAVER_LEAN_EXECUTABLE");
    if (configured && strcmp(path, own) == 0) {
        size_t n = strlen(configured);
        if (n > size) n = size;
        memcpy(buf, configured, n);
        return (ssize_t)n;
    }
    ssize_t (*real_readlink)(const char *, char *, size_t) = dlsym(RTLD_NEXT, "readlink");
    return real_readlink(path, buf, size);
}
