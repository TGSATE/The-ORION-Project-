# Negative findings — WN-XWK-001 v0.3.0

## Status at v0.3.0

| | finding | v0.3.0 |
|---|---|---|
| D2 | (LatticeCore conformance run 1) facets collapsed to ordinal 4: 150 translation cases, 64 portfolio-ceiling cases, G-06 composites of two facets reading E4 | **closed** — levels and the lattice meet throughout; conformance run 3: 0 mismatches on 555,708 cases across all five Crosswalk tables, and reintroducing the collapse in-process reproduces exactly the 150 and the 64 |
| NF-002 … NF-012 | | unchanged by this version |

New findings for v0.3.0 are at the end, after the v0.2.0 findings.


## Status of the v0.1.0 findings

| | v0.1.0 finding | v0.2.0 |
|---|---|---|
| NF-001 | array order changed the receipt digest | closed, `input_digest` + `claims_digest` |
| NF-002 | derived mappings are not evidence | **open, now mechanical** — every rung carries a `source` block, all 76 are unbound, and the registry reports UNRATIFIED until they are cited |
| NF-003 | corpus is an extraction from prose | **open, now capped** — G-10 caps unverified extractions at E2 and the provenance block is required |
| NF-004 | witness independence declared, not verified | **partly closed** — `INDEPENDENT` now requires a signature this tool verified plus a quotable key fingerprint; see NF-008 for what remains |
| NF-005 | no cryptographic signing | closed for witness receipts, Ed25519 over a canonical preimage; still open for the adjudication receipt itself |
| NF-006 | denotation vocabulary is a design choice | open and unchanged; still the seat of judgment, still needs outside review |
| NF-007 | adjudicating labels is not auditing artifacts | open by construction, now stated in every receipt's `non_claims` |

The v0.1.0 findings below are retained verbatim as lineage. New findings for
this version follow them.

## v0.1.0 findings, retained

Defects found during construction and limitations known at release. Kept with
the artifact rather than fixed out of the record.

## NF-001 — array order silently changed the receipt digest

**Found by:** the determinism test, on its first run.

Canonical JSON sorts object keys, so key order was already neutralised. Array
order is not, and correctly so. But `input_digest` was computed over the corpus
as given, which meant reordering the artifacts in the file produced a different
receipt for an identical set of claims. A witness who reformatted the corpus
before running would have reported a divergence that meant nothing.

**Resolution:** two digests are now recorded. `input_digest` binds the exact
declaration including its layout. `claims_digest` binds the same claims
normalized to sorted order. Neither hides the other. Two tests now assert the
distinction: the judgment is layout-independent, the input digest is not.

**Class:** this is the same shape as the previously recorded canonicalization
defects in this portfolio — the boundary was under-specified, not the logic.

## NF-002 — the registry's derived mappings are not evidence

Only three rungs of `sealkit.local` are pinned by a governing document
(E4, E5, E6). The rest are interpolated by me, conservatively, and marked
`"pinned": false`. Every use of a derived mapping emits a `DERIVED_MAPPING`
finding. A derived mapping may only lower a reading, never support one, but it
is still an assumption sitting inside a registry that otherwise records
decisions. The same applies to `handoff.2026-08-03` and `sxr.2026-08-04`, whose
non-pinned rungs were reconstructed from the adjudication record rather than
from the source documents.

**Consequence:** the registry is at E1 — documented and inspected — not E2. It
has not been checked against the original source documents rung by rung. That
check is the single most valuable thing anyone could do to this artifact next.

## NF-003 — the corpus is an extraction from prose

Artifact claims in `corpus/wn-2026-08-06.json` were extracted by hand from a
narrative handoff. Every entry is a reading of a sentence, not a measurement.
This is the softest joint in the instrument and the same weakness logged
against `handoff_adjudicator` v0.1.0's claims bundle. A wrong extraction
produces a confident, deterministic, wrong receipt.

## NF-004 — witness independence is declared, not verified

`classify_witness` reads fields. It compares strings for organization and
principal and checks that `signed` and `identity_binding` are non-empty. It
does not verify a signature, resolve an identity, or detect an undeclared
conflict of interest. A determined author can produce an `INDEPENDENT`
classification by writing one into the corpus. The rule raises the cost of
self-acceptance; it does not make it impossible.

## NF-005 — no cryptographic signing

Digests bind content. Nothing here binds content to a person. Until receipts
are signed with a key bound to an externally checkable identity, every
attestation in this package is a claim about a claim. This is the same open gap
recorded portfolio-wide.

## NF-006 — the denotation vocabulary is a design choice

`axes.py` fixes a vocabulary of denotation keys and their canonical ordinals.
That table is the actual seat of judgment in this tool, and it was written by
me from the portfolio's own definitions. If a denotation is placed one rung too
low or too high, every claim routed through it inherits the error, silently and
deterministically. It is small enough to be reviewed line by line in a few
minutes, and it should be, by someone who was not involved in writing it.

## NF-007 — an adjudication of labels is not an audit of artifacts

The tool reports `evidence ceiling E2` for a corpus in which it has executed
nothing, opened no package, and verified no test result. Everything it says is
downstream of what the corpus declares. A corpus of confident fictions would
receive a clean, reproducible, entirely worthless receipt.

## Non-defects, recorded to prevent re-litigation

- **Exit code 2 on the standard corpus is correct.** The tool exits non-zero
  because it found P0 findings, which is the expected state of this corpus. A
  zero exit here would be the surprising result.
- **`min()` looks harsh on ladders that are internally consistent.** It is. A
  ladder that agrees with canon in both readings is unaffected, which
  `wn-final-package.v1.0` demonstrates: it passes through unchanged.
- **The tool refuses rather than maps across authority kinds.** This will look
  like a bug the first time someone stated a real O2 on the CSAA ladder and got
  O0 back. It is not. Restate the claim on the canonical axis.


## New in v0.2.0

## NF-008 — a verified signature is not a verified identity

`attest` proves that the holder of a key signed exactly these fields. It does
not resolve `identity_binding` to anything, does not fetch the URL, and does
not check the fingerprint against a published one. An author can generate a
keypair, write their own identity into the receipt, sign it, and receive
`verified: true`.

What the change actually buys: the signature commits to the *whole receipt*, so
the environment, commands, digests and disposition can no longer be edited
after the fact without detection; and the key fingerprint is a short externally
quotable string that a human can compare against what the named person
publishes. The arithmetic is machine-checked. The identity is not, and the
verification output says so in its own `does_not_establish` list.

**Remaining work:** a key register mapping fingerprints to identity bindings,
with the register itself source-bound the same way ladders are.

## NF-009 — the Ed25519 implementation is unconfirmed where the reference is absent

The pure-stdlib implementation is byte-identical to the `cryptography` package
across randomized keys, signatures and rejection cases — on a machine where
that package is installed. Where it is not, the conformance test skips. A skip
is reported, not hidden, but a skipped conformance test is an unconfirmed
implementation, and a witness verifying a receipt on a bare machine is relying
on arithmetic nobody cross-checked there.

**Mitigation available and not yet done:** ship the RFC 8032 test vectors so
conformance is checkable with no third-party package at all.

## NF-010 — G-09 may be measuring the corpus, not the artifacts

Claim binding drops most of the corpus to E1 because no `artifact_digest` was
recorded. In several cases the digest certainly exists — Sealkit has a release
tree and Merkle proofs — it simply was not carried into the corpus entry.

This is the correct behaviour: an evidence system cannot distinguish "not
recorded" from "does not exist", and it must not guess in the direction that
grants more. But the resulting E1 readings should be read as *the corpus does
not identify these bytes*, not as *this work was not done*. Filling in three
digests would move three artifacts back to E2 in about ten minutes, and that is
the correct fix rather than relaxing the rule.

## NF-011 — the ratification gate can be satisfied without doing the work

`binding_class` checks that six fields are non-empty. It does not fetch the
document, verify the digest, or check that the locator points anywhere. A
determined author can bind all 76 rungs with plausible-looking strings in an
afternoon and get RATIFIED.

The gate raises the cost of skipping the audit and makes the skip visible; it
does not perform the audit. As with witness independence, the mechanism is a
forcing function for a human act, not a replacement for one.

## NF-012 — the amendment mechanism is report-only

`amendments` describes what AM-001 would change and computes which ladders stop
being refused. It does not produce a counterfactual adjudication, so nobody can
see the full downstream effect of adopting it without doing the migration. A
dual-canon engine was deliberately not built: two simultaneously live axes is a
worse failure mode than an un-modelled proposal.


## New in v0.3.0

## NF-013 — no registered rung declares its facet

A bare `E4` names no facet. v0.3.0 reads it as the facet its own definition
names, and when the definition names none, as E3: the only thing all three
facets share. That is the fail-closed choice, and it has one visible cost in
the shipped registry: `handoff.2026-08-03:E4` (defined as qualified external
assessment, E6) read **E4** under v0.2.0 and reads **E3** now, with
`E4_FACET_UNSPECIFIED`. No corpus artifact states that rung, so the corpus
result is unchanged — but it is a reading change on a registered rung, and the
code cannot know whether the ladder's author meant reproduction, review or
assessment.

The fix is data, not code: the rung's governing document says which facet its
E4 means, and the rung records it as `"level"`. No rung declares one yet, which
makes this the same audit as NF-002 — and only a document can supply the
answer, not this tool.

## NF-014 — the order above the facets is half decided

The 2026-10-04 ruling fixed the facets' relation to each other (distinct facets
meet at E3) and the portfolio ceiling (an aggregation, never a join). It did
not say whether **E5 and E6 sit above every facet**. v0.3.0 keeps the stage
order, in which they do: E4-B ⊓ E5 = E4-B, and an E5 artifact counts as an
independent reproduction.

If the portfolio decides instead that operational validation (E5) does not
imply independent review or adversarial assessment, the axis is no longer a
chain above E3, and readings that meet a facet with E5 or E6 change. The
decision lands in exactly one function (`axes.leq`; `meet` and `ceiling` are
derived from it) and in the LatticeCore model, which encodes the same order —
the conformance tables would have to be regenerated and re-pinned together
with it. Until then, conformance with those tables is agreement on the
decided half and on an assumption about the other half, and should be stated
that way.

## NF-015 — the integer API still exists, and it can still collapse facets

For compatibility, every v0.2.0 integer field survives: `evidence_ordinal`,
`normalized_ordinal`, `evidence_ceiling_ordinal`, and integer inputs to
`evidence_floors` and `composition_floor`. All three facets are stage 4 in
those fields. A consumer that writes `evidence_ordinal >= 4`, or takes a
minimum of stages across two results, has re-created D2 in its own code, and
nothing in this package can see it happen.

The levels are the reading; stages are for display. `evidence_ceiling` now
contains `" + "` when the portfolio has more than one maximum, so a consumer
parsing it as a single label fails loudly rather than reading one facet as
another. Keeping the integers was a deliberate trade — v0.2.0 callers keep
working — but it leaves a well-lit way to be wrong.

## Behaviour changes, recorded so they are not mistaken for regressions

- **Independent reproduction means E4-A or above.** v0.2.0 counted any
  stage-4 reading, so an artifact at independent review (E4-B) or adversarial
  assessment (E4-C) counted as a reproduction and lifted `production` off
  `PROHIBITED`. Neither is a reproduction; v0.3.0 counts only E4-A, E5 and E6
  (the last two by NF-014's assumption).
- **A composite of an E4-A part and an E4-B part reads E3.** No part holds
  both facets, so the composite cannot show either one. v0.2.0 read it E4.
- **A label naming one facet with a definition naming another reads E3**, with
  a P0 `FACET_CONFLICT`. v0.2.0 read it E4 and reported no conflict.
