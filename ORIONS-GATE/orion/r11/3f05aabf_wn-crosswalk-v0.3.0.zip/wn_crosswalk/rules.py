"""Guard rails applied after an artifact's claim has been translated.

Every rule here can only lower a reading. None can raise one. They encode
constraints already ratified elsewhere in the portfolio, so that the constraint
is enforced by execution rather than by remembering to apply it:

  G-01  receipt rule            any level >= E3 needs a receipt digest and a
                                witness identity binding, no exception
  G-02  witness independence    a candidate may not control its own acceptance
  G-03  substrate              simulation is not physical verification
  G-04  supersession           historical evidence is not current state
  G-05  mythos quarantine      mythos has no runtime authority
  G-06  composition floor      a composite is capped by its weakest part
  G-07  authority firewall     evidence never converts itself into authority
  G-08  track separation       research and mythos carry no runtime authority

v0.3.0, facets. Every evidence floor caps at E3 or below (the INDEPENDENT witness class "caps" at
E6, i.e. not at all) and every condition is a stage threshold, so the floors cannot distinguish
facets: they are computed on stages exactly as in v0.2.0 and a facet passes through untouched
unless a cap applies. A cap is always strictly below stage 4, so it never produces a facet. G-06 is different: it MEETS its parts,
and the meet of E4-A and E4-B is E3, so a composite resting on independent reproduction and on
independent review, with no part holding both, reads E3, not E4.
"""

from __future__ import annotations

from . import axes
from .translate import Finding

NO_WITNESS = "none"
SAME_PRINCIPAL = "same_principal"
SAME_ORG = "same_org"
INDEPENDENT = "independent"
UNVERIFIED_INDEPENDENT = "claimed_independent_unverified"

INDEPENDENCE_FLOOR = {
    NO_WITNESS: 2,
    SAME_PRINCIPAL: 2,
    SAME_ORG: 3,
    UNVERIFIED_INDEPENDENT: 3,
    INDEPENDENT: axes.CEILING[axes.EVIDENCE],
}


def classify_witness(artifact: dict) -> str:
    witness = artifact.get("witness") or {}
    principal = witness.get("principal")
    if not principal:
        return NO_WITNESS
    owner_principal = artifact.get("owner_principal")
    if owner_principal and principal == owner_principal:
        return SAME_PRINCIPAL
    if witness.get("org") and witness.get("org") == artifact.get("owner_org"):
        return SAME_ORG
    if not witness.get("identity_binding") or not witness.get("signed"):
        return UNVERIFIED_INDEPENDENT
    # A declared signature is not a verified one. Independence requires a
    # signature this tool has actually checked, against a quotable key.
    signature = witness.get("signature") or {}
    if not signature.get("verified") or not signature.get("key_fingerprint"):
        return UNVERIFIED_INDEPENDENT
    return INDEPENDENT


def evidence_floors(artifact: dict, value):
    """Floor an evidence reading. Accepts a level (v0.3.0: "E4-B") or a stage (v0.2.0: 4) and
    returns the same kind. A facet survives unless a cap applies; caps never produce a facet."""
    if isinstance(value, str):
        start = axes.stage(axes.EVIDENCE, value)
        shown = lambda st: value if st == start else axes.label(axes.EVIDENCE, st)  # noqa: E731
        floored, findings = _evidence_floors_stage(artifact, start, shown)
        return (value if floored == start else axes.level_of_stage(axes.EVIDENCE, floored)), findings
    return _evidence_floors_stage(artifact, value, lambda st: axes.label(axes.EVIDENCE, st))


def _evidence_floors_stage(artifact: dict, ordinal: int, shown) -> tuple[int, list[Finding]]:
    """Return the floored stage and the findings that explain each drop."""
    findings: list[Finding] = []
    result = ordinal

    independence = classify_witness(artifact)
    floor = INDEPENDENCE_FLOOR[independence]
    if result > floor:
        findings.append(
            Finding(
                "G-02_WITNESS_INDEPENDENCE",
                "P0",
                f"witness classified {independence!r}; "
                f"{shown(result)} lowered to "
                f"{axes.label(axes.EVIDENCE, floor)}. A candidate may not control its own "
                "acceptance mechanism.",
            )
        )
        result = floor

    if result >= 3:
        missing = []
        if not (artifact.get("bindings") or {}).get("receipt_digest"):
            missing.append("receipt_digest")
        if not ((artifact.get("witness") or {}).get("identity_binding")):
            missing.append("witness_identity_binding")
        if missing:
            findings.append(
                Finding(
                    "G-01_RECEIPT_RULE",
                    "P0",
                    f"E3 and above require {' and '.join(missing)}; lowered to E2, fail-closed",
                )
            )
            result = 2

    if artifact.get("substrate") == "simulation" and result > 2:
        findings.append(
            Finding(
                "G-03_SUBSTRATE",
                "P0",
                "substrate is simulation; simulation is not physical verification, lowered to E2",
            )
        )
        result = 2

    bindings = artifact.get("bindings") or {}
    if result > 1 and not bindings.get("artifact_digest"):
        findings.append(
            Finding(
                "G-09_CLAIM_BINDING",
                "P0",
                "no artifact_digest: a claim of local execution must identify the bytes "
                "that were executed. Named is not located; located is not verified. "
                "Lowered to E1.",
            )
        )
        result = 1

    extraction = artifact.get("extraction") or {}
    if result > 2 and extraction.get("extraction_status") != "verified":
        findings.append(
            Finding(
                "G-10_EXTRACTION_UNVERIFIED",
                "P1",
                f"claim provenance is {extraction.get('extraction_status') or 'undeclared'!r}; "
                "a claim read out of prose cannot itself carry replay or independence. "
                "Lowered to E2.",
            )
        )
        result = 2

    if artifact.get("track") == "mythos" and result > 0:
        findings.append(
            Finding("G-05_MYTHOS_QUARANTINE", "info", "mythos track carries no runtime evidence")
        )
        result = 0

    return result, findings


def authority_floors(artifact: dict, ordinal: int) -> tuple[int, list[Finding]]:
    findings: list[Finding] = []
    result = ordinal

    if result > 0:
        ratification = artifact.get("ratification") or {}
        if not ratification.get("principal") or not ratification.get("date"):
            findings.append(
                Finding(
                    "G-07_AUTHORITY_FIREWALL",
                    "P0",
                    "authority above O0 asserted with no ratification record naming an "
                    "accountable human and a date; authority is granted, never derived. "
                    "Lowered to O0.",
                )
            )
            result = 0

    if artifact.get("track") in ("research", "mythos") and result > 0:
        findings.append(
            Finding(
                "G-08_TRACK_SEPARATION",
                "P0",
                f"track {artifact.get('track')!r} carries no runtime authority; lowered to O0",
            )
        )
        result = 0

    return result, findings


def composition_floor(value, component_levels: dict):
    """G-06. Levels (v0.3.0) meet their parts; stages (v0.2.0 API) take the minimum."""
    if not component_levels:
        return value, []
    if isinstance(value, str):
        return _composition_floor_levels(value, component_levels)
    return _composition_floor_stages(value, component_levels)


def _composition_floor_levels(level: str, component_levels: dict[str, str]) -> tuple[str, list[Finding]]:
    parts = axes.meet_all(axes.EVIDENCE, component_levels.values())
    floored = axes.meet(axes.EVIDENCE, level, parts)
    if floored == level:
        return level, []
    listed = ", ".join(f"{k} at {v}" for k, v in sorted(component_levels.items()))
    return floored, [
        Finding(
            "G-06_COMPOSITION_FLOOR",
            "P0",
            f"composed of {listed}; a composite cannot show more than the meet of its parts "
            f"({parts}), lowered from {level} to {floored}",
        )
    ]


def _composition_floor_stages(ordinal: int, component_levels: dict[str, int]) -> tuple[int, list[Finding]]:
    weakest = min(component_levels.values())
    weakest_name = ", ".join(sorted(k for k, v in component_levels.items() if v == weakest))
    if ordinal <= weakest:
        return ordinal, []
    return weakest, [
        Finding(
            "G-06_COMPOSITION_FLOOR",
            "P0",
            f"composed of {weakest_name} at {axes.label(axes.EVIDENCE, weakest)}; a composite "
            f"cannot show more than its weakest part, lowered from "
            f"{axes.label(axes.EVIDENCE, ordinal)}",
        )
    ]


def counts_toward_ceiling(artifact: dict) -> tuple[bool, str | None]:
    if artifact.get("status") == "superseded":
        return False, "G-04_SUPERSESSION"
    if artifact.get("track") == "mythos":
        return False, "G-05_MYTHOS_QUARANTINE"
    return True, None
