"""Adjudicate a corpus of artifact claims against the canonical axes.

Combinators, deliberately different and both inherited from
handoff_adjudicator v0.1.0:

  within one artifact : FLOOR  -- fail-closed, the weakest reading wins
                                 (v0.3.0: the lattice meet; two facets meet at E3)
  across the portfolio: MAX    -- the ceiling is the best thing that can be
                                 shown, not the worst sentence written
                                 (v0.3.0: the set of MAXIMAL readings, each held by
                                 some artifact; an aggregation, never a join)

The receipt is split. `core` is byte-reproducible on any machine. `envelope`
carries the fields that cannot be, and names them, so that a reader is never
left guessing which part of a digest is stable. Unhashed envelope fields were a
recorded defect in this portfolio; here the envelope binds the core digest and
declares its own non-determinism instead.
"""

from __future__ import annotations

import json
import platform
import unicodedata
from pathlib import Path

from . import axes, collisions
from .canon import digest
from .registry import Registry
from .schema import validate_or_raise
from .rules import (
    authority_floors,
    classify_witness,
    composition_floor,
    counts_toward_ceiling,
    evidence_floors,
)
from .translate import Finding, translate

RULESET_VERSION = "wn.crosswalk.rules/0.3.0"
TOOL = "wn_crosswalk"
TOOL_VERSION = "0.3.0"

EXIT_CONFORMANT = 0
EXIT_LOWERED = 1
EXIT_INVARIANT = 2


def load_corpus(path: Path | str) -> dict:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if raw.get("schema") != "wn.crosswalk.corpus/1":
        raise ValueError(f"unsupported corpus schema {raw.get('schema')!r}")
    validate_or_raise(raw, "corpus")
    return raw


def runtime_fingerprint() -> dict:
    """Recorded in the envelope so a digest divergence can be attributed.

    Deliberately NOT in the core. Putting the Unicode version inside the
    reproducible digest would guarantee divergence across Python releases;
    putting it in the envelope means a witness can see why one occurred.
    """
    return {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "unicode_database": unicodedata.unidata_version,
        "platform": platform.system().lower(),
    }


def _adjudicate_one(registry: Registry, artifact: dict) -> dict:
    findings: list[Finding] = []

    claim = artifact.get("claim") or {}
    reading = translate(
        registry, axes.EVIDENCE, claim.get("ladder", ""), claim.get("label", "")
    )
    findings.extend(reading.findings)
    evidence = reading.normalized_level

    evidence, floor_findings = evidence_floors(artifact, evidence)
    findings.extend(floor_findings)

    auth_claim = artifact.get("authority_claim") or {}
    auth_reading = translate(
        registry, axes.AUTHORITY, auth_claim.get("ladder", ""), auth_claim.get("label", "")
    )
    findings.extend(auth_reading.findings)
    authority, auth_findings = authority_floors(artifact, auth_reading.normalized_ordinal)
    findings.extend(auth_findings)

    return {
        "artifact_id": artifact["artifact_id"],
        "name": artifact.get("name", artifact["artifact_id"]),
        "track": artifact.get("track", "logos"),
        "status": artifact.get("status", "active"),
        "stated": {
            "evidence": f"{claim.get('ladder', '?')}:{claim.get('label', '?')}",
            "authority": f"{auth_claim.get('ladder', '?')}:{auth_claim.get('label', '?')}",
        },
        "reading": reading.to_dict(),
        "witness_class": classify_witness(artifact),
        "components": sorted(artifact.get("components") or []),
        "evidence_level": evidence,
        "evidence_ordinal": axes.stage(axes.EVIDENCE, evidence),
        "authority_ordinal": authority,
        "findings": [f.to_dict() for f in findings],
    }


def _governance(result: dict, ratified: bool) -> dict:
    """Separate the analytical result from any status decision.

    The kernel computes a normalized claim. It does not set portfolio status.
    While the registry is unratified nothing it produces is adoptable, however
    clean the arithmetic looks.
    """
    severities = {f["severity"] for f in result["findings"]}
    if not ratified:
        recommendation = "ADVISORY_ONLY"
        reason = "registry is unratified; no result may be recorded as portfolio status"
    elif "P0" in severities:
        recommendation = "RESTATE_CLAIM"
        reason = "at least one P0 finding; the claim as written should not be carried forward"
    elif severities & {"P1", "P2"}:
        recommendation = "ADOPT_WITH_FINDINGS"
        reason = "normalized cleanly, with findings that should travel with the claim"
    else:
        recommendation = "ADOPT"
        reason = "normalized with no findings"
    return {
        "normalized_claim": {
            "evidence": result["evidence_level"],
            "authority": axes.label(axes.AUTHORITY, result["authority_ordinal"]),
        },
        "governance_recommendation": recommendation,
        "reason": reason,
        "ratification_status": "NOT_RATIFIED",
    }


def adjudicate(registry: Registry, corpus: dict) -> dict:
    ratification = registry.ratification()
    ratified = ratification["status"] == "RATIFIED"
    artifacts = sorted(corpus["artifacts"], key=lambda a: a["artifact_id"])
    results = {a["artifact_id"]: _adjudicate_one(registry, a) for a in artifacts}
    by_id = {a["artifact_id"]: a for a in artifacts}

    # Composition floor: iterate to a fixpoint so that a composite built from
    # composites settles. Bounded by the artifact count; deterministic order.
    for _ in range(len(artifacts) + 1):
        changed = False
        for artifact_id in sorted(results):
            result = results[artifact_id]
            levels = {
                component: results[component]["evidence_level"]
                for component in result["components"]
                if component in results
            }
            missing = [c for c in result["components"] if c not in results]
            for component in missing:
                finding = Finding(
                    "G-06_COMPONENT_MISSING",
                    "P0",
                    f"declared component {component!r} is not in the corpus; unverifiable "
                    "composition is not approval",
                ).to_dict()
                if finding not in result["findings"]:
                    result["findings"].append(finding)
                    result["evidence_level"], result["evidence_ordinal"] = "E0", 0
                    changed = True
            floored, comp_findings = composition_floor(result["evidence_level"], levels)
            if floored != result["evidence_level"]:
                result["evidence_level"] = floored
                result["evidence_ordinal"] = axes.stage(axes.EVIDENCE, floored)
                result["findings"].extend(f.to_dict() for f in comp_findings)
                changed = True
        if not changed:
            break

    counted: list[str] = []
    excluded: list[dict] = []
    for artifact_id in sorted(results):
        counts, reason = counts_toward_ceiling(by_id[artifact_id])
        results[artifact_id]["counts_toward_ceiling"] = counts
        if counts:
            counted.append(artifact_id)
        else:
            excluded.append({"artifact_id": artifact_id, "reason": reason})

    # The ceiling is an aggregation, not a join: the maximal readings among counted artifacts,
    # each one a reading some artifact holds. E4-A beside E4-B is [E4-A, E4-B], never E5.
    ceiling_levels = axes.ceiling(axes.EVIDENCE, [results[a]["evidence_level"] for a in counted]) or ["E0"]

    # Independent REPRODUCTION is E4-A or above. Independent review (E4-B) and adversarial
    # assessment (E4-C) are independent, but they are not reproduction.
    independent = sorted(
        aid for aid in counted if axes.leq(axes.EVIDENCE, "E4-A", results[aid]["evidence_level"])
    )
    authorized = sorted(aid for aid in results if results[aid]["authority_ordinal"] > 0)

    severity_counts: dict[str, int] = {}
    for result in results.values():
        for finding in result["findings"]:
            severity_counts[finding["severity"]] = severity_counts.get(finding["severity"], 0) + 1

    label_collisions = collisions.detect(registry)

    core = {
        "receipt_type": "wn.crosswalk.receipt/1",
        "tool": TOOL,
        "tool_version": TOOL_VERSION,
        "ruleset_version": RULESET_VERSION,
        "corpus": {
            "corpus_id": corpus.get("corpus_id", "unnamed"),
            "baseline": corpus.get("baseline"),
            "artifact_count": len(artifacts),
            "input_digest": digest(corpus),
            "claims_digest": digest(
                {
                    "corpus_id": corpus.get("corpus_id", "unnamed"),
                    "baseline": corpus.get("baseline"),
                    "artifacts": artifacts,
                }
            ),
        },
        "registry": {
            "fingerprint": registry.fingerprint(),
            "digest": digest(registry.fingerprint()),
            "ratification": ratification,
        },
        "artifacts": [
            dict(results[aid], governance=_governance(results[aid], ratified))
            for aid in sorted(results)
        ],
        "collisions": label_collisions,
        "unsafe_labels": collisions.unsafe_labels(label_collisions),
        "aggregate": {
            "evidence_ceiling_levels": ceiling_levels,
            "evidence_ceiling": " + ".join(ceiling_levels),
            "evidence_ceiling_ordinal": max(axes.stage(axes.EVIDENCE, x) for x in ceiling_levels),
            "artifacts_counted": counted,
            "artifacts_excluded": excluded,
            "independent_reproduction_count": len(independent),
            "independent_reproduction_artifacts": independent,
            "artifacts_with_authority": authorized,
            "authority": axes.label(
                axes.AUTHORITY, max([results[a]["authority_ordinal"] for a in results] + [0])
            ),
            "production": "PROHIBITED" if not independent else "SEPARATE_GOVERNANCE_DECISION",
            "finding_severity_counts": severity_counts,
            "registry_ratification": ratification["status"],
            "adoptability": (
                "ADOPTABLE" if ratified else "ADVISORY_ONLY"
            ),
            "adoptability_reason": ratification["consequence"],
        },
        "non_claims": [
            "This receipt is evidence about labels and claims, not about the artifacts themselves.",
            "Running this tool is not an independent reproduction of anything it adjudicates.",
            "A conformant label is not a correct implementation.",
            "No rule in this ruleset can raise a reading.",
            "The declared corpus normalizes to this ceiling. That is not a finding that the "
            "underlying artifacts deserve it: no package here was opened, executed, or checked.",
            "While the registry is unratified, every result above is ADVISORY_ONLY.",
        ],
    }

    return core


def exit_code(core: dict) -> int:
    severities = core["aggregate"]["finding_severity_counts"]
    if severities.get("P0"):
        return EXIT_INVARIANT
    if severities.get("P1") or severities.get("P2"):
        return EXIT_LOWERED
    return EXIT_CONFORMANT


def wrap(core: dict, generated_at: str) -> dict:
    """Envelope binds the core digest and names its own unstable fields."""
    envelope = {
        "envelope_type": "wn.crosswalk.envelope/1",
        "core_sha256": digest(core),
        "generated_at": generated_at,
        "nondeterministic_fields": ["envelope.generated_at", "envelope.runtime"],
        "runtime": runtime_fingerprint(),
        "reproducible_digest": "envelope.core_sha256",
        "note": (
            "Only core_sha256 is expected to match across machines. The envelope as a whole "
            "is not, by construction, and says so rather than presenting a digest that "
            "quietly cannot be reproduced."
        ),
    }
    return {"envelope": envelope, "core": core}
