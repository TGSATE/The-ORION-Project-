"""Ladder registry: load, validate, index, and report on ratification.

A registry is not ratified because it is called a registry. It is ratified when
every rung of every canonical ladder cites the governing document that fixed
it, and an accountable human has adopted the resulting set by digest. Until
then this module reports UNRATIFIED and every result computed from it is
advisory.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from . import axes
from .canon import digest

DEFAULT_REGISTRY = Path(__file__).resolve().parent.parent / "registry" / "ladders.json"

CANONICAL_LADDER = {
    axes.EVIDENCE: "wn.core",
    axes.AUTHORITY: "wn.core.authority",
    axes.STANDING: "wn.core.standing",
    axes.PERMISSION: "wn.core.permission",
    axes.ASSURANCE: "wn.core.assurance",
}

STATUS_FINDING = {
    "retired": ("RETIRED_LADDER", "P0"),
    "rejected": ("REJECTED_LADDER", "P0"),
    "adjudicated_nonconformant": ("NONCONFORMANT_LADDER", "P1"),
    "superseded": ("SUPERSEDED_LADDER", "P2"),
    "local": ("LOCAL_LADDER", "P2"),
    "proposed": ("PROPOSED_LADDER", "P1"),
    "canonical": (None, None),
    "canonical_subclass": (None, None),
}

# A rung's source binding class. Only `bound` counts toward ratification.
UNBOUND, CITED, BOUND = "unbound", "cited", "bound"
CITATION_FIELDS = ("document", "version", "locator", "decided_by", "decided_on")


class RegistryError(ValueError):
    pass


def binding_class(source: dict | None) -> str:
    if not source:
        return UNBOUND
    if any(not source.get(field) for field in CITATION_FIELDS):
        return UNBOUND
    return BOUND if source.get("document_digest") else CITED


@dataclass(frozen=True)
class Rung:
    label: str
    ordinal: int
    denotes: str
    pinned: bool
    gloss: str
    source: dict | None = None
    # v0.3.0: the label reading as a level, when the label names one the ordinal cannot
    # (a facet: ordinal 4 is three incomparable rungs). Optional; absent in v0.2 registries.
    level: str | None = None

    @property
    def binding(self) -> str:
        return binding_class(self.source)


@dataclass(frozen=True)
class Ladder:
    ladder_id: str
    axis: str
    kind: str
    status: str
    label_comparable: bool
    source: str
    rungs: dict[str, Rung]
    axis_if_amended: str | None = None

    @property
    def is_canonical_kind(self) -> bool:
        return self.kind == axes.CANONICAL_KIND[self.axis]

    @property
    def in_force(self) -> bool:
        return self.axis in axes.IN_FORCE


class Registry:
    def __init__(self, raw: dict, ladders: dict[str, Ladder]):
        self.raw = raw
        self.ladders = ladders
        self.version = raw.get("registry_version", "unknown")
        self.amendments = raw.get("amendments", [])
        self.adoption = raw.get("adoption")

    # -- loading ------------------------------------------------------------
    @classmethod
    def load(cls, path: Path | str | None = None) -> "Registry":
        path = Path(path) if path else DEFAULT_REGISTRY
        raw = json.loads(path.read_text(encoding="utf-8"))
        if raw.get("schema") != "wn.crosswalk.registry/2":
            raise RegistryError(f"unsupported registry schema {raw.get('schema')!r}")
        ladders: dict[str, Ladder] = {}
        for entry in raw["ladders"]:
            ladder = cls._build(entry)
            if ladder.ladder_id in ladders:
                raise RegistryError(f"duplicate ladder_id {ladder.ladder_id!r}")
            ladders[ladder.ladder_id] = ladder
        for axis in axes.IN_FORCE:
            if CANONICAL_LADDER[axis] not in ladders:
                raise RegistryError(f"missing canonical {axis} ladder")
        return cls(raw, ladders)

    @staticmethod
    def _build(entry: dict) -> Ladder:
        axis = entry["axis"]
        if axis not in axes.ALL_AXES:
            raise RegistryError(f"unknown axis {axis!r}")
        if entry["status"] not in STATUS_FINDING:
            raise RegistryError(f"unknown ladder status {entry['status']!r}")
        rungs: dict[str, Rung] = {}
        for item in entry["rungs"]:
            denotes = item["denotes"]
            if axes.denotation_ordinal(axis, denotes) is None:
                raise RegistryError(
                    f"{entry['ladder_id']}: rung {item['label']} denotes {denotes!r}, "
                    "which is not in the shared denotation vocabulary for this axis"
                )
            level = item.get("level")
            if level is not None:
                if level not in axes.levels(axis):
                    raise RegistryError(f"{entry['ladder_id']}: rung {item['label']} level {level!r} is not on the {axis} axis")
                if axes.stage(axis, level) != axes.clamp(axis, int(item["ordinal"])):
                    raise RegistryError(f"{entry['ladder_id']}: rung {item['label']} level {level!r} disagrees with its ordinal")
            rung = Rung(
                label=item["label"],
                ordinal=int(item["ordinal"]),
                denotes=denotes,
                pinned=bool(item.get("pinned", False)),
                gloss=item.get("gloss", ""),
                source=item.get("source"),
                level=level,
            )
            if rung.label in rungs:
                raise RegistryError(f"{entry['ladder_id']}: duplicate rung {rung.label!r}")
            rungs[rung.label] = rung
        return Ladder(
            ladder_id=entry["ladder_id"],
            axis=axis,
            kind=entry["kind"],
            status=entry["status"],
            label_comparable=bool(entry["label_comparable"]),
            source=entry.get("source", ""),
            rungs=rungs,
            axis_if_amended=entry.get("axis_if_amended"),
        )

    # -- access -------------------------------------------------------------
    def get(self, ladder_id: str) -> Ladder | None:
        return self.ladders.get(ladder_id)

    def by_axis(self, axis: str) -> list[Ladder]:
        return sorted(
            (lad for lad in self.ladders.values() if lad.axis == axis),
            key=lambda lad: lad.ladder_id,
        )

    def fingerprint(self) -> dict:
        return {
            "registry_version": self.version,
            "ladder_count": len(self.ladders),
            "ladders": [
                {
                    "ladder_id": lad.ladder_id,
                    "axis": lad.axis,
                    "kind": lad.kind,
                    "status": lad.status,
                    "rungs": sorted(lad.rungs),
                    "bindings": {
                        label: rung.binding for label, rung in sorted(lad.rungs.items())
                    },
                    # declared levels are semantic data; listed only where declared, so a v0.2
                    # registry keeps its v0.2 digest
                    **({"levels": {label: rung.level for label, rung in sorted(lad.rungs.items())
                                   if rung.level is not None}}
                       if any(r.level is not None for r in lad.rungs.values()) else {}),
                }
                for lad in sorted(self.ladders.values(), key=lambda x: x.ladder_id)
            ],
        }

    # -- ratification -------------------------------------------------------
    def source_audit(self) -> dict:
        """Which rungs still have no governing citation."""
        counts = {UNBOUND: 0, CITED: 0, BOUND: 0}
        unbound: list[str] = []
        for ladder in sorted(self.ladders.values(), key=lambda x: x.ladder_id):
            for label, rung in sorted(ladder.rungs.items()):
                counts[rung.binding] += 1
                if rung.binding == UNBOUND:
                    unbound.append(f"{ladder.ladder_id}:{label}")
        return {"counts": counts, "unbound_rungs": unbound, "rung_total": sum(counts.values())}

    def ratification(self) -> dict:
        """RATIFIED only when every canonical rung is source-bound and adopted."""
        reasons: list[str] = []
        audit = self.source_audit()

        canonical_unbound = [
            f"{lad.ladder_id}:{label}"
            for lad in sorted(self.ladders.values(), key=lambda x: x.ladder_id)
            if lad.status in ("canonical", "canonical_subclass")
            for label, rung in sorted(lad.rungs.items())
            if rung.binding != BOUND
        ]
        if canonical_unbound:
            reasons.append(
                f"{len(canonical_unbound)} canonical rungs are not source-bound to a "
                "governing document with a digest"
            )

        adoption = self.adoption or {}
        if not adoption.get("principal") or not adoption.get("date"):
            reasons.append("no adoption record naming an accountable human and a date")
        elif adoption.get("ladder_set_digest") != digest(self.fingerprint()):
            reasons.append(
                "the adoption record's ladder_set_digest does not match the current "
                "registry; the registry changed after it was adopted"
            )

        return {
            "status": "RATIFIED" if not reasons else "UNRATIFIED",
            "reasons": reasons,
            "canonical_rungs_unbound": canonical_unbound,
            "source_audit": audit,
            "ladder_set_digest": digest(self.fingerprint()),
            "consequence": (
                "Results are adoptable."
                if not reasons
                else "Every result computed from this registry is ADVISORY_ONLY and may "
                "not be recorded as a portfolio status decision."
            ),
        }

    # -- amendments ---------------------------------------------------------
    def amendment_report(self) -> list[dict]:
        report = []
        for amendment in self.amendments:
            moves = []
            for ladder_id, new_axis in sorted(
                (amendment.get("ladder_reassignments") or {}).items()
            ):
                ladder = self.get(ladder_id)
                if not ladder:
                    continue
                now_refused = not ladder.is_canonical_kind
                would_be_refused = ladder.kind != axes.CANONICAL_KIND[new_axis]
                moves.append(
                    {
                        "ladder_id": ladder_id,
                        "from_axis": ladder.axis,
                        "to_axis": new_axis,
                        "currently_refused": now_refused,
                        "refused_after_amendment": would_be_refused,
                        "effect": (
                            "becomes translatable on its own axis"
                            if now_refused and not would_be_refused
                            else "no change to translatability"
                        ),
                    }
                )
            report.append(
                {
                    "amendment_id": amendment["amendment_id"],
                    "title": amendment.get("title", ""),
                    "status": amendment.get("status", "proposed"),
                    "requires": amendment.get("requires", []),
                    "rationale": amendment.get("rationale", ""),
                    "cost": amendment.get("cost", ""),
                    "ladder_moves": moves,
                }
            )
        return report
