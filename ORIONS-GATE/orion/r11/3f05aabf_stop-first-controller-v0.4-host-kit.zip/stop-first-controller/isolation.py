"""Fail-closed child isolation. Requires a delegated writable cgroup v2 parent."""
import os
from pathlib import Path
import signal
import subprocess
import sys
import uuid
import time


class IsolationUnavailable(RuntimeError):
    pass


def require_cgroup_mount(path):
    resolved = Path(path).resolve(strict=True)
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        before, after = line.split(' - ', 1)
        if after.split()[0] != 'cgroup2':
            continue
        mount = Path(before.split()[4].replace('\\040', ' '))
        if resolved == mount or mount in resolved.parents:
            return str(mount)
    raise IsolationUnavailable('path is not on a real cgroup v2 mount')


class CgroupV2:
    def __init__(self, parent='/sys/fs/cgroup', *, test_only_files=False):
        parent = Path(parent)
        if not test_only_files:
            require_cgroup_mount(parent)
        if not (parent / 'cgroup.controllers').is_file() or not (parent / 'cgroup.procs').is_file():
            raise IsolationUnavailable('cgroup v2 parent unavailable')
        self.path = parent / ('stopfirst-' + uuid.uuid4().hex)
        try:
            self.path.mkdir(mode=0o700)
        except OSError as exc:
            raise IsolationUnavailable('delegated writable cgroup required') from exc
        self.attached = False

    def attach(self, pid):
        try:
            (self.path / 'cgroup.procs').write_text(str(pid))
            if str(pid) not in (self.path / 'cgroup.procs').read_text().split():
                raise IsolationUnavailable('cgroup membership did not verify')
            self.attached = True
        except OSError as exc:
            raise IsolationUnavailable('cgroup attach failed') from exc

    def kill(self):
        # Never fall back to a single PID for a populated cgroup.
        if self.attached:
            (self.path / 'cgroup.kill').write_text('1')

    def close(self):
        # cgroup.kill can return before task removal finishes.
        deadline = time.monotonic() + 2
        while True:
            try:
                self.path.rmdir()
                return
            except OSError as exc:
                if exc.errno != 16 or time.monotonic() >= deadline:
                    raise
                time.sleep(0.01)


def can_drop_uid():
    if os.geteuid() != 0:
        return False
    try:
        status = Path('/proc/self/status').read_text()
        effective = int(next(line.split()[1] for line in status.splitlines()
                             if line.startswith('CapEff:')), 16)
    except (OSError, StopIteration, ValueError):
        return False
    return bool(effective & (1 << 6) and effective & (1 << 7))


def _drop_privileges(uid, gid):
    os.setgroups([])
    os.setgid(gid)
    os.setuid(uid)


def spawn(script, group, uid, gid, *, test_only_same_uid=False):
    if not test_only_same_uid and (not can_drop_uid() or uid == 0 or gid == 0):
        raise IsolationUnavailable('CAP_SETUID and CAP_SETGID required')
    script = str(Path(script).resolve(strict=True))
    gate_read, gate_write = os.pipe()
    child = None
    try:
        child = subprocess.Popen(
            [sys.executable, '-I', str(Path(__file__).with_name('proposer_bootstrap.py')),
             str(gate_read), script], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, pass_fds=(gate_read,),
            preexec_fn=None if test_only_same_uid else lambda: _drop_privileges(uid, gid))
        os.close(gate_read)
        gate_read = -1
        group.attach(child.pid)
        # Bootstrap cannot execute proposer code before placement is verified.
        os.write(gate_write, b'G')
        return child
    except BaseException:
        if child is not None:
            child.kill()
            child.wait(timeout=2)
            child.stdout.close()
        raise
    finally:
        if gate_read >= 0:
            os.close(gate_read)
        os.close(gate_write)
