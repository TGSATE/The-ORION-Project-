"""Bootstrap holds a dropped-UID child until the parent verifies cgroup attach."""
import os
import sys

if len(sys.argv) != 3:
    raise SystemExit(2)
fd = int(sys.argv[1])
script = sys.argv[2]
if os.read(fd, 1) != b'G':
    raise SystemExit(3)
os.close(fd)
os.execv(sys.executable, [sys.executable, '-I', script])
