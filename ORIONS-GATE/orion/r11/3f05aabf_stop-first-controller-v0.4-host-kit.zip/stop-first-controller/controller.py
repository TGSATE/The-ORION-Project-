"""One controller process: trusted selector loop, no model invocation."""
import argparse
import json
import os
import selectors
import subprocess
import sys
import signal
import time
from kernel import Kernel, Policy, replay
from tool_sandbox import ToolGate, DummyFileGate, reconcile_file
from isolation import CgroupV2, spawn


def run(input_fd, path, policy=Policy(), stop_fd=None, child=None, child_kill=None, worker_uid=65534, worker_gid=65534):
    # Caller supplies pipe/socket FDs. No user-defined functions enter the loop.
    kernel = Kernel(path, policy)
    started = time.monotonic_ns()
    stop_requested = False
    def request_stop(signum, frame):
        nonlocal stop_requested
        stop_requested = True
    old_handlers = {}
    selector = selectors.DefaultSelector()
    saved_blocking = {}
    try:
        for sig in (signal.SIGTERM, signal.SIGINT):
            old_handlers[sig] = signal.signal(sig, request_stop)
        for fd, tag in ((input_fd, 'model'), (stop_fd, 'stop')):
            if fd is not None:
                saved_blocking[fd] = os.get_blocking(fd)
                os.set_blocking(fd, False)
                selector.register(fd, selectors.EVENT_READ, tag)
        while kernel.state['mode'] == 'RUNNING':
            # Control is polled before EVERY frame/read, even with a full buffer.
            ready = selector.select(0)
            now = time.monotonic_ns() - started
            if stop_requested or any(key.data == 'stop' for key, _ in ready):
                kernel.step('operator_stop', now)
                break
            if child is not None and child.poll() is not None and child.returncode != 0:
                kernel.step('child_killed' if child.returncode == -signal.SIGKILL else 'child_failed', now)
                break
            if now >= policy.deadline_ns:
                kernel.step('tick', now)
                break
            if kernel.state['pending'] is not None:
                gate = (DummyFileGate(path, uid=worker_uid, gid=worker_gid)
                        if kernel.state['pending']['op'] == 'file_write' else ToolGate(path))
                gate.execute(kernel, started, lambda: stop_requested or any(
                    key.data == 'stop' for key, _ in selector.select(0)))
                continue
            if b'\n' in bytes.fromhex(kernel.state['buffer']):
                kernel.step('frame', now)
                continue
            if any(key.data == 'model' for key, _ in ready):
                allowance = min(policy.chunk, policy.budget - kernel.state['spent'])
                try:
                    raw = os.read(input_fd, allowance)
                except BlockingIOError:
                    continue
                # Recheck operator control after input read, before admission.
                ready = selector.select(0)
                now = time.monotonic_ns() - started
                if stop_requested or any(key.data == 'stop' for key, _ in ready):
                    kernel.step('operator_stop', now)
                else:
                    if raw:
                        kernel.step('receive', now, raw.hex())
                    elif child is not None:
                        code = child.wait(timeout=0.1)
                        kernel.step('child_killed' if code == -signal.SIGKILL else
                                    'child_failed' if code != 0 else 'eof', now)
                    else:
                        kernel.step('eof', now)
                continue
            selector.select(min(0.005, max(0, (policy.deadline_ns - now) / 1e9)))
        return kernel.state
    finally:
        selector.close()
        for fd, blocking in saved_blocking.items():
            os.set_blocking(fd, blocking)
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
        kernel.close()
        if child is not None:
            if child_kill is not None:
                child_kill()
            elif child.poll() is None:
                child.kill()
            child.wait(timeout=2)


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    live = sub.add_parser('run')
    live.add_argument('--journal', required=True)
    live.add_argument('--input-fd', type=int, default=0)
    live.add_argument('--stop-fd', type=int)
    live.add_argument('--deadline-ms', type=int, default=1000)
    live.add_argument('--budget', type=int, default=8192)
    live.add_argument('--dummy-target', default='')
    supervised = sub.add_parser('supervise')
    supervised.add_argument('--journal', required=True)
    supervised.add_argument('--proposer-script', required=True)
    supervised.add_argument('--deadline-ms', type=int, default=1000)
    supervised.add_argument('--budget', type=int, default=8192)
    supervised.add_argument('--dummy-target', default='')
    supervised.add_argument('--stop-fd', type=int)
    isolated = sub.add_parser('isolated')
    isolated.add_argument('--journal', required=True)
    isolated.add_argument('--proposer-script', required=True)
    isolated.add_argument('--cgroup-parent', default='/sys/fs/cgroup')
    isolated.add_argument('--uid', type=int, required=True)
    isolated.add_argument('--gid', type=int, required=True)
    isolated.add_argument('--deadline-ms', type=int, default=1000)
    isolated.add_argument('--budget', type=int, default=8192)
    isolated.add_argument('--dummy-target', default='')
    reconcile = sub.add_parser('reconcile-file')
    reconcile.add_argument('journal')
    audit = sub.add_parser('replay')
    audit.add_argument('journal')
    audit.add_argument('--recover-tail', action='store_true')
    audit.add_argument('--expected-head')
    args = parser.parse_args()
    if args.command in ('run', 'supervise') and args.dummy_target:
        parser.error('dummy file target requires isolated mode')
    if args.command == 'reconcile-file':
        print(reconcile_file(args.journal))
        return
    if args.command == 'run':
        result = run(args.input_fd, args.journal,
                     Policy(deadline_ns=args.deadline_ms * 1_000_000, budget=args.budget,
                            file_target=args.dummy_target), args.stop_fd)
    elif args.command == 'isolated':
        group = CgroupV2(args.cgroup_parent)
        try:
            child = spawn(args.proposer_script, group, args.uid, args.gid)
            try:
                result = run(child.stdout.fileno(), args.journal,
                             Policy(deadline_ns=args.deadline_ms * 1_000_000, budget=args.budget,
                            file_target=args.dummy_target),
                             child=child, child_kill=group.kill,
                             worker_uid=args.uid, worker_gid=args.gid)
            finally:
                child.stdout.close()
                group.kill()
                child.wait(timeout=2)
        finally:
            group.close()
    elif args.command == 'supervise':
        # The operator chooses a script; it receives no kernel state or journal FD.
        # Same-UID OS isolation is not claimed.
        child = subprocess.Popen([sys.executable, '-I', args.proposer_script],
                                 stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.DEVNULL, close_fds=True)
        try:
            result = run(child.stdout.fileno(), args.journal,
                         Policy(deadline_ns=args.deadline_ms * 1_000_000, budget=args.budget,
                            file_target=args.dummy_target),
                         args.stop_fd, child)
        finally:
            child.stdout.close()
            if child.poll() is None:
                child.kill()
            child.wait(timeout=2)
    else:
        result = replay(args.journal, recover_tail=args.recover_tail, expected_head=args.expected_head)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
