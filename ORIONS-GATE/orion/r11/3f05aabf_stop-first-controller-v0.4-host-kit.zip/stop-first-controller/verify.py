"""One command, stdlib only; records actual local test and mutation outcomes."""
import json
import platform
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
runs = []
for args in (['-m', 'unittest', 'discover', '-s', 'tests', '-v'], ['mutation_check.py']):
    result = subprocess.run([sys.executable, *args], cwd=ROOT, capture_output=True, text=True, timeout=60)
    runs.append(dict(command=[sys.executable, *args], exit_code=result.returncode,
                     stdout=result.stdout, stderr=result.stderr))
    print(result.stdout, end='')
    print(result.stderr, end='', file=sys.stderr)
report = dict(python=platform.python_version(), platform=platform.platform(),
              status='PASS' if all(r['exit_code'] == 0 for r in runs) else 'FAIL', runs=runs,
              claim='Local fault-injection evidence; no formal proof or hard-real-time guarantee.')
(ROOT / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if report['status'] == 'PASS' else 1)
