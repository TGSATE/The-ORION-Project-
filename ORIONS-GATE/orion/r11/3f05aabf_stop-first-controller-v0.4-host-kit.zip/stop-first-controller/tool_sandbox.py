"""Fixed, allowlisted tool worker and write-ahead gate. No shell/network actions."""
import json
import hashlib
import stat
import tempfile
import uuid
import os
from pathlib import Path
import subprocess
import sys
import time
# -I removes ambient import paths; allow only this fixed sibling module.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from kernel import canonical, replay, strict_json
from isolation import _drop_privileges, can_drop_uid


class ToolGate:
    def __init__(self, journal_path):
        self.journal_path = os.fspath(journal_path)

    def execute(self, kernel, started_ns, stop_requested):
        """Stage already fsynced by frame. Commit only after post-return replay."""
        pending = kernel.state['pending']
        if pending is None or pending['result'] is not None:
            raise ValueError('missing tool intent')
        remaining = (kernel.policy.deadline_ns - (time.monotonic_ns() - started_ns)) / 1e9
        if remaining <= 0:
            kernel.step('tick', time.monotonic_ns() - started_ns)
            return
        request = canonical({'op': 'upper', 'input': pending['input']})
        try:
            result = subprocess.run([sys.executable, '-I', str(Path(__file__).resolve()), '--worker'],
                                    input=request, capture_output=True,
                                    timeout=remaining, check=True)
            response = strict_json(result.stdout)
            if (type(response) is not dict or set(response) != {'output'}
                    or type(response['output']) is not str or len(response['output']) > 128):
                raise ValueError('bad worker response')
        except (subprocess.SubprocessError, ValueError, UnicodeError):
            kernel.step('tool_abort', time.monotonic_ns() - started_ns)
            return
        now = time.monotonic_ns() - started_ns
        if stop_requested():
            kernel.step('operator_stop', now)
            return
        if now >= kernel.policy.deadline_ns:
            kernel.step('tick', now)
            return
        kernel.step('tool_result', now, response['output'])
        # This precise check is the commit gate. No tail recovery or fallback.
        checked = replay(self.journal_path, expected_head=kernel.journal.head)
        if checked['torn_tail'] or checked['state'] != kernel.state:
            raise ValueError('post-tool replay mismatch')
        if stop_requested():
            kernel.step('operator_stop', time.monotonic_ns() - started_ns)
            return
        kernel.step('tool_commit', time.monotonic_ns() - started_ns, checked['head'])


def worker():
    request = sys.stdin.buffer.read(513)
    if len(request) > 512:
        raise ValueError('worker input limit')
    payload = strict_json(request)
    if (type(payload) is not dict or set(payload) != {'op', 'input'}
            or payload['op'] != 'upper' or type(payload['input']) is not str
            or len(payload['input']) > 128):
        raise ValueError('worker schema')
    output = payload['input'].upper()
    if len(output) > 128:
        raise ValueError('worker output limit')
    sys.stdout.buffer.write(canonical({'output': output}))


# Dummy file effect gate. This is a separate configured operation; the model
# never chooses the path. Publication is recoverable after a durable commit.


def stage_file_worker(path):
    # Only writes an untrusted staging file; it cannot see the protected target.
    request = sys.stdin.buffer.read(513)
    payload = strict_json(request)
    if (len(request) > 512 or type(payload) is not dict or set(payload) != {'input'}
            or type(payload['input']) is not str or len(payload['input']) > 128):
        raise ValueError('bad staging input')
    raw = payload['input'].encode('utf-8')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(raw)
            output.flush()
            os.fsync(output.fileno())
    except BaseException:
        os.unlink(path)
        raise
    sys.stdout.buffer.write(canonical({'digest': hashlib.sha256(raw).hexdigest()}))


def _fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def reconcile_file(journal_path):
    """Finish an already-receipted commit after crash. Never infer authority."""
    verified = replay(journal_path)
    with open(journal_path, 'rb') as source:
        last = strict_json(source.readlines()[-1])
        genesis = None
        source.seek(0)
        genesis = strict_json(source.readline())
    target = Path(genesis['event']['policy']['file_target'])
    if not target.is_absolute() or not target.name:
        raise ValueError('no configured file target')
    if last['event'].get('kind') != 'tool_commit':
        return 'NO_COMMIT'
    old_head = last['event']['data']
    pending = target.with_name('.' + target.name + '.pending-' + old_head)
    source_rows = Path(journal_path).read_bytes().splitlines()
    result_state = strict_json(source_rows[-2])['after']
    key = result_state['pending']['key']
    expected = verified['state']['values'].get(key)
    if expected is None:
        raise ValueError('missing committed digest')
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() == expected:
        pending.unlink(missing_ok=True)
        return 'PUBLISHED'
    if not pending.is_file() or hashlib.sha256(pending.read_bytes()).hexdigest() != expected:
        raise ValueError('committed effect cannot be reconciled')
    os.replace(pending, target)
    _fsync_directory(target.parent)
    return 'PUBLISHED'


class DummyFileGate:
    def __init__(self, journal_path, *, uid=65534, gid=65534, test_only_same_uid=False):
        self.journal_path = os.fspath(journal_path)
        self.uid, self.gid = uid, gid
        self.test_only_same_uid = test_only_same_uid

    def execute(self, kernel, started_ns, stop_requested):
        pending = kernel.state['pending']
        if pending is None or pending['op'] != 'file_write':
            raise ValueError('missing dummy file intent')
        target = Path(kernel.policy.file_target)
        if not target.parent.is_dir() or target.is_symlink():
            raise ValueError('unsafe target')
        # Root-owned target directory must exclude the worker UID.
        if not self.test_only_same_uid and (not can_drop_uid() or self.uid == 0 or self.gid == 0):
            raise ValueError('separate UID worker unavailable')
        if target.parent.stat().st_uid != os.geteuid():
            raise ValueError('target directory must be controller-owned')
        if target.parent.stat().st_mode & 0o022:
            raise ValueError('target directory permits untrusted writes')
        stage_dir = Path(tempfile.mkdtemp(prefix='stopfirst-stage-'))
        os.chmod(stage_dir, 0o733)
        staged = stage_dir / ('stage-' + uuid.uuid4().hex)
        trusted = None
        committed = False
        try:
            remaining = (kernel.policy.deadline_ns - (time.monotonic_ns() - started_ns)) / 1e9
            if remaining <= 0:
                kernel.step('tick', time.monotonic_ns() - started_ns)
                return
            request = canonical({'input': pending['input']})
            try:
                result = subprocess.run(
                    [sys.executable, '-I', str(Path(__file__).resolve()), '--stage-file', str(staged)],
                    input=request, capture_output=True, timeout=remaining, check=True,
                    preexec_fn=None if self.test_only_same_uid else
                    lambda: _drop_privileges(self.uid, self.gid))
                response = strict_json(result.stdout)
                expected = hashlib.sha256(pending['input'].encode('utf-8')).hexdigest()
                if type(response) is not dict or response != {'digest': expected}:
                    raise ValueError('invalid worker result')
                fd = os.open(staged, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    info = os.fstat(fd)
                    if not stat.S_ISREG(info.st_mode) or info.st_uid != (os.geteuid() if self.test_only_same_uid else self.uid) or info.st_size > 512:
                        raise ValueError('unsafe staged file')
                    raw = os.read(fd, 513)
                    if raw != pending['input'].encode('utf-8'):
                        raise ValueError('staged content mismatch')
                finally:
                    os.close(fd)
                # Copy into a trusted directory before the replay gate. The worker
                # cannot change this file between verification and publication.
                trusted = target.with_name('.' + target.name + '.pending-' + kernel.journal.head)
                # The final name is rebound below to the tool-result head.
                now = time.monotonic_ns() - started_ns
                if stop_requested():
                    kernel.step('operator_stop', now)
                    return
                if now >= kernel.policy.deadline_ns:
                    kernel.step('tick', now)
                    return
                kernel.step('tool_result', now, expected)
                trusted = target.with_name('.' + target.name + '.pending-' + kernel.journal.head)
                out = os.open(trusted, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                with os.fdopen(out, 'wb') as stream:
                    stream.write(raw)
                    stream.flush()
                    os.fsync(stream.fileno())
                _fsync_directory(target.parent)
                try:
                    checked = replay(self.journal_path, expected_head=kernel.journal.head)
                except (ValueError, OSError) as exc:
                    raise RuntimeError('post-worker replay failed') from exc
                if checked['torn_tail'] or checked['state'] != kernel.state:
                    raise RuntimeError('post-worker replay mismatch')
                if stop_requested():
                    kernel.step('operator_stop', time.monotonic_ns() - started_ns)
                    return
                now = time.monotonic_ns() - started_ns
                if now >= kernel.policy.deadline_ns:
                    kernel.step('tick', now)
                    return
                verdict = kernel.step('tool_commit', now, checked['head'])
                if verdict != 'TOOL_COMMIT':
                    return
                committed = True
                os.replace(trusted, target)
                _fsync_directory(target.parent)
            except (subprocess.SubprocessError, ValueError, UnicodeError):
                if kernel.state['mode'] == 'RUNNING' and kernel.state['pending'] is not None:
                    kernel.step('tool_abort', time.monotonic_ns() - started_ns)
                elif kernel.state['mode'] == 'HALTED':
                    return
                else:
                    raise
        finally:
            if staged.exists():
                staged.unlink()
            stage_dir.rmdir()
            if trusted is not None and not committed:
                trusted.unlink(missing_ok=True)

if __name__ == '__main__':
    if sys.argv[1:] == ['--worker']:
        worker()
    elif len(sys.argv) == 3 and sys.argv[1] == '--stage-file':
        stage_file_worker(sys.argv[2])
    else:
        raise SystemExit(2)

