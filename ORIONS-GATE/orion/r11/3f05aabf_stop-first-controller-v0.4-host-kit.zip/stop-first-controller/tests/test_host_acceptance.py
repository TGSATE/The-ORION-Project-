import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

from host_acceptance import PrerequisiteMissing, run_acceptance
from isolation import CgroupV2, IsolationUnavailable


class HostAcceptanceGateTests(unittest.TestCase):
    def test_fake_control_files_cannot_be_accepted_as_real_cgroup(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            (path / 'cgroup.controllers').write_text('cpu')
            (path / 'cgroup.procs').write_text('')
            with self.assertRaisesRegex(IsolationUnavailable, 'real cgroup'):
                CgroupV2(path)
            self.assertEqual(len(list(path.iterdir())), 2)

    def test_missing_cgroup_cannot_report_green(self):
        with patch('host_acceptance.identity_probe', return_value={'real_os_transition': True}), \
             patch('host_acceptance.file_probe', return_value={'real_worker': True}), \
             patch('host_acceptance.tree_kill_probe', side_effect=PrerequisiteMissing('read-only')):
            report = run_acceptance('/blocked', 65534, 65534)
        self.assertEqual(report['status'], 'BLOCKED')
        self.assertFalse(report['tools_allowed'])
        self.assertEqual(sum(gate['status'] == 'BLOCKED' for gate in report['gates']), 3)
        self.assertFalse(report['simulation'])


if __name__ == '__main__':
    unittest.main()
