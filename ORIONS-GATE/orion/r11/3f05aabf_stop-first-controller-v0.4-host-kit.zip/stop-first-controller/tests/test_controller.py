import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from kernel import Kernel, Policy, canonical, digest, replay

ROOT = Path(__file__).resolve().parents[1]


def proposal(seq=1, **updates):
    p = dict(seq=seq, op='put', key='a', value='legal')
    p.update(updates)
    return canonical(p) + b'\n'


class KernelTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'receipts.jsonl'
        self.kernel = Kernel(self.path)

    def tearDown(self):
        self.kernel.close()
        self.temp.cleanup()

    def feed(self, raw):
        self.kernel.step('receive', 1, raw.hex())
        return self.kernel.step('frame', 2)

    def test_legal_write_replays(self):
        self.assertEqual(self.feed(proposal()), 'WRITE')
        recovered = replay(self.path)
        self.assertEqual(recovered['state'], self.kernel.state)
        self.assertFalse(recovered['executable'])
        self.assertEqual(recovered['recovery_mode'], 'HALTED')
        self.assertEqual(recovered['state']['spent'], len(proposal()) + 10)

    def test_model_lies_cannot_authorize(self):
        self.assertEqual(self.feed(proposal(authorized=True, cost=0, halt=False)), 'REJECT')
        self.assertEqual(self.kernel.state['values'], {})
        self.assertEqual(self.kernel.state['spent'], len(proposal(authorized=True, cost=0, halt=False)))

    def test_unknown_action(self):
        self.assertEqual(self.feed(proposal(op='shell')), 'REJECT')

    def test_unknown_key(self):
        self.assertEqual(self.feed(proposal(key='../../owned')), 'REJECT')

    def test_sequence_replay(self):
        self.feed(proposal())
        self.kernel.step('receive', 3, proposal().hex())
        self.assertEqual(self.kernel.step('frame', 4), 'REJECT')
        self.assertEqual(self.kernel.state['writes'], 1)

    def test_bool_sequence(self):
        self.assertEqual(self.feed(proposal(seq=True)), 'REJECT')

    def test_duplicate_json_keys(self):
        self.assertEqual(self.feed(b'{"seq":1,"seq":1,"op":"put","key":"a","value":"x"}\n'), 'REJECT')

    def test_malformed_unicode_and_nan(self):
        for raw in (b'\xff\n', b'NaN\n', b'null\n', b'[]\n'):
            self.kernel.step('receive', self.kernel.state['elapsed_ns'] + 1, raw.hex())
            self.assertEqual(self.kernel.step('frame', self.kernel.state['elapsed_ns'] + 1), 'REJECT')

    def test_sticky_halt(self):
        self.kernel.step('operator_stop', 1)
        with self.assertRaises(ValueError):
            self.kernel.step('receive', 2, proposal().hex())
        self.assertEqual(self.kernel.state['values'], {})

    def test_deadline_before_write(self):
        self.kernel.step('receive', 1, proposal().hex())
        self.kernel.step('frame', self.kernel.policy.deadline_ns)
        self.assertEqual(self.kernel.state['reason'], 'DEADLINE')
        self.assertEqual(self.kernel.state['writes'], 0)

    def test_backwards_clock(self):
        self.kernel.step('tick', 10)
        with self.assertRaises(ValueError):
            self.kernel.step('tick', 9)

    def test_bounded_read(self):
        with self.assertRaises(ValueError):
            self.kernel.step('receive', 1, (b'x' * 257).hex())

    def test_write_spend_cannot_overdraft(self):
        self.kernel.close()
        self.path.unlink()
        self.kernel = Kernel(self.path, Policy(budget=len(proposal()) + 9))
        self.assertEqual(self.feed(proposal()), 'HALT')
        self.assertEqual(self.kernel.state['values'], {})
        self.assertLessEqual(self.kernel.state['spent'], self.kernel.policy.budget)

    def test_frame_count_caps_valid_flood(self):
        self.kernel.close()
        self.path.unlink()
        self.kernel = Kernel(self.path, Policy(max_frames=1))
        self.feed(proposal())
        self.assertEqual(self.kernel.state['mode'], 'HALTED')
        self.assertEqual(self.kernel.state['reason'], 'FRAME_COUNT')

    def test_failed_fsync_does_not_publish(self):
        before = self.kernel.state.copy()
        with patch('kernel.os.fsync', side_effect=OSError('disk failure')):
            with self.assertRaises(OSError):
                self.kernel.step('receive', 1, proposal().hex())
        self.assertEqual(self.kernel.state, before)
        with self.assertRaises(RuntimeError):
            self.kernel.step('operator_stop', 2)

    def test_existing_journal_never_overwritten(self):
        with self.assertRaises(FileExistsError):
            Kernel(self.path)

    def test_torn_tail_explicit_recovery(self):
        self.feed(proposal())
        self.kernel.close()
        with self.path.open('ab') as file:
            file.write(b'{"partial":')
        with self.assertRaises(ValueError):
            replay(self.path)
        result = replay(self.path, recover_tail=True)
        self.assertTrue(result['torn_tail'])
        self.assertEqual(result['state']['values'], {'a': 'legal'})
        self.assertFalse(result['executable'])

    def test_rehashed_illegal_state_rejected(self):
        self.feed(proposal())
        rows = [json.loads(line) for line in self.path.read_text().splitlines()]
        rows[-1]['after']['values']['a'] = 'forged'
        row = rows[-1]
        row.pop('hash')
        row['hash'] = digest(row)
        self.path.write_bytes(b''.join(canonical(r) + b'\n' for r in rows))
        with self.assertRaisesRegex(ValueError, 'semantic'):
            replay(self.path)

    def test_byte_tamper(self):
        self.feed(proposal())
        self.path.write_bytes(self.path.read_bytes().replace(b'legal', b'false'))
        with self.assertRaises(ValueError):
            replay(self.path)

    def test_tail_removal_detected_with_checkpoint(self):
        self.feed(proposal())
        head = replay(self.path)['head']
        lines = self.path.read_bytes().splitlines(keepends=True)
        self.path.write_bytes(b''.join(lines[:-1]))
        with self.assertRaisesRegex(ValueError, 'checkpoint'):
            replay(self.path, expected_head=head)

    def test_empty_journal_rejected(self):
        self.path.write_bytes(b'')
        with self.assertRaises(ValueError):
            replay(self.path)

    def test_deep_json_bounded_and_rejected(self):
        self.assertEqual(self.feed(b'[' * 100 + b']' * 100 + b'\n'), 'REJECT')


class ProcessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'receipts.jsonl'
        self.children = []
        self.fds = []

    def tearDown(self):
        for child in self.children:
            if child.poll() is None:
                child.kill()
            child.communicate(timeout=3)
        for fd in self.fds:
            try:
                os.close(fd)
            except OSError:
                pass
        self.temp.cleanup()

    def start(self, source, deadline=150, budget=8192, stop=None):
        producer = subprocess.Popen([sys.executable, '-c', source], stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL)
        self.children.append(producer)
        command = [sys.executable, str(ROOT / 'controller.py'), 'run', '--journal', str(self.path),
                   '--deadline-ms', str(deadline), '--budget', str(budget)]
        if stop is not None:
            command += ['--stop-fd', str(stop)]
        controller = subprocess.Popen(command, stdin=producer.stdout, stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE, pass_fds=() if stop is None else (stop,))
        producer.stdout.close()
        self.children.append(controller)
        return producer, controller

    def finish(self, controller):
        stdout, stderr = controller.communicate(timeout=3)
        self.assertEqual(controller.returncode, 0, stderr.decode())
        state = json.loads(stdout)
        self.assertEqual(state, replay(self.path)['state'])
        return state

    def wait_write(self, controller):
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            if self.path.exists():
                try:
                    if replay(self.path, recover_tail=True)['state']['writes'] == 1:
                        return
                except ValueError:
                    pass
            if controller.poll() is not None:
                self.fail('controller exited before write')
            time.sleep(0.005)
        self.fail('write did not arrive')

    def test_stalled_model_deadline(self):
        began = time.monotonic()
        _, controller = self.start('import time; time.sleep(10)')
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'DEADLINE')
        self.assertEqual(state['spent'], 0)
        self.assertLess(time.monotonic() - began, 2)

    def test_unterminated_token_flood(self):
        _, controller = self.start("import os\nwhile True: os.write(1,b'x'*4096)", deadline=1000)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'FRAME_LIMIT')
        self.assertLessEqual(state['spent'], 1280)
        self.assertLess(self.path.stat().st_size, 32768)

    def test_byte_budget_flood(self):
        _, controller = self.start("import os\nwhile True: os.write(1,b'x'*4096)", budget=500)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'BUDGET')
        self.assertEqual(state['spent'], 500)

    def test_operator_stop_beats_ready_flood(self):
        read_fd, write_fd = os.pipe()
        self.fds += [read_fd, write_fd]
        os.write(write_fd, b'STOP')
        _, controller = self.start("import os\nwhile True: os.write(1,b'{}\\n'*100)", stop=read_fd)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'OPERATOR_STOP')
        self.assertEqual(state['spent'], 0)
        self.assertEqual(state['writes'], 0)

    def test_kill_model_preserves_legal_state(self):
        source = 'import os,time; os.write(1,' + repr(proposal()) + '); time.sleep(10)'
        producer, controller = self.start(source, deadline=5000)
        self.wait_write(controller)
        producer.kill()
        producer.wait(timeout=2)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'MODEL_EOF')
        self.assertEqual(state['values'], {'a': 'legal'})

    def test_sigterm_controller_halts_after_write(self):
        source = 'import os,time; os.write(1,' + repr(proposal()) + '); time.sleep(10)'
        _, controller = self.start(source, deadline=5000)
        self.wait_write(controller)
        controller.send_signal(signal.SIGTERM)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'OPERATOR_STOP')
        self.assertEqual(state['values'], {'a': 'legal'})

    def test_sigkill_controller_offline_recovery(self):
        source = 'import os,time; os.write(1,' + repr(proposal()) + '); time.sleep(10)'
        _, controller = self.start(source, deadline=5000)
        self.wait_write(controller)
        controller.kill()
        controller.wait(timeout=2)
        command = [sys.executable, str(ROOT / 'controller.py'), 'replay', str(self.path), '--recover-tail']
        result = subprocess.run(command, check=True, capture_output=True, text=True, timeout=3)
        recovered = json.loads(result.stdout)
        self.assertEqual(recovered['state']['values'], {'a': 'legal'})
        self.assertEqual(recovered['recovery_mode'], 'HALTED')
        self.assertFalse(recovered['executable'])

    def test_malformed_frame_flood(self):
        _, controller = self.start("import os\nwhile True: os.write(1,b'{}\\n'*100)", deadline=2000)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'FRAME_COUNT')
        self.assertEqual(state['frames'], 64)
        self.assertEqual(state['writes'], 0)

    def test_partial_frame_model_death(self):
        _, controller = self.start("import os; os.write(1,b'{broken')", deadline=2000)
        state = self.finish(controller)
        self.assertEqual(state['reason'], 'MODEL_EOF')
        self.assertEqual(state['writes'], 0)


if __name__ == '__main__':
    unittest.main()
