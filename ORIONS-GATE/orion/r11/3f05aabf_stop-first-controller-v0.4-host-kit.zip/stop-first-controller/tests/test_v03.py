import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from isolation import CgroupV2, IsolationUnavailable, spawn, can_drop_uid
from kernel import Kernel, Policy, canonical, replay
from tool_sandbox import DummyFileGate, reconcile_file

ROOT = Path(__file__).resolve().parents[1]


class UIDAndCgroupTests(unittest.TestCase):
    @unittest.skipUnless(can_drop_uid(), 'requires CAP_SETUID and CAP_SETGID')
    def test_child_uid_dropped_before_release(self):
        with tempfile.TemporaryDirectory(prefix='sf-uid-') as folder:
            parent = Path(folder)
            parent.chmod(0o755)
            script = parent / 'proposer.py'
            script.write_text('import os\nos.write(1,str(os.geteuid()).encode())\n')
            script.chmod(0o644)
            class Gate:
                def attach(self, pid):
                    status = Path('/proc') / str(pid) / 'status'
                    line = next(line for line in status.read_text().splitlines() if line.startswith('Uid:'))
                    assert line.split()[1] == '65534'
            child = spawn(script, Gate(), 65534, 65534)
            try:
                stdout, _ = child.communicate(timeout=3)
                self.assertEqual(child.returncode, 0)
                self.assertEqual(stdout, b'65534')
            finally:
                if child.poll() is None:
                    child.kill(); child.wait(timeout=2)

    def test_failed_placement_never_executes_proposer(self):
        with tempfile.TemporaryDirectory(prefix='sf-gate-') as folder:
            parent = Path(folder)
            parent.chmod(0o755)
            marker = parent / 'ran'
            script = parent / 'proposer.py'
            script.write_text('from pathlib import Path\nPath(' + repr(str(marker)) + ").write_text('ran')\n")
            script.chmod(0o644)
            class Reject:
                def attach(self, pid):
                    raise IsolationUnavailable('injected attach failure')
            with self.assertRaises(IsolationUnavailable):
                spawn(script, Reject(), 65534, 65534, test_only_same_uid=True)
            self.assertFalse(marker.exists())

    def test_strict_uid_mode_fails_closed_without_capabilities(self):
        if can_drop_uid():
            self.skipTest('UID capabilities present')
        with self.assertRaises(IsolationUnavailable):
            spawn(__file__, object(), 65534, 65534)

    def test_read_only_cgroup_fails_before_child_or_journal(self):
        with tempfile.TemporaryDirectory(prefix='sf-ro-') as folder:
            parent = Path(folder)
            (parent / 'cgroup.controllers').write_text('cpu')
            (parent / 'cgroup.procs').write_text('')
            parent.chmod(0o555)
            # Root may bypass permissions; mock mkdir to emulate a read-only
            # delegated mount. The real mount is inspected separately.
            with patch('isolation.Path.mkdir', side_effect=OSError('read-only')):
                with self.assertRaises(IsolationUnavailable):
                    CgroupV2(parent)

    def test_actual_mount_refuses_isolated_launch(self):
        mount = Path('/sys/fs/cgroup')
        if not mount.exists() or os.access(mount, os.W_OK):
            self.skipTest('requires read-only cgroup mount')
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            marker = path / 'ran'
            script = path / 'proposer.py'
            script.write_text('from pathlib import Path\nPath(' + repr(str(marker)) + ').write_text("yes")')
            journal = path / 'journal.jsonl'
            command = [sys.executable, str(ROOT / 'controller.py'), 'isolated',
                       '--cgroup-parent', str(mount), '--uid', '65534', '--gid', '65534',
                       '--proposer-script', str(script), '--journal', str(journal)]
            result = subprocess.run(command, capture_output=True, timeout=3)
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(journal.exists())
            self.assertFalse(marker.exists())

    def test_cgroup_kill_driver_writes_kill_knob_simulated(self):
        with tempfile.TemporaryDirectory(prefix='sf-cgroup-sim-') as folder:
            parent = Path(folder)
            (parent / 'cgroup.controllers').write_text('cpu')
            (parent / 'cgroup.procs').write_text('')
            group = CgroupV2(parent, test_only_files=True)
            try:
                (group.path / 'cgroup.procs').write_text('123')
                (group.path / 'cgroup.kill').write_text('')
                group.attach(123)
                group.kill()
                self.assertEqual((group.path / 'cgroup.kill').read_text(), '1')
            finally:
                for file in group.path.iterdir():
                    file.unlink()
                group.close()


class DummyWriteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='sf-dummy-')
        self.folder = Path(self.temp.name)
        self.folder.chmod(0o700)
        self.target = self.folder / 'dummy.txt'
        self.target.write_text('ORIGINAL')
        self.journal = self.folder / 'receipts.jsonl'
        self.kernel = Kernel(self.journal, Policy(deadline_ns=5_000_000_000,
                                                 file_target=str(self.target)))
        raw = canonical({'seq':1,'op':'file_write','key':'a','value':'hello'}) + b'\n'
        self.kernel.step('receive', 1, raw.hex())
        self.assertEqual(self.kernel.step('frame', 2), 'TOOL_INTENT')
        self.gate = DummyFileGate(self.journal, test_only_same_uid=True)

    def tearDown(self):
        self.kernel.close()
        self.temp.cleanup()

    def test_commit_publishes_after_replay(self):
        staged = replay(self.journal)
        self.assertEqual(staged['state']['values'], {})
        self.assertEqual(self.target.read_text(), 'ORIGINAL')
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertEqual(self.target.read_text(), 'hello')
        self.assertEqual(self.kernel.state['values']['a'], hashlib.sha256(b'hello').hexdigest())
        self.assertEqual(self.kernel.state, replay(self.journal)['state'])
        self.assertEqual(reconcile_file(self.journal), 'PUBLISHED')

    def test_replay_failure_rolls_back_stage_and_preserves_target(self):
        actual = subprocess.run
        def corrupt_after_return(*args, **kwargs):
            result = actual(*args, **kwargs)
            raw = self.journal.read_bytes()
            self.journal.write_bytes(raw.replace(b'hello', b'jello', 1))
            return result
        with patch('tool_sandbox.subprocess.run', side_effect=corrupt_after_return):
            with self.assertRaises(RuntimeError):
                self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertEqual(self.target.read_text(), 'ORIGINAL')
        self.assertEqual(self.kernel.state['values'], {})
        self.assertNotIn(b'"kind":"tool_commit"', self.journal.read_bytes())
        self.assertFalse(list(self.folder.glob('.dummy.txt.pending-*')))

    def test_crash_window_reconciles_durable_commit(self):
        with patch('tool_sandbox.os.replace', side_effect=OSError('injected crash window')):
            with self.assertRaises(OSError):
                self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertEqual(self.target.read_text(), 'ORIGINAL')
        self.assertEqual(replay(self.journal)['state']['writes'], 1)
        self.assertEqual(reconcile_file(self.journal), 'PUBLISHED')
        self.assertEqual(self.target.read_text(), 'hello')

    def test_stop_before_file_commit_preserves_target(self):
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: True)
        self.assertEqual(self.target.read_text(), 'ORIGINAL')
        self.assertEqual(self.kernel.state['reason'], 'OPERATOR_STOP')

    def test_strict_worker_refuses_same_uid_environment(self):
        if can_drop_uid():
            self.skipTest('UID capabilities present')
        strict = DummyFileGate(self.journal)
        with self.assertRaisesRegex(ValueError, 'separate UID'):
            strict.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertEqual(self.target.read_text(), 'ORIGINAL')

    def test_target_mode_in_simulation(self):
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertEqual(self.target.stat().st_uid, 0)
        self.assertEqual(self.target.stat().st_mode & 0o777, 0o600)


if __name__ == '__main__':
    unittest.main()
