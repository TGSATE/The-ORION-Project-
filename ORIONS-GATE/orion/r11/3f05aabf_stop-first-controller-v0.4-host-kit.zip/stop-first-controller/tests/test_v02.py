import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from kernel import Kernel, Policy, canonical, digest, replay
from tool_sandbox import ToolGate

ROOT = Path(__file__).resolve().parents[1]


def tool_proposal(value='hello'):
    return canonical({'seq': 1, 'op': 'tool_upper', 'key': 'a', 'value': value}) + b'\n'


class ToolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'receipts.jsonl'
        self.kernel = Kernel(self.path, Policy(deadline_ns=5_000_000_000))
        raw = tool_proposal()
        self.kernel.step('receive', 1, raw.hex())
        self.assertEqual(self.kernel.step('frame', 2), 'TOOL_INTENT')
        self.gate = ToolGate(self.path)

    def tearDown(self):
        self.kernel.close()
        self.temp.cleanup()

    def test_write_ahead_and_commit(self):
        staged = replay(self.path)
        self.assertEqual(staged['state']['values'], {})
        self.assertEqual(staged['state']['pending']['input'], 'hello')
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        checked = replay(self.path)
        self.assertEqual(checked['state']['values'], {'a': 'HELLO'})
        self.assertEqual(checked['state']['writes'], 1)
        kinds = [json.loads(row)['event'].get('kind') for row in self.path.read_text().splitlines()[1:]]
        self.assertEqual(kinds[-3:], ['frame', 'tool_result', 'tool_commit'])
        self.assertEqual(json.loads(self.path.read_text().splitlines()[-1])['event']['data'],
                         json.loads(self.path.read_text().splitlines()[-2])['hash'])

    def test_replay_failure_after_worker_returns_forbids_commit(self):
        actual_run = subprocess.run
        def corrupt_on_return(*args, **kwargs):
            result = actual_run(*args, **kwargs)
            # Tamper with an earlier, already fsynced intent after the tool returns.
            rows = [json.loads(line) for line in self.path.read_text().splitlines()]
            rows[-1]['after']['pending']['input'] = 'forged'
            self.path.write_bytes(b''.join(canonical(row) + b'\n' for row in rows))
            return result
        with patch('tool_sandbox.subprocess.run', side_effect=corrupt_on_return):
            with self.assertRaises(ValueError):
                self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertNotIn(b'"kind":"tool_commit"', self.path.read_bytes())
        self.assertEqual(self.kernel.state['values'], {})

    def test_rehashed_illegal_tool_result_rejected(self):
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        rows = [json.loads(line) for line in self.path.read_text().splitlines()]
        result_row = rows[-2]
        result_row['event']['data'] = 'EVIL'
        body = dict(result_row)
        body.pop('hash')
        result_row['hash'] = digest(body)
        rows[-1]['previous'] = result_row['hash']
        body = dict(rows[-1]); body.pop('hash')
        rows[-1]['hash'] = digest(body)
        self.path.write_bytes(b''.join(canonical(row) + b'\n' for row in rows))
        with self.assertRaises(ValueError):
            replay(self.path)

    def test_commit_binding_mutation_detected(self):
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        rows = [json.loads(line) for line in self.path.read_text().splitlines()]
        rows[-1]['event']['data'] = '0' * 64
        body = dict(rows[-1]); body.pop('hash')
        rows[-1]['hash'] = digest(body)
        self.path.write_bytes(b''.join(canonical(row) + b'\n' for row in rows))
        with self.assertRaisesRegex(ValueError, 'binding'):
            replay(self.path)

    def test_worker_failure_halts_without_write(self):
        with patch('tool_sandbox.subprocess.run', side_effect=subprocess.TimeoutExpired('worker', 0.001)):
            self.gate.execute(self.kernel, time.monotonic_ns(), lambda: False)
        self.assertEqual(self.kernel.state['reason'], 'TOOL_ABORT')
        self.assertEqual(replay(self.path)['state']['values'], {})

    def test_operator_stop_after_return_before_commit(self):
        self.gate.execute(self.kernel, time.monotonic_ns(), lambda: True)
        self.assertEqual(self.kernel.state['reason'], 'OPERATOR_STOP')
        self.assertEqual(self.kernel.state['values'], {})


class SupervisedChildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        self.journal = self.folder / 'journal.jsonl'
        self.pidfile = self.folder / 'child.pid'
        self.processes = []

    def tearDown(self):
        for process in self.processes:
            if process.poll() is None:
                process.kill()
            process.communicate(timeout=3)
        if self.pidfile.exists():
            pid = int(self.pidfile.read_text())
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        self.temp.cleanup()

    def start(self, source, deadline=2500, budget=8192):
        script = self.folder / 'proposer.py'
        script.write_text(source)
        controller = subprocess.Popen([sys.executable, str(ROOT / 'controller.py'), 'supervise',
                                       '--proposer-script', str(script), '--journal', str(self.journal),
                                       '--deadline-ms', str(deadline), '--budget', str(budget)],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.processes.append(controller)
        return controller

    def wait_for(self, check):
        end = time.monotonic() + 2
        while time.monotonic() < end:
            if check():
                return
            time.sleep(0.005)
        self.fail('condition not reached')

    def finish(self, process):
        stdout, stderr = process.communicate(timeout=4)
        self.assertEqual(process.returncode, 0, stderr.decode())
        state = json.loads(stdout)
        self.assertEqual(state, replay(self.journal)['state'])
        return state

    def test_sigkill_child_is_its_own_halt(self):
        source = 'import os,time\nfrom pathlib import Path\n'
        source += 'Path(' + repr(str(self.pidfile)) + ').write_text(str(os.getpid()))\n'
        source += 'os.write(1,' + repr(canonical({'seq':1,'op':'put','key':'a','value':'legal'}) + b'\n') + ')\n'
        source += 'time.sleep(20)\n'
        process = self.start(source)
        self.wait_for(lambda: self.pidfile.exists() and self.journal.exists() and
                      len(self.journal.read_text().splitlines()) >= 3)
        os.kill(int(self.pidfile.read_text()), signal.SIGKILL)
        state = self.finish(process)
        self.assertEqual(state['reason'], 'CHILD_SIGKILL')
        self.assertEqual(state['values'], {'a': 'legal'})
        self.assertNotEqual(state['reason'], 'DEADLINE')

    def test_deadline_kills_stalled_child(self):
        source = 'import os,time,signal\nfrom pathlib import Path\n'
        source += 'signal.signal(signal.SIGTERM,signal.SIG_IGN)\n'
        source += 'Path(' + repr(str(self.pidfile)) + ').write_text(str(os.getpid()))\n'
        source += 'time.sleep(20)\n'
        process = self.start(source, deadline=250)
        state = self.finish(process)
        self.assertEqual(state['reason'], 'DEADLINE')
        self.assertTrue(self.pidfile.exists())
        with self.assertRaises(ProcessLookupError):
            os.kill(int(self.pidfile.read_text()), 0)

    def test_supervised_tool_receipt_replays(self):
        source = 'import os\nos.write(1,' + repr(tool_proposal()) + ')\n'
        process = self.start(source)
        state = self.finish(process)
        self.assertEqual(state['values'], {'a': 'HELLO'})
        self.assertEqual(state['writes'], 1)

    def test_supervised_flood_stops(self):
        process = self.start("import os\nwhile True: os.write(1,b'x'*4096)")
        state = self.finish(process)
        self.assertIn(state['reason'], ('FRAME_LIMIT', 'BUDGET'))
        self.assertEqual(state['writes'], 0)


if __name__ == '__main__':
    unittest.main()
