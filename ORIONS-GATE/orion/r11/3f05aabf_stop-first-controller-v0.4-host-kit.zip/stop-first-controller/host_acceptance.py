"""Real-host release gate. No simulation, no skipped gates, no auto-remediation."""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch

from isolation import CgroupV2, IsolationUnavailable, can_drop_uid, spawn
from kernel import Kernel, Policy, canonical, replay
from controller import run as run_controller
from tool_sandbox import DummyFileGate


class PrerequisiteMissing(RuntimeError):
    pass


def identity_probe(uid, gid):
    if not can_drop_uid():
        raise PrerequisiteMissing('CAP_SETUID and CAP_SETGID required')
    # Only placement is omitted for this identity-specific check. The child
    # actually switches OS identity; this gate does not claim cgroup containment.
    class IdentityOnly:
        def attach(self, pid):
            status = (Path('/proc') / str(pid) / 'status').read_text()
            ids = {line.split(':')[0]: line.split(':',1)[1].strip()
                   for line in status.splitlines() if ':' in line}
            if list(map(int, ids['Uid'].split())) != [uid] * 4:
                raise AssertionError('UID was not switched')
            if list(map(int, ids['Gid'].split())) != [gid] * 4 or ids['Groups']:
                raise AssertionError('GID or supplementary groups not dropped')
    with tempfile.TemporaryDirectory(prefix='sf-host-identity-') as folder:
        directory = Path(folder)
        directory.chmod(0o755)
        script = directory / 'probe.py'
        script.write_text('import os,json\nprint(json.dumps([os.getuid(),os.getgid(),os.getgroups()]),flush=True)\n')
        script.chmod(0o644)
        child = spawn(script, IdentityOnly(), uid, gid)
        try:
            output, _ = child.communicate(timeout=3)
            if child.returncode != 0 or json.loads(output) != [uid, gid, []]:
                raise AssertionError('identity probe failed')
            return dict(uid=uid, gid=gid, groups=[], real_os_transition=True,
                        cgroup_verified=False)
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=2)


def _read_line(pipe, timeout=3):
    selector = selectors.DefaultSelector()
    selector.register(pipe, selectors.EVENT_READ)
    raw = bytearray()
    end = time.monotonic() + timeout
    try:
        while time.monotonic() < end:
            if selector.select(max(0, end-time.monotonic())):
                chunk = os.read(pipe.fileno(), 1)
                if not chunk:
                    raise AssertionError('child closed before readiness')
                raw.extend(chunk)
                if len(raw) > 1024:
                    raise AssertionError('child readiness output exceeded limit')
                if chunk == b'\n':
                    return json.loads(raw)
        raise AssertionError('child readiness timed out')
    finally:
        selector.close()


def _running(pid):
    try:
        status = (Path('/proc') / str(pid) / 'status').read_text()
        state = next(line.split()[1] for line in status.splitlines() if line.startswith('State:'))
        return state not in ('Z', 'X')
    except FileNotFoundError:
        return False


def tree_kill_probe(parent, uid, gid, *, remove_kill=False, controller_halt=False):
    if not can_drop_uid():
        raise PrerequisiteMissing('UID switching capabilities unavailable')
    try:
        group = CgroupV2(parent)  # Default requires a REAL cgroup2 mount.
    except (IsolationUnavailable, OSError) as exc:
        raise PrerequisiteMissing(str(exc)) from exc
    child = None
    descendant = None
    try:
        with tempfile.TemporaryDirectory(prefix='sf-host-tree-') as folder:
            directory = Path(folder)
            directory.chmod(0o755)
            script = directory / 'proposer.py'
            script.write_text(
                'import os,json,time\n'
                'descendant=os.fork()\n'
                'if descendant==0:\n    time.sleep(30)\n    os._exit(0)\n'
                'print(json.dumps({"pid":os.getpid(),"descendant":descendant,"uid":os.getuid()}),flush=True)\n'
                'time.sleep(30)\n')
            script.chmod(0o644)
            child = spawn(script, group, uid, gid)
            ready = _read_line(child.stdout)
            descendant = ready['descendant']
            if ready['pid'] != child.pid or ready['uid'] != uid:
                raise AssertionError('unexpected child identity')
            # Read actual kernel-maintained membership before sending the kill.
            members = set(map(int, (group.path / 'cgroup.procs').read_text().split()))
            if not {child.pid, descendant} <= members:
                raise AssertionError('parent and descendant not contained')
            if not _running(child.pid) or not _running(descendant):
                raise AssertionError('tree was not alive before kill')
            if remove_kill:
                # Mutation: omit cgroup.kill. The test must observe failure;
                # cleanup below always uses the unmutated kill operation.
                time.sleep(0.1)
                if _running(child.pid) and _running(descendant):
                    return dict(mutation='omit_cgroup_kill', detected=True,
                                real_tree_remained_alive=True)
                raise AssertionError('kill mutation was not distinguishable')
            controller_state = None
            if controller_halt:
                journal = directory / 'controller.jsonl'
                controller_state = run_controller(child.stdout.fileno(), journal,
                    Policy(deadline_ns=100_000_000), child=child, child_kill=group.kill)
                if controller_state['reason'] != 'DEADLINE' or replay(journal)['state'] != controller_state:
                    raise AssertionError('controller deadline receipt failed replay')
            else:
                group.kill()
            code = child.wait(timeout=3)
            end = time.monotonic() + 3
            while time.monotonic() < end:
                events = dict(line.split() for line in (group.path / 'cgroup.events').read_text().splitlines())
                if events.get('populated') == '0' and not _running(descendant):
                    break
                time.sleep(0.01)
            else:
                raise AssertionError('cgroup remained populated or descendant survived')
            if code != -signal.SIGKILL or _running(child.pid):
                raise AssertionError('leader was not SIGKILLed')
            return dict(child_pid=child.pid, descendant_pid=descendant,
                        returncode=code, populated=0, descendant_running=False,
                        real_cgroup_mount=True,
                        controller_deadline_replayed=controller_state is not None)
    finally:
        try:
            if group.attached:
                group.kill()  # Real cleanup, including mutation case.
            if child is not None:
                child.wait(timeout=3)
                child.stdout.close()
        finally:
            group.close()


def file_probe(uid, gid, *, corrupt=False, bypass_replay=False):
    if not can_drop_uid():
        raise PrerequisiteMissing('separate UID worker requires UID/GID capabilities')
    with tempfile.TemporaryDirectory(prefix='sf-host-file-') as folder:
        directory = Path(folder)
        directory.chmod(0o700)
        target = directory / 'dummy.txt'
        target.write_bytes(b'ORIGINAL')
        journal = directory / 'journal.jsonl'
        kernel = Kernel(journal, Policy(deadline_ns=5_000_000_000, file_target=str(target)))
        observed = {}
        real_run = subprocess.run
        def return_hook(*args, **kwargs):
            result = real_run(*args, **kwargs)
            if result.returncode != 0:
                raise AssertionError('real separate UID worker failed')
            # Inspect the actual staged file before its parent cleans it up.
            staged = Path(args[0][-1])
            observed['worker_file_uid'] = staged.stat().st_uid
            if observed['worker_file_uid'] != uid:
                raise AssertionError('worker used wrong UID')
            if corrupt:
                journal.write_bytes(journal.read_bytes().replace(b'hello', b'jello', 1))
            return result
        try:
            frame = canonical({'seq':1,'op':'file_write','key':'a','value':'hello'}) + b'\n'
            kernel.step('receive', 1, frame.hex())
            if kernel.step('frame', 2) != 'TOOL_INTENT':
                raise AssertionError('missing durable intent')
            gate = DummyFileGate(journal, uid=uid, gid=gid)  # NO test_only flag.
            def fake_replay(*args, **kwargs):
                return dict(head=kernel.journal.head, state=kernel.state, torn_tail=False)
            with patch('tool_sandbox.subprocess.run', side_effect=return_hook):
                if bypass_replay:
                    with patch('tool_sandbox.replay', side_effect=fake_replay):
                        gate.execute(kernel, time.monotonic_ns(), lambda: False)
                elif corrupt:
                    try:
                        gate.execute(kernel, time.monotonic_ns(), lambda: False)
                    except RuntimeError as exc:
                        if 'replay' not in str(exc):
                            raise
                    else:
                        raise AssertionError('corrupted replay was accepted')
                else:
                    gate.execute(kernel, time.monotonic_ns(), lambda: False)
            if not observed:
                raise AssertionError('no real worker observed')
            if corrupt and not bypass_replay:
                if target.read_bytes() != b'ORIGINAL' or kernel.state['writes'] != 0:
                    raise AssertionError('rollback did not preserve target')
                if list(directory.glob('.dummy.txt.pending-*')):
                    raise AssertionError('trusted stage survived rollback')
                if b'"kind":"tool_commit"' in journal.read_bytes():
                    raise AssertionError('commit issued after replay failure')
                return dict(**observed, original_preserved=True, stage_removed=True,
                            commit_issued=False, real_worker=True)
            if target.read_bytes() != b'hello' or kernel.state['writes'] != 1:
                raise AssertionError('expected publication missing')
            if bypass_replay:
                # Removing the replay gate defeats the baseline rollback test.
                return dict(**observed, mutation='bypass_replay', detected=True,
                            rollback_property_broken=True, real_worker=True)
            if replay(journal)['state'] != kernel.state:
                raise AssertionError('committed state failed replay')
            return dict(**observed, target_uid=target.stat().st_uid, published=True,
                        digest=hashlib.sha256(target.read_bytes()).hexdigest(), real_worker=True)
        finally:
            kernel.close()


def run_acceptance(parent, uid, gid):
    checks = [
        ('real_uid_switch', lambda: identity_probe(uid,gid)),
        ('real_cgroup_tree_kill', lambda: tree_kill_probe(parent,uid,gid)),
        ('real_controller_cgroup_halt', lambda: tree_kill_probe(parent,uid,gid,controller_halt=True)),
        ('real_dummy_file_commit', lambda: file_probe(uid,gid)),
        ('real_dummy_file_rollback', lambda: file_probe(uid,gid,corrupt=True)),
        ('real_cgroup_kill_mutation', lambda: tree_kill_probe(parent,uid,gid,remove_kill=True)),
        ('real_replay_gate_mutation', lambda: file_probe(uid,gid,corrupt=True,bypass_replay=True)),
    ]
    outcomes = []
    for name, check in checks:
        try:
            observations = check()
            outcomes.append(dict(gate=name, status='PASS', observations=observations))
        except (PrerequisiteMissing, IsolationUnavailable) as exc:
            outcomes.append(dict(gate=name, status='BLOCKED', reason=str(exc)))
        except Exception as exc:
            outcomes.append(dict(gate=name, status='FAIL', reason=type(exc).__name__ + ': ' + str(exc)))
    statuses = {gate['status'] for gate in outcomes}
    status = 'GREEN' if statuses == {'PASS'} else 'FAIL' if 'FAIL' in statuses else 'BLOCKED'
    root = Path(__file__).resolve().parent
    sources = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
               for name in ('host_acceptance.py', 'isolation.py', 'controller.py',
                            'proposer_bootstrap.py', 'kernel.py', 'tool_sandbox.py')}
    return dict(status=status, tools_allowed=False, cgroup_parent=str(parent),
                runtime=dict(python=platform.python_version(), kernel=platform.release(),
                             controller_uid=os.geteuid()), source_sha256=sources,
                uid=uid, gid=gid, simulation=False, gates=outcomes,
                claim='Real OS identity and file behavior. GREEN additionally requires real cgroup tree kill and gate mutation evidence.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cgroup-parent', required=True)
    parser.add_argument('--uid', type=int, default=65534)
    parser.add_argument('--gid', type=int, default=65534)
    parser.add_argument('--report', default='host-acceptance.json')
    args = parser.parse_args()
    if args.uid <= 0 or args.gid <= 0:
        parser.error('select a separate positive UID and GID')
    report = run_acceptance(args.cgroup_parent, args.uid, args.gid)
    Path(args.report).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    return 0 if report['status'] == 'GREEN' else 2 if report['status'] == 'BLOCKED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
