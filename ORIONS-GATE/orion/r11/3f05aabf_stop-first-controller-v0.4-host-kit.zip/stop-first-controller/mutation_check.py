"""Targeted guard-removal probes; each must fail its named behavioral test."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
MUTANTS = [
    ('deadline_guard', 'kernel.py', 'if now >= policy.deadline_ns:', 'if False:',
     'KernelTests.test_deadline_before_write'),
    ('sticky_halt', 'kernel.py', "if state['mode'] != 'RUNNING':", 'if False:',
     'KernelTests.test_sticky_halt'),
    ('input_spend', 'kernel.py', "state['spent'] += len(raw)", "state['spent'] += 0",
     'KernelTests.test_legal_write_replays'),
    ('write_budget', 'kernel.py', "if state['spent'] + policy.write_cost > policy.budget:", 'if False:',
     'KernelTests.test_write_spend_cannot_overdraft'),
    ('unknown_claims', 'kernel.py', "set(proposal) == {'seq', 'op', 'key', 'value'}", "{'seq', 'op', 'key', 'value'} <= set(proposal)",
     'KernelTests.test_model_lies_cannot_authorize'),
    ('semantic_replay', 'kernel.py', "if canonical(row['after']) != canonical(after) or row['verdict'] != verdict:", 'if False:',
     'KernelTests.test_rehashed_illegal_state_rejected'),
    ('publish_before_fsync', 'kernel.py', 'self.journal.append(event, after, verdict)',
     'self.state = after\n            self.journal.append(event, after, verdict)',
     'KernelTests.test_failed_fsync_does_not_publish'),
    ('operator_priority', 'controller.py', "if stop_requested or any(key.data == 'stop' for key, _ in ready):", 'if False:',
     'ProcessTests.test_operator_stop_beats_ready_flood'),
    ('child_sigkill_classification', 'controller.py',
     'child.returncode == -signal.SIGKILL', 'False',
     'test_v02.SupervisedChildTests.test_sigkill_child_is_its_own_halt'),
    ('tool_stage_early_write', 'kernel.py',
     "state['pending'] = dict(key=proposal['key'], input=proposal['value'],\n                                        op=proposal['op'], result=None)",
     "state['values'][proposal['key']] = proposal['value']\n                state['pending'] = dict(key=proposal['key'], input=proposal['value'],\n                                        op=proposal['op'], result=None)",
     'test_v02.ToolTests.test_write_ahead_and_commit'),
    ('tool_replay_commit_gate', 'tool_sandbox.py',
     'checked = replay(self.journal_path, expected_head=kernel.journal.head)',
     "checked = {'torn_tail': False, 'state': kernel.state, 'head': kernel.journal.head}",
     'test_v02.ToolTests.test_replay_failure_after_worker_returns_forbids_commit'),
    ('child_attach_gate', 'isolation.py', 'group.attach(child.pid)', 'pass',
     'test_v03.UIDAndCgroupTests.test_failed_placement_never_executes_proposer'),
    ('cgroup_kill', 'isolation.py', "(self.path / 'cgroup.kill').write_text('1')", 'pass',
     'test_v03.UIDAndCgroupTests.test_cgroup_kill_driver_writes_kill_knob_simulated'),
    ('dummy_file_replay_gate', 'tool_sandbox.py',
     'checked = replay(self.journal_path, expected_head=kernel.journal.head)',
     "checked = {'torn_tail': False, 'state': kernel.state, 'head': kernel.journal.head}",
     'test_v03.DummyWriteTests.test_replay_failure_rolls_back_stage_and_preserves_target'),
]



def main():
    results = []
    for name, filename, old, new, test in MUTANTS:
        with tempfile.TemporaryDirectory() as directory:
            work = Path(directory)
            for item in ('kernel.py', 'controller.py', 'tool_sandbox.py', 'isolation.py', 'proposer_bootstrap.py'):
                shutil.copy2(ROOT / item, work / item)
            shutil.copytree(ROOT / 'tests', work / 'tests', ignore=shutil.ignore_patterns('__pycache__'))
            path = work / filename
            source = path.read_text()
            if old not in source:
                raise RuntimeError('mutation anchor missing: ' + name)
            path.write_text(source.replace(old, new))
            # Compilation/import failure does NOT count as a killed mutation.
            compile(path.read_text(), str(path), 'exec')
            run = subprocess.run([sys.executable, '-m', 'unittest', test if test.startswith(('test_v02.', 'test_v03.')) else 'test_controller.' + test, '-v'],
                                 cwd=work, env=dict(__import__('os').environ, PYTHONPATH=str(work / 'tests') + ':' + str(work)),
                                 capture_output=True, text=True, timeout=10)
            killed = run.returncode != 0 and 'FAIL:' in run.stderr and 'ERROR:' not in run.stderr
            results.append(dict(mutation=name, test=test, status='KILLED' if killed else 'SURVIVED_OR_INVALID'))
    print(json.dumps(results, indent=2))
    return 0 if all(r['status'] == 'KILLED' for r in results) else 1


if __name__ == '__main__':
    raise SystemExit(main())
