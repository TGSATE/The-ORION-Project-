import os
os.write(1, b'{"seq":1,"op":"tool_upper","key":"a","value":"hello"}\n')
