# Stop-First Controller v0.4 host acceptance kit

The controller remains tool-free except for the fixed uppercase fixture and one
configured dummy file effect. This kit adds a real-host acceptance runner with
seven mandatory gates. It cannot report GREEN with a blocked gate, skipped
containment check, or simulated cgroup. No bash or network tool is enabled by
any report status.

## Actual current-host result

`current-host-acceptance.json` is **BLOCKED**, exit code 2. This session now has
UID/GID switching capabilities, but `/sys/fs/cgroup` remains read-only.

| Gate | Actual result | Evidence |
| --- | --- | --- |
| UID/GID switch | PASS | Child UID/GID 65534, supplementary groups empty |
| Cgroup tree kill | BLOCKED | Writable delegated cgroup unavailable |
| Controller-driven cgroup halt | BLOCKED | Same prerequisite |
| Dummy file publication | PASS | Real worker stage owned by UID 65534; target owned by controller |
| Replay-failure rollback | PASS | Original retained, trusted stage removed, no commit receipt |
| Cgroup kill mutation | BLOCKED | Cannot create the real cgroup tree here |
| Replay gate mutation | PASS | Bypassing replay with a real worker broke the rollback property |

The separate identity probe does **not** claim cgroup placement; its record
explicitly says `cgroup_verified: false`. The file probes use the strict
`DummyFileGate`, with no `test_only_same_uid` flag. Each worker stage's actual
OS owner is checked. The report binds its results to SHA-256 hashes of the
controller, kernel, isolation, bootstrap, worker, and acceptance runner source.

`verification.json` records the regression suite: 55 tests ran, 53 passed, 2
skipped because their fixtures require UID capabilities to be absent, plus
14/14 targeted source mutations killed. The real UID test now passes. The
regression cgroup mutation still uses simulated files; only the separate host
acceptance runner can supply real cgroup kill evidence.

## Run on a capable host

Use Linux with cgroup v2, a delegated writable parent supporting `cgroup.kill`,
and root capabilities `CAP_SETUID` and `CAP_SETGID`. The package must be in a
controller-owned location readable/traversable by the worker UID; the private
journal and target directory must remain inaccessible to that UID. The runner
does not remount filesystems, alter users, or configure host delegation.

From the extracted package root:

```sh
python3 verify.py
python3 host_acceptance.py \
  --cgroup-parent /sys/fs/cgroup/delegated \
  --uid 65534 --gid 65534 \
  --report host-acceptance.json
```

The operator must supply an actual delegated path. Use a dedicated non-root
UID/GID on the host; the numeric defaults are fixtures. The runner does not
connect to a remote host. Status and exit codes:

| Status | Exit code | Meaning |
| --- | --- | --- |
| GREEN | 0 | All seven real-host gates passed |
| FAIL | 1 | A gate ran and its expected behavior failed |
| BLOCKED | 2 | Required host capability unavailable; no green claim |

The cgroup probes create a child and a forked descendant, check their real
`cgroup.procs` membership, send `cgroup.kill`, require leader exit `-SIGKILL`,
and require `cgroup.events` to report `populated 0` with no running descendant.
A separate probe drives the controller's own deadline and verifies its halt
receipt by replay, then checks the same tree death. The no-kill mutation must
leave the real tree alive and therefore fail the baseline death condition;
cleanup always invokes the real kill operation. No alternate PID kill counts
as cgroup evidence.

The cgroup driver now rejects ordinary directories containing lookalike
control files unless explicitly invoked with its test-only fixture flag.
Cleanup waits briefly for asynchronous task removal before removing the group.
A missing cgroup or capability causes refusal before proposer code runs.

## File transaction and recovery

The policy records an operator-configured absolute dummy target in genesis.
The model supplies only a bounded string and a slot key. The strict worker runs
under a different UID and stages its bytes in an untrusted directory. The
parent verifies ownership, content and digest, copies into a controller-owned
pending file, and fsyncs a result receipt. It then replays strictly to its current
head and checks live-state equality before issuing `TOOL_COMMIT` and replacing
the target.

Injected replay corruption after the real worker returns leaves the original
file intact, removes staging, and issues no commit. Removing that replay gate
allows publication and is detected by the real-worker mutation probe.

A crash between the durable commit and rename is a separate case: replay proves
the commit, and `python3 controller.py reconcile-file JOURNAL` can finish the
matching pending publication. It refuses mismatched or missing content.

## Claim limits

The remaining cgroup gates are unproven on this host. GREEN on another host
would support the seven recorded conditions, not arbitrary OS containment or a
formal proof. UID/cgroup separation does not restrict all filesystem reads,
network access, or resources by itself. The fixed file worker is not placed in
the proposer's cgroup; it has a separate UID and subprocess deadline. Parent
SIGKILL cleanup still needs an external supervisor. There is no automatic
promotion from test results to tool authority.
