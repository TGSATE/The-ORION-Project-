"""Stop-first reference kernel. No inference, callbacks, or tool execution."""
import copy
import hashlib
import json
import os
from dataclasses import asdict, dataclass

MAX_RECEIPT = 32768


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                      allow_nan=False).encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def strict_json(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('duplicate key')
            out[key] = value
        return out
    def bad_constant(value):
        raise ValueError('non-finite number')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad_constant)


@dataclass(frozen=True)
class Policy:
    deadline_ns: int = 1_000_000_000
    budget: int = 8192
    max_frames: int = 64
    max_frame: int = 1024
    chunk: int = 256
    write_cost: int = 10

    def validate(self):
        limits = {'deadline_ns': 60_000_000_000, 'budget': 1_000_000,
                  'max_frames': 1000, 'max_frame': 4096, 'chunk': 256,
                  'write_cost': 1000}
        for name, ceiling in limits.items():
            value = getattr(self, name)
            if type(value) is not int or not 1 <= value <= ceiling:
                raise ValueError('invalid policy: ' + name)
        return self


def initial(policy):
    policy.validate()
    return dict(mode='RUNNING', reason=None, spent=0, frames=0, writes=0,
                values={}, buffer='', elapsed_ns=0, pending=None)


def halt(state, reason):
    state['mode'], state['reason'], state['buffer'] = 'HALTED', reason, ''


def transition(before, event, policy):
    """Pure total-over-valid-events reducer, shared with offline replay."""
    state = copy.deepcopy(before)
    if state['mode'] != 'RUNNING':
        raise ValueError('halt is sticky')
    if not isinstance(event, dict) or set(event) != {'kind', 'data', 'elapsed_ns'}:
        raise ValueError('invalid event')
    kind, data, now = event['kind'], event['data'], event['elapsed_ns']
    if type(now) is not int or now < state['elapsed_ns']:
        raise ValueError('invalid clock')
    if kind not in ('tick', 'receive', 'frame', 'eof', 'operator_stop',
                     'child_killed', 'child_failed', 'tool_result', 'tool_commit', 'tool_abort'):
        raise ValueError('invalid event kind')
    if kind not in ('receive', 'tool_result', 'tool_commit') and data is not None:
        raise ValueError('unexpected event data')
    state['elapsed_ns'] = now
    if kind == 'operator_stop':
        halt(state, 'OPERATOR_STOP')
        return state, 'HALT'
    if now >= policy.deadline_ns:
        halt(state, 'DEADLINE')
        return state, 'HALT'
    if kind == 'child_killed':
        halt(state, 'CHILD_SIGKILL')
        return state, 'HALT'
    if kind == 'child_failed':
        halt(state, 'CHILD_FAILED')
        return state, 'HALT'
    if kind == 'tool_abort':
        halt(state, 'TOOL_ABORT')
        return state, 'HALT'
    if kind == 'tool_result':
        pending = state['pending']
        if (type(pending) is not dict or pending.get('result') is not None
                or type(data) is not str or len(data) > 128
                or data != pending['input'].upper()):
            raise ValueError('invalid tool result')
        state['pending']['result'] = data
        return state, 'TOOL_RESULT'
    if kind == 'tool_commit':
        pending = state['pending']
        if (type(pending) is not dict or pending.get('result') is None
                or type(data) is not str or len(data) != 64
                or any(c not in '0123456789abcdef' for c in data)):
            raise ValueError('invalid tool commit')
        # data binds this commit to the result receipt immediately before it.
        # The runtime must replay to this exact head before submitting commit.
        if state['spent'] + policy.write_cost > policy.budget:
            halt(state, 'BUDGET')
            return state, 'HALT'
        state['spent'] += policy.write_cost
        state['values'][pending['key']] = pending['result']
        state['writes'] += 1
        state['pending'] = None
        return state, 'TOOL_COMMIT'
    if state['pending'] is not None and kind in ('receive', 'frame', 'eof'):
        raise ValueError('pending tool must resolve first')
    if kind == 'tick':
        return state, 'TICK'
    if kind == 'eof':
        halt(state, 'MODEL_EOF')
        return state, 'HALT'
    if kind == 'receive':
        if type(data) is not str or len(data) > policy.chunk * 2:
            raise ValueError('unbounded receive')
        raw = bytes.fromhex(data)
        if not raw or len(raw) > policy.chunk or raw.hex() != data:
            raise ValueError('invalid receive')
        if len(raw) > policy.budget - state['spent']:
            raise ValueError('adapter exceeded budget')
        # Every admitted byte costs one unit, including malformed output.
        state['spent'] += len(raw)
        pending = bytes.fromhex(state['buffer'])
        if b'\n' in pending:
            raise ValueError('must process pending frame before reading')
        pending += raw
        if len(pending.split(b'\n', 1)[0]) > policy.max_frame:
            halt(state, 'FRAME_LIMIT')
            return state, 'HALT'
        state['buffer'] = pending.hex()
        if state['spent'] == policy.budget:
            halt(state, 'BUDGET')
            return state, 'HALT'
        return state, 'RECEIVE'
    pending = bytes.fromhex(state['buffer'])
    if b'\n' not in pending:
        raise ValueError('no complete frame')
    raw, remainder = pending.split(b'\n', 1)
    if len(raw) > policy.max_frame:
        halt(state, 'FRAME_LIMIT')
        return state, 'HALT'
    state['buffer'] = remainder.hex()
    state['frames'] += 1
    verdict = 'REJECT'
    try:
        proposal = strict_json(raw)
        if (type(proposal) is dict and set(proposal) == {'seq', 'op', 'key', 'value'}
                and type(proposal['seq']) is int and proposal['seq'] == state['frames']
                and proposal['op'] in ('put', 'tool_upper')
                and type(proposal['key']) is str and proposal['key'] in ('a', 'b', 'c')
                and type(proposal['value']) is str and len(proposal['value']) <= 128):
            if proposal['op'] == 'put':
                if state['spent'] + policy.write_cost > policy.budget:
                    halt(state, 'BUDGET')
                    return state, 'HALT'
                state['spent'] += policy.write_cost
                state['values'][proposal['key']] = proposal['value']
                state['writes'] += 1
                verdict = 'WRITE'
            else:
                # A write-ahead intent; protected values do not change yet.
                state['pending'] = dict(key=proposal['key'], input=proposal['value'], result=None)
                verdict = 'TOOL_INTENT'
    except (ValueError, TypeError, RecursionError, UnicodeError):
        pass
    if state['frames'] >= policy.max_frames:
        halt(state, 'FRAME_COUNT')
    elif state['spent'] == policy.budget:
        halt(state, 'BUDGET')
    return state, verdict


class Journal:
    """Exclusive new journal. Durable receipt precedes publication of state."""
    def __init__(self, path, policy):
        self.path = os.fspath(path)
        self.fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        self.index, self.head = 0, '0' * 64
        self.append({'policy': asdict(policy)}, initial(policy), 'GENESIS')
        parent = os.open(os.path.dirname(os.path.abspath(self.path)), os.O_RDONLY)
        try:
            os.fsync(parent)
        finally:
            os.close(parent)

    def append(self, event, after, verdict):
        body = dict(index=self.index, previous=self.head, event=event,
                    after=after, verdict=verdict)
        receipt = dict(body, hash=digest(body))
        line = canonical(receipt) + b'\n'
        if len(line) > MAX_RECEIPT:
            raise ValueError('receipt too large')
        view = memoryview(line)
        while view:
            count = os.write(self.fd, view)
            if count <= 0:
                raise OSError('short journal write')
            view = view[count:]
        os.fsync(self.fd)
        self.index += 1
        self.head = receipt['hash']

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None


class Kernel:
    def __init__(self, path, policy=Policy()):
        self.policy = policy.validate()
        self.state = initial(policy)
        self.journal = Journal(path, policy)
        self.failed = False

    def step(self, kind, now, data=None):
        if self.failed:
            raise RuntimeError('journal failure: restart forbidden')
        event = dict(kind=kind, data=data, elapsed_ns=now)
        after, verdict = transition(self.state, event, self.policy)
        try:
            self.journal.append(event, after, verdict)
        except BaseException:
            self.failed = True
            raise
        self.state = after
        return verdict

    def close(self):
        self.journal.close()


def replay(path, *, recover_tail=False, expected_head=None):
    """Validate chain AND recompute semantics. Never grants execution authority."""
    state, policy, head, count, torn = None, None, '0' * 64, 0, False
    with open(path, 'rb') as source:
        while True:
            line = source.readline(MAX_RECEIPT + 1)
            if not line:
                break
            if len(line) > MAX_RECEIPT:
                raise ValueError('oversize receipt')
            if not line.endswith(b'\n'):
                if recover_tail:
                    torn = True
                    break
                raise ValueError('torn tail')
            row = strict_json(line)
            if type(row) is not dict or set(row) != {'index','previous','event','after','verdict','hash'}:
                raise ValueError('receipt schema')
            claimed = row.pop('hash')
            if (type(row['index']) is not int or row['index'] != count
                    or row['previous'] != head or digest(row) != claimed):
                raise ValueError('chain mismatch')
            if count == 0:
                if type(row['event']) is not dict or set(row['event']) != {'policy'}:
                    raise ValueError('genesis schema')
                policy = Policy(**row['event']['policy']).validate()
                after, verdict = initial(policy), 'GENESIS'
            else:
                if (row['event'].get('kind') == 'tool_commit'
                        and row['event'].get('data') != head):
                    raise ValueError('tool commit receipt binding')
                after, verdict = transition(state, row['event'], policy)
            if canonical(row['after']) != canonical(after) or row['verdict'] != verdict:
                raise ValueError('semantic mismatch')
            state, head, count = after, claimed, count + 1
    if count == 0:
        raise ValueError('empty journal')
    if expected_head is not None and expected_head != head:
        raise ValueError('checkpoint mismatch')
    return dict(state=state, head=head, receipts=count, torn_tail=torn,
                recovery_mode='HALTED', executable=False)
