"""Fixed, allowlisted tool worker and write-ahead gate. No shell/network actions."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
# -I removes ambient import paths; allow only this fixed sibling module.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from kernel import canonical, replay, strict_json


class ToolGate:
    def __init__(self, journal_path):
        self.journal_path = os.fspath(journal_path)

    def execute(self, kernel, started_ns, stop_requested):
        """Stage already fsynced by frame. Commit only after post-return replay."""
        pending = kernel.state['pending']
        if pending is None or pending['result'] is not None:
            raise ValueError('missing tool intent')
        remaining = (kernel.policy.deadline_ns - (time.monotonic_ns() - started_ns)) / 1e9
        if remaining <= 0:
            kernel.step('tick', time.monotonic_ns() - started_ns)
            return
        request = canonical({'op': 'upper', 'input': pending['input']})
        try:
            result = subprocess.run([sys.executable, '-I', str(Path(__file__).resolve()), '--worker'],
                                    input=request, capture_output=True,
                                    timeout=remaining, check=True)
            response = strict_json(result.stdout)
            if (type(response) is not dict or set(response) != {'output'}
                    or type(response['output']) is not str or len(response['output']) > 128):
                raise ValueError('bad worker response')
        except (subprocess.SubprocessError, ValueError, UnicodeError):
            kernel.step('tool_abort', time.monotonic_ns() - started_ns)
            return
        now = time.monotonic_ns() - started_ns
        if stop_requested():
            kernel.step('operator_stop', now)
            return
        if now >= kernel.policy.deadline_ns:
            kernel.step('tick', now)
            return
        kernel.step('tool_result', now, response['output'])
        # This precise check is the commit gate. No tail recovery or fallback.
        checked = replay(self.journal_path, expected_head=kernel.journal.head)
        if checked['torn_tail'] or checked['state'] != kernel.state:
            raise ValueError('post-tool replay mismatch')
        if stop_requested():
            kernel.step('operator_stop', time.monotonic_ns() - started_ns)
            return
        kernel.step('tool_commit', time.monotonic_ns() - started_ns, checked['head'])


def worker():
    request = sys.stdin.buffer.read(513)
    if len(request) > 512:
        raise ValueError('worker input limit')
    payload = strict_json(request)
    if (type(payload) is not dict or set(payload) != {'op', 'input'}
            or payload['op'] != 'upper' or type(payload['input']) is not str
            or len(payload['input']) > 128):
        raise ValueError('worker schema')
    output = payload['input'].upper()
    if len(output) > 128:
        raise ValueError('worker output limit')
    sys.stdout.buffer.write(canonical({'output': output}))


if __name__ == '__main__':
    if sys.argv[1:] != ['--worker']:
        raise SystemExit(2)
    worker()
