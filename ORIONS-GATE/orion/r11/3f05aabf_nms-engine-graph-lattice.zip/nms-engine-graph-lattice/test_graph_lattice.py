"""Tests for the lattice-parameter patch to graph.py (ruling D3, 2026-10-04).

    python3 -m unittest test_graph_lattice -v

Stdlib only. TestAgainstOriginal needs reference/graph_original.py (the Drive file, sha256
819056d0...bc2c) and compares the two modules on seeded random graphs: on the CSAA chain the
patched module must reproduce the original exactly, except for nodes the original failed to tag as
cyclic, and for those it must be right where the original was not.
"""
import importlib.util
import os
import random
import unittest

import graph as g
from graph import CANONICAL, CSAA_HANDOFF, ClaimGraph, GraphError, Order, OrderError

HERE = os.path.dirname(os.path.abspath(__file__))


def build(spec, order=CANONICAL):
    """spec: {id: (asserted, [deps])}"""
    return ClaimGraph({k: {"asserted": a, "depends_on": d} for k, (a, d) in spec.items()}, order=order)


class TestOrders(unittest.TestCase):
    def test_canonical_shape(self):
        o = CANONICAL
        self.assertEqual((o.bottom, o.top), ("E0", "E6"))
        self.assertFalse(o.is_chain())
        self.assertEqual(o.covers("E3"), ("E4-A", "E4-B", "E4-C"))
        for f in g.CANONICAL_FACETS:
            self.assertEqual(o.covers(f), ("E5",))
        for a in g.CANONICAL_FACETS:
            for b in g.CANONICAL_FACETS:
                self.assertEqual(o.le(a, b), a == b)
                self.assertEqual(o.meet(a, b), a if a == b else "E3")
        # the stage-order assumption for the half the ruling left open (LatticeCore A1)
        self.assertEqual(o.meet("E4-B", "E5"), "E4-B")
        self.assertEqual(o.meet("E4-C", "E6"), "E4-C")

    def test_meet_is_the_greatest_lower_bound(self):
        for o in (CANONICAL, CSAA_HANDOFF):
            for a in o.levels:
                for b in o.levels:
                    m = o.meet(a, b)
                    self.assertTrue(o.le(m, a) and o.le(m, b))
                    for x in o.levels:
                        if o.le(x, a) and o.le(x, b):
                            self.assertTrue(o.le(x, m), (o.name, a, b, x))
                    self.assertEqual(m, o.meet(b, a))
                    self.assertEqual(o.le(a, b), m == a)

    def test_csaa_chain_is_the_original_ladder(self):
        self.assertTrue(CSAA_HANDOFF.is_chain())
        self.assertEqual(list(CSAA_HANDOFF.levels), g.LEVELS)
        for a in g.LEVELS:
            for b in g.LEVELS:
                self.assertEqual(CSAA_HANDOFF.le(a, b), g.RANK[a] <= g.RANK[b])

    def test_refuses_what_is_not_a_meet_semilattice_with_a_least_level(self):
        rank = {"a": 0, "b": 1}
        cases = {
            "not reflexive": (["a", "b"], lambda x, y: rank[x] < rank[y]),
            "not antisymmetric": (["a", "b"], lambda x, y: True),
            "no least level": (["a", "b"], lambda x, y: x == y),
            # bowtie: c and d have two maximal common lower bounds, a and b
            "no meet": (["0", "a", "b", "c", "d"],
                        lambda x, y: x == y or x == "0" or (x in "ab" and y in "cd")),
        }
        for why, (levels, le) in cases.items():
            with self.subTest(why):
                with self.assertRaises(OrderError):
                    Order(why, levels, le)
        steps = {("a", "b"), ("b", "c")}  # a<=b<=c without a<=c
        with self.assertRaises(OrderError):
            Order("not transitive", ["a", "b", "c"], lambda x, y: x == y or (x, y) in steps)

    def test_order_error_is_a_graph_error(self):
        self.assertTrue(issubclass(OrderError, GraphError))

    def test_meet_of_nothing_needs_a_top(self):
        vee = Order("vee", ["0", "a", "b"], lambda x, y: x == y or x == "0")
        self.assertIsNone(vee.top)
        with self.assertRaises(OrderError):
            vee.meet_all([])
        self.assertEqual(CANONICAL.meet_all([]), "E6")

    def test_maximal_never_synthesizes(self):
        self.assertEqual(CANONICAL.maximal(["E4-B", "E2", "E4-A", "E4-A"]), ["E4-A", "E4-B"])
        self.assertEqual(CANONICAL.maximal(["E4-B", "E5"]), ["E5"])


class TestEffective(unittest.TestCase):
    def test_default_order_is_canonical(self):
        self.assertIs(build({"n": ("E4-C", [])}).order, CANONICAL)

    def test_handoff_levels_need_the_handoff_order(self):
        with self.assertRaises(GraphError) as ctx:
            build({"n": ("E3self", [])})
        self.assertIn("pass order=CSAA_HANDOFF", str(ctx.exception))
        with self.assertRaises(GraphError) as ctx:
            build({"n": ("E4-A", [])}, order=CSAA_HANDOFF)
        self.assertIn("pass order=CANONICAL", str(ctx.exception))
        self.assertEqual(build({"n": ("E3self", [])}, order=CSAA_HANDOFF).effective("n")["level"], "E3self")

    def test_rejects_malformed_input(self):
        for bad in ({}, [], {"n": "E2"}, {"n": {"asserted": "E7"}}):
            with self.subTest(bad=bad):
                with self.assertRaises(GraphError):
                    ClaimGraph(bad)
        with self.assertRaises(GraphError):
            ClaimGraph({"n": {"asserted": "E1"}}, order="canonical")

    def test_two_facets_meet_at_E3_and_both_limit(self):
        G = build({"X": ("E4-A", []), "Y": ("E4-B", []), "N": ("E6", ["X", "Y"])})
        self.assertEqual(G.effective("N"), {"level": "E3", "limiters": ["X", "Y"], "reason": "propagated"})

    def test_only_the_lower_dependency_limits_beside_a_facet(self):
        G = build({"X": ("E4-A", []), "Y": ("E3", []), "N": ("E6", ["X", "Y"])})
        self.assertEqual(G.effective("N"), {"level": "E3", "limiters": ["Y"], "reason": "propagated"})

    def test_a_facet_is_kept_when_nothing_disagrees(self):
        G = build({"X": ("E4-A", []), "N": ("E4-A", ["X"]), "M": ("E5", ["X"])})
        self.assertEqual(G.effective("N")["level"], "E4-A")
        self.assertEqual(G.effective("N")["limiters"], ["N", "X"])
        self.assertEqual(G.effective("M"), {"level": "E4-A", "limiters": ["X"], "reason": "propagated"})

    def test_own_assertion_limits_when_lowest(self):
        G = build({"X": ("E5", []), "N": ("E2", ["X"])})
        self.assertEqual(G.effective("N"), {"level": "E2", "limiters": ["N"], "reason": "self"})

    def test_missing_dependency_fails_closed(self):
        G = build({"N": ("E5", ["ghost"])})
        self.assertEqual(G.effective("N"), {"level": "E0", "limiters": ["ghost"], "reason": "propagated"})
        self.assertEqual(G.effective("ghost")["reason"], "EVID-MISSING-DEP")

    def test_every_node_on_a_cycle_is_tagged(self):
        # the gap in the original: D is on D->C->A->D, reached through C after C finished
        G = build({"A": ("E5", ["B", "D"]), "B": ("E5", ["C"]), "C": ("E5", ["A"]), "D": ("E5", ["C"]),
                   "X": ("E5", ["D"])})
        for cid in "ABCD":
            self.assertEqual(G.effective(cid), {"level": "E0", "limiters": [cid], "reason": "EVID-CYCLE"})
        self.assertEqual(G.effective("X"), {"level": "E0", "limiters": ["D"], "reason": "propagated"})

    def test_self_loop_is_a_cycle(self):
        G = build({"S": ("E3", ["S"]), "T": ("E3", ["S"])})
        self.assertEqual(G.effective("S")["reason"], "EVID-CYCLE")
        self.assertEqual(G.effective("T"), {"level": "E0", "limiters": ["S"], "reason": "propagated"})

    def test_deep_chains_do_not_recurse(self):
        n = 20000
        spec = {f"c{i}": ("E5", [f"c{i + 1}"]) for i in range(n)}
        spec[f"c{n}"] = ("E4-B", [])
        G = build(spec)
        self.assertEqual(G.effective("c0"), {"level": "E4-B", "limiters": [f"c{n}"], "reason": "propagated"})

    def test_limiters_are_the_union_of_the_smallest_blocking_sets(self):
        # three facets: every way up needs two of them to rise; all three are listed
        G = build({"A": ("E4-A", []), "B": ("E4-B", []), "C": ("E4-C", []), "N": ("E6", ["A", "B", "C"])})
        self.assertEqual(G.effective("N"), {"level": "E3", "limiters": ["A", "B", "C"], "reason": "propagated"})
        # own E4-B assertion beside an E4-A and an E3 dependency: Y blocks every way up, N and X are
        # alternatives, and the union lists all three
        G = build({"X": ("E4-A", []), "Y": ("E3", []), "N": ("E4-B", ["X", "Y"])})
        self.assertEqual(G.effective("N"), {"level": "E3", "limiters": ["N", "X", "Y"], "reason": "propagated"})

    def test_a_graph_changed_in_place_is_refused_not_looped(self):
        import signal
        if hasattr(signal, "alarm"):
            signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(AssertionError("looped")))
            signal.alarm(5)
        try:
            G = build({"a": ("E3", ["b"]), "b": ("E3", [])})
            G.nodes["b"]["depends_on"].append("a")   # a cycle the constructor never saw
            with self.assertRaises(GraphError):
                G.effective("a")
        finally:
            if hasattr(signal, "alarm"):
                signal.alarm(0)

    def test_levels_need_not_be_strings(self):
        ints = Order.chain("ints", [0, 1, 2])
        G = ClaimGraph({"a": {"asserted": 2, "depends_on": ["b"]}, "b": {"asserted": 1}}, order=ints)
        self.assertEqual(G.effective("a")["level"], 1)
        self.assertFalse(CANONICAL.has(["E1"]))

    def test_any_meet_semilattice_can_be_supplied(self):
        diamond = Order("diamond", ["lo", "l", "r", "hi"],
                        lambda x, y: x == y or x == "lo" or y == "hi")
        G = build({"a": ("l", []), "b": ("r", []), "n": ("hi", ["a", "b"])}, order=diamond)
        self.assertEqual(G.effective("n"), {"level": "lo", "limiters": ["a", "b"], "reason": "propagated"})


class TestCeiling(unittest.TestCase):
    def test_ceiling_is_an_antichain_not_a_join(self):
        G = build({"X": ("E4-A", []), "Y": ("E4-B", []), "Z": ("E4-B", []), "N": ("E6", ["X", "Y"])})
        self.assertEqual(G.ceilings(), [("E4-A", ["X"]), ("E4-B", ["Y", "Z"])])
        with self.assertRaises(GraphError):
            G.ceiling()

    def test_single_maximum(self):
        G = build({"X": ("E4-A", []), "Y": ("E5", ["X"]), "W": ("E2", [])})
        self.assertEqual(G.ceiling(), ("E4-A", ["X", "Y"]))
        G = build({"a": ("E3self", []), "b": ("E2", [])}, order=CSAA_HANDOFF)
        self.assertEqual(G.ceiling(), ("E3self", ["a"]))

    def test_all_at_the_bottom(self):
        G = build({"a": ("E0", []), "b": ("E2", ["ghost"])})
        self.assertEqual(G.ceiling(), ("E0", ["a", "b"]))

    def test_asserting_uses_the_least_level(self):
        G = build({"a": ("E0", []), "b": ("E1", ["a"])})
        self.assertEqual([r["id"] for r in G.asserting()], ["b"])


def _load_original():
    path = os.path.join(HERE, "reference", "graph_original.py")
    if not os.path.exists(path):
        return None
    spec = importlib.util.spec_from_file_location("graph_original", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _on_a_cycle(spec, cid):
    seen, todo = set(), [d for d in spec[cid][1] if d in spec]
    while todo:
        x = todo.pop()
        if x == cid:
            return True
        if x not in seen:
            seen.add(x)
            todo.extend(d for d in spec[x][1] if d in spec)
    return False


def _random_graphs(levels, count, seed):
    rng = random.Random(seed)
    for _ in range(count):
        n = rng.randint(1, 7)
        ids = [f"n{i}" for i in range(n)]
        spec = {}
        for cid in ids:
            deps = rng.sample(ids + ["ghost"], rng.randint(0, min(3, n)))
            spec[cid] = (rng.choice(levels), deps)
        yield spec


class TestAgainstOriginal(unittest.TestCase):
    """On a chain the patch is the original, plus the cycle-tagging fix."""

    @classmethod
    def setUpClass(cls):
        cls.orig = _load_original()

    def setUp(self):
        if self.orig is None:
            self.skipTest("reference/graph_original.py not present: the original is unconfirmed here")

    def compare(self, spec, order, to_orig=lambda lvl: lvl):
        """Returns how many nodes the original failed to tag as cyclic."""
        nodes = {k: {"asserted": to_orig(a), "depends_on": d} for k, (a, d) in spec.items()}
        old = self.orig.ClaimGraph(nodes)
        new = build(spec, order)
        exact = {cid for cid in spec if _on_a_cycle(spec, cid)}
        # the original's cycle set is a subset of the true one, never more
        self.assertLessEqual(old._cyclic, exact, spec)
        # the fix changes no level anywhere: a missed cycle node was already E0 through the cycle
        for cid in spec:
            self.assertEqual(to_orig(new.effective(cid)["level"]), old.effective(cid)["level"], (spec, cid))
        # and with the true cycle set, the original algorithm IS the patched one, field for field
        fixed = self.orig.ClaimGraph(nodes)
        fixed._cyclic, fixed._memo = exact, {}
        for cid in list(spec) + ["ghost"]:
            o, n = fixed.effective(cid), new.effective(cid)
            self.assertEqual((to_orig(n["level"]), n["limiters"], n["reason"]),
                             (o["level"], o["limiters"], o["reason"]), (spec, cid))
        self.assertEqual(new.limiter_census(), fixed.limiter_census())
        self.assertEqual((to_orig(new.ceiling()[0]), new.ceiling()[1]), fixed.ceiling())
        self.assertEqual([r["id"] for r in new.collapses()], [r["id"] for r in fixed.collapses()])
        self.assertEqual([r["id"] for r in new.asserting()], [r["id"] for r in fixed.asserting()])
        return len(exact - old._cyclic)

    def test_identical_on_the_csaa_chain(self):
        retagged = sum(self.compare(spec, CSAA_HANDOFF) for spec in _random_graphs(g.LEVELS, 3000, 20261004))
        self.assertGreater(retagged, 0, "the sample never exercised the cycle-tagging gap")

    def test_identical_on_canonical_graphs_without_facets(self):
        # the old adapter's order-preserving name map; facets have no image in the chain
        levels = ["E0", "E1", "E2", "E3", "E5", "E6"]
        for spec in _random_graphs(levels, 2000, 7):
            self.compare(spec, CANONICAL)


if __name__ == "__main__":
    unittest.main()
