# nms-engine `graph.py`: the order is a parameter

Ruling D3 (2026-10-04): `ClaimGraph` should not hardcode the CSAA handoff's chain. It takes an
order, and the default is the canonical faceted axis.

```python
from graph import ClaimGraph, CANONICAL, CSAA_HANDOFF, Order

ClaimGraph(nodes)                        # canonical faceted axis (default)
ClaimGraph(nodes, order=CSAA_HANDOFF)    # the handoff's own ladder, exactly as before
```

| order | levels |
|---|---|
| `CANONICAL` | `E0 < E1 < E2 < E3 < {E4-A, E4-B, E4-C} < E5 < E6`, facets pairwise incomparable |
| `CSAA_HANDOFF` | `E0 < E1 < E2 < E3self < E3 < E4 < E5 < E6`, a chain (`LEVELS`, `RANK`, `MEANING`, unchanged) |

Any finite meet-semilattice with a least level can be passed as an `Order`. It is checked when built
(partial order, least level, a unique meet for every pair) and refused otherwise.

## What changed

**Effective level = the meet**, not the minimum by rank. On a chain these are the same. On the
canonical axis, a claim depending on an E4-A claim and an E4-B claim, with nothing holding both, is
held at **E3**.

**Every node on a cycle is tagged `EVID-CYCLE`** (Tarjan, strongly connected components). The
previous search marked only the nodes on its current path when it met a back edge. With
`A->B->C->A` and `A->D->C`, D lies on the cycle `D->C->A->D` but was reported as `propagated`,
limited by C. Its **level was already right** (E0, through C); its reason and limiters were not, and
the error flowed into `limiter_census()`. Measured: the original mis-tagged 64 nodes across the
8,308 facet-free LatticeCore table graphs, and 45 nodes across 3,000 random CSAA graphs in the test
suite. Levels were identical in every case.

**Limiters on a partial order.** A claim held at level L can only rise through one of L's covers
(the levels immediately above it). For each cover, the contributions not at or above it block that
way up. `limiters` is the **union of the smallest blocking sets**: every contribution whose rise is
part of some cheapest way up. On a chain, L has one cover and one blocking set, the contributions
sitting at L. That is exactly the previous definition, and the differential test checks it field for
field. On the faceted axis E3 has three covers, so the union can mix alternatives:

| N held at E3 by | `limiters` | what it takes to rise |
|---|---|---|
| E4-A and E4-B deps, N asserted E6 | both | raise **either** one |
| E4-A, E4-B and E4-C deps, N asserted E6 | all three | raise **any two** |
| E4-A dep X and E3 dep Y, N asserted E6 | Y only | raise Y |
| E4-A dep X and E3 dep Y, N asserted E4-B | N, X, Y | raise Y, **and** N or X |

A contribution that is in every blocking set (Y in the last two rows) must rise for any way up. The
list does not single those out; the census counts alternatives as load.

**The ceiling is an aggregation.** `ceilings()` returns every maximal effective level, each with its
holders. `[("E4-A", [...]), ("E4-B", [...])]` is two entries, never a synthesized E5.
`ceiling()` keeps its `(level, holders)` shape and always succeeds on a chain. With incomparable
maxima, it raises `GraphError` rather than picking one.

**No recursion.** Evaluation is an explicit post-order, so a 20,000-deep dependency chain runs. The
previous version would have hit Python's recursion limit. A `ClaimGraph` is not meant to be
changed after construction: cycles are found once and results are memoized. If an in-place change
creates a cycle the constructor never saw, an evaluation that walks into it refuses with
`GraphError` instead of looping. Results already computed are **not** revisited, so they can be
stale. Build a new graph instead.

**Levels need not be strings.** Any hashable level works in a supplied `Order`.

## Compatibility: read before merging

- **The default changed, and the change cannot always be detected.** Every caller that builds
  `ClaimGraph` from CSAA-labelled data must now pass `order=CSAA_HANDOFF`.
  - If the data uses a CSAA-only level (`E3self`, or `E4` meaning operational validation),
    construction fails loudly: `unknown level 'E3self' on order canonical-faceted; 'E3self' is a
    level of csaa-handoff, pass order=CSAA_HANDOFF`.
  - If it only uses names the two ladders share (E0, E1, E2, E3, E5, E6), it is **not detected**. It
    builds under the canonical order. The computed levels come out as the same strings either way
    (the differential test shows this), but anything that interprets them reads them with canonical
    meanings: CSAA's E3 is independent reproduction, while canonical E3 is same-organization replay.
    That covers `order.meaning`, thresholds and reports.
- **Only `graph.py` was available** (Drive, sha256 `819056d0…bc2c`). The rest of nms-engine
  (`canon.py`, `envelope.py`, `gate.py`, `report.py`, `__main__.py`, its 39-test suite) was not, so
  their compatibility is **unverified**. The likely touch points are any `ClaimGraph(...)`
  construction (pass the order), any code that reads `RANK[level]` for a canonical level (use
  `graph.order.le`), and any caller of `ceiling()` on canonical graphs (handle the refusal or use
  `ceilings()`). Please run the full suite.
- Receipts or reports that record `reason` or `limiters` change for nodes the old search mis-tagged.
  They never change for levels.
- `E5` and `E6` sit above every facet. That is the stage order. The 2026-10-04 ruling left that half
  of the order open (LatticeCore assumption A1). If it is decided otherwise, `CANONICAL` is the one
  definition to change.

## Evidence

```
python3 -m unittest test_graph_lattice -v      # 28 tests
```

- `TestAgainstOriginal` loads `reference/graph_original.py` (the Drive file, byte-identical) and
  compares on seeded random graphs (3,000 on the CSAA chain, 2,000 canonical without facets). The
  original's cycle set is always a subset of the true one, and levels are identical everywhere. With
  the true cycle set substituted into the original, the original algorithm equals the patched module
  field for field: level, limiters, reason, census, ceiling, collapses, asserting.
- LatticeCore conformance (`nms_effective`, format v2, pinned): **0 mismatches on all 55,119 node
  values in 17,388 graphs, facet graphs included, nothing skipped.** That is with the default order.
  Run 2 could only confirm 25,175 of them, because 9,080 facet graphs had no image in the chain.
- Each of these, put into the real code in-process, is caught: facets meeting by list position, a
  cyclic node keeping its assertion, a missing dependency counting as E6. Each of these, put into
  this file, fails the unit tests: the old cycle search, facets meeting by list position, limiters
  by equality only, a single-maximum ceiling. A missed self-loop now fails the suite (it used to
  hang it, which a second review found; that review was by another Claude instance with the same
  principal, so it was not independent).
