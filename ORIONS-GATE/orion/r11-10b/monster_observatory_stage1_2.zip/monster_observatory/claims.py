"""Stage-1 claim registry.

Statuses deliberately distinguish source-backed mathematical/historical claims
from locally machine-checked arithmetic. Nothing here proves the Monster or
monstrous moonshine.
"""

CLAIMS = [
    {
        "claim": "The Monster is the largest sporadic simple group.",
        "status": "SOURCE_BACKED_NOT_REPROVED",
        "local_verification": "NONE",
    },
    {
        "claim": "There are 26 sporadic simple groups.",
        "status": "SOURCE_BACKED_NOT_REPROVED",
        "local_verification": "NONE",
    },
    {
        "claim": "The displayed decimal order equals the displayed prime factorization.",
        "status": "VERIFIED_LOCAL_EXACT_ARITHMETIC",
        "local_verification": "order.py",
    },
    {
        "claim": "The smallest nontrivial complex representation has dimension 196883.",
        "status": "SOURCE_BACKED_NOT_RECONSTRUCTED",
        "local_verification": "NONE",
    },
    {
        "claim": "The Griess algebra has dimension 196884 and Monster automorphism group.",
        "status": "SOURCE_BACKED_NOT_RECONSTRUCTED",
        "local_verification": "NONE",
    },
    {
        "claim": "196884 = 1 + 196883.",
        "status": "VERIFIED_LOCAL_EXACT_ARITHMETIC",
        "local_verification": "j_invariant.py",
    },
    {
        "claim": "21493760 = 1 + 196883 + 21296876.",
        "status": "VERIFIED_LOCAL_EXACT_ARITHMETIC",
        "local_verification": "j_invariant.py",
    },
    {
        "claim": "J(q)=q^-1+196884 q+21493760 q^2+... from j=E4^3/Delta and J=j-744.",
        "status": "VERIFIED_LOCAL_FORMAL_SERIES_ARITHMETIC_TO_Q2",
        "local_verification": "j_invariant.py",
    },
    {
        "claim": "The Monster is the full automorphism group of the moonshine module VOA V^natural.",
        "status": "SOURCE_BACKED_THEOREM_NOT_REPROVED",
        "local_verification": "NONE",
    },
    {
        "claim": "Monstrous moonshine links Monster traces to special modular functions.",
        "status": "INFORMAL_SLOGAN_REQUIRES_PRECISE_THEOREM_STATEMENT",
        "local_verification": "NONE",
    },
    {
        "claim": "The Monster was discovered in 1971.",
        "status": "REJECTED_HISTORICAL_CLAIM",
        "local_verification": "NONE",
        "note": "Sources place prediction around 1973; Griess announced a construction in 1980 and published it in 1982.",
    },
    {
        "claim": "The central polyhedral artwork is a geometric realization of Monster symmetry.",
        "status": "ARTISTIC_NO_MATHEMATICAL_AUTHORITY",
        "local_verification": "NONE",
    },
]
