"""Derive initial j/J coefficients with exact integer series arithmetic.

Euler's function is generated from Euler's pentagonal-number theorem:
  prod_{n>=1}(1-q^n) = sum_{k in Z} (-1)^k q^{k(3k-1)/2}.
No in-place recurrence is used.
"""
from math import comb

def sigma_k(n, k):
    return sum(d**k for d in range(1, n+1) if n % d == 0)

def e4_series(N):
    # E4(q) = 1 + 240 sum_{n>=1} sigma_3(n) q^n
    return [1] + [240 * sigma_k(n, 3) for n in range(1, N+1)]

def mul(a, b, N):
    out = [0]*(N+1)
    for i, ai in enumerate(a):
        if ai == 0:
            continue
        for j, bj in enumerate(b):
            if i+j > N:
                break
            out[i+j] += ai*bj
    return out

def pow_series(a, exponent, N):
    out = [1] + [0]*N
    base = a[:N+1]
    e = exponent
    while e:
        if e & 1:
            out = mul(out, base, N)
        e >>= 1
        if e:
            base = mul(base, base, N)
    return out

def euler_phi_series(N):
    # Explicit generalized pentagonal sum. Coefficient at q^0 is 1.
    out = [0]*(N+1)
    out[0] = 1
    k = 1
    while True:
        g1 = k*(3*k-1)//2
        g2 = k*(3*k+1)//2
        if g1 > N and g2 > N:
            break
        s = -1 if (k % 2) else 1
        if g1 <= N:
            out[g1] += s
        if g2 <= N:
            out[g2] += s
        k += 1
    return out

def div_series(num, den, N):
    # Exact formal power-series division; requires den[0] = 1.
    if den[0] != 1:
        raise ValueError("denominator constant term must be 1")
    q = [0]*(N+1)
    for n in range(N+1):
        q[n] = num[n] - sum(den[k]*q[n-k] for k in range(1, n+1))
    return q

def j_shifted_coefficients(max_J_power=2):
    # j = q^-1 * E4^3 / phi(q)^24.
    # To obtain J through q^m we need the quotient through q^(m+1).
    N = max_J_power + 1
    e4 = e4_series(N)
    e4_cubed = pow_series(e4, 3, N)
    phi24 = pow_series(euler_phi_series(N), 24, N)
    r = div_series(e4_cubed, phi24, N)
    # j has coefficient r[n] at q^(n-1); J=j-744 only changes q^0.
    coeffs = {-1: r[0], 0: r[1]-744}
    for power in range(1, max_J_power+1):
        coeffs[power] = r[power+1]
    return coeffs

def verify_first_moonshine_identities():
    c = j_shifted_coefficients(2)
    return {
        "J_coefficients": {str(k): v for k, v in c.items()},
        "196884_identity": 196884 == 1 + 196883,
        "21493760_identity": 21493760 == 1 + 196883 + 21296876,
        "J_q1_match": c[1] == 196884,
        "J_q2_match": c[2] == 21493760,
    }

if __name__ == "__main__":
    print(verify_first_moonshine_identities())
