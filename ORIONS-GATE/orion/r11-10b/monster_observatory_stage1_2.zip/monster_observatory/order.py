"""Exact arithmetic checks for the Monster order. Stdlib only."""
PRIME_POWERS = {
    2: 46, 3: 20, 5: 9, 7: 6, 11: 2, 13: 3,
    17: 1, 19: 1, 23: 1, 29: 1, 31: 1, 41: 1, 47: 1, 59: 1, 71: 1,
}
STATED_ORDER = 808017424794512875886459904961710757005754368000000000

def product_from_factorization():
    n = 1
    for p, e in PRIME_POWERS.items():
        n *= p**e
    return n

def verify_order():
    computed = product_from_factorization()
    return {
        "computed": computed,
        "stated": STATED_ORDER,
        "match": computed == STATED_ORDER,
    }

if __name__ == "__main__":
    print(verify_order())
