import unittest
from j_invariant import euler_phi_series, j_shifted_coefficients, verify_first_moonshine_identities

class TestJInvariant(unittest.TestCase):
    def test_pentagonal_initial_terms(self):
        # phi(q)=1-q-q^2+q^5+q^7-...
        self.assertEqual(euler_phi_series(7), [1,-1,-1,0,0,1,0,1])

    def test_J_initial_coefficients(self):
        c = j_shifted_coefficients(2)
        self.assertEqual(c[-1], 1)
        self.assertEqual(c[0], 0)
        self.assertEqual(c[1], 196884)
        self.assertEqual(c[2], 21493760)

    def test_moonshine_integer_identities(self):
        v = verify_first_moonshine_identities()
        self.assertTrue(v["196884_identity"])
        self.assertTrue(v["21493760_identity"])
        self.assertTrue(v["J_q1_match"])
        self.assertTrue(v["J_q2_match"])

if __name__ == "__main__":
    unittest.main()
