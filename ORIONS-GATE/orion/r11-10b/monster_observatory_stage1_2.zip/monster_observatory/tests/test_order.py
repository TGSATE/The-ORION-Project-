import unittest
from order import STATED_ORDER, product_from_factorization, verify_order

class TestMonsterOrder(unittest.TestCase):
    def test_factorization_matches_decimal(self):
        self.assertEqual(product_from_factorization(), STATED_ORDER)
        self.assertTrue(verify_order()["match"])

if __name__ == "__main__":
    unittest.main()
