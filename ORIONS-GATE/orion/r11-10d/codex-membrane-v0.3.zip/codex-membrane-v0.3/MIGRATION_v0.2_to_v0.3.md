# Migration: v0.2 → v0.3

Claim envelopes add two required fields:

- `canon_history`
- `cross_corpus_links`

Human-reviewed relations additionally require:

- `supporting_sources` referencing declared `source_roots`
- `reviewer`

Formally-derived relations require `derivation_ref`.

The claim verifier grows from 10 to 12 gates. Receipt format moves from `codex-membrane-receipt-1` to `codex-membrane-receipt-2` and now supports exact replay.

v0.3 also introduces a separate corpus-graph audit surface. A claim can pass while a corpus containing it fails because of cross-node leakage or transitive Mythos-to-operational taint. This distinction is intentional.
