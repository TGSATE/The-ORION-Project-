import json, pathlib, unittest, copy, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from codex_membrane.verifier import verify_claim
from codex_membrane.graph import audit_corpus
from codex_membrane.receipt import make_receipt, make_corpus_receipt, replay_claim_receipt, replay_corpus_receipt


def load(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))

class ClaimTests(unittest.TestCase):
    def test_valid_symbolic_passes(self):
        r = verify_claim(load("fixtures/valid/symbolic_claim.json"), {"authority":"O0"})
        self.assertTrue(r.passed); self.assertFalse(r.protected_state_mutated)

    def test_valid_monster_passes(self):
        self.assertTrue(verify_claim(load("fixtures/valid/monster_arithmetic.json")).passed)

    def test_nc01_sacred_number_rejected(self):
        r = verify_claim(load("fixtures/hostile/nc01_717_budget.json"))
        self.assertIn("MYTHIC_VALUE_OPERATIONAL_DEPENDENCY", [x.code for x in r.rules])

    def test_nc02_relation_smuggling_rejected(self):
        r = verify_claim(load("fixtures/hostile/nc02_relation_smuggling.json"))
        self.assertIn("RELATION_SMUGGLING", [x.code for x in r.rules])

    def test_nc03_therapeutic_overclaim_rejected(self):
        r = verify_claim(load("fixtures/hostile/nc03_therapeutic_overclaim.json"))
        self.assertIn("REFLECTIVE_TO_CLINICAL_PROMOTION", [x.code for x in r.rules])

    def test_nc04_implicit_register_shift_rejected(self):
        r = verify_claim(load("fixtures/hostile/nc04_dks_divinity.json"))
        self.assertIn("IMPLICIT_REGISTER_PROMOTION", [x.code for x in r.rules])

    def test_nc05_formal_to_empirical_rejected(self):
        r = verify_claim(load("fixtures/hostile/nc05_monster_overclaim.json"))
        self.assertIn("IMPLICIT_REGISTER_PROMOTION", [x.code for x in r.rules])

    def test_nc06_selfmodel_consciousness_rejected(self):
        r = verify_claim(load("fixtures/hostile/nc06_selfmodel_consciousness.json"))
        self.assertIn("IMPLICIT_REGISTER_PROMOTION", [x.code for x in r.rules])

    def test_authority_mint_rejected(self):
        c = load("fixtures/valid/symbolic_claim.json"); c["authority_class"] = "O1"
        self.assertIn("AUTHORITY_MINTING_FORBIDDEN", [x.code for x in verify_claim(c).rules])

    def test_authority_delta_rejected(self):
        c = load("fixtures/valid/symbolic_claim.json"); c["authority_delta"] = 1
        self.assertIn("AUTHORITY_DELTA_NONZERO", [x.code for x in verify_claim(c).rules])

    def test_relation_requires_known_support(self):
        c = load("fixtures/valid/symbolic_claim.json"); c["relations"][0]["supporting_sources"] = ["UNKNOWN"]
        self.assertIn("RELATION_SOURCE_UNKNOWN", [x.code for x in verify_claim(c).rules])

    def test_human_reviewed_requires_reviewer(self):
        c = load("fixtures/valid/symbolic_claim.json"); c["relations"][0].pop("reviewer")
        self.assertIn("RELATION_REVIEWER_MISSING", [x.code for x in verify_claim(c).rules])

    def test_canon_skip_rejected(self):
        c = load("fixtures/valid/symbolic_claim.json"); c["canon_history"] = ["INGESTED","CANON_CANDIDATE"]
        self.assertIn("CANON_TRANSITION_FORBIDDEN", [x.code for x in verify_claim(c).rules])

    def test_canon_relation_review_incomplete_rejected(self):
        c = load("fixtures/valid/symbolic_claim.json"); c["relations"][0]["state"] = "SOURCE_SUPPORTED"; c["relations"][0]["consumed_as_canonical"] = False
        self.assertIn("CANON_RELATION_REVIEW_INCOMPLETE", [x.code for x in verify_claim(c).rules])

    def test_cross_corpus_ontology_requires_review(self):
        c = load("fixtures/valid/monster_arithmetic.json")
        c["cross_corpus_links"]=[{"target_id":"OTHER","link_type":"ONTOLOGY_EQUIVALENCE","human_reviewed":False}]
        self.assertIn("CROSS_CORPUS_ONTOLOGY_UNREVIEWED", [x.code for x in verify_claim(c).rules])

    def test_reject_preserves_protected_state(self):
        c = load("fixtures/hostile/nc01_717_budget.json"); s={"authority":"O0","protected":[1,2,3]}
        self.assertFalse(verify_claim(c,s).protected_state_mutated)

    def test_receipt_deterministic_and_replays(self):
        c = load("fixtures/valid/symbolic_claim.json")
        a=make_receipt(verify_claim(c,{"authority":"O0","canon":"OPEN"}))
        b=make_receipt(verify_claim(c,{"authority":"O0","canon":"OPEN"}))
        self.assertEqual(a,b)
        self.assertEqual("PASS", replay_claim_receipt(c,a,{"authority":"O0","canon":"OPEN"})["replay"])

    def test_tampered_receipt_rejected(self):
        c=load("fixtures/valid/symbolic_claim.json")
        r=make_receipt(verify_claim(c,{"authority":"O0","canon":"OPEN"})); r["decision"]="REJECT"
        self.assertEqual("REJECT", replay_claim_receipt(c,r,{"authority":"O0","canon":"OPEN"})["replay"])

class CorpusTests(unittest.TestCase):
    def test_valid_graph_passes(self):
        self.assertTrue(audit_corpus(load("fixtures/corpus/valid/codex_architecture.json")).passed)

    def _assert_leak(self, file, code):
        r=audit_corpus(load("fixtures/corpus/hostile/"+file))
        self.assertFalse(r.passed)
        got={x.leak_code for x in r.leaks if x.detected}
        self.assertIn(code,got)

    def test_l1_relation_leakage(self): self._assert_leak("l1_relation_leakage.json","L1_RELATION_LEAKAGE")
    def test_l2_register_leakage(self): self._assert_leak("l2_register_leakage.json","L2_REGISTER_LEAKAGE")
    def test_l3_authority_leakage(self): self._assert_leak("l3_authority_leakage.json","L3_AUTHORITY_LEAKAGE")
    def test_l4_mythic_taint_propagates(self): self._assert_leak("l4_mythic_taint.json","L4_MYTHIC_OPERATIONAL_TAINT")
    def test_l5_therapeutic_leakage(self): self._assert_leak("l5_therapeutic_leakage.json","L5_THERAPEUTIC_LEAKAGE")
    def test_l6_name_leakage(self): self._assert_leak("l6_name_leakage.json","L6_NAME_LEAKAGE")

    def test_corpus_receipt_deterministic_and_replays(self):
        g=load("fixtures/corpus/valid/codex_architecture.json")
        a=make_corpus_receipt(audit_corpus(g)); b=make_corpus_receipt(audit_corpus(g))
        self.assertEqual(a,b); self.assertEqual("PASS", replay_corpus_receipt(g,a)["replay"])

    def test_tampered_corpus_receipt_rejected(self):
        g=load("fixtures/corpus/valid/codex_architecture.json")
        r=make_corpus_receipt(audit_corpus(g)); r["graph_hash"]="0"*64
        self.assertEqual("REJECT", replay_corpus_receipt(g,r)["replay"])

if __name__ == "__main__": unittest.main()
