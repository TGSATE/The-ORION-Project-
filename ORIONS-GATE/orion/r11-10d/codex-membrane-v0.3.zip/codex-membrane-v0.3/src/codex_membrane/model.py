from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List

@dataclass
class RuleResult:
    rule_id: str
    passed: bool
    code: str
    detail: str

    def as_dict(self) -> Dict[str, Any]:
        return {"rule_id": self.rule_id, "passed": self.passed, "code": self.code, "detail": self.detail}

@dataclass
class VerificationResult:
    decision: str
    claim_id: str
    claim_hash: str
    policy_hash: str
    rules: List[RuleResult] = field(default_factory=list)
    protected_state_mutated: bool = False

    @property
    def passed(self) -> bool:
        return self.decision == "PASS"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "decision": self.decision,
            "claim_id": self.claim_id,
            "claim_hash": self.claim_hash,
            "policy_hash": self.policy_hash,
            "protected_state_mutated": self.protected_state_mutated,
            "rules": [r.as_dict() for r in self.rules],
        }

@dataclass
class LeakResult:
    leak_code: str
    detected: bool
    detail: str

    def as_dict(self) -> Dict[str, Any]:
        return {"leak_code": self.leak_code, "detected": self.detected, "detail": self.detail}

@dataclass
class CorpusAuditResult:
    decision: str
    graph_id: str
    graph_hash: str
    policy_hash: str
    leaks: List[LeakResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.decision == "PASS"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "decision": self.decision,
            "graph_id": self.graph_id,
            "graph_hash": self.graph_hash,
            "policy_hash": self.policy_hash,
            "leaks": [x.as_dict() for x in self.leaks],
        }
