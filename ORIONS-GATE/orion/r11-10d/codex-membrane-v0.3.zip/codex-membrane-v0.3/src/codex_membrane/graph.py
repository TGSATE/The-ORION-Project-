from __future__ import annotations
from collections import defaultdict, deque
from typing import Any, Dict, List, Set
from .canonical import sha256_obj
from .model import CorpusAuditResult, LeakResult
from .verifier import POLICY_HASH
from . import policy


def _leak(code: str, detected: bool, detail: str) -> LeakResult:
    return LeakResult(code, detected, detail)


def _nodes(graph: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for node in graph.get("nodes", []):
        if isinstance(node, dict) and node.get("id"):
            out[node["id"]] = node
    return out


def _taint_reaches_operational(graph: Dict[str, Any], nodes: Dict[str, Dict[str, Any]]) -> List[str]:
    adj: Dict[str, List[str]] = defaultdict(list)
    for e in graph.get("edges", []):
        if e.get("propagates_semantics", False):
            adj[e.get("from")].append(e.get("to"))
    starts = [nid for nid, n in nodes.items() if n.get("mythos_derived")]
    q = deque(starts)
    seen: Set[str] = set(starts)
    hits: List[str] = []
    while q:
        cur = q.popleft()
        n = nodes.get(cur, {})
        if n.get("operational") or n.get("operational_behavior"):
            hits.append(cur)
        for nxt in adj.get(cur, []):
            if nxt in nodes and nxt not in seen:
                seen.add(nxt); q.append(nxt)
    return sorted(set(hits))


def audit_corpus(graph: Dict[str, Any]) -> CorpusAuditResult:
    nodes = _nodes(graph)
    edges = [e for e in graph.get("edges", []) if isinstance(e, dict)]

    l1_hits = [e for e in edges if e.get("type") in {"RELATES", "ONTOLOGY_EQUIVALENCE"} and e.get("basis") == "shared_source_only"]

    l2_hits = []
    for e in edges:
        if e.get("type") == "CONSUMES":
            src, dst = nodes.get(e.get("from"), {}), nodes.get(e.get("to"), {})
            accepted = set(dst.get("accepted_registers", []))
            reg = src.get("register")
            if accepted and reg not in accepted:
                l2_hits.append(f"{e.get('from')}->{e.get('to')}:{reg}")
        if e.get("type") == "PROMOTES" and not e.get("promotion_event"):
            l2_hits.append(f"implicit:{e.get('from')}->{e.get('to')}")

    l3_hits = []
    for e in edges:
        if e.get("type") == "AUTHORIZES" and nodes.get(e.get("from"), {}).get("kind") in {"CLAIM", "RELATION", "SYMBOL", "MYTHOS"}:
            l3_hits.append(f"{e.get('from')}->{e.get('to')}")
    for nid, n in nodes.items():
        if n.get("authority_class") not in (None, "NONE", "O0"):
            l3_hits.append(f"{nid}:{n.get('authority_class')}")

    l4_hits = _taint_reaches_operational(graph, nodes)

    l5_hits = []
    for e in edges:
        if e.get("type") == "CONSUMES":
            src, dst = nodes.get(e.get("from"), {}), nodes.get(e.get("to"), {})
            if src.get("register") == "THERAPEUTIC_REFLECTIVE" and dst.get("clinical"):
                l5_hits.append(f"{e.get('from')}->{e.get('to')}")

    l6_hits = [nid for nid, n in nodes.items() if n.get("name_only_capability_claim") and not n.get("capability_verified")]

    leaks = [
        _leak("L1_RELATION_LEAKAGE", bool(l1_hits), f"hits={l1_hits}"),
        _leak("L2_REGISTER_LEAKAGE", bool(l2_hits), f"hits={l2_hits}"),
        _leak("L3_AUTHORITY_LEAKAGE", bool(l3_hits), f"hits={l3_hits}"),
        _leak("L4_MYTHIC_OPERATIONAL_TAINT", bool(l4_hits), f"hits={l4_hits}"),
        _leak("L5_THERAPEUTIC_LEAKAGE", bool(l5_hits), f"hits={l5_hits}"),
        _leak("L6_NAME_LEAKAGE", bool(l6_hits), f"hits={l6_hits}"),
    ]
    decision = "REJECT" if any(x.detected for x in leaks) else "PASS"
    return CorpusAuditResult(decision, str(graph.get("graph_id", "<missing>")), sha256_obj(graph), POLICY_HASH, leaks)
