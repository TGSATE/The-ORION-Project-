from __future__ import annotations
from copy import deepcopy
from typing import Any, Dict

from .canonical import sha256_obj
from .model import RuleResult, VerificationResult
from . import policy

POLICY_FINGERPRINT = {
    "version": policy.VERSION,
    "registers": policy.REGISTERS,
    "relation_states": policy.RELATION_STATES,
    "canon_states": policy.CANON_STATES,
    "canon_transitions": sorted(list(policy.ALLOWED_CANON_TRANSITIONS)),
    "forbidden_implicit_promotions": sorted(list(policy.FORBIDDEN_IMPLICIT_PROMOTIONS)),
    "sacred_motifs": sorted(policy.SACRED_MOTIFS),
    "protected_operational_uses": sorted(policy.PROTECTED_OPERATIONAL_USES),
    "clinical_claim_types": sorted(policy.CLINICAL_CLAIM_TYPES),
    "allowed_authority": sorted(policy.ALLOWED_AUTHORITY),
    "rules": policy.RULE_IDS,
    "leaks": policy.LEAK_CODES,
}
POLICY_HASH = sha256_obj(POLICY_FINGERPRINT)

REQUIRED_FIELDS = {
    "claim_id", "claim_text", "register", "origin_register", "scope", "source_roots",
    "relations", "evidence_class", "authority_class", "review_status", "canon_history",
    "promotion_history", "non_implications", "numeric_dependencies", "therapeutic_claim_types",
    "mythos_derived_semantics", "cross_corpus_links"
}

def _rr(rule_id: str, passed: bool, code: str, detail: str) -> RuleResult:
    return RuleResult(rule_id, passed, code, detail)

def _schema_valid(c: Dict[str, Any]) -> RuleResult:
    missing = sorted(REQUIRED_FIELDS - set(c))
    if missing:
        return _rr("G1_SCHEMA_VALID", False, "SCHEMA_MISSING_FIELDS", f"missing={missing}")
    list_fields = ("source_roots", "relations", "canon_history", "promotion_history", "non_implications", "numeric_dependencies", "therapeutic_claim_types", "mythos_derived_semantics", "cross_corpus_links")
    if any(not isinstance(c.get(k), list) for k in list_fields):
        return _rr("G1_SCHEMA_VALID", False, "SCHEMA_BAD_TYPE", "required collection fields must be lists")
    return _rr("G1_SCHEMA_VALID", True, "OK", "required fields present")

def _register(c: Dict[str, Any]) -> RuleResult:
    r, o = c.get("register"), c.get("origin_register")
    if r not in policy.REGISTERS or o not in policy.REGISTERS:
        return _rr("G2_REGISTER_DECLARED", False, "REGISTER_INVALID", f"origin={o!r} register={r!r}")
    return _rr("G2_REGISTER_DECLARED", True, "OK", f"{o}->{r}")

def _source(c: Dict[str, Any]) -> RuleResult:
    roots = c.get("source_roots", [])
    if not roots:
        return _rr("G3_SOURCE_BOUND", False, "SOURCE_UNBOUND", "at least one source root is required")
    ids = []
    for x in roots:
        if not isinstance(x, dict) or not x.get("id") or not x.get("kind"):
            return _rr("G3_SOURCE_BOUND", False, "SOURCE_MALFORMED", "each source needs id and kind")
        ids.append(x["id"])
    if len(ids) != len(set(ids)):
        return _rr("G3_SOURCE_BOUND", False, "SOURCE_DUPLICATE_ID", "source ids must be unique")
    return _rr("G3_SOURCE_BOUND", True, "OK", f"roots={len(roots)}")

def _relations(c: Dict[str, Any]) -> RuleResult:
    source_ids = {x.get("id") for x in c.get("source_roots", []) if isinstance(x, dict)}
    for rel in c.get("relations", []):
        if not isinstance(rel, dict) or not rel.get("id") or not rel.get("type"):
            return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_MALFORMED", "relation requires id and type")
        state = rel.get("state")
        if state not in policy.RELATION_STATES:
            return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_STATE_INVALID", f"state={state!r}")
        if state in {"PROPOSED", "SOURCE_SUPPORTED"} and rel.get("consumed_as_canonical", False):
            return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_SMUGGLING", f"{state} relation consumed as canonical ontology")
        if state in {"SOURCE_SUPPORTED", "FORMALLY_DERIVED", "HUMAN_REVIEWED"} and not rel.get("justification"):
            return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_JUSTIFICATION_MISSING", "supported relation lacks justification")
        supports = rel.get("supporting_sources", [])
        if state in {"SOURCE_SUPPORTED", "HUMAN_REVIEWED"}:
            if not supports:
                return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_SOURCE_SUPPORT_MISSING", rel["id"])
            unknown = [s for s in supports if s not in source_ids]
            if unknown:
                return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_SOURCE_UNKNOWN", f"{rel['id']} unknown={unknown}")
        if state == "FORMALLY_DERIVED" and not rel.get("derivation_ref"):
            return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_DERIVATION_MISSING", rel["id"])
        if state == "HUMAN_REVIEWED" and not rel.get("reviewer"):
            return _rr("G4_RELATION_JUSTIFIED", False, "RELATION_REVIEWER_MISSING", rel["id"])
    return _rr("G4_RELATION_JUSTIFIED", True, "OK", f"relations={len(c.get('relations', []))}")

def _promotion(c: Dict[str, Any]) -> RuleResult:
    history = c.get("promotion_history", [])
    origin, current = c.get("origin_register"), c.get("register")
    cursor = origin
    for p in history:
        fr, to = p.get("from_register"), p.get("to_register")
        if fr not in policy.REGISTERS or to not in policy.REGISTERS:
            return _rr("G5_PROMOTION_EXPLICIT", False, "PROMOTION_REGISTER_INVALID", f"{fr}->{to}")
        if fr != cursor:
            return _rr("G5_PROMOTION_EXPLICIT", False, "PROMOTION_CHAIN_BROKEN", f"expected from={cursor}, got={fr}")
        if not p.get("justification") or not p.get("evidence_refs"):
            return _rr("G5_PROMOTION_EXPLICIT", False, "PROMOTION_UNJUSTIFIED", f"{fr}->{to} lacks justification/evidence")
        cursor = to
    if cursor != current:
        return _rr("G5_PROMOTION_EXPLICIT", False, "IMPLICIT_REGISTER_PROMOTION", f"history ends={cursor}, declared={current}")
    return _rr("G5_PROMOTION_EXPLICIT", True, "OK", f"events={len(history)}")

def _taint(c: Dict[str, Any]) -> RuleResult:
    for dep in c.get("numeric_dependencies", []):
        value, use = dep.get("value"), dep.get("use")
        mythic = bool(dep.get("mythic_dependency"))
        justification = dep.get("engineering_justification")
        if mythic and use in policy.PROTECTED_OPERATIONAL_USES:
            return _rr("G6_MYTHIC_TAINT_CONTAINED", False, "MYTHIC_VALUE_OPERATIONAL_DEPENDENCY", f"value={value!r} use={use}")
        if value in policy.SACRED_MOTIFS and use in policy.PROTECTED_OPERATIONAL_USES and not justification:
            return _rr("G6_MYTHIC_TAINT_CONTAINED", False, "SACRED_NUMBER_NO_ENGINEERING_JUSTIFICATION", f"value={value!r} use={use}")
    for sem in c.get("mythos_derived_semantics", []):
        if sem.get("affects_operational_behavior"):
            return _rr("G6_MYTHIC_TAINT_CONTAINED", False, "MYTHOS_SEMANTICS_AFFECT_OPERATION", sem.get("name", "unnamed"))
    return _rr("G6_MYTHIC_TAINT_CONTAINED", True, "OK", "mythic semantics contained")

def _therapeutic(c: Dict[str, Any]) -> RuleResult:
    types = set(c.get("therapeutic_claim_types", []))
    if c.get("register") == "THERAPEUTIC_REFLECTIVE" and (types & policy.CLINICAL_CLAIM_TYPES):
        return _rr("G7_THERAPEUTIC_BOUNDARY_INTACT", False, "REFLECTIVE_TO_CLINICAL_PROMOTION", f"clinical={sorted(types & policy.CLINICAL_CLAIM_TYPES)}")
    return _rr("G7_THERAPEUTIC_BOUNDARY_INTACT", True, "OK", "no clinical overclaim")

def _authority(c: Dict[str, Any]) -> RuleResult:
    a = c.get("authority_class")
    if a not in policy.ALLOWED_AUTHORITY:
        return _rr("G8_AUTHORITY_UNCHANGED", False, "AUTHORITY_MINTING_FORBIDDEN", f"authority={a!r}")
    if c.get("authority_delta", 0) != 0:
        return _rr("G8_AUTHORITY_UNCHANGED", False, "AUTHORITY_DELTA_NONZERO", f"delta={c.get('authority_delta')}")
    return _rr("G8_AUTHORITY_UNCHANGED", True, "OK", a)

def _nonimp(c: Dict[str, Any]) -> RuleResult:
    ni = c.get("non_implications", [])
    if not ni:
        return _rr("G9_NONIMPLICATIONS_PRESERVED", False, "NONIMPLICATIONS_MISSING", "at least one explicit non-implication required")
    if any(not isinstance(x, str) or not x.strip() for x in ni):
        return _rr("G9_NONIMPLICATIONS_PRESERVED", False, "NONIMPLICATIONS_MALFORMED", "entries must be non-empty strings")
    return _rr("G9_NONIMPLICATIONS_PRESERVED", True, "OK", f"count={len(ni)}")

def _canon(c: Dict[str, Any]) -> RuleResult:
    history = c.get("canon_history", [])
    status = c.get("review_status")
    if status not in policy.CANON_STATES:
        return _rr("G10_CANON_STATE_VALID", False, "CANON_STATE_INVALID", f"status={status!r}")
    if not history or history[0] != "INGESTED":
        return _rr("G10_CANON_STATE_VALID", False, "CANON_HISTORY_BAD_START", "history must start INGESTED")
    if history[-1] != status:
        return _rr("G10_CANON_STATE_VALID", False, "CANON_HISTORY_STATUS_MISMATCH", f"last={history[-1]!r} status={status!r}")
    for a, b in zip(history, history[1:]):
        if (a, b) not in policy.ALLOWED_CANON_TRANSITIONS:
            return _rr("G10_CANON_STATE_VALID", False, "CANON_TRANSITION_FORBIDDEN", f"{a}->{b}")
    if status in {"RELATION_REVIEWED", "CANON_CANDIDATE", "CANON_ACCEPTED"}:
        unsafe = [r.get("id") for r in c.get("relations", []) if r.get("state") not in {"HUMAN_REVIEWED", "FORMALLY_DERIVED", "REJECTED"}]
        if unsafe:
            return _rr("G10_CANON_STATE_VALID", False, "CANON_RELATION_REVIEW_INCOMPLETE", f"relations={unsafe}")
    return _rr("G10_CANON_STATE_VALID", True, "OK", f"status={status}")

def _cross_corpus(c: Dict[str, Any]) -> RuleResult:
    for link in c.get("cross_corpus_links", []):
        if not isinstance(link, dict) or not link.get("target_id") or not link.get("link_type"):
            return _rr("G11_CROSS_CORPUS_LINKS_VALID", False, "CROSS_LINK_MALFORMED", "target_id and link_type required")
        if link.get("link_type") == "ONTOLOGY_EQUIVALENCE" and not link.get("human_reviewed"):
            return _rr("G11_CROSS_CORPUS_LINKS_VALID", False, "CROSS_CORPUS_ONTOLOGY_UNREVIEWED", link.get("target_id"))
        if link.get("affects_authority"):
            return _rr("G11_CROSS_CORPUS_LINKS_VALID", False, "CROSS_CORPUS_AUTHORITY_LEAK", link.get("target_id"))
    return _rr("G11_CROSS_CORPUS_LINKS_VALID", True, "OK", f"links={len(c.get('cross_corpus_links', []))}")

def _receipt(c: Dict[str, Any]) -> RuleResult:
    try:
        sha256_obj(c)
        return _rr("G12_AUDIT_RECEIPT_EMITTABLE", True, "OK", "canonical serialization stable")
    except Exception as e:
        return _rr("G12_AUDIT_RECEIPT_EMITTABLE", False, "RECEIPT_SERIALIZATION_FAILED", type(e).__name__)

def verify_claim(claim: Dict[str, Any], protected_state: Dict[str, Any] | None = None) -> VerificationResult:
    before = deepcopy(protected_state or {})
    after = deepcopy(before)
    claim_id = str(claim.get("claim_id", "<missing>"))
    claim_hash = sha256_obj(claim)
    rules = [
        _schema_valid(claim), _register(claim), _source(claim), _relations(claim), _promotion(claim),
        _taint(claim), _therapeutic(claim), _authority(claim), _nonimp(claim), _canon(claim),
        _cross_corpus(claim), _receipt(claim),
    ]
    decision = "PASS" if all(r.passed for r in rules) else "REJECT"
    return VerificationResult(decision, claim_id, claim_hash, POLICY_HASH, rules, before != after)
