from __future__ import annotations
import argparse, json, pathlib, sys
from .verifier import verify_claim
from .graph import audit_corpus
from .receipt import make_receipt, make_corpus_receipt, replay_claim_receipt, replay_corpus_receipt

PROTECTED = {"authority":"O0", "canon":"OPEN"}

def _load(path: str):
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))

def _write(path: str | None, obj):
    text = json.dumps(obj, indent=2, sort_keys=True) + "\n"
    print(text, end="")
    if path:
        pathlib.Path(path).write_text(text, encoding="utf-8")

def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] not in {"claim", "corpus", "replay-claim", "replay-corpus"}:
        argv.insert(0, "claim")
    p = argparse.ArgumentParser(prog="codex-membrane", description="Codex Membrane v0.3 verifier")
    sp = p.add_subparsers(dest="cmd", required=True)
    pc = sp.add_parser("claim"); pc.add_argument("claim"); pc.add_argument("--receipt")
    pg = sp.add_parser("corpus"); pg.add_argument("graph"); pg.add_argument("--receipt")
    pr = sp.add_parser("replay-claim"); pr.add_argument("claim"); pr.add_argument("receipt")
    pgr = sp.add_parser("replay-corpus"); pgr.add_argument("graph"); pgr.add_argument("receipt")
    ns = p.parse_args(argv)
    if ns.cmd == "claim":
        result = verify_claim(_load(ns.claim), PROTECTED); receipt = make_receipt(result); _write(ns.receipt, receipt); return 0 if result.passed else 2
    if ns.cmd == "corpus":
        result = audit_corpus(_load(ns.graph)); receipt = make_corpus_receipt(result); _write(ns.receipt, receipt); return 0 if result.passed else 2
    if ns.cmd == "replay-claim":
        replay = replay_claim_receipt(_load(ns.claim), _load(ns.receipt), PROTECTED); _write(None, replay); return 0 if replay["replay"] == "PASS" else 2
    replay = replay_corpus_receipt(_load(ns.graph), _load(ns.receipt)); _write(None, replay); return 0 if replay["replay"] == "PASS" else 2

if __name__ == "__main__":
    raise SystemExit(main())
