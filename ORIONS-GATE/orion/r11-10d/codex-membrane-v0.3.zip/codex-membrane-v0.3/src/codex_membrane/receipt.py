from __future__ import annotations
from typing import Any, Dict
from .canonical import sha256_obj
from .model import VerificationResult, CorpusAuditResult
from . import policy


def _seal(core: Dict[str, Any], kind: str) -> Dict[str, Any]:
    body = dict(core)
    body["receipt_version"] = "codex-membrane-receipt-2"
    body["verifier_version"] = policy.VERSION
    body["receipt_kind"] = kind
    body["run_id"] = sha256_obj(body)
    return body


def make_receipt(result: VerificationResult) -> Dict[str, Any]:
    return _seal(result.as_dict(), "CLAIM")


def make_corpus_receipt(result: CorpusAuditResult) -> Dict[str, Any]:
    return _seal(result.as_dict(), "CORPUS")


def replay_claim_receipt(claim: Dict[str, Any], receipt: Dict[str, Any], protected_state: Dict[str, Any] | None = None) -> Dict[str, Any]:
    from .verifier import verify_claim
    expected = make_receipt(verify_claim(claim, protected_state))
    return {
        "replay": "PASS" if expected == receipt else "REJECT",
        "expected_run_id": expected.get("run_id"),
        "observed_run_id": receipt.get("run_id"),
        "claim_hash_match": expected.get("claim_hash") == receipt.get("claim_hash"),
        "policy_hash_match": expected.get("policy_hash") == receipt.get("policy_hash"),
        "decision_match": expected.get("decision") == receipt.get("decision"),
        "exact_receipt_match": expected == receipt,
    }


def replay_corpus_receipt(graph: Dict[str, Any], receipt: Dict[str, Any]) -> Dict[str, Any]:
    from .graph import audit_corpus
    expected = make_corpus_receipt(audit_corpus(graph))
    return {
        "replay": "PASS" if expected == receipt else "REJECT",
        "expected_run_id": expected.get("run_id"),
        "observed_run_id": receipt.get("run_id"),
        "graph_hash_match": expected.get("graph_hash") == receipt.get("graph_hash"),
        "policy_hash_match": expected.get("policy_hash") == receipt.get("policy_hash"),
        "decision_match": expected.get("decision") == receipt.get("decision"),
        "exact_receipt_match": expected == receipt,
    }
