from __future__ import annotations

VERSION = "0.3.0"

REGISTERS = (
    "SYMBOLIC",
    "NARRATIVE",
    "THERAPEUTIC_REFLECTIVE",
    "PHILOSOPHICAL",
    "METAPHYSICAL",
    "FORMAL",
    "EMPIRICAL",
    "OPERATIONAL",
)

RELATION_STATES = (
    "PROPOSED",
    "SOURCE_SUPPORTED",
    "FORMALLY_DERIVED",
    "HUMAN_REVIEWED",
    "DISPUTED",
    "REJECTED",
)

CANON_STATES = (
    "INGESTED",
    "PROVISIONAL",
    "SOURCE_VERIFIED",
    "RELATION_REVIEWED",
    "CANON_CANDIDATE",
    "CANON_ACCEPTED",
    "DISPUTED",
    "RETIRED",
)

ALLOWED_CANON_TRANSITIONS = {
    ("INGESTED", "PROVISIONAL"),
    ("PROVISIONAL", "SOURCE_VERIFIED"),
    ("SOURCE_VERIFIED", "RELATION_REVIEWED"),
    ("RELATION_REVIEWED", "CANON_CANDIDATE"),
    ("CANON_CANDIDATE", "CANON_ACCEPTED"),
    ("INGESTED", "DISPUTED"),
    ("PROVISIONAL", "DISPUTED"),
    ("SOURCE_VERIFIED", "DISPUTED"),
    ("RELATION_REVIEWED", "DISPUTED"),
    ("CANON_CANDIDATE", "DISPUTED"),
    ("CANON_ACCEPTED", "DISPUTED"),
    ("DISPUTED", "PROVISIONAL"),
    ("DISPUTED", "RETIRED"),
    ("CANON_ACCEPTED", "RETIRED"),
}

FORBIDDEN_IMPLICIT_PROMOTIONS = {
    ("SYMBOLIC", "METAPHYSICAL"),
    ("METAPHYSICAL", "EMPIRICAL"),
    ("THERAPEUTIC_REFLECTIVE", "OPERATIONAL"),
    ("FORMAL", "EMPIRICAL"),
    ("EMPIRICAL", "OPERATIONAL"),
}

SACRED_MOTIFS = {3, 7, 12, 33, 108, 144, 145, 717}

PROTECTED_OPERATIONAL_USES = {
    "safety_threshold",
    "model_parameter",
    "execution_budget",
    "retry_count",
    "security_constant",
    "confidence_threshold",
    "governance_quorum",
    "cryptographic_parameter",
    "production_timer",
    "authority_level",
    "policy_gate",
}

CLINICAL_CLAIM_TYPES = {
    "diagnosis",
    "treatment",
    "cure",
    "risk_assessment",
    "psychiatric_classification",
    "medical_advice",
    "guaranteed_psychological_outcome",
}

ALLOWED_AUTHORITY = {"NONE", "O0"}

RULE_IDS = (
    "G1_SCHEMA_VALID",
    "G2_REGISTER_DECLARED",
    "G3_SOURCE_BOUND",
    "G4_RELATION_JUSTIFIED",
    "G5_PROMOTION_EXPLICIT",
    "G6_MYTHIC_TAINT_CONTAINED",
    "G7_THERAPEUTIC_BOUNDARY_INTACT",
    "G8_AUTHORITY_UNCHANGED",
    "G9_NONIMPLICATIONS_PRESERVED",
    "G10_CANON_STATE_VALID",
    "G11_CROSS_CORPUS_LINKS_VALID",
    "G12_AUDIT_RECEIPT_EMITTABLE",
)

LEAK_CODES = (
    "L1_RELATION_LEAKAGE",
    "L2_REGISTER_LEAKAGE",
    "L3_AUTHORITY_LEAKAGE",
    "L4_MYTHIC_OPERATIONAL_TAINT",
    "L5_THERAPEUTIC_LEAKAGE",
    "L6_NAME_LEAKAGE",
)
