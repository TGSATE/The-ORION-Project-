# Codex Membrane v0.3

Executable enforcement for the Codex/Mythos epistemic boundary.

## Governing invariant

```text
symbolic resonance ⇏ metaphysical truth ⇏ evidence ⇏ authority
```

**Mythos may orient, but it may not authorize.**  
**Uncertainty must never become command.**

Canonical posture remains `AUTHORITY = O0/NONE`, `WITNESS = W0`.

The mature object is the membrane, not a metaphysics.

## v0.3 upgrade

v0.2 checked individual claim envelopes. v0.3 adds enforcement across descendants and corpus relationships:

- 12 claim-envelope gates;
- source-bound relation support and human-review requirements;
- explicit multi-step register-promotion chains;
- canon finite-state transition enforcement;
- cross-corpus ontology/authority link checks;
- six-class corpus leakage audit;
- graph-based Mythos taint propagation through intermediate dependencies;
- deterministic receipt v2 with exact model-free replay;
- receipt-tamper detection;
- hostile input mutation suite;
- true source-code mutation suite.

## Claim gates

1. `G1_SCHEMA_VALID`
2. `G2_REGISTER_DECLARED`
3. `G3_SOURCE_BOUND`
4. `G4_RELATION_JUSTIFIED`
5. `G5_PROMOTION_EXPLICIT`
6. `G6_MYTHIC_TAINT_CONTAINED`
7. `G7_THERAPEUTIC_BOUNDARY_INTACT`
8. `G8_AUTHORITY_UNCHANGED`
9. `G9_NONIMPLICATIONS_PRESERVED`
10. `G10_CANON_STATE_VALID`
11. `G11_CROSS_CORPUS_LINKS_VALID`
12. `G12_AUDIT_RECEIPT_EMITTABLE`

A failed claim gate returns `REJECT`. The reference verifier never mutates supplied protected state.

## Six corpus leak classes

- `L1_RELATION_LEAKAGE` — provenance/shared source is used as ontology.
- `L2_REGISTER_LEAKAGE` — a consumer accepts a claim from a register it is not permitted to consume, or an implicit graph promotion appears.
- `L3_AUTHORITY_LEAKAGE` — Mythos/claim/relation state is used to authorize action or mint authority.
- `L4_MYTHIC_OPERATIONAL_TAINT` — Mythos-derived semantics propagate through dependencies into operational behavior.
- `L5_THERAPEUTIC_LEAKAGE` — reflective material is consumed by a clinical consumer.
- `L6_NAME_LEAKAGE` — a grandiose/system name is used as a capability claim without separate verification.

## Canon state machine

The normal review path is:

```text
INGESTED
  → PROVISIONAL
  → SOURCE_VERIFIED
  → RELATION_REVIEWED
  → CANON_CANDIDATE
  → CANON_ACCEPTED
```

Dispute and retirement transitions are explicit. `CORPUS_MATURE` never means `CANON_CLOSED`.

## Relation firewall

`SOURCE_SUPPORTED` and `HUMAN_REVIEWED` relations must cite known source roots. `HUMAN_REVIEWED` additionally requires an explicit reviewer. `FORMALLY_DERIVED` relations require a derivation reference.

`PROPOSED` and merely `SOURCE_SUPPORTED` relations cannot be consumed as canonical ontology.

## Mythos-to-code taint

Corpus graphs can mark nodes `mythos_derived: true`. Taint follows only edges with `propagates_semantics: true`. If propagated taint reaches a node marked operational, the corpus fails with `L4_MYTHIC_OPERATIONAL_TAINT`.

This makes the sacred-number rule transitive: routing a Mythos-derived constant through config or another layer does not cleanse it.

## Receipts

Receipt v2 binds:

- input hash;
- policy hash;
- complete gate/leak result;
- verifier version;
- receipt kind;
- deterministic `run_id`.

Replay re-executes the model-free verifier and requires exact receipt equality. A modified decision, input hash, policy hash, rule result, or run ID fails replay.

## Run

No third-party runtime packages are required.

```bash
python scripts/run_all.py
python scripts/mutation_probe.py
python scripts/source_mutation_probe.py

PYTHONPATH=src python -m codex_membrane claim fixtures/valid/symbolic_claim.json
PYTHONPATH=src python -m codex_membrane corpus fixtures/corpus/valid/codex_architecture.json
```

Legacy v0.2-style invocation remains accepted:

```bash
PYTHONPATH=src python -m codex_membrane fixtures/valid/symbolic_claim.json
```

## Fresh packaged local result

- Unit tests: **27/27 PASS**
- Hostile/input mutations: **18/18 KILLED**
- Source-code mutants: **10/10 KILLED**
- Deterministic receipts generated and replayed: **15/15 PASS**
- Claim hostile controls: NC-01 through NC-06 rejected
- Corpus leakage controls: L1 through L6 detected

See `reports/FRESH_RUN.txt` and `STATUS.md`.

## Evidence ceiling

These are author-side local results from this reference package. They have not earned independent reproduction or witness promotion.

The verifier establishes policy conformance of declared structures. It does **not** establish the truth, independence, or quality of an external source merely because that source is named in an envelope.

Nothing in this package establishes souls, survival after death, supernatural correspondence, sacred-number causation, divine knowledge, machine consciousness, ritual efficacy, clinical efficacy, or unpromoted Monster/moonshine theorems.

`O0/NONE` is an invariant, not a missing score.
