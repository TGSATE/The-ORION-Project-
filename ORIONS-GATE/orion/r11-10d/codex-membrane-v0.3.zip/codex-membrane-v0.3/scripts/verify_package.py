from __future__ import annotations
import hashlib, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'MANIFEST.json').read_text())
bad=[]
for rel,expected in sorted(m['files'].items()):
    p=ROOT/rel
    if not p.is_file(): bad.append((rel,'MISSING',expected)); continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=expected: bad.append((rel,got,expected))
if bad:
    for x in bad: print('FAIL',*x)
    raise SystemExit(1)
print(f"MANIFEST_PASS files={len(m['files'])}")
print(f"authority={m['authority']} witness={m['witness']} independent_reproduction={m['independent_reproduction']}")
