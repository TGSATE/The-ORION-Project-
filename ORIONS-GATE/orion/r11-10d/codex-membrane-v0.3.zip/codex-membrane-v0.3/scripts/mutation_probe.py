from __future__ import annotations
import json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from codex_membrane.verifier import verify_claim
from codex_membrane.graph import audit_corpus

def load(rel): return json.loads((ROOT/rel).read_text())
base=load('fixtures/valid/symbolic_claim.json')
probes=[]
def cp(): return json.loads(json.dumps(base))

c=cp(); c['register']='REALM'; probes.append(('invalid register',lambda: verify_claim(c).passed))
c=cp(); c['source_roots']=[]; probes.append(('remove sources',lambda: verify_claim(c).passed))
c=cp(); c['authority_class']='O1'; probes.append(('mint authority',lambda: verify_claim(c).passed))
c=cp(); c['authority_delta']=1; probes.append(('authority delta',lambda: verify_claim(c).passed))
c=cp(); c['non_implications']=[]; probes.append(('remove nonimplications',lambda: verify_claim(c).passed))
c=cp(); c['numeric_dependencies']=[{'value':717,'use':'execution_budget','engineering_justification':'','mythic_dependency':True}]; probes.append(('717 budget',lambda: verify_claim(c).passed))
c=cp(); c['mythos_derived_semantics']=[{'name':'symbolic gate','affects_operational_behavior':True}]; probes.append(('mythic operational semantics',lambda: verify_claim(c).passed))
c=cp(); c['relations'][0]['state']='PROPOSED'; c['relations'][0]['consumed_as_canonical']=True; probes.append(('relation smuggling',lambda: verify_claim(c).passed))
c=cp(); c['origin_register']='FORMAL'; c['register']='EMPIRICAL'; c['promotion_history']=[]; probes.append(('implicit promotion',lambda: verify_claim(c).passed))
c=cp(); c['register']='THERAPEUTIC_REFLECTIVE'; c['origin_register']='THERAPEUTIC_REFLECTIVE'; c['promotion_history']=[]; c['therapeutic_claim_types']=['diagnosis']; probes.append(('clinical overclaim',lambda: verify_claim(c).passed))
c=cp(); c['canon_history']=['INGESTED','CANON_CANDIDATE']; probes.append(('canon skip',lambda: verify_claim(c).passed))
c=cp(); c['cross_corpus_links']=[{'target_id':'X','link_type':'ONTOLOGY_EQUIVALENCE','human_reviewed':False}]; probes.append(('cross-corpus ontology',lambda: verify_claim(c).passed))
for fname in ['l1_relation_leakage.json','l2_register_leakage.json','l3_authority_leakage.json','l4_mythic_taint.json','l5_therapeutic_leakage.json','l6_name_leakage.json']:
    g=load('fixtures/corpus/hostile/'+fname); probes.append((fname,lambda g=g: audit_corpus(g).passed))

killed=0
for name,fn in probes:
    survived=fn(); ok=not survived
    print(f"{'KILLED' if ok else 'SURVIVED'}: {name}")
    killed += int(ok)
print(f"INPUT_MUTATIONS_KILLED={killed}/{len(probes)}")
raise SystemExit(0 if killed==len(probes) else 1)
