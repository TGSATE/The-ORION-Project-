from __future__ import annotations
import json, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]

def run(cmd):
    r=subprocess.run(cmd,cwd=ROOT)
    if r.returncode: raise SystemExit(r.returncode)

run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'tests'),'-v'])
sys.path.insert(0,str(ROOT/'src'))
from codex_membrane.verifier import verify_claim
from codex_membrane.graph import audit_corpus
from codex_membrane.receipt import make_receipt, make_corpus_receipt, replay_claim_receipt, replay_corpus_receipt

receipts=ROOT/'receipts'; receipts.mkdir(exist_ok=True)
for old in receipts.glob('*.receipt.json'): old.unlink()
claim_files=sorted((ROOT/'fixtures'/'valid').glob('*.json'))+sorted((ROOT/'fixtures'/'hostile').glob('*.json'))
for p in claim_files:
    c=json.loads(p.read_text()); receipt=make_receipt(verify_claim(c,{'authority':'O0','canon':'OPEN'}))
    (receipts/(p.stem+'.receipt.json')).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    assert replay_claim_receipt(c,receipt,{'authority':'O0','canon':'OPEN'})['replay']=='PASS'
corpus_files=sorted((ROOT/'fixtures'/'corpus'/'valid').glob('*.json'))+sorted((ROOT/'fixtures'/'corpus'/'hostile').glob('*.json'))
for p in corpus_files:
    g=json.loads(p.read_text()); receipt=make_corpus_receipt(audit_corpus(g))
    (receipts/('corpus_'+p.stem+'.receipt.json')).write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    assert replay_corpus_receipt(g,receipt)['replay']=='PASS'
print(f'WROTE {len(list(receipts.glob("*.receipt.json")))} RECEIPTS; ALL REPLAYED')
run([sys.executable,str(ROOT/'scripts'/'mutation_probe.py')])
run([sys.executable,str(ROOT/'scripts'/'source_mutation_probe.py')])
