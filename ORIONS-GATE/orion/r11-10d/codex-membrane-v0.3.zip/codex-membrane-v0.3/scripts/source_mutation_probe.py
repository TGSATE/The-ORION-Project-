from __future__ import annotations
import pathlib, shutil, subprocess, sys, tempfile, json, os
ROOT=pathlib.Path(__file__).resolve().parents[1]
SRC=ROOT/'src'/'codex_membrane'

MUTANTS=[
 ('M01_allow_O1','verifier.py','if a not in policy.ALLOWED_AUTHORITY:','if False and a not in policy.ALLOWED_AUTHORITY:','claim','authority'),
 ('M02_allow_authority_delta','verifier.py','if c.get("authority_delta", 0) != 0:','if False and c.get("authority_delta", 0) != 0:','claim','authority_delta'),
 ('M03_allow_relation_smuggling','verifier.py','if state in {"PROPOSED", "SOURCE_SUPPORTED"} and rel.get("consumed_as_canonical", False):','if False and state in {"PROPOSED", "SOURCE_SUPPORTED"} and rel.get("consumed_as_canonical", False):','claim','relation'),
 ('M04_allow_clinical_overclaim','verifier.py','if c.get("register") == "THERAPEUTIC_REFLECTIVE" and (types & policy.CLINICAL_CLAIM_TYPES):','if False and c.get("register") == "THERAPEUTIC_REFLECTIVE" and (types & policy.CLINICAL_CLAIM_TYPES):','claim','clinical'),
 ('M05_allow_empty_nonimp','verifier.py','if not ni:','if False and not ni:','claim','nonimp'),
 ('M06_allow_canon_skip','verifier.py','if (a, b) not in policy.ALLOWED_CANON_TRANSITIONS:','if False and (a, b) not in policy.ALLOWED_CANON_TRANSITIONS:','claim','canon'),
 ('M07_allow_cross_ontology','verifier.py','if link.get("link_type") == "ONTOLOGY_EQUIVALENCE" and not link.get("human_reviewed"):','if False and link.get("link_type") == "ONTOLOGY_EQUIVALENCE" and not link.get("human_reviewed"):','claim','cross'),
 ('M08_disable_L1','graph.py','l1_hits = [e for e in edges if e.get("type") in {"RELATES", "ONTOLOGY_EQUIVALENCE"} and e.get("basis") == "shared_source_only"]','l1_hits = []','graph','l1'),
 ('M09_disable_L4','graph.py','if n.get("operational") or n.get("operational_behavior"):','if False and (n.get("operational") or n.get("operational_behavior")):','graph','l4'),
 ('M10_disable_L6','graph.py','l6_hits = [nid for nid, n in nodes.items() if n.get("name_only_capability_claim") and not n.get("capability_verified")]','l6_hits = []','graph','l6'),
]

PROBE=r'''
import json, pathlib, sys
from codex_membrane.verifier import verify_claim
from codex_membrane.graph import audit_corpus
root=pathlib.Path(sys.argv[1]); kind=sys.argv[2]; probe=sys.argv[3]
def load(rel): return json.loads((root/rel).read_text())
if kind=='graph':
    files={'l1':'l1_relation_leakage.json','l4':'l4_mythic_taint.json','l6':'l6_name_leakage.json'}
    passed=audit_corpus(load('fixtures/corpus/hostile/'+files[probe])).passed
else:
    c=load('fixtures/valid/symbolic_claim.json')
    if probe=='authority': c['authority_class']='O1'
    elif probe=='authority_delta': c['authority_delta']=1
    elif probe=='relation':
        c['review_status']='PROVISIONAL'; c['canon_history']=['INGESTED','PROVISIONAL']; c['relations'][0]['state']='PROPOSED'; c['relations'][0]['consumed_as_canonical']=True
    elif probe=='clinical':
        c['review_status']='PROVISIONAL'; c['canon_history']=['INGESTED','PROVISIONAL']; c['register']='THERAPEUTIC_REFLECTIVE'; c['origin_register']='THERAPEUTIC_REFLECTIVE'; c['promotion_history']=[]; c['relations']=[]; c['therapeutic_claim_types']=['diagnosis']
    elif probe=='nonimp': c['non_implications']=[]
    elif probe=='canon': c['canon_history']=['INGESTED','CANON_CANDIDATE']
    elif probe=='cross':
        c=load('fixtures/valid/monster_arithmetic.json'); c['cross_corpus_links']=[{'target_id':'X','link_type':'ONTOLOGY_EQUIVALENCE','human_reviewed':False}]
    passed=verify_claim(c).passed
sys.exit(1 if passed else 0)
'''

killed=0
for name,file,old,new,kind,probe in MUTANTS:
    with tempfile.TemporaryDirectory(prefix='codex-mut-') as td:
        t=pathlib.Path(td); shutil.copytree(SRC,t/'src'/'codex_membrane')
        p=t/'src'/'codex_membrane'/file; txt=p.read_text()
        if old not in txt:
            print(f'ERROR {name}: mutation target missing'); continue
        p.write_text(txt.replace(old,new,1))
        env=dict(os.environ); env['PYTHONPATH']=str(t/'src')
        r=subprocess.run([sys.executable,'-c',PROBE,str(ROOT),kind,probe],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        is_killed=(r.returncode!=0)
        print(f"{'KILLED' if is_killed else 'SURVIVED'}: {name}")
        if r.stderr and not is_killed: print(r.stderr.strip())
        killed+=int(is_killed)
print(f'SOURCE_MUTATIONS_KILLED={killed}/{len(MUTANTS)}')
raise SystemExit(0 if killed==len(MUTANTS) else 1)
