# EXP-001 / BBX Operating Rules v0.1

## Objective

Evaluate the recursive-coherence wrapper as a black box using predeclared tasks, controls, metrics, and stopping conditions.

## Minimum experiment packet

Each run should contain:
- experiment ID;
- hypothesis;
- model/wrapper version;
- dataset or task-set hash;
- predeclared metrics;
- negative controls;
- seed policy where relevant;
- hardware/runtime description;
- exact outputs;
- analysis script hash;
- result summary;
- explicit non-claims.

## Separation rules

- Formal result != behavioral result.
- Behavioral result != empirical ontology validation.
- Internal coherence != truth.
- Benchmark gain != AGI.

## Negative controls

At minimum, compare against:
- no-wrapper baseline;
- state reset / ablated recursion;
- shuffled or corrupted state where meaningful;
- metric-blind sanity checks;
- repeated runs sufficient to expose instability.

## Result status labels

- SPECIFIED_NOT_RUN
- RUN_LOCAL
- REPRODUCED_LOCAL
- INDEPENDENTLY_REPRODUCED
- INCONCLUSIVE
- REFUTED

No result should skip directly from RUN_LOCAL to production or truth claims.
