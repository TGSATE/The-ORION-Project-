# Claim Boundaries v0.1

## Canonical claim ceilings

### EFMW
Allowed:
- internal formal relations as actually encoded and proved;
- explicit process-ontology hypotheses;
- recursive-emergence bookkeeping;
- bounded implementation claims.

Not established:
- that EFMW equations describe nature;
- that EFMW is a physical theory;
- consciousness;
- AGI;
- metaphysical truth.

### Recursive-coherence wrapper
Allowed:
- implementation behavior demonstrated by reproducible tests;
- stateful wrapper properties supported by artifacts;
- bounded coherence metrics.

Not established:
- truth of the ontology;
- general intelligence;
- production readiness absent the required evidence and governance gates.

### EXP-001 / BBX
Allowed:
- experiment-specific behavioral results;
- predeclared metrics;
- bounded comparisons and negative controls.

Not allowed:
- extrapolating a local benchmark result into AGI, truth, or deployment authority;
- silently changing the hypothesis after observing results;
- treating model-internal coherence as external evidence.

## Promotion rule

Every promoted claim should identify:
1. exact artifact or commit;
2. exact proposition;
3. evidence class;
4. unresolved obligations;
5. whether evidence is local or independent;
6. operational authority, if any.

Green CI is candidate evidence, not independent validation.
