# Weaver Interface Boundary v0.1

Weaver may contribute provenance, evidence handling, replay, receipts, governance, or evaluation discipline to Monolithic work.

Weaver does not define Monolithic LLC's mission.

If Weaver-derived components enter the Monolithic stack, the current local Weaver posture remains binding for those components:

- Witness: W0
- Operational authority: O0 / WITHHELD
- Production authorization: PROHIBITED
- Independent E4 reproduction: NOT EARNED

## Merge rule

> **Do not merge green merely because CI passes.**

A candidate may be green and still remain unpromoted because:
- the evidence is local;
- the claim ceiling is narrower than the implementation scope;
- independent reproduction is missing;
- proof obligations remain open;
- durable/restart semantics are incomplete;
- operational authority is withheld.

Green is evidence. Green is not promotion.
