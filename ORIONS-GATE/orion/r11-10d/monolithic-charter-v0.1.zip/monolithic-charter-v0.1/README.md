# Monolithic LLC — Charter Pack v0.1

Status: WORKING / NOT YET COMPANY-RATIFIED
Date: 2026-10-05

This package captures the current public-facing mission and operating boundaries for Monolithic LLC based on the working brief provided in chat.

## Core posture

- EFMW is a research corpus around process ontology and recursive-emergence bookkeeping.
- Lean checks internal formal relations where encoded; proofs do not establish that the equations describe nature.
- The practical engineering track is a stateful recursive-coherence wrapper.
- EXP-001 / BBX is the black-box evaluation track.
- Coherence is not truth.
- Open proof obligations stay open.
- No AGI shipment claim is made.
- If Weaver-derived components are used, Ryan's local Weaver boundary remains: W0 / O0 WITHHELD / production prohibited until independent E4 is earned.

See `MISSION_CHARTER.md`, `CLAIM_BOUNDARIES.md`, `WEAVER_INTERFACE.md`, and `ROADMAP_12_18_MONTHS.md`.
