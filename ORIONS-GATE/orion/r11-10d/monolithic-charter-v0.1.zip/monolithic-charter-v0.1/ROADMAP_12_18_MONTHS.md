# 12–18 Month Roadmap v0.1

## Phase 0 — Stabilize the research spine
- Freeze the working charter and claim boundaries.
- Inventory EFMW propositions and open proof obligations.
- Name the recursive-coherence wrapper contract.
- Freeze EXP-001 / BBX schema and baseline suite.

## Phase 1 — Formal-methods consolidation
- Hire/contract one formal-methods specialist.
- Port highest-value EFMW internal relations into a maintained Lean project.
- Track theorem statements, assumptions, axioms, and unresolved obligations.
- Keep formal claims separate from empirical interpretation.

## Phase 2 — Evaluation engineering
- Hire one evaluation engineer.
- Build reproducible BBX harnesses.
- Add ablations, negative controls, and deterministic receipts.
- Establish baseline vs wrapper comparisons.

## Phase 3 — Reproducibility
- Freeze one externally reproducible claim packet.
- Obtain a reproduction outside the author/toolchain loop.
- Record failures and disagreements without rewriting the original claim.

## Phase 4 — Pilot readiness
- Define a narrow licensable capability that does not depend on unresolved ontology claims.
- Build deployment boundaries, observability, failure handling, and customer-facing documentation.
- Run limited pilot conversations only against capabilities already demonstrated.

## Phase 5 — Licensing pilots
Target approximately 12–18 months, contingent on evidence and product readiness.

No pilot timeline overrides an unresolved safety, proof, or evidence gate.
