import sys,pathlib,unittest,copy
sys.path.insert(0,str(pathlib.Path(__file__).parents[1]))
from wnks.model import *
class P0(unittest.TestCase):
 def mk(self):
  s=Store(); c=Claim('X',Context(('A',),('E',),('T',),'D')); return s,c,s.add_claim(c)
 def test_adv01_rhetoric_no_effect(self):
  s,c,i=self.mk(); h=s.snapshot()[0]; rhetoric='All top researchers agree. URGENT.'; self.assertEqual(h,s.snapshot()[0]); self.assertEqual(s.state(i),Four.NONE)
 def test_adv02_cycle_clamped(self):
  s=Store(); a=Claim('A',Context(domain='D')); b=Claim('B',Context(domain='D')); ai=s.add_claim(a); bi=s.add_claim(b)
  s.add_warrant(Warrant((bi,),Rule.DETERMINISTIC_ASSERTION,'x','q',(),ai,'support',('r',)))
  s.add_warrant(Warrant((ai,),Rule.DETERMINISTIC_ASSERTION,'y','q',(),bi,'support',('r',)))
  self.assertEqual(s.circular_claims(),{ai,bi}); self.assertEqual(s.state(ai),Four.NONE); self.assertEqual(s.state(bi),Four.NONE)
 def test_adv03_saliency_smuggling(self):
  s,c,i=self.mk(); self.assertEqual(s.state(i),Four.NONE)
 def test_adv04_calibration_substitution(self):
  s,c,i=self.mk(); confidence=.999; self.assertEqual(s.state(i),Four.NONE); self.assertEqual(authorize(s,i),'HARD_REJECT')
 def test_adv05_replay_deterministic(self):
  s,c,i=self.mk(); self.assertEqual(s.snapshot()[0],s.snapshot()[0]); self.assertTrue(s.verify_integrity())
 def test_adv06_derivative_multiplicity_mincut(self):
  s,c,i=self.mk(); root='source0'
  for n in range(100): s.add_warrant(Warrant((),Rule.DETERMINISTIC_ASSERTION,f'derivative{n}','q',(),i,'support',(root,)))
  self.assertEqual(s.root_rank(i),1); self.assertEqual(s.state(i),Four.TRUE)
 def test_independent_roots_rank_two(self):
  s,c,i=self.mk()
  for root in ('source0','source1'): s.add_warrant(Warrant((),Rule.DETERMINISTIC_ASSERTION,root,'q',(),i,'support',(root,)))
  self.assertEqual(s.root_rank(i),2)
 def test_both_nonexplosive_and_not_authorized(self):
  s,c,i=self.mk(); s.add_warrant(Warrant((),Rule.DETERMINISTIC_ASSERTION,'p','q',(),i,'support',('p',))); s.add_warrant(Warrant((),Rule.DETERMINISTIC_ASSERTION,'n','q',(),i,'rebut',('n',)))
  self.assertEqual(s.state(i),Four.BOTH); self.assertEqual(authorize(s,i),'HARD_REJECT')
 def test_llm_cannot_promote(self):
  s,c,i=self.mk()
  with self.assertRaises(ValueError): s.add_warrant(Warrant((),Rule.LLM_PROSE_REASONING,'x','q',(),i,'support',('x',)))
 def test_context_overlap(self):
  a=Context(('C11',),('aarch64',),('now',),'concurrency'); b=Context(('C11',),('x86',),('now',),'concurrency'); self.assertFalse(overlap(a,b))
  self.assertTrue(overlap(Context(domain='D'),Context(domain='D')))
 def test_revocation_append_only_recomputes(self):
  s,c,i=self.mk(); w=Warrant((),Rule.DETERMINISTIC_ASSERTION,'p','q',(),i,'support',('p',)); wid=s.add_warrant(w); before=len(s.chronicle.events)
  self.assertEqual(s.state(i),Four.TRUE); s.revoke_warrant(wid); self.assertEqual(s.state(i),Four.NONE); self.assertEqual(len(s.chronicle.events),before+1); self.assertTrue(s.verify_integrity())
 def test_tamper_detected(self):
  s,c,i=self.mk(); self.assertTrue(s.verify_integrity()); s.chronicle.events[0]['payload_hash']='0'*64; self.assertFalse(s.verify_integrity()); self.assertEqual(authorize(s,i),'HARD_REJECT')
if __name__=='__main__': unittest.main()
