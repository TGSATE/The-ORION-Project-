import argparse,hashlib,json,subprocess,sys,platform
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('--verify-package',required=True); a=ap.parse_args(); root=Path(a.verify_package).resolve(); m=json.loads((root/'MANIFEST.json').read_text()); bad=[]
H=lambda b: hashlib.sha256(b).hexdigest()
for rel,h in m['files'].items():
 p=root/rel
 if not p.exists() or H(p.read_bytes())!=h: bad.append(rel)
if bad: print('HASH_FAIL',*bad); sys.exit(2)
test=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(root/'tests'),'-v'],cwd=root)
if test.returncode: sys.exit(test.returncode)
mut=subprocess.run([sys.executable,str(root/'mutation/run_mutants.py')],cwd=root,capture_output=True,text=True)
print(mut.stdout,end='')
if mut.returncode: print('MUTATION_FAIL'); sys.exit(mut.returncode)
demo=subprocess.check_output([sys.executable,str(root/'demo.py')],cwd=root)
# Explicit witness tuple fields. v0.2 local harness records hashes but does not sign them.
source_hash=H((root/'wnks/model.py').read_bytes())
toolchain_obj={'python':platform.python_version(),'implementation':platform.python_implementation(),'platform':platform.platform()}
toolchain_hash=H(json.dumps(toolchain_obj,sort_keys=True,separators=(',',':')).encode())
input_hash=H((root/'vs001/STATUS.json').read_bytes())
policy_hash=H((root/'spec/P0_FROZEN_SPEC.md').read_bytes())
log_hash=H(mut.stdout.encode()+demo)
# finalState is the deterministic demo transcript in this reference candidate; a future VS run replaces it with sealed substrate state.
final_state_hash=H(demo)
result='LOCAL_VERIFY_PASS;VS001_NOT_EXECUTED;E4_NOT_EARNED'
att={'schema':'E4-001-witness-envelope-v0.2','manifest_sha256':H((root/'MANIFEST.json').read_bytes()),'source_sha256':source_hash,'build_sha256':H(json.dumps(m,sort_keys=True,separators=(',',':')).encode()),'toolchain_sha256':toolchain_hash,'toolchain':toolchain_obj,'input_sha256':input_hash,'policy_sha256':policy_hash,'execution_log_sha256':log_hash,'final_state_sha256':final_state_hash,'result':result,'clean_tests':'PASS','mutation_score':'4/4','signature':'UNSIGNED_EXTERNAL_WITNESS_REQUIRED','e4_status':'NOT_EARNED'}
(root/'WITNESS_ATTESTATION.json').write_text(json.dumps(att,sort_keys=True,separators=(',',':'))+'\n')
print(json.dumps(att,indent=2,sort_keys=True)); print(result)
