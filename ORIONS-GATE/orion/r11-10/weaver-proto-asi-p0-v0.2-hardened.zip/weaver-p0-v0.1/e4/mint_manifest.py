from pathlib import Path
import hashlib,json
root=Path(__file__).parents[1]
exclude={'MANIFEST.json','WITNESS_ATTESTATION.json'}
files={}
for p in sorted(root.rglob('*')):
 if p.is_file() and p.name not in exclude and '__pycache__' not in p.parts:
  files[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
obj={'schema':'E4-001-manifest-v0.1','hash':'sha256','files':files,'claim':'LOCAL_PACKAGE_SEALED_NOT_E4'}
(root/'MANIFEST.json').write_text(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n')
print(hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest())
