# Weaver Proto-ASI P0 v0.2 — Hardened Freeze Candidate

Executable hardening of **WN-KS-001 + ENPL-ADV-001 + VS-001 + E4-001**.

## Earned locally
- 12/12 clean invariant/adversarial tests PASS.
- 4/4 targeted source mutants KILLED.
- Tarjan SCC circular-support clamping.
- Root-capacitated max-flow provenance independence (`RootRank`).
- Append-only hash-chained Chronicle with revocation events.
- FOUR contradiction handling; `BOTH` cannot authorize.
- Tamper detection fails closed.
- Witness envelope binds source/build/toolchain/input/policy/log/final-state/result.

## Not earned
- VS-001 Loom counterexample: **SPECIFIED_NOT_EXECUTED / NOT_CLAIMED**.
- Hermetic Rust/Loom/Lean execution: unavailable on this build host.
- Independent witness signature: absent.
- E4: **NOT_EARNED**.
- Operational authority: **O0 / WITHHELD**.

## Run
```bash
python3 -m unittest discover -s tests -v
python3 mutation/run_mutants.py
python3 demo.py
python3 e4/mint_manifest.py
python3 e4/weaver_witness.py --verify-package .
```

Constitutional law: `Capability != Confidence != Evidence != Verification != Truth != Authority`.

AI proposes. Evidence disposes. Authority governs.
