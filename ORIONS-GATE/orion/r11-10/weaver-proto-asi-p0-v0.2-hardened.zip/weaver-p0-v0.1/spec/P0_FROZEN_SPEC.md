# P0 Hardened Freeze Candidate Specification

## Constitutional laws
1. Capability != Confidence != Evidence != Verification != Truth != Authority.
2. AI proposes; evidence disposes; authority governs.
3. Multiplicity != independence.
4. Signature != truth.
5. Rejected authorization causes no protected external-state mutation.
6. Sandbox validity and runtime authority are separate planes.

## WN-KS-001
- Contextual content-addressed claims and typed warrants.
- Belnap-Dunn FOUR status: NONE, TRUE, FALSE, BOTH. BOTH is non-explosive and ineligible for authority.
- Tarjan SCC detection clamps circular self-derived support.
- ADV-06 RootRank uses max-flow with **primitive-root capacity 1**. This is required for independent-root counting; infinite-capacity roots would incorrectly count derivative branches from one source as independent.
- Chronicle is append-only and hash chained. Revocation appends a WARRANT_REVOCATION event; it does not rewrite history.
- Canonical package-local JSON uses sorted UTF-8 keys, compact separators, finite numbers only, SHA-256. It is not claimed to implement RFC 8785.

## ENPL-ADV-001
ADV-01 rhetoric; ADV-02 circular support; ADV-03 saliency smuggling; ADV-04 calibration substitution; ADV-05 deterministic replay; ADV-06 derivative multiplicity.

## Mutation gate
MUT-01 BOTH authorization bypass; MUT-02 min-cut bypass; MUT-03 integrity bypass; MUT-04 context bypass. Freeze candidate requires 4/4 killed.

## VS-001
Bounded concurrent-deque optimization verification slice. `SPECIFIED_NOT_EXECUTED`. No Loom counterexample is claimed by this package. A pinned Rust/Loom environment and observed replayable result are required before promotion.

## E4-001
Local verification cannot self-mint E4. The witness envelope binds source, build/manifest, toolchain, input, policy, execution log, final state, and result. Signature != truth. Whether one qualifying independent reproduction satisfies E4 is a separately frozen evidence-policy question; this package leaves E4 `NOT_EARNED`.
