# VS-001

This directory intentionally contains **no fabricated Loom trace**.

Target: determine whether a frozen Chase-Lev deque optimization preserves named safety invariants under a frozen weak-memory model.

Status: `SPECIFIED_NOT_EXECUTED`.

Promotion requires a pinned Rust + Loom harness, an observed counterexample or proof result, a content-addressed trace/result, and replay on the frozen toolchain. A generic OS stress test is not accepted as a substitute.
