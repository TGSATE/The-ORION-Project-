from dataclasses import dataclass
from enum import Enum
from hashlib import sha256
from collections import defaultdict, deque
import json

class Four(str,Enum): NONE='NONE'; TRUE='TRUE'; FALSE='FALSE'; BOTH='BOTH'
class Rule(str,Enum):
 LEAN4_KERNEL='LEAN4_KERNEL'; LOOM_CONCURRENCY_TRACE='LOOM_CONCURRENCY_TRACE'; SMT_Z3_CHECK='SMT_Z3_CHECK'; DETERMINISTIC_ASSERTION='DETERMINISTIC_ASSERTION'; HUMAN_CHAIR_SIGNATURE='HUMAN_CHAIR_SIGNATURE'; LLM_PROSE_REASONING='LLM_PROSE_REASONING'

def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def hid(x): return sha256(canon(x)).hexdigest()
@dataclass(frozen=True)
class Context:
 assumptions: tuple=(); envelope: tuple=(); temporal: tuple=(); domain: str=''
@dataclass(frozen=True)
class Claim:
 proposition: str; context: Context; kind: str='HYPOTHESIS'
 def obj(self): return {'proposition':self.proposition,'context':{'assumptions':self.context.assumptions,'envelope':self.context.envelope,'temporal':self.context.temporal,'domain':self.context.domain},'kind':self.kind}
 @property
 def id(self): return hid(self.obj())
@dataclass(frozen=True)
class Warrant:
 premises: tuple; rule: Rule; backing_hash: str; qualifier: str; rebuttals: tuple; conclusion: str; polarity: str; roots: tuple=()
 def obj(self): return {'premises':self.premises,'rule':self.rule.value,'backing_hash':self.backing_hash,'qualifier':self.qualifier,'rebuttals':self.rebuttals,'conclusion':self.conclusion,'polarity':self.polarity,'roots':self.roots}
 @property
 def id(self): return hid(self.obj())

def overlap(a,b):
 # Empty dimensions are wildcards, not evidence of incompatibility.
 def dim(x,y): return True if not x or not y else bool(set(x)&set(y))
 return dim(a.assumptions,b.assumptions) and dim(a.envelope,b.envelope) and dim(a.temporal,b.temporal) and (not a.domain or not b.domain or a.domain==b.domain)

class Chronicle:
 def __init__(self,domain_id='WN-KS-001'):
  self.domain_id=domain_id; self.events=[]; self.head=sha256(('GENESIS'+domain_id).encode()).hexdigest()
 def append(self,event_type,payload,timestamp):
  ph=hid(payload); prev=self.head
  self.head=sha256((prev+'|'+timestamp+'|'+event_type+'|'+ph).encode()).hexdigest()
  e={'seq':len(self.events),'prev':prev,'timestamp':timestamp,'type':event_type,'payload_hash':ph,'head':self.head}
  self.events.append(e); return e
 def verify(self):
  head=sha256(('GENESIS'+self.domain_id).encode()).hexdigest()
  for i,e in enumerate(self.events):
   if e['seq']!=i or e['prev']!=head: return False
   head=sha256((head+'|'+e['timestamp']+'|'+e['type']+'|'+e['payload_hash']).encode()).hexdigest()
   if e['head']!=head: return False
  return head==self.head

class Store:
 def __init__(self,domain_id='WN-KS-001'):
  self.claims={}; self.warrants={}; self.revoked=set(); self.chronicle=Chronicle(domain_id)
 def add_claim(self,c,timestamp='1970-01-01T00:00:00Z'):
  self.claims[c.id]=c; self.chronicle.append('CLAIM_ADD',c.obj(),timestamp); return c.id
 def add_warrant(self,w,timestamp='1970-01-01T00:00:00Z'):
  if w.rule==Rule.LLM_PROSE_REASONING and w.polarity in ('support','rebut'): raise ValueError('LLM prose cannot operationally promote')
  if w.conclusion not in self.claims: raise KeyError('unknown conclusion')
  if any(p not in self.claims for p in w.premises): raise KeyError('unknown premise')
  self.warrants[w.id]=w; self.chronicle.append('WARRANT_ADD',w.obj(),timestamp); return w.id
 def revoke_warrant(self,wid,timestamp='1970-01-01T00:00:00Z'):
  if wid not in self.warrants: raise KeyError('unknown warrant')
  self.revoked.add(wid); self.chronicle.append('WARRANT_REVOCATION',{'warrant_id':wid},timestamp)
 def dependency_graph(self):
  g=defaultdict(set)
  for wid,w in self.warrants.items():
   if wid in self.revoked: continue
   for p in w.premises: g[p].add(w.conclusion)
  for c in self.claims: g[c]
  return g
 def circular_claims(self):
  g=self.dependency_graph(); idx=0; stack=[]; on=set(); ind={}; low={}; circular=set()
  def visit(v):
   nonlocal idx
   ind[v]=low[v]=idx; idx+=1; stack.append(v); on.add(v)
   for z in sorted(g[v]):
    if z not in ind: visit(z); low[v]=min(low[v],low[z])
    elif z in on: low[v]=min(low[v],ind[z])
   if low[v]==ind[v]:
    comp=[]
    while True:
     z=stack.pop(); on.remove(z); comp.append(z)
     if z==v: break
    if len(comp)>1 or (len(comp)==1 and comp[0] in g[comp[0]]): circular.update(comp)
  for v in sorted(g):
   if v not in ind: visit(v)
  return circular
 def _active_warrants(self,cid):
  circular=self.circular_claims()
  for wid,w in self.warrants.items():
   if wid in self.revoked or w.conclusion!=cid: continue
   # A self-derived/circular warrant cannot bootstrap support. External premise-free warrants remain valid.
   if w.premises and w.conclusion in circular and any(p in circular for p in w.premises): continue
   yield w
 def state(self,cid):
  pos=neg=False
  for w in self._active_warrants(cid):
   # Premises must themselves have operational support; FALSE/NONE premises do not carry a warrant.
   ok=True
   for p in w.premises:
    ps=self.state_nonrecursive(p,set())
    if ps not in (Four.TRUE,Four.BOTH): ok=False; break
   if not ok: continue
   pos |= w.polarity=='support'; neg |= w.polarity=='rebut'
  return Four.BOTH if pos and neg else Four.TRUE if pos else Four.FALSE if neg else Four.NONE
 def state_nonrecursive(self,cid,seen):
  if cid in seen: return Four.NONE
  seen=set(seen); seen.add(cid); pos=neg=False; circular=self.circular_claims()
  for wid,w in self.warrants.items():
   if wid in self.revoked or w.conclusion!=cid: continue
   if w.premises and cid in circular and any(p in circular for p in w.premises): continue
   if all(self.state_nonrecursive(p,seen) in (Four.TRUE,Four.BOTH) for p in w.premises):
    pos |= w.polarity=='support'; neg |= w.polarity=='rebut'
  return Four.BOTH if pos and neg else Four.TRUE if pos else Four.FALSE if neg else Four.NONE
 def provenance_graph(self,cid):
  # Nodes are primitive roots, claims, and warrants. Direction is evidence -> conclusion.
  g=defaultdict(set); roots=set(); reachable_claims={cid}; changed=True
  while changed:
   changed=False
   for wid,w in self.warrants.items():
    if wid in self.revoked or w.conclusion not in reachable_claims: continue
    for r in w.roots: roots.add('R:'+r); g['R:'+r].add('W:'+wid)
    for p in w.premises:
     g['C:'+p].add('W:'+wid)
     if p not in reachable_claims: reachable_claims.add(p); changed=True
    g['W:'+wid].add('C:'+w.conclusion)
  for n in list(g):
   for z in g[n]: g[z]
  return g,roots,'C:'+cid
 def root_rank(self,cid):
  # Max vertex-disjoint primitive-root -> claim paths. Primitive roots themselves have capacity 1,
  # preventing one source from being counted multiple times via derivative branches.
  g,roots,sink=self.provenance_graph(cid)
  if not roots: return 0
  INF=10**6; cap=defaultdict(lambda:defaultdict(int)); S='__S__'; T='__T__'
  nodes=set(g)|{x for vs in g.values() for x in vs}|roots|{sink}
  for v in nodes:
   vin=v+'#i'; vout=v+'#o'; nodecap=1 if v in roots or (v.startswith('W:') and v!=sink) else INF
   cap[vin][vout]+=nodecap
  for u,vs in g.items():
   for v in vs: cap[u+'#o'][v+'#i']+=INF
  for r in roots: cap[S][r+'#i']+=1
  cap[sink+'#o'][T]+=INF
  flow=0
  while True:
   parent={S:None}; q=deque([S])
   while q and T not in parent:
    u=q.popleft()
    for v,c in cap[u].items():
     if c>0 and v not in parent: parent[v]=u; q.append(v)
   if T not in parent: break
   aug=INF; v=T
   while parent[v] is not None: aug=min(aug,cap[parent[v]][v]); v=parent[v]
   v=T
   while parent[v] is not None:
    u=parent[v]; cap[u][v]-=aug; cap[v][u]+=aug; v=u
   flow+=aug
  return flow
 def snapshot(self):
  o={'claims':{k:v.obj() for k,v in sorted(self.claims.items())},'warrants':{k:v.obj() for k,v in sorted(self.warrants.items())},'revoked':sorted(self.revoked),'chronicle':self.chronicle.events,'chronicle_head':self.chronicle.head}
  return hid(o),o
 def verify_integrity(self):
  return self.chronicle.verify() and all(k==v.id for k,v in self.claims.items()) and all(k==v.id for k,v in self.warrants.items())

def authorize(store,cid):
 return 'ELIGIBLE' if store.verify_integrity() and store.state(cid)==Four.TRUE else 'HARD_REJECT'
