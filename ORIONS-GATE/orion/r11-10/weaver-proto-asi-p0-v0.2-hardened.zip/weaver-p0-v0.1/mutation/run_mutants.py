import pathlib,subprocess,tempfile,shutil,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
src=(ROOT/'wnks/model.py').read_text()
mutants={
'MUT-01_ALLOW_BOTH_AUTH':("store.state(cid)==Four.TRUE","store.state(cid) in (Four.TRUE,Four.BOTH)"),
'MUT-02_DISABLE_MINCUT':("return flow\n def snapshot", "return len(self.warrants)\n def snapshot"),
'MUT-03_DISABLE_INTEGRITY':("return self.chronicle.verify() and all(k==v.id for k,v in self.claims.items()) and all(k==v.id for k,v in self.warrants.items())","return True"),
'MUT-04_BYPASS_CONTEXT':("return dim(a.assumptions,b.assumptions) and dim(a.envelope,b.envelope) and dim(a.temporal,b.temporal) and (not a.domain or not b.domain or a.domain==b.domain)","return True"),
}
killed=[]; survived=[]
for name,(old,new) in mutants.items():
 if old not in src: print(name,'INVALID_MUTATION_PATTERN'); survived.append(name); continue
 with tempfile.TemporaryDirectory() as td:
  dst=pathlib.Path(td)/'pkg'; shutil.copytree(ROOT,dst,ignore=shutil.ignore_patterns('MANIFEST.json','WITNESS_ATTESTATION.json','__pycache__'))
  p=dst/'wnks/model.py'; p.write_text(src.replace(old,new,1))
  r=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests'],cwd=dst,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  if r.returncode!=0: killed.append(name); print(name,'KILLED')
  else: survived.append(name); print(name,'SURVIVED')
print(f'MUTATION_SCORE {len(killed)}/{len(mutants)}')
sys.exit(0 if not survived else 1)
