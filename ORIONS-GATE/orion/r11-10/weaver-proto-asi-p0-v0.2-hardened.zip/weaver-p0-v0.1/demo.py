from wnks.model import *
s=Store(); c=Claim('Fence elision is safe',Context(('C11',),('aarch64',),('unbounded',),'concurrency')); cid=s.add_claim(c)
print('initial',s.state(cid).value,cid)
trace=hid({'fixture':'counterexample','status':'EXPECTED_NOT_REPRODUCED'})
w=Warrant((),Rule.LOOM_CONCURRENCY_TRACE,trace,'counterexample',(),cid,'rebut',(trace,)); s.add_warrant(w)
print('after rebuttal',s.state(cid).value,'warrant',w.id)
print('snapshot',s.snapshot()[0])
print('authority','HARD_REJECT' if s.state(cid)!=Four.TRUE else 'ELIGIBLE')
