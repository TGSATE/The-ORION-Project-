# Current Portfolio Snapshot

## Alpha-OmegaLeanTeam

PR #22 is open, draft, mergeable, and green at
`e14019f5c2fc185bb72ec7dae7e13089a3f369ff`.

The candidate closes the bounded technical implementation work for the frozen
v0.6 named-step forward-simulation claim, subject to independent review. It does
not close the independent-reproduction or authority gates.

## Weaver_Os

- PR #65 — Activation Runtime v1:
  open, non-draft, mergeable; head `8db6965aa6341a07828f17bdd0d30ca11caf545b`.
- PR #66 — Crash recovery specification + lattice core:
  open, draft, mergeable; head `b162a7cea43959214bd9e928ea6c9965976cdcc2`.
- PR #67 — P0 portfolio registry freeze:
  open, non-draft, mergeable; head `ab62a5648fccc8a30679d06a5c2504ae262a1c13`.

## Remaining Top-Level Gates

1. Independent review/reproduction of the v0.6 correspondence candidate.
2. Durable recovery implementation and crash campaign beyond the current spec.
3. Stop-first controller host proof on a host with writable delegated cgroup.
4. Unified execution receipts across the promoted stack.
5. Protected promotion sequence through the P0 registry.
6. Preserve W0/O0 and production-withheld posture until evidence actually changes.
