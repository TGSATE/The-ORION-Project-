"""G0 security regression suite: the policy's versioned action allowlist is fail-closed.

These tests check *advisory policy decisions only*. They do not establish
authenticated external approval, OS isolation, or resource-side enforcement.
"""
import copy
from pathlib import Path
import shutil
import sys

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from runtime.policy_engine import PolicyEngine


@pytest.fixture
def engine():
    return PolicyEngine(ROOT)


# Ten distinct denial cases, including the original vulnerable O4/True combination.
@pytest.mark.parametrize("agent_authority", ["O0", "O1", "O2", "O3", "O4"])
@pytest.mark.parametrize("user_authorized", [False, True])
def test_unknown_action_always_denied(engine, agent_authority, user_authorized):
    d = engine.evaluate(
        action_class="teleport_money",
        agent_authority=agent_authority,
        user_authorized=user_authorized,
    )
    assert d.allowed is False
    assert d.required_authority == "NONE"


@pytest.mark.parametrize("action_class", [
    "", " ", "READ", "Read", "read ", " read", "read\\n",
    "read\\x00", "rｅad", "write-external", "writeExternal",
    "execute_external_side_effect ", "teleport_money",
])
def test_noncanonical_and_aliased_action_names_denied(engine, action_class):
    assert engine.evaluate(
        action_class=action_class,
        agent_authority="O4",
        user_authorized=True,
    ).allowed is False


@pytest.mark.parametrize("action_class", [None, 0, True, [], {}, b"read"])
def test_malformed_action_type_denied_without_crash(engine, action_class):
    assert engine.evaluate(
        action_class=action_class,
        agent_authority="O4",
        user_authorized=True,
    ).allowed is False


@pytest.mark.parametrize("agent_authority", [None, 5, [], {}, True, "o4", "O5"])
def test_invalid_authority_denied_without_crash(engine, agent_authority):
    assert engine.evaluate(
        action_class="read",
        agent_authority=agent_authority,
        user_authorized=True,
    ).allowed is False


@pytest.mark.parametrize("user_authorized", [1, 0, "true", "false", None, [], {}])
def test_nonboolean_approval_signal_denied(engine, user_authorized):
    assert engine.evaluate(
        action_class="write_external",
        agent_authority="O4",
        user_authorized=user_authorized,
    ).allowed is False


@pytest.mark.parametrize("agent_authority,user_authorized", [
    ("O0", False), ("O4", False), ("O4", True),
])
def test_unknown_action_denial_precedes_authority_or_approval(engine, agent_authority, user_authorized):
    d = engine.evaluate(action_class="teleport_money",
                        agent_authority=agent_authority,
                        user_authorized=user_authorized)
    assert d.allowed is False
    assert "unknown" in d.reason.lower()


def copy_policy_fixture(tmp_path):
    (tmp_path / "policy").mkdir()
    shutil.copy(ROOT / "policy/authority.yaml", tmp_path / "policy/authority.yaml")
    shutil.copy(ROOT / "constitution.yaml", tmp_path / "constitution.yaml")
    src = ROOT / "policy/tool_controls.yaml"
    cfg = yaml.safe_load(src.read_text())
    return cfg


@pytest.mark.parametrize("mode", ["wrong_version", "missing_version", "invalid_requirement",
                                    "missing_action_table", "noncanonical_allowlist_key",
                                    "unhashable_requirement"])
def test_invalid_allowlist_configuration_refused_at_startup(tmp_path, mode):
    cfg = copy_policy_fixture(tmp_path)
    if mode == "wrong_version":
        cfg["version"] = "0.9.0"
    elif mode == "missing_version":
        del cfg["version"]
    elif mode == "invalid_requirement":
        cfg["tool_action_classes"]["read"]["required_authority"] = "O999"
    elif mode == "missing_action_table":
        del cfg["tool_action_classes"]
    elif mode == "unhashable_requirement":
        cfg["tool_action_classes"]["read"]["required_authority"] = []
    elif mode == "noncanonical_allowlist_key":
        cfg["tool_action_classes"]["Read"] = {"required_authority": "O0"}
    (tmp_path / "policy/tool_controls.yaml").write_text(yaml.safe_dump(cfg))
    with pytest.raises(ValueError):
        PolicyEngine(tmp_path)


def test_allowlisted_action_binds_exact_name_and_scope_metadata(engine):
    d = engine.evaluate(action_class="write_external",
                        agent_authority="O2", user_authorized=True)
    assert d.allowed is True
    assert d.action_class == "write_external"
    assert d.required_authority == "O2"
    assert engine.required_authority_for("teleport_money") is None

@pytest.mark.parametrize("malformed", [None, 1, "false", {}])
def test_malformed_constitutional_violation_fails_closed(engine, malformed):
    d = engine.evaluate(action_class="read", agent_authority="O4",
                        user_authorized=True, constitutional_violation=malformed)
    assert d.allowed is False


def test_mutating_loaded_yaml_cannot_expand_pinned_allowlist(engine):
    engine.tools["tool_action_classes"]["teleport_money"] = {
        "required_authority": "O0", "default_reversibility": True
    }
    d = engine.evaluate(action_class="teleport_money",
                        agent_authority="O4", user_authorized=True)
    assert d.allowed is False
