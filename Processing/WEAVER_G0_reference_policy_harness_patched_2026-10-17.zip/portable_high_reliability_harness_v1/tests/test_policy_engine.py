import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from runtime.policy_engine import PolicyEngine, promote_evidence

class PolicyEngineTests(unittest.TestCase):
    def setUp(self):
        self.engine = PolicyEngine(ROOT)

    def test_o0_can_read(self):
        d = self.engine.evaluate(
            action_class="read",
            agent_authority="O0",
            user_authorized=False
        )
        self.assertTrue(d.allowed)

    def test_o0_cannot_write_external(self):
        d = self.engine.evaluate(
            action_class="write_external",
            agent_authority="O0",
            user_authorized=True
        )
        self.assertFalse(d.allowed)

    def test_o2_external_write_requires_user_authorization(self):
        d = self.engine.evaluate(
            action_class="write_external",
            agent_authority="O2",
            user_authorized=False
        )
        self.assertFalse(d.allowed)

    def test_o2_external_write_with_authorization(self):
        d = self.engine.evaluate(
            action_class="write_external",
            agent_authority="O2",
            user_authorized=True
        )
        self.assertTrue(d.allowed)

    def test_constitution_overrides_authority(self):
        d = self.engine.evaluate(
            action_class="read",
            agent_authority="O4",
            user_authorized=True,
            constitutional_violation=True
        )
        self.assertFalse(d.allowed)

    def test_unknown_action_fails_closed(self):
        d = self.engine.evaluate(
            action_class="teleport_money",
            agent_authority="O4",
            user_authorized=False
        )
        self.assertFalse(d.allowed)

    def test_evidence_promotion_does_not_change_authority(self):
        claim = {"evidence_level":"E1", "authority_state":"O0"}
        promoted = promote_evidence(claim, "E4")
        self.assertEqual(promoted["evidence_level"], "E4")
        self.assertEqual(promoted["authority_state"], "O0")

if __name__ == "__main__":
    unittest.main()
