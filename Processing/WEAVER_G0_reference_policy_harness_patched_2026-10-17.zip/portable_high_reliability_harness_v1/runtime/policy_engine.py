"""Reference policy engine: fail-closed action admission, *not* an effect executor.

Inputs `agent_authority` and `user_authorized` are caller-provided assertions.
A protected resource MUST independently authenticate and enforce them before commit.
"""
from dataclasses import dataclass, asdict
from pathlib import Path
from types import MappingProxyType
from typing import Optional, Dict, Any
import re
import yaml

AUTHORITY_ORDER = {"O0": 0, "O1": 1, "O2": 2, "O3": 3, "O4": 4}
SUPPORTED_TOOL_POLICY_VERSION = "1.0.0"
ACTION_NAME = re.compile(r"[a-z][a-z0-9_]*", re.ASCII)


@dataclass
class Decision:
    allowed: bool
    action_class: str
    agent_authority: str
    required_authority: str
    reason: str
    reversible: Any
    user_authorized: bool
    constitutional_violation: bool

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class PolicyEngine:
    def __init__(self, root: Optional[Path] = None):
        self.root = Path(root) if root else Path(__file__).resolve().parents[1]
        self.authority = yaml.safe_load(
            (self.root / "policy/authority.yaml").read_text(encoding="utf-8")
        )
        self.tools = yaml.safe_load(
            (self.root / "policy/tool_controls.yaml").read_text(encoding="utf-8")
        )
        self.constitution = yaml.safe_load(
            (self.root / "constitution.yaml").read_text(encoding="utf-8")
        )

        # Pin the allowlist contract; malformed/downgraded policy must NOT start.
        if not isinstance(self.tools, dict) or self.tools.get("version") != SUPPORTED_TOOL_POLICY_VERSION:
            raise ValueError("Unsupported or missing tool action policy version.")
        classes = self.tools.get("tool_action_classes")
        if not isinstance(classes, dict) or not classes:
            raise ValueError("Tool action allowlist is missing or malformed.")

        pinned = {}
        for name, meta in classes.items():
            if not isinstance(name, str) or not ACTION_NAME.fullmatch(name):
                raise ValueError("Tool action allowlist contains a noncanonical action name.")
            if not isinstance(meta, dict):
                raise ValueError("Tool action metadata must be an object.")
            level = meta.get("required_authority")
            if not isinstance(level, str) or level not in AUTHORITY_ORDER:
                raise ValueError("Tool action has an invalid required authority.")
            pinned[name] = MappingProxyType(dict(meta))
        # Protect the evaluated configuration from subsequent changes to self.tools.
        self.allowed_actions = MappingProxyType(pinned)

    def required_authority_for(self, action_class: str) -> Optional[str]:
        if not isinstance(action_class, str):
            return None
        meta = self.allowed_actions.get(action_class)
        return meta["required_authority"] if meta is not None else None

    def evaluate(
        self,
        *,
        action_class: str,
        agent_authority: str,
        user_authorized: bool,
        constitutional_violation: bool = False,
    ) -> Decision:
        action_display = action_class if isinstance(action_class, str) else "<invalid-action-class>"
        authority_display = agent_authority if isinstance(agent_authority, str) else "<invalid-authority>"
        approval_is_boolean = type(user_authorized) is bool
        # Preserve the raw signal in Decision for audit, but it is never treated
        # as authenticated proof of permission.
        def deny(required: str, reason: str, reversible: Any = "unknown") -> Decision:
            return Decision(False, action_display, authority_display, required,
                            reason, reversible, user_authorized,
                            constitutional_violation is True)

        # Strict class allowlist BEFORE any authority or approval checks.
        # Neither O4 nor `user_authorized=True` can admit unknown actions.
        if not isinstance(action_class, str) or action_class not in self.allowed_actions:
            return deny("NONE", "Denied: unknown action class (not in versioned allowlist).")

        required = self.allowed_actions[action_class]["required_authority"]
        reversible = self.allowed_actions[action_class].get("default_reversibility", "unknown")
        if not isinstance(agent_authority, str) or agent_authority not in AUTHORITY_ORDER:
            return deny(required, "Denied: unknown agent authority.", reversible)
        if not approval_is_boolean:
            return deny(required, "Denied: malformed user authorization signal.", reversible)
        if type(constitutional_violation) is not bool:
            return deny(required, "Denied: malformed constitutional violation signal.", reversible)
        if constitutional_violation:
            return deny(required, "Denied: constitutional rule would be violated.", reversible)
        if AUTHORITY_ORDER[agent_authority] < AUTHORITY_ORDER[required]:
            return deny(required, "Denied: insufficient operational authority.", reversible)
        # Provisional policy check only; trusted human approval and its scope
        # require a separate authenticated mechanism at the resource boundary.
        if AUTHORITY_ORDER[required] >= AUTHORITY_ORDER["O2"] and not user_authorized:
            return deny(required, "Denied: explicit user authorization required.", reversible)

        return Decision(True, action_class, agent_authority, required,
                        "Permitted by reference policy only; resource-side authorization required.",
                        reversible, user_authorized, False)


def promote_evidence(record: Dict[str, Any], new_level: str) -> Dict[str, Any]:
    """Evidence promotion does not modify authority_state."""
    allowed = {"E0", "E1", "E2", "E3", "E4"}
    if new_level not in allowed:
        raise ValueError(f"Invalid evidence level: {new_level}")
    out = dict(record)
    out["evidence_level"] = new_level
    return out
