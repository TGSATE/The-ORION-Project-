# Changelog

## 1.0.1-g0-local — 2026-10-17
- Fix fail-open for action classes absent from versioned tool allowlist.
- Fail closed on malformed action classes, authority and approval types.
- Pin supported tool policy version to 1.0.0 and validate allowlist entries at startup.
- Snapshot allowlist configuration to prevent simple subsequent YAML-data mutation.
- Added G0 security regression suite; reference policy only, not resource-side assurance.
- Preserved previous 1.0.0 tests and separate E2/W0/O0 posture.

## 1.0.0
- Established six-layer architecture.
- Canonicalized constitutional separation laws.
- Added independent evidence and authority ledgers.
- Added T0-T4 rigor classification.
- Added execution routing and problem-validity preflight.
- Added tool trust classes and authority admission rules.
- Added claim/evaluation/receipt/trace/incident schemas.
- Added sample executable-evaluation specification.
- Added provenance/standards crosswalk.
- Added deterministic prompt generator and harness validator.

- Added minimal fail-closed runtime policy engine and unit tests.
