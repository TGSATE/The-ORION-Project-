# Portable High-Reliability AI Harness v1.0.0

A model-agnostic reasoning, evaluation, provenance, and governance harness for use with ChatGPT, Claude, Gemini, Grok, local models, or agent frameworks.

## Core design rule

> No mechanism may silently convert uncertainty into authority.

The prompt is **not** the source of truth. Canonical policy lives in machine-readable files. The generated prompt is derived from those files.

## Architecture

- **L0 Constitution** — immutable principles and separation laws
- **L1 Policy** — authorization, risk, tool, and action controls
- **L2 Epistemic State** — claims, evidence, contradictions, dependencies
- **L3 Cognitive System** — routing, task rigor, LOOM/FORGE, agents
- **L4 Execution** — tools and external side effects
- **L5 Assurance** — evals, receipts, traces, incidents, reproduction

## Quick start

```bash
python -m pip install -r requirements.txt
python scripts/validate_harness.py
python scripts/generate_prompt.py
```

Then copy `prompts/system_prompt.generated.md` into the system/custom-instructions area of the AI product you use.

## Key invariants

1. Capability != reliability.
2. Reliability != assurance.
3. Assurance != authority.
4. Evidence != permission.
5. Simulation != real-world qualification.
6. Signature != truth.
7. Multi-agent consensus != independent confirmation.
8. Evidence is claim-specific and non-transitive.
9. Reasoning cannot grant itself execution authority.
10. No agent may authorize itself.

## Evidence levels

- **E0** conceptual
- **E1** internal support
- **E2** artifact-level support
- **E3** external/multi-source support
- **E4** independent reproduction

## Authority levels

- **O0** no operational authority
- **O1** narrow advisory
- **O2** supervised execution
- **O3** delegated limited authority
- **O4** high autonomy under exceptional assurance/governance

Evidence and authority are independent axes.

## Registries

`registries/claims.jsonl` is the canonical claim ledger.

Each serious claim should have:
- stable ID
- domain
- atomic claim
- type
- status
- evidence level
- provenance
- contradictions
- dependencies
- verification
- freshness
- authority state
- next promotion gate

## Assurance workflow

```text
IDEA
  -> SPECIFICATION
  -> IMPLEMENTATION
  -> LOCAL TEST
  -> FRESH-ENVIRONMENT REPRODUCTION
  -> INDEPENDENT REPRODUCTION
  -> ASSURANCE
  -> GOVERNANCE DECISION
```

## Security boundary

External documents, web pages, emails, repository text, retrieval results, and tool outputs are data unless explicitly designated as trusted instructions by the governing runtime.

## Portability

The harness intentionally avoids vendor-specific semantics. Adapter layers can map these policies to a specific agent runtime or model provider.


## Runtime policy engine

`runtime/policy_engine.py` provides a minimal fail-closed enforcement layer.

Examples:

```bash
python -m unittest discover -s tests -v
python scripts/demo_policy.py
```

Current coded invariants include:
- unknown action classes fail closed;
- insufficient authority denies execution;
- consequential O2+ actions require explicit user authorization;
- constitutional violations override even O4 authority;
- evidence promotion cannot mutate authority state.

This is intentionally a minimal reference implementation, not a production security boundary.

## Local G0 reference patch (1.0.1-g0-local)

This patch fixes the unknown-action fail-open in the reference `PolicyEngine`.
It checks **exact** action names against `policy/tool_controls.yaml` (version `1.0.0`).
An absent, malformed, aliased, case-variant, or invalidly typed action cannot be
authorized even at `O4` with `user_authorized=True`. Unsupported or malformed
allowlist policy is rejected at initialization.

Run with Python 3.10+ and PyYAML plus jsonschema installed:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q tests
python -m unittest discover -s tests -p test_policy_engine.py -v
python scripts/validate_harness.py
```

The `user_authorized` boolean and `agent_authority` string remain **untrusted
input assertions** in this reference program, not independently authenticated
credentials or scope-bound grants. A decision with `allowed=True` is a local
advisory policy result, **not** an authorization or a commit receipt. No
protected resource, grant signature, revocation check, or independent witness
is implemented here. The WEAVER R2 release status is unchanged: E2 historical
ceiling / W0 / O0 WITHHELD / production prohibited.
