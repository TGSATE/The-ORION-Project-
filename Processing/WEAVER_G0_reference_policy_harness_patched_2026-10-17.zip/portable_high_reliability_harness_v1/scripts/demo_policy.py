from pathlib import Path
import sys, json

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))

from runtime.policy_engine import PolicyEngine

engine = PolicyEngine(root)

cases = [
    dict(action_class="read", agent_authority="O0", user_authorized=False),
    dict(action_class="write_external", agent_authority="O0", user_authorized=True),
    dict(action_class="write_external", agent_authority="O2", user_authorized=False),
    dict(action_class="write_external", agent_authority="O2", user_authorized=True),
]

for case in cases:
    decision = engine.evaluate(**case)
    print(json.dumps(decision.to_dict(), indent=2))
