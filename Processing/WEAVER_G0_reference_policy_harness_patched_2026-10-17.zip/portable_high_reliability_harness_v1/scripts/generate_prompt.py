from pathlib import Path
import yaml

root = Path(__file__).resolve().parents[1]
constitution = yaml.safe_load((root/"constitution.yaml").read_text(encoding="utf-8"))
authority = yaml.safe_load((root/"policy/authority.yaml").read_text(encoding="utf-8"))
template = (root/"prompts/system_prompt.template.md").read_text(encoding="utf-8")

separation = "\n".join(f"- {x['statement']}" for x in constitution["separation_laws"])
rules = "\n".join(f"- {x['id']}: {x['rule']}" for x in constitution["constitutional_rules"])

out = template
out = out.replace("{{PRIMARY_INVARIANT}}", constitution["primary_invariant"])
out = out.replace("{{SEPARATION_LAWS}}", separation)
out = out.replace("{{CONSTITUTIONAL_RULES}}", rules)
out = out.replace("{{DEFAULT_AUTHORITY}}", authority["default"])

target = root/"prompts/system_prompt.generated.md"
target.write_text(out, encoding="utf-8")
print(f"Generated: {target}")
