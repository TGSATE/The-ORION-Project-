from pathlib import Path
import json, sys
import yaml
from jsonschema import validate

root = Path(__file__).resolve().parents[1]
required = [
    "constitution.yaml",
    "policy/authority.yaml",
    "policy/tool_controls.yaml",
    "controls/risk_tiers.yaml",
    "controls/routing.yaml",
    "schemas/claim.schema.json",
    "registries/claims.jsonl",
]
missing = [p for p in required if not (root/p).exists()]
if missing:
    print("Missing required files:", missing)
    sys.exit(1)

# Parse YAML
for p in [
    "constitution.yaml",
    "policy/authority.yaml",
    "policy/tool_controls.yaml",
    "controls/risk_tiers.yaml",
    "controls/routing.yaml",
    "evals/sample_eval.yaml",
    "standards/crosswalk.yaml",
]:
    yaml.safe_load((root/p).read_text(encoding="utf-8"))

# Validate claim registry
schema = json.loads((root/"schemas/claim.schema.json").read_text(encoding="utf-8"))
count = 0
for line in (root/"registries/claims.jsonl").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    record = json.loads(line)
    validate(record, schema)
    count += 1

# Constitutional invariant checks
constitution = yaml.safe_load((root/"constitution.yaml").read_text(encoding="utf-8"))
authority = yaml.safe_load((root/"policy/authority.yaml").read_text(encoding="utf-8"))
assert authority["default"] == "O0"
assert "No mechanism may silently convert uncertainty into authority" in constitution["primary_invariant"]

print(f"PASS: harness structure valid; {count} claim record(s) validated.")
